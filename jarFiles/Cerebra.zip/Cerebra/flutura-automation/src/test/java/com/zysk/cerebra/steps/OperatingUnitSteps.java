package com.zysk.cerebra.steps;


import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertTrue;

import org.assertj.core.api.SoftAssertions;

import com.zysk.cerebra.csv_reader.CSVHelper;
import com.zysk.cerebra.csv_reader.OperatingUnitCSVReader;
import com.zysk.cerebra.pages.OperatingUnitPage;

import au.com.bytecode.opencsv.CSVReader;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class OperatingUnitSteps {

OperatingUnitPage operatingUnitPage;
	
	/********************************************************************
   	* Description: Select the Operating Unit
   	* Status: Completed
   	********************************************************************/
	@When("^I click on Operating Unit$")
	public void whenIClickOnOperatingUnit()
	{
		operatingUnitPage.selectOperatingUnit();
	}
	
	/********************************************************************
   	* Description: Customer list should be displayed
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the customer list$")
	public void thenCustomerListWillBeDisplayed()
	{
		String expUrl = OperatingUnitCSVReader.getOUUrl();
		assertTrue("Customer page with all the elements is not displayed",operatingUnitPage.verifyCustomerPage(expUrl));
	}
	
	/********************************************************************
   	* Description: Select a customer
   	* Status: Completed
   	********************************************************************/
	@When("^I select customer$")
	public void whenISelectCustomer()
	{
		String customer = OperatingUnitCSVReader.getCustomer();
		operatingUnitPage.selectCustomer(customer);
	}
	
	/********************************************************************
   	* Description: Verify Model list
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the model list$")
	public void thenModelListWillBeDisplayed()
	{
		String modelurl = OperatingUnitCSVReader.getModelsUrl();
		assertTrue("Model page is not displayed with all the elements",operatingUnitPage.verifyModelList(modelurl));
	}
	
	/********************************************************************
   	* Description: Select a customer to add operating unit
   	* Status: Completed
   	********************************************************************/
	@When("^I select customer to add operating unit$")
	public void whenISelectCustomerToAddOperatingUnit()
	{
		String customer = OperatingUnitCSVReader.getCustomerforOperatingUnit();
		operatingUnitPage.selectCustomer(customer);
	}
	
	/********************************************************************
   	* Description: Select a model to add operating unit
   	* Status: Completed
   	********************************************************************/
	@When("^I select Model to add operating unit$")
	public void whenISelectModelToAddOperatingUnit()
	{
		String Model = OperatingUnitCSVReader.getModelToAddOperatingUnit();
		operatingUnitPage.selectModelToAddOperatingUnit(Model);
	}
	
	/********************************************************************
   	* Description: Add operating unit
   	* Status: Completed
   	********************************************************************/
	@When("^I add operating unit$")
	public void whenAddOperatingUnit()
	{
		String operatingUnitName = OperatingUnitCSVReader.getOUNameToAddOperatingUnit();
		String operatingUnitNumber = OperatingUnitCSVReader.getOUNumberToAddOperatingUnit();
		String date = OperatingUnitCSVReader.getManufacturedDateForOperatingUnit();
		String gateway = OperatingUnitCSVReader.getGatewayForOperatingUnit();
		operatingUnitPage.addOperatingUnit(operatingUnitName,operatingUnitNumber,date,gateway);
	}
	
	/********************************************************************
   	* Description: Verify the added operating unit
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the operating unit gets added$")
	public void thenIcanSeeOperatingUnitGetsAdded()
	{
		String operatingUnitName = OperatingUnitCSVReader.getOUNameToAddOperatingUnit();
		assertTrue("Operating is not displayed",operatingUnitPage.verifyOperatingUnit(operatingUnitName));
	}
	
	/********************************************************************
   	* Description: Click on operating unit
   	* Status: Completed
   	********************************************************************/
	@When("^I click on operating unit$")
	public void selectOperatingUnit()
	{
		String operatingUnit = OperatingUnitCSVReader.getOUNameToAddOperatingUnit();
		operatingUnitPage.selectOperatingUnitToViewTheDetails(operatingUnit);
	}
	
	/********************************************************************
   	* Description: Verify operating unit details
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the operating unit details$")
	public void verifyOperatingetails()
	{
		String operatingUnitName = OperatingUnitCSVReader.getOUNameToAddOperatingUnit();
		String operatingUnitNumber = OperatingUnitCSVReader.getOUNumberToAddOperatingUnit();
		String manuDate = OperatingUnitCSVReader.getManufacturedDateForOperatingUnit();
		assertTrue("Operating unit details is not proper",operatingUnitPage.verifyOperatingUnitDetailsPage(operatingUnitName,operatingUnitNumber,manuDate));
	}
	
	/********************************************************************
   	* Description: Select a customer to add subsbsytem to operating unit
   	* Status: Completed
   	********************************************************************/
	@When("^I select customer to add subsystem to operating unit$")
	public void whenISelectCustomerToAddSubsystemToOperatingUnit()
	{
		String customer = OperatingUnitCSVReader.getCustomerToAddSubsystem();
		operatingUnitPage.selectCustomer(customer);
	}
	
	/********************************************************************
   	* Description: Select a model to add subsystem to operating unit
   	* Status: Completed
   	********************************************************************/
	@When("^I select Model to add subsystem to operating unit$")
	public void whenISelectModelToAddSubsystemToOperatingUnit()
	{
		String Model = OperatingUnitCSVReader.getModelToAddSubsystem();
		operatingUnitPage.selectModelToAddOperatingUnit(Model);
	}
	
	/********************************************************************
   	* Description: Add subsystem to Operating Unit
   	* Status: Completed
   	********************************************************************/
	@When("^I add subssystem$")
	public void addSubsystem()
	{
		String parentUnit = OperatingUnitCSVReader.getOperatingUnitToAddSubsystem();
		String childModel = OperatingUnitCSVReader.getModelToAddAsSubsystem();
		String gatewaySelection = OperatingUnitCSVReader.getGatewayForOperatingUnit();
		String count = OperatingUnitCSVReader.getCountOfSubsystem();
		operatingUnitPage.addSubsystemForOperatinUnit(parentUnit,childModel,count,gatewaySelection);
	}
	
	/********************************************************************
   	* Description: Verify the added subsystem to the Operating Unit
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see subsystem gets added$")
	public void thenSusbystemWillBeAdded()
	{
		String childModel = OperatingUnitCSVReader.getModelToAddAsSubsystem();
		assertTrue("Subystem is not displayed",operatingUnitPage.verifyAddedOperatingUnit(childModel));
	}
	
	/********************************************************************
   	* Description: Select a customer to reassign operating unit to another customer
   	* Status: Completed
   	********************************************************************/
	@When("^I select customer to reassign operating unit to another customer$")
	public void whenISelectCustomerToReassignOperatingUnit()
	{
		String customer = OperatingUnitCSVReader.getCustomerToReassignOperatingUnitToAnotherCustomer();
		operatingUnitPage.selectCustomer(customer);
	}
	
	/********************************************************************
   	* Description: Select a model to reassign operating unit to another customer
   	* Status: Completed
   	********************************************************************/
	@When("^I select Model to reassign operating unit to another customer$")
	public void whenISelectModelToReassignOperatingUnit()
	{
		String Model = OperatingUnitCSVReader.getModelToReassignOperatingUnitToAnotherCustomer();
		operatingUnitPage.selectModelToAddOperatingUnit(Model);
	}
	
	/********************************************************************
   	* Description: Reassign operating unit to another customer
   	* Status: Completed
   	********************************************************************/
	@When("^I reassign operating unit to another customer$")
	public void whenIReassignOUtoAnotherCustomer()
	{
		String operatingUnit = OperatingUnitCSVReader.getOperatingUnitToReassign();
		String customer = OperatingUnitCSVReader.getcustomerToWhichOperatingUnitIsReassigned();
		operatingUnitPage.reassignOperatingUnitToAnotherCustomer(operatingUnit, customer);
	}
	
	/********************************************************************
   	* Description: Operating Unit should be reassigned to customer
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the operating unit for the added customer$")
	public void thenOperatingUnitForWillBeAddToAnotherCustomer()
	{
		String customer = OperatingUnitCSVReader.getcustomerToWhichOperatingUnitIsReassigned();
		String Model = OperatingUnitCSVReader.getModelToReassignOperatingUnitToAnotherCustomer();
		String operatingUnit = OperatingUnitCSVReader.getOperatingUnitToReassign();
		assertTrue("Assigned operating unit is not displayed in the assigned customer",operatingUnitPage.verifyReassignedOperatingUnit(customer,Model,operatingUnit));
	}
	
	/********************************************************************
   	* Description: Select a customer to add subsystem to the operating unit with count>1
   	* Status: Completed
   	********************************************************************/
	@When("^I select customer to add subsystem to operating unit with count>1$")
	public void whenISelectCustomerToAddSubsystemToOperatingUnitWithCountGreaterThanOne()
	{
		String customer = OperatingUnitCSVReader.getCustomerToAddSubsystemWithCountMoreThan1();
		operatingUnitPage.selectCustomer(customer);
	}
	
	/********************************************************************
   	* Description: Select a model to add subsystem to the operating unit with count>1
   	* Status: Completed
   	********************************************************************/
	@When("^I select Model to add subsystem to operating unit with count>1$")
	public void whenISelectModelToAddSubsystemToOperatingUnitWithCountGreaterThanOne()
	{
		String Model = OperatingUnitCSVReader.getModelToAddSubsystemWithCountMoreThan1();
		operatingUnitPage.selectModelToAddOperatingUnit(Model);
	}
	
	/********************************************************************
   	* Description: Add subsystem with count>1
   	* Status: Completed
   	********************************************************************/
	@When("^I add subssystem with count >1$")
	public void addSubysytemWithCountMoreThanOne()
	{
		String parentUnit = OperatingUnitCSVReader.getOperatingUnitToAddSubsystemWithCountMoreThan1();
		String childModel = OperatingUnitCSVReader.getModelToAddAsSubsystemWithCountMoreThan1();
		String count = OperatingUnitCSVReader.getCountOfSubsystemToAddSubsystemWithCountMoreThan1();
		String gatewaySelection = OperatingUnitCSVReader.getGatewayToAddSubsystemWithCountMoreThan1();
		operatingUnitPage.addSubsystemForOperatinUnit(parentUnit,childModel,count,gatewaySelection);
	}
	
	/********************************************************************
   	* Description: Subsystem will be displayed 
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see subsystem gets added with count>1$")
	public void verifyTheAddSubsystemWithCountMoreThanOne()
	{
		String childModel = OperatingUnitCSVReader.getModelToAddAsSubsystemWithCountMoreThan1();
		assertTrue("Subsystem is not added as per count",operatingUnitPage.verifyAddedOperatingUnit(childModel));
	}
	
	/********************************************************************
   	* Description: Select a customer to edit the operating unit details
   	* Status: Completed
   	********************************************************************/
	@When("^I select customer to edit the operating unit$")
	public void whenISelectCustomerToEditOperatingUnit()
	{
		String customer = OperatingUnitCSVReader.getCustomerToUpdateOperatingUnit();
		operatingUnitPage.selectCustomer(customer);
	}
	
	/********************************************************************
   	* Description: Select a model to edit operating unit 
   	* Status: Completed
   	********************************************************************/
	@When("^I select Model to edit the operating unit")
	public void whenISelectModelToEditOperatingUnit()
	{
		String Model = OperatingUnitCSVReader.getModelToUpdateOperatingUnit();
		operatingUnitPage.selectModelToAddOperatingUnit(Model);
	}
	
	/********************************************************************
   	* Description: Edit operating unit 
   	* Status: Completed
   	********************************************************************/
	@When("^I edit the operating unit details$")
	public void whenIEditOperatingUnit()
	{
		String OUToEdit = OperatingUnitCSVReader.getOperatingUnitToEdit();
		String updateOUName = OperatingUnitCSVReader.getUpdatedOpertingUnitName();
		String updateOUNumber = OperatingUnitCSVReader.getUpdatedOpertingUnitNumber();
		String manuDate = OperatingUnitCSVReader.getManufacturedDatetOUpdateOperatingUnit();
		String deployDate = OperatingUnitCSVReader.getDeploymentDatetoUpdateOperatingUnit();
		String updateGateway = OperatingUnitCSVReader.getGatewayToUpdate();
		operatingUnitPage.updateOperatingUnit(OUToEdit,updateOUName,updateOUNumber,manuDate,deployDate,updateGateway);
	}
	
	/********************************************************************
   	* Description: Verify the edited operating unit 
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the operating unit gets edited$")
	public void thenIcanSeetheOperatingUnitgetsEdited()
	{
		String updatedOUName = OperatingUnitCSVReader.getUpdatedOpertingUnitName();
		assertTrue("Updated operating unit is not displayed in the list",operatingUnitPage.verifyUpdatedOperatingUnit(updatedOUName));
	}
	
	/********************************************************************
   	* Description: Select a customer to verify the operating unit details
   	* Status: Completed
   	********************************************************************/
	@When("^I select customer to verify the operating unit details$")
	public void whenISelectCustomerToVerifyOperatingUnitDetails()
	{
		String customer = OperatingUnitCSVReader.getCustomerToAddSubsystemWithCountMoreThan1();
		operatingUnitPage.selectCustomer(customer);
	}
	
	/********************************************************************
   	* Description: Select a model to verify the operating unit details
   	* Status: Completed
   	********************************************************************/
	@When("^I select Model to verify the operating unit details$")
	public void whenISelectModelToVerifyOperatingUnitDetails()
	{
		String Model = OperatingUnitCSVReader.getModelToAddSubsystemWithCountMoreThan1();
		operatingUnitPage.selectModelToAddOperatingUnit(Model);
	}
	
	/********************************************************************
   	* Description: Select customer to disable operating unit
   	* Status: Completed
   	********************************************************************/
	@When("^I select customer to disable operating unit$")
	public void selectCustomerToDisableOperatingUnit()
	{
		String customer = OperatingUnitCSVReader.getCustomerToDisableEnableOperatingUnit();
		operatingUnitPage.selectCustomer(customer);
	}
	
	/********************************************************************
   	* Description: Select model to disable operating unit
   	* Status: Completed
   	********************************************************************/
	@When("^I select Model to disable operating unit$")
	public void selectModelToDisableOperatingUnit()
	{
		String Model = OperatingUnitCSVReader.getModelToDisableEnableOperatingUnit();
		operatingUnitPage.selectModelToAddOperatingUnit(Model);
	}
	
	/********************************************************************
   	* Description: Disable operating unit
   	* Status: Completed
   	********************************************************************/
	@When("^I disable the operating unit$")
	public void disableOperatingUnit()
	{
		String operatingUnit = OperatingUnitCSVReader.getOperatingUnitToDisableEnableOperatingUnit();
		operatingUnitPage.disableOperatingUnit(operatingUnit);
	}
	
	/********************************************************************
   	* Description: Verify disabled operating unit
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the operating unit gets disabled$")
	public void verifyDisabledOperatingUnit()
	{
		String operatingUnit = OperatingUnitCSVReader.getOperatingUnitToDisableEnableOperatingUnit();
		assertTrue("Operating unit is not disabled",operatingUnitPage.verifyDisabledOperatingUnit(operatingUnit));
	}
	
	/********************************************************************
   	* Description: Select customer to enable operating unit
   	* Status: Completed
   	********************************************************************/
	@When("^I select customer to enable operating unit$")
	public void selectCustomerToEnableOperatingUnit()
	{
		String customer = OperatingUnitCSVReader.getCustomerToDisableEnableOperatingUnit();
		operatingUnitPage.selectCustomer(customer);
	}
	
	/********************************************************************
   	* Description: Select model to enable operating unit
   	* Status: Completed
   	********************************************************************/
	@When("^I select Model to enable operating unit$")
	public void selectModelToEnableOperatingUnit()
	{
		String Model = OperatingUnitCSVReader.getModelToDisableEnableOperatingUnit();
		operatingUnitPage.selectModelToAddOperatingUnit(Model);
	}
	
	/********************************************************************
   	* Description: Enable operating unit
   	* Status: Completed
   	********************************************************************/
	@When("^I enable the operating unit$")
	public void enableOperatingUnit()
	{
		String operatingUnit = OperatingUnitCSVReader.getOperatingUnitToDisableEnableOperatingUnit();
		operatingUnitPage.enableOperatingUnit(operatingUnit);
	}
	
	/********************************************************************
   	* Description: Verify enabled operating unit
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the operating unit gets enabled$")
	public void verifyEnabledOperatingUnit()
	{
		String operatingUnit = OperatingUnitCSVReader.getOperatingUnitToDisableEnableOperatingUnit();
		assertTrue("Operating unit is not getting enabled",operatingUnitPage.verifyEnabledOperatingUnit(operatingUnit));
	}
	
	/********************************************************************
   	* Description: Select customer to delete operating unit
   	* Status: Completed
   	********************************************************************/
	@When("^I select customer to delete the operating unit$")
	public void selectCustomerToDeleteOperatingUnit()
	{
		String customer = OperatingUnitCSVReader.getCustomerToDeleteOperatingUnit();
		operatingUnitPage.selectCustomer(customer);
	}
	
	/********************************************************************
   	* Description: Select model to enable operating unit
   	* Status: Completed
   	********************************************************************/
	@When("^I select Model to delete the operating unit$")
	public void selectModelToDeleteOperatingUnit()
	{
	    String Model = OperatingUnitCSVReader.getModelToDeleteOperatingUnit();
		operatingUnitPage.selectModelToAddOperatingUnit(Model);
	}
	
	/********************************************************************
   	* Description: Delete operating unit
   	* Status: Completed
   	********************************************************************/
	@When("^I delete the operating unit details$")
	public void deleteOperatingUnit()
	{
		String operatingUnit = OperatingUnitCSVReader.getOperatingUnitToDelete();
		operatingUnitPage.deleteOperatingUnit(operatingUnit);
	}
	
	/********************************************************************
   	* Description: Verify the deleted operating unit
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the operating unit gets deleted$")
	public void verifyDeletedOperatingUnit()
	{
		String operatingUnit = OperatingUnitCSVReader.getOperatingUnitToDelete();
		assertTrue("Deleted operating unit is displayed",operatingUnitPage.verifyDeletedOperatingUnit(operatingUnit));
	}
	
	/********************************************************************
   	* Description: Go to operating unit>>Select customer>>Model>>Operating Unit to add parameter
   	* Status: Completed
   	********************************************************************/
	@When("^Go to OperatingUnit>>Select customer>>Select Model>>Select Operating unit to add parameter$")
	public void selectCustomerModelOperatingUnitToAddParameter()
	{
		operatingUnitPage.selectOperatingUnit();
		String customer = OperatingUnitCSVReader.getCustomerToAddParameterForOperatingUnit();
		operatingUnitPage.selectCustomer(customer);
		String Model = OperatingUnitCSVReader.getModelToAddParameterForOperatingUnit();
		operatingUnitPage.selectModelToAddOperatingUnit(Model);
		String operatingUnit = OperatingUnitCSVReader.getOperatingUnitToAddParameter();
		operatingUnitPage.selectOperatingUnitToAddOperatingUnit(operatingUnit);
	}
	
	/********************************************************************
   	* Description: Add Measurement parameter to operating unit
   	* Status: Completed
   	********************************************************************/
	@When("^I add measurement parameter to the operating unit$")
	public void addMeasurementParameterToOperatingUnit()
	{
		String tabName = CSVHelper.getMeasurementTab();
		String measurementName = OperatingUnitCSVReader.getMeasurementName();
		String measurementParameter = OperatingUnitCSVReader.getMeasurementParameter();
		String metricOption = OperatingUnitCSVReader.getMetricOptionForMeasurement();
		String unit = OperatingUnitCSVReader.getUnitOfMeasurement();
		String prioritySelection = OperatingUnitCSVReader.getPriorityofMeasurement();
		operatingUnitPage.addMeasurementParameter(tabName, measurementName, measurementParameter, metricOption, unit, prioritySelection);
	}
	
	/********************************************************************
   	* Description: Verify added measurement parameter
   	* Status: Completed
   	********************************************************************/
	@When("^I can see the measurement parameter gets added$")
	public void verifyAddedMeasurementParameterToOperatingUnit()
	{
		String measurementName = OperatingUnitCSVReader.getMeasurementName();
		String unit = OperatingUnitCSVReader.getUnitOfMeasurement();
		String prioritySelection = OperatingUnitCSVReader.getPriorityofMeasurement();
		assertTrue("Measurement Parameter is not displayed with all the details",operatingUnitPage.verifyMeasurementParameterAdded(measurementName, unit, prioritySelection));
	}
	
	/********************************************************************
   	* Description: Add Alarm parameter to operating unit
   	* Status: Completed
   	********************************************************************/
	@When("^I add alarm parameter to the operating unit$")
	public void addAlarmParameterToOperatingUnit()
	{
		String tabName = CSVHelper.getAlarmTab();
		String parameterName = OperatingUnitCSVReader.getAlarmName();
		String parameterSelection = OperatingUnitCSVReader.getAlarmParameter();
		operatingUnitPage.addParameter(tabName, parameterName, parameterSelection);
	}
	
	/********************************************************************
   	* Description: Verify added alarm parameter
   	* Status: Completed
   	********************************************************************/
	@When("^I can see the alarm parameter gets added$")
	public void verifyAddedAlarmParameter()
	{
		String parameterName = OperatingUnitCSVReader.getAlarmName();
		assertTrue("Parameter added is not displayed with all the details",operatingUnitPage.verifyParameterAdded(parameterName));
	}
	
	/********************************************************************
   	* Description: Add trip parameter to operating unit
   	* Status: Completed
   	********************************************************************/
	@When("^I add trip parameter to the operating unit$")
	public void addTripParameterToOperatingUnit()
	{
		String tabName = CSVHelper.getTripTab();
		String parameterName = OperatingUnitCSVReader.getTripName();
		String parameterSelection = OperatingUnitCSVReader.getTripParameter();
		operatingUnitPage.addParameter(tabName, parameterName, parameterSelection);
	}
	
	/********************************************************************
   	* Description: Verify added trip parameter
   	* Status: Completed
   	********************************************************************/
	@When("^I can see the trip parameter gets added$")
	public void verifyAddedTripParameter()
	{
		String parameterName = OperatingUnitCSVReader.getTripName();
		assertTrue("Parameter added is not displayed with all the details",operatingUnitPage.verifyParameterAdded(parameterName));
	}
	
	/********************************************************************
   	* Description: Add fault parameter to operating unit
   	* Status: Completed
   	********************************************************************/
	@When("^I add fault parameter to the operating unit$")
	public void addFaultParameterToOperatingUnit()
	{
		String tabName = CSVHelper.getFaultsTab();
		String parameterName = OperatingUnitCSVReader.getFaultName();
		String parameterSelection = OperatingUnitCSVReader.getFaultParameter();
		operatingUnitPage.addParameter(tabName, parameterName, parameterSelection);
	}
	
	/********************************************************************
   	* Description: Verify added fault parameter
   	* Status: Completed
   	********************************************************************/
	@When("^I can see the fault parameter gets added$")
	public void verifyAddedFaultParameter()
	{
		String parameterName = OperatingUnitCSVReader.getFaultName();
		assertTrue("Parameter added is not displayed with all the details",operatingUnitPage.verifyParameterAdded(parameterName));
	}
	
	/********************************************************************
   	* Description: Add function states parameter to operating unit
   	* Status: Completed
   	********************************************************************/
	@When("^I add function states to the operating unit$")
	public void addFunctionStatesParameterToOperatingUnit()
	{
		String tabName = CSVHelper.getFunctionStatesTab();
		String parameterName = OperatingUnitCSVReader.getFSName();
		String parameterSelection = OperatingUnitCSVReader.getFSParameter();
		operatingUnitPage.addParameter(tabName, parameterName, parameterSelection);
	}
	
	/********************************************************************
   	* Description: Verify added function states parameter
   	* Status: Completed
   	********************************************************************/
	@When("^I can see the function states parameter gets added$")
	public void verifyAddedFunctionStateParameter()
	{
		String parameterName = OperatingUnitCSVReader.getFSName();
		assertTrue("Parameter added is not displayed with all the details",operatingUnitPage.verifyParameterAdded(parameterName));
	}
	
	/********************************************************************
   	* Description: Add calibration parameter to operating unit
   	* Status: Completed
   	********************************************************************/
	@When("^I add calibration parameter to the operating unit$")
	public void addCalibrationParameterToOperatingUnit()
	{
		String tabName = CSVHelper.getCalibrationTab();
		String parameterName = OperatingUnitCSVReader.getCalibrationName();
		String value = OperatingUnitCSVReader.getCalibrationValue();
		String parameterSelection = OperatingUnitCSVReader.getCalibrationParameter();
		String metricSelection = OperatingUnitCSVReader.getMetricOptionForCalibration();
	    String unit = OperatingUnitCSVReader.getUnitOfCalibration();
		operatingUnitPage.addParameterforCalibration(tabName, parameterName, value, parameterSelection, metricSelection, unit);
	}
	
	/********************************************************************
   	* Description: Verify added calibration parameter
   	* Status: Completed
   	********************************************************************/
	@When("^I can see the calibration parameter gets added$")
	public void verifyAddedCalibrationParameter()
	{
		String parameterName = OperatingUnitCSVReader.getCalibrationName();
		assertTrue("Parameter added is not displayed with all the details",operatingUnitPage.verifyParameterAdded(parameterName));
	}
	
	/********************************************************************
   	* Description: Go to operating unit>>Select customer>>Model>>Operating Unit to edit parameter
   	* Status: Completed
   	********************************************************************/
	@When("^Go to OperatingUnit>>Select customer>>Select Model>>Select Operating unit to edit parameter$")
	public void selectCustomerModelOperatingUnitToEditParameter()
	{
		operatingUnitPage.selectOperatingUnit();
		String customer = OperatingUnitCSVReader.getCustomerToEditParameterForOperatingUnit();
		operatingUnitPage.selectCustomer(customer);
		String Model = OperatingUnitCSVReader.getModelToEditParameterForOperatingUnit();
		operatingUnitPage.selectModelToAddOperatingUnit(Model);
		String operatingUnit = OperatingUnitCSVReader.getOperatingUnitToEditParameter();
		operatingUnitPage.selectOperatingUnitToAddOperatingUnit(operatingUnit);
	}
	
	/********************************************************************
   	* Description: Edit measurement parameter in operating unit
   	* Status: Completed
   	********************************************************************/
	@When("^I edit measurement parameter$")
	public void editMeasurementParameter()
	{
		String tabName = CSVHelper.getMeasurementTab();
		String parameterName = OperatingUnitCSVReader.getParameterNameToEdit();
		String editParameter = OperatingUnitCSVReader.getUpdatedParameterName();
		String metricSelection = OperatingUnitCSVReader.getMetricSelection();
		String unitOfMeasurement = OperatingUnitCSVReader.getUnitOfMeasurementToEdit();
		String LCLvalue = OperatingUnitCSVReader.getLCLValue();
		String UCLvalue = OperatingUnitCSVReader.getUCLValue();
		String minRange = OperatingUnitCSVReader.getMinimumSignalRange();
		String maxRange = OperatingUnitCSVReader.getMaximumSignalRange();
		String tagId = OperatingUnitCSVReader.getTagId();
		String aggregator = OperatingUnitCSVReader.getAggregatorSelection();
		String priorityFlag = OperatingUnitCSVReader.getPriorityFlag();
		String visibilityFlag = OperatingUnitCSVReader.getVisibilityFlag();
		operatingUnitPage.editParameterForMeasurement(tabName, parameterName, editParameter, metricSelection, unitOfMeasurement, LCLvalue, UCLvalue, minRange, maxRange, tagId, aggregator, priorityFlag, visibilityFlag);
	}
	
	/********************************************************************
   	* Description:Verify edited measurement parameter in operating unit
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the parameter gets edited for measurement$")
	public void verifyEditedParameterForMeasurement()
	{
		String updatedMeasurement = OperatingUnitCSVReader.getUpdatedParameterName();
		String unitOfMeasurement = OperatingUnitCSVReader.getUnitOfMeasurementToEdit();
		String LCLvalue = OperatingUnitCSVReader.getLCLValue();
		String UCLvalue = OperatingUnitCSVReader.getUCLValue();
		String minRange = OperatingUnitCSVReader.getMinimumSignalRange();
		String maxRange = OperatingUnitCSVReader.getMaximumSignalRange();
		String tagId = OperatingUnitCSVReader.getTagId();
		String priorityFlag = OperatingUnitCSVReader.getPriorityFlag();
		String visibilityFlag = OperatingUnitCSVReader.getVisibilityFlag();
		assertTrue("Edited parameter is not displayed with all the details",operatingUnitPage.verifyEditedMeasurement(updatedMeasurement, unitOfMeasurement, LCLvalue, UCLvalue, minRange, maxRange, tagId, priorityFlag,visibilityFlag));
	}
	
	/********************************************************************
   	* Description: Edit alarm parameter in operating unit
   	* Status: Completed
   	********************************************************************/
	@When("^I edit alarms parameter$")
	public void editAlarmParameter()
	{
		String tabName = CSVHelper.getAlarmTab();
		String parameterName = OperatingUnitCSVReader.getAlarmNameToEdit();
		String editParameterName = OperatingUnitCSVReader.getUpdatedAlarmName();
		String severity = OperatingUnitCSVReader.getSeverityForAlarm();
		String tagId = OperatingUnitCSVReader.gettagIdForAlarm();
		String relatedMeasurement = OperatingUnitCSVReader.getrelatedMeasurementForAlarm();
		String recommendationMessage = OperatingUnitCSVReader.getrecommendedMessageForAlarm();
		String value = null;
		String operatingUnit = null;
		String metricUnitSelection = null;
		operatingUnitPage.editParameter(tabName, parameterName, editParameterName, severity, tagId, relatedMeasurement, recommendationMessage, value,operatingUnit,metricUnitSelection);
	}
	
	/********************************************************************
   	* Description:Verify edited alarm parameter in operating unit
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the parameter gets edited for alarm$")
	public void verifyEditedParameterForAlarm()
	{
		String editParameterName = OperatingUnitCSVReader.getUpdatedAlarmName();
		String severity = OperatingUnitCSVReader.getSeverityForAlarm();
		String tagId = OperatingUnitCSVReader.gettagIdForAlarm();
		String relatedMeasurement = OperatingUnitCSVReader.getrelatedMeasurementForAlarm();
		String recommendationtext = OperatingUnitCSVReader.getrecommendedMessageForAlarm();
		assertTrue("Edited parameter is not displayed with all the details",operatingUnitPage.verifyEditedParameterAlarmsTripsFaults(editParameterName, severity, tagId, relatedMeasurement, recommendationtext));
	}
	
	/********************************************************************
   	* Description: Edit trip parameter in operating unit
   	* Status: Completed
   	********************************************************************/
	@When("^I edit trip parameter$")
	public void editTripParameter()
	{
		String tabName = CSVHelper.getTripTab();
		String parameterName = OperatingUnitCSVReader.getTripNameToEdit();
		String editParameterName = OperatingUnitCSVReader.getUpdatedTripName();
		String severity = OperatingUnitCSVReader.getSeverityForTrip();
		String tagId = OperatingUnitCSVReader.gettagIdForTrip();
		String relatedMeasurement = OperatingUnitCSVReader.getrelatedMeasurementForTrip();
		String recommendationMessage = OperatingUnitCSVReader.getrecommendedMessageForTrip();
		String value = null;
		String operatingUnit = null;
		String metricUnitSelection = null;
		operatingUnitPage.editParameter(tabName, parameterName, editParameterName, severity, tagId, relatedMeasurement, recommendationMessage, value, operatingUnit, metricUnitSelection);
	}
	
	/********************************************************************
   	* Description:Verify edited trip parameter in operating unit
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the parameter gets edited for trip$")
	public void verifyEditedParameterForTrip()
	{
		String editParameterName = OperatingUnitCSVReader.getUpdatedTripName();
		String severity = OperatingUnitCSVReader.getSeverityForTrip();
		String tagId = OperatingUnitCSVReader.gettagIdForTrip();
		String relatedMeasurement = OperatingUnitCSVReader.getrelatedMeasurementForTrip();
		String recommendationtext = OperatingUnitCSVReader.getrecommendedMessageForTrip();
		assertTrue("Edited parameter is not displayed with all the details",operatingUnitPage.verifyEditedParameterAlarmsTripsFaults(editParameterName, severity, tagId, relatedMeasurement, recommendationtext));
	}
	
	/********************************************************************
   	* Description: Edit fault parameter in operating unit
   	* Status: Completed
   	********************************************************************/
	@When("^I edit fault parameter$")
	public void editFaultParameter()
	{
		String tabName = CSVHelper.getFaultsTab();
		String parameterName = OperatingUnitCSVReader.getFaultNameToEdit();
		String editParameterName = OperatingUnitCSVReader.getUpdatedFaultName();
		String severity = OperatingUnitCSVReader.getSeverityForFault();
		String tagId = OperatingUnitCSVReader.gettagIdForFault();
		String relatedMeasurement = OperatingUnitCSVReader.getrelatedMeasurementForFault();
		String recommendationMessage = OperatingUnitCSVReader.getrecommendedMessageForFault();
		String value = null;
		String operatingUnit = null;
		String metricUnitSelection = null;
		operatingUnitPage.editParameter(tabName, parameterName, editParameterName, severity, tagId, relatedMeasurement, recommendationMessage, value, operatingUnit, metricUnitSelection);
	}
	
	/********************************************************************
   	* Description:Verify edited fault parameter in operating unit
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the fault parameter gets edited for fault$")
	public void verifyEditedParameterForFault()
	{
		String editParameterName = OperatingUnitCSVReader.getUpdatedFaultName();
		String severity = OperatingUnitCSVReader.getSeverityForFault();
		String tagId = OperatingUnitCSVReader.gettagIdForFault();
		String relatedMeasurement = OperatingUnitCSVReader.getrelatedMeasurementForFault();
		String recommendationtext = OperatingUnitCSVReader.getrecommendedMessageForFault();
		assertTrue("Edited parameter is not displayed with all the details",operatingUnitPage.verifyEditedParameterAlarmsTripsFaults(editParameterName, severity, tagId, relatedMeasurement, recommendationtext));
	}
	
	/********************************************************************
   	* Description: Edit function states parameter in operating unit
   	* Status: Completed
   	********************************************************************/
	@When("^I edit function states parameter$")
	public void editFunctionStatesParameter()
	{
		String tabName = CSVHelper.getFunctionStatesTab();
		String parameterName = OperatingUnitCSVReader.getFSNameToEdit();
		String editParameterName = OperatingUnitCSVReader.getUpdatedFSName();
		String severity = null;
		String tagId = OperatingUnitCSVReader.gettagIdForFS();
		String relatedMeasurement = OperatingUnitCSVReader.getrelatedMeasurementForFS();
		String recommendationMessage = null;
		String value = null;
		String operatingUnit = null;
		String metricUnitSelection = null;
		operatingUnitPage.editParameter(tabName, parameterName, editParameterName, severity, tagId, relatedMeasurement, recommendationMessage, value, operatingUnit, metricUnitSelection);
	}
	
	/********************************************************************
   	* Description:Verify edited function states parameter in operating unit
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the function states get edited for function states$")
	public void verifyEditedParameterForFunctionStates()
	{
		String editParameterName = OperatingUnitCSVReader.getUpdatedFSName();
		String tagId = OperatingUnitCSVReader.gettagIdForFS();
		String relatedMeasurement = OperatingUnitCSVReader.getrelatedMeasurementForFS();
		assertTrue("Edited parameter is not displayed with all the details",operatingUnitPage.verifyEditedParameterForFucntionStates(editParameterName,tagId, relatedMeasurement));
	}
	
	/********************************************************************
   	* Description: Edit calibration parameter in operating unit
   	* Status: Completed
   	********************************************************************/
	@When("^I edit calibration parameter$")
	public void editCalibrationParameter()
	{
		String tabName = CSVHelper.getCalibrationTab();
		String parameterName = OperatingUnitCSVReader.getCalibrationNameToEdit();
		String editParameterName = OperatingUnitCSVReader.getUpdatedCalibrationName();
		String severity = null;
		String tagId = OperatingUnitCSVReader.getTagIdForCalibration();
		String relatedMeasurement = OperatingUnitCSVReader.getRelatedMeasurementForCalibration();
		String recommendationMessage = null;
		String value = OperatingUnitCSVReader.getValueToUpdateCalibration();
		String operatingUnit = OperatingUnitCSVReader.getUpdatedUnitOfCalibration();
		String metricUnitSelection = OperatingUnitCSVReader.getMetricUntiForCalibration();
		operatingUnitPage.editParameter(tabName, parameterName, editParameterName, severity, tagId, relatedMeasurement, recommendationMessage, value, operatingUnit, metricUnitSelection);
	}
	
	/********************************************************************
   	* Description:Verify edited fault parameter in operating unit
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the calibration parameter gets edited for calibration$")
	public void verifyEditedParameterForCalibration()
	{
		String editParameterName = OperatingUnitCSVReader.getUpdatedCalibrationName();
		String tagId = OperatingUnitCSVReader.getTagIdForCalibration();
		String relatedMeasurement = OperatingUnitCSVReader.getRelatedMeasurementForCalibration();
		String value = OperatingUnitCSVReader.getValueToUpdateCalibration();
		String unitofMeasurement = OperatingUnitCSVReader.getUpdatedUnitOfCalibration();
		assertTrue("Edited parameter is not displayed with all the details",operatingUnitPage.verifyEditedParameterForCalibration(editParameterName, value, unitofMeasurement, tagId, relatedMeasurement));
	}

	/********************************************************************
   	* Description: Go to operating unit>>Select customer>>Model>>Operating Unit to disable/enable parameter
   	* Status: Completed
   	********************************************************************/
	@When("^Go to OperatingUnit>>Select customer>>Select Model>>Select Operating unit to disable/enable parameter$")
	public void selectCustomerModelOperatingUnitToDisableEnableParameter()
	{
		operatingUnitPage.selectOperatingUnit();
		String customer = OperatingUnitCSVReader.getCustomerToEditParameterForOperatingUnit();
		operatingUnitPage.selectCustomer(customer);
		String Model = OperatingUnitCSVReader.getModelToEditParameterForOperatingUnit();
		operatingUnitPage.selectModelToAddOperatingUnit(Model);
		String operatingUnit = OperatingUnitCSVReader.getOperatingUnitToEditParameter();
		operatingUnitPage.selectOperatingUnitToAddOperatingUnit(operatingUnit);
	}
	
	/********************************************************************
   	* Description:Disable the Measurement parameter
   	* Status: Completed
   	********************************************************************/
	@When("^I disable the Measurement parameter$")
	public void disableMeasurementParameter()
	{
		String tabName = CSVHelper.getMeasurementTab();
		String parameterName = OperatingUnitCSVReader.getMeasurementParameterToDisableEnable();
		operatingUnitPage.disableEnableParameter(tabName, parameterName);
	}
	
	/********************************************************************
   	* Description:Verify disabled Measurement parameter
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the Measurement parameter gets disabled$")
	public void verifyDisabledMeasurementParameter()
	{
		String parameterName = OperatingUnitCSVReader.getMeasurementParameterToDisableEnable();
		assertTrue("Parameter is already disabled",operatingUnitPage.verifyDisabledParamter(parameterName));
	}
	
	/********************************************************************
   	* Description:Disable the Alarm parameter
   	* Status: Completed
   	********************************************************************/
	@When("^I disable the Alarm parameter$")
	public void disableAlarmParameter()
	{
		String tabName = CSVHelper.getAlarmTab();
		String parameterName = OperatingUnitCSVReader.getAlarmParameterToDisableEnable();
		operatingUnitPage.disableEnableParameter(tabName, parameterName);
	}
	
	/********************************************************************
   	* Description:Verify disabled Alarm parameter
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the alarm parameter gets disabled$")
	public void verifyDisabledAlarmParameter()
	{
		String parameterName = OperatingUnitCSVReader.getAlarmParameterToDisableEnable();
		assertTrue("Parameter is already disabled",operatingUnitPage.verifyDisabledParamter(parameterName));
	}
	
	/********************************************************************
   	* Description:Disable the Trip parameter
   	* Status: Completed
   	********************************************************************/
	@When("^I disable the Trip parameter$")
	public void disableTripParameter()
	{
		String tabName = CSVHelper.getTripTab();
		String parameterName = OperatingUnitCSVReader.getTripParameterToDisableEnable();
		operatingUnitPage.disableEnableParameter(tabName, parameterName);
	}
	
	/********************************************************************
   	* Description:Verify disabled Trip parameter
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the Trip parameter gets disabled$")
	public void verifyDisabledTripParameter()
	{
		String parameterName = OperatingUnitCSVReader.getTripParameterToDisableEnable();
		assertTrue("Parameter is already disabled",operatingUnitPage.verifyDisabledParamter(parameterName));
	}
	
	/********************************************************************
   	* Description:Disable the Fault parameter
   	* Status: Completed
   	********************************************************************/
	@When("^I disable the Fault parameter$")
	public void disableFaultParameter()
	{
		String tabName = CSVHelper.getFaultsTab();
		String parameterName = OperatingUnitCSVReader.getFaultParameterToDisableEnable();
		operatingUnitPage.disableEnableParameter(tabName, parameterName);
	}
	
	/********************************************************************
   	* Description:Verify disabled Fault parameter
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the Fault parameter gets disabled$")
	public void verifyDisabledFaultParameter()
	{
		String parameterName = OperatingUnitCSVReader.getFaultParameterToDisableEnable();
		assertTrue("Parameter is already disabled",operatingUnitPage.verifyDisabledParamter(parameterName));
	}
	
	/********************************************************************
   	* Description:Disable the Fault parameter
   	* Status: Completed
   	********************************************************************/
	@When("^I disable the FS parameter$")
	public void disableFSParameter()
	{
		String tabName = CSVHelper.getFunctionStatesTab();
		String parameterName = OperatingUnitCSVReader.getFSParameterToDisableEnable();
		operatingUnitPage.disableEnableParameter(tabName, parameterName);
	}
	
	/********************************************************************
   	* Description:Verify disabled Fault parameter
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the FS parameter gets disabled$")
	public void verifyDisabledFSParameter()
	{
		String parameterName = OperatingUnitCSVReader.getFSParameterToDisableEnable();
		assertTrue("Parameter is already disabled",operatingUnitPage.verifyDisabledParamter(parameterName));
	}
	
	/********************************************************************
   	* Description:Disable the Fault parameter
   	* Status: Completed
   	********************************************************************/
	@When("^I disable Calibration parameter$")
	public void disableCalibrationParameter()
	{
		String tabName = CSVHelper.getCalibrationTab();
		String parameterName = OperatingUnitCSVReader.getCalibrationParameterToDisableEnable();
		operatingUnitPage.disableEnableParameter(tabName, parameterName);
	}
	
	/********************************************************************
   	* Description:Verify disabled Fault parameter
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the calibration parameter gets disabled$")
	public void verifyDisabledCaibrationParameter()
	{
		String parameterName = OperatingUnitCSVReader.getCalibrationParameterToDisableEnable();
		assertTrue("Parameter is already disabled",operatingUnitPage.verifyDisabledParamter(parameterName));
	}
	
	/********************************************************************
   	* Description: Select customer to enable parameter for operating unit
   	* Status: Completed
   	********************************************************************/
	@When("^I select customer to enable parameters for the operating unit$")
	public void selectCustomerToEnableParameterToOperatingUnit()
	{
		String customer = OperatingUnitCSVReader.getCustomerToDisableEnableParameterForOperatingUnit();
		operatingUnitPage.selectCustomer(customer);
	}
	
	/********************************************************************
   	* Description: Select model to enable parameter for operating unit
   	* Status: Completed
   	********************************************************************/
	@When("^I select Model to enable parameters For the operating unit$")
	public void selectModelToEnableParameterForOperatingUnit()
	{
	    String Model = OperatingUnitCSVReader.getModelToDisableEnableParameterForOperatingUnit();
		operatingUnitPage.selectModelToAddOperatingUnit(Model);
	}
	
	/********************************************************************
   	* Description: Select model to edit parameter to operating unit
   	* Status: Completed
   	********************************************************************/
	@When("^I select operating unit to enable parameter$")
	public void selectOperatingUnitToEnableParameter()
	{
		String operatingUnit = OperatingUnitCSVReader.getOperatingUnitToDisableEnableParameter();
		operatingUnitPage.selectOperatingUnitToAddOperatingUnit(operatingUnit);
	}
	
	/********************************************************************
   	* Description:Enable the Measurement parameter
   	* Status: Completed
   	********************************************************************/
	@When("^I enable the Measurement parameter$")
	public void enableMeasurementParameter()
	{
		String tabName = CSVHelper.getMeasurementTab();
		String parameterName = OperatingUnitCSVReader.getMeasurementParameterToDisableEnable();
		operatingUnitPage.disableEnableParameter(tabName, parameterName);
	}
	
	/********************************************************************
   	* Description:Verify enabled Measurement parameter
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the Measurement parameter gets enabled$")
	public void verifyEnabledMeasurementParameter()
	{
		String parameterName = OperatingUnitCSVReader.getMeasurementParameterToDisableEnable();
		assertTrue("Parameter is already enabled",operatingUnitPage.verifyEnabledParamter(parameterName));
	}
	
	/********************************************************************
   	* Description:Enable the Alarm parameter
   	* Status: Completed
   	********************************************************************/
	@When("^I enable the Alarm parameter$")
	public void enableAlarmParameter()
	{
		String tabName = CSVHelper.getAlarmTab();
		String parameterName = OperatingUnitCSVReader.getAlarmParameterToDisableEnable();
		operatingUnitPage.disableEnableParameter(tabName, parameterName);
	}
	
	/********************************************************************
   	* Description:Verify enabled Alarm parameter
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the alarm parameter gets enabled$")
	public void verifyEnabledAlarmParameter()
	{
		String parameterName = OperatingUnitCSVReader.getAlarmParameterToDisableEnable();
		assertTrue("Parameter is already enabled",operatingUnitPage.verifyEnabledParamter(parameterName));
	}
	
	/********************************************************************
   	* Description:Enable the Trip parameter
   	* Status: Completed
   	********************************************************************/
	@When("^I enable the Trip parameter$")
	public void enableTripParameter()
	{
		String tabName = CSVHelper.getTripTab();
		String parameterName = OperatingUnitCSVReader.getTripParameterToDisableEnable();
		operatingUnitPage.disableEnableParameter(tabName, parameterName);
	}
	
	/********************************************************************
   	* Description:Verify enabled Trip parameter
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the Trip parameter gets enabled$")
	public void verifyEnabledTripParameter()
	{
		String parameterName = OperatingUnitCSVReader.getTripParameterToDisableEnable();
		assertTrue("Parameter is already enabled",operatingUnitPage.verifyEnabledParamter(parameterName));
	}
	
	/********************************************************************
   	* Description:Enable the Fault parameter
   	* Status: Completed
   	********************************************************************/
	@When("^I enable the Fault parameter$")
	public void enableFaultParameter()
	{
		String tabName = CSVHelper.getFaultsTab();
		String parameterName = OperatingUnitCSVReader.getFaultParameterToDisableEnable();
		operatingUnitPage.disableEnableParameter(tabName, parameterName);
	}
	
	/********************************************************************
   	* Description:Verify enabled Fault parameter
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the Fault parameter gets enabled$")
	public void verifyEnabledFaultParameter()
	{
		String parameterName = OperatingUnitCSVReader.getFaultParameterToDisableEnable();
		assertTrue("Parameter is already enabled",operatingUnitPage.verifyEnabledParamter(parameterName));
	}
	
	/********************************************************************
   	* Description:Enable the Fault parameter
   	* Status: Completed
   	********************************************************************/
	@When("^I enable the FS parameter$")
	public void enableFSParameter()
	{
		String tabName = CSVHelper.getFunctionStatesTab();
		String parameterName = OperatingUnitCSVReader.getFSParameterToDisableEnable();
		operatingUnitPage.disableEnableParameter(tabName, parameterName);
	}
	
	/********************************************************************
   	* Description:Verify disabled Fault parameter
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the FS parameter gets enabled$")
	public void verifyEnabledFSParameter()
	{
		String parameterName = OperatingUnitCSVReader.getFSParameterToDisableEnable();
		assertTrue("Parameter is already enabled",operatingUnitPage.verifyEnabledParamter(parameterName));
	}
	
	/********************************************************************
   	* Description:Enable the Calibration parameter
   	* Status: Completed
   	********************************************************************/
	@When("^I enable Calibration parameter$")
	public void enableCalibrationParameter()
	{
		String tabName = CSVHelper.getCalibrationTab();
		String parameterName = OperatingUnitCSVReader.getCalibrationParameterToDisableEnable();
		operatingUnitPage.disableEnableParameter(tabName, parameterName);
	}
	
	/********************************************************************
   	* Description:Verify enabled Calibration parameter
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the calibration parameter gets enabled$")
	public void verifyEnabledCaibrationParameter()
	{
		String parameterName = OperatingUnitCSVReader.getCalibrationParameterToDisableEnable();
		assertTrue("Parameter is already enabled",operatingUnitPage.verifyEnabledParamter(parameterName));
	}
	
	/********************************************************************
   	* Description: Go to operating unit>>Select customer>>Model>>Operating Unit to delete parameter
   	* Status: Completed
   	********************************************************************/
	@When("^Go to OperatingUnit>>Select customer>>Select Model>>Select Operating unit to delete parameter$")
	public void selectCustomerModelOperatingUnitToDeleteParameter()
	{
		operatingUnitPage.selectOperatingUnit();
		String customer = OperatingUnitCSVReader.getCustomerToDeleteParameterForOperatingUnit();
		operatingUnitPage.selectCustomer(customer);
		String Model = OperatingUnitCSVReader.getModelToDeleteParameterForOperatingUnit();
		operatingUnitPage.selectModelToAddOperatingUnit(Model);
		String operatingUnit = OperatingUnitCSVReader.getOperatingUnitToDeleteParameter();
		operatingUnitPage.selectOperatingUnitToAddOperatingUnit(operatingUnit);
	}
	
	
	/********************************************************************
   	* Description: Delete the measurement parameter
   	* Status: Completed
   	********************************************************************/
	@When("^I delete the Measurement parameter$")
	public void deleteMeasurementParamter()
	{
		String tabName = CSVHelper.getMeasurementTab();
		String parameterName = OperatingUnitCSVReader.getMeasurementParameterToDelete();
		operatingUnitPage.deleteParameter(tabName, parameterName);
	}
	
	/********************************************************************
   	* Description: Verify deleted  measurement parameter
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the Measurement parameter gets removed$")
	public void verifyMeasurementParameterGetsDeleted()
	{
		String parameterName = OperatingUnitCSVReader.getMeasurementParameterToDelete();
		assertTrue("Parameter is displayed in the list",operatingUnitPage.verifyDeletedParameter(parameterName));
	}
	
	/********************************************************************
   	* Description: Delete the alarm parameter
   	* Status: Completed
   	********************************************************************/
	@When("^I delete the Alarm parameter$")
	public void deleteAlarmParamter()
	{
		String tabName = CSVHelper.getAlarmTab();
		String parameterName = OperatingUnitCSVReader.getAlarmParameterToDelete();
		operatingUnitPage.deleteParameter(tabName, parameterName);
	}
	
	/********************************************************************
   	* Description: Verify deleted  measurement parameter
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the alarm parameter gets removed$")
	public void verifyAlarmParameterGetsDeleted()
	{
		String parameterName = OperatingUnitCSVReader.getAlarmParameterToDelete();
		assertTrue("Parameter is displayed in the list",operatingUnitPage.verifyDeletedParameter(parameterName));
	}
	
	/********************************************************************
   	* Description: Delete the trip parameter
   	* Status: Completed
   	********************************************************************/
	@When("^I delete the Trip parameter$")
	public void deleteTripParamter()
	{
		String tabName = CSVHelper.getTripTab();
		String parameterName = OperatingUnitCSVReader.getTripParameterToDelete();
		operatingUnitPage.deleteParameter(tabName, parameterName);
	}
	
	/********************************************************************
   	* Description: Verify deleted  measurement parameter
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the Trip parameter gets removed$")
	public void verifyTripParameterGetsDeleted()
	{
		String parameterName = OperatingUnitCSVReader.getTripParameterToDelete();
		assertTrue("Parameter is displayed in the list",operatingUnitPage.verifyDeletedParameter(parameterName));
	}
	
	/********************************************************************
   	* Description: Delete the fault parameter
   	* Status: Completed
   	********************************************************************/
	@When("^I delete the Fault parameter$")
	public void deleteFaultParamter()
	{
		String tabName = CSVHelper.getFaultsTab();
		String parameterName = OperatingUnitCSVReader.getFaultParameterToDelete();
		operatingUnitPage.deleteParameter(tabName, parameterName);
	}
	
	/********************************************************************
   	* Description: Verify deleted Fault parameter
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the Fault parameter gets removed$")
	public void verifyFaultParameterGetsDeleted()
	{
		String parameterName = OperatingUnitCSVReader.getFaultParameterToDelete();
		assertTrue("Parameter is displayed in the list",operatingUnitPage.verifyDeletedParameter(parameterName));
	}
	
	/********************************************************************
   	* Description: Delete the FS parameter
   	* Status: Completed
   	********************************************************************/
	@When("^I delete the FS parameter$")
	public void deleteFSParamter()
	{
		String tabName = CSVHelper.getFunctionStatesTab();
		String parameterName = OperatingUnitCSVReader.getFSParameterToDelete();
		operatingUnitPage.deleteParameter(tabName, parameterName);
	}
	
	/********************************************************************
   	* Description: Verify deleted FS parameter
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the FS parameter gets removed$")
	public void verifyFSParameterGetsDeleted()
	{
		String parameterName = OperatingUnitCSVReader.getFSParameterToDelete();
		assertTrue("Parameter is displayed in the list",operatingUnitPage.verifyDeletedParameter(parameterName));
	}
	
	/********************************************************************
   	* Description: Delete the Calibration parameter
   	* Status: Completed
   	********************************************************************/
	@When("^I delete the Calibration parameter$")
	public void deleteCalibrationParamterForOperatingUnit()
	{
		String tabName = CSVHelper.getCalibrationTab();
		String parameterName = OperatingUnitCSVReader.getCalibrationParameterToDelete();
		operatingUnitPage.deleteParameter(tabName, parameterName);
	}
	
	/********************************************************************
   	* Description: Verify deleted Calibration parameter
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the calibration parameter gets removed$")
	public void verifyCalibrationParameterGetsDeleted()
	{
		String parameterName = OperatingUnitCSVReader.getCalibrationParameterToDelete();
		assertTrue("Parameter is displayed in the list",operatingUnitPage.verifyDeletedParameter(parameterName));
	}
	
	/********************************************************************
   	* Description: Select customer to sync the unsynced parameter for operating unit
   	* Status: Completed
   	********************************************************************/
	@When("^I select customer to sync the parameters for the operating unit$")
	public void selectCustomerToSyncParameterForOperatingUnit()
	{
		String customer = OperatingUnitCSVReader.getCustomerToSyncParameterForOperatingUnit();
		operatingUnitPage.selectCustomer(customer);
	}
	
	/********************************************************************
   	* Description: Select model to sync the unsynced parameter for operating unit
   	* Status: Completed
   	********************************************************************/
	@When("^I select Model to sync the parameters For the operating unit$")
	public void selectModelToSyncParameterForOperatingUnit()
	{
	    String Model = OperatingUnitCSVReader.getModelToSyncParameterForOperatingUnit();
		operatingUnitPage.selectModelToAddOperatingUnit(Model);
	}
	
	/********************************************************************
   	* Description: Select operating to sync parameter 
   	* Status: Completed
   	********************************************************************/
	@When("^I select operating unit to sync the parameter$")
	public void selectOperatingUnitToSyncParameter()
	{
		String operatingUnit = OperatingUnitCSVReader.getOperatingUnitToSyncParameter();
		operatingUnitPage.selectOperatingUnitToAddOperatingUnit(operatingUnit);
	}
	
	/********************************************************************
   	* Description: Click on sync in configuration
   	* Status: Completed
   	********************************************************************/
	@When("^I click on Sync$")
	public void clickOnsync()
	{
		operatingUnitPage.clickOnSync();
	}
	
	/********************************************************************
   	* Description: Click on sync in configuration
   	* Status: Completed
   	********************************************************************/
	@When("^I sync all the unsynced parameters$")
	public void syncParameter()
	{
		operatingUnitPage.syncAllParameters();
	}
	
	/********************************************************************
   	* Description: Click on sync in configuration
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see all the parameters gets synced$")
	public void verifySyncedParameter()
	{
		assertTrue("All the parameters are not synced",operatingUnitPage.verifySyncedParameters());
	}
	
	/********************************************************************
   	* Description: Select a customer to add operating unit with an existing name
   	* Status: Completed
   	********************************************************************/
	@When("^I select customer to add operating unit with an existing name$")
	public void whenISelectCustomerToAddOperatingUnitWithAnExistingName()
	{
		String customer = OperatingUnitCSVReader.getCustomerToAddOperatingUnitWithAnExistingName();
		operatingUnitPage.selectCustomer(customer);
	}
	
	/********************************************************************
   	* Description: Select a model to add operating unit with an existing name
   	* Status: Completed
   	********************************************************************/
	@When("^I select Model to add operating unit with an existing name$")
	public void whenISelectModelToAddOperatingUnitWithAnExistingName()
	{
		String Model = OperatingUnitCSVReader.getModelToAddOperatingUnitWithAnExistingName();
		operatingUnitPage.selectModelToAddOperatingUnit(Model);
	}
	
	/********************************************************************
   	* Description: Add operating unit with an existing name
   	* Status: Completed
   	********************************************************************/
	@When("^I add operating unit with an existing name$")
	public void whenAddOperatingUnitWithAnExistingName()
	{
		String operatingUnitName = OperatingUnitCSVReader.getOperatingUnitNameToVerifyDuplicate();
		String operatingUnitNumber = OperatingUnitCSVReader.getOperatingUnitNumberToVerifyDuplicate();
		String date = OperatingUnitCSVReader.getOperatingUnitDateToVerifyDuplicate();
		String gateway = OperatingUnitCSVReader.getOperatingUnitGatewayToVerifyDuplicate();
		operatingUnitPage.addOperatingUnit(operatingUnitName,operatingUnitNumber,date,gateway);
	}
	
	/********************************************************************
   	* Description: Verify error message and no duplicate operating unit gets created
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see error message and no duplicate operating unit gets created$")
	public void thenICanSeeErrorMessageAndNoDuplicateOperatingUnitGetsCreated()
	{
		String operatingUnitName = OperatingUnitCSVReader.getOperatingUnitNameToVerifyDuplicate();
		assertTrue("Error Message or url is not proper",operatingUnitPage.verifyErrorMessageWhileAddingDuplicateOperatingUnit(operatingUnitName));
	}
	
	/********************************************************************
   	* Description: Select a customer to add measurement with an existing name
   	* Status: Completed
   	********************************************************************/
	@When("^I select customer to add measurement with an existing name$")
	public void whenISelectCustomerToAddMeasurementWithAnExistingName()
	{
		String customer = OperatingUnitCSVReader.getCustomerToVerifyDuplicateParameterForOU();
		operatingUnitPage.selectCustomer(customer);
	}
	
	/********************************************************************
   	* Description: Select a model to add measurement with an existing name
   	* Status: Completed
   	********************************************************************/
	@When("^I select Model to add measurement with an existing name$")
	public void whenISelectModelToAddMeasurementWithAnExistingName()
	{
		String Model = OperatingUnitCSVReader.getModelToVerifyDuplicateParameterForOU();
		operatingUnitPage.selectModelToAddOperatingUnit(Model);
	}
	
	/********************************************************************
   	* Description: Select operating to add measurement with an existing name
   	* Status: Completed
   	********************************************************************/
	@When("^I select operating unit to add measurement with an existing name$")
	public void selectOperatingUnitToAddMeasurementWithAnExistingName()
	{
		String operatingUnit = OperatingUnitCSVReader.getOUToVerifyDuplicateParameterForOU();
		operatingUnitPage.selectOperatingUnitToAddOperatingUnit(operatingUnit);
	}
	
	/********************************************************************
   	* Description: Add Duplicate Measurement parameter to operating unit
   	* Status: Completed
   	********************************************************************/
	@When("^I add measurement parameter with an existing name$")
	public void addDuplicateMeasurementParameterToOperatingUnit()
	{
		String tabName = CSVHelper.getMeasurementTab();
		String measurementName = OperatingUnitCSVReader.getMeasurementNameToVerifyDuplicateParameterForOU();
		String measurementParameter = OperatingUnitCSVReader.getMeasurementParameterToVerifyDuplicateParameterForOU();
		String metricOption = OperatingUnitCSVReader.getMetricOptionToVerifyDuplicateParameterForOU();
		String unit = OperatingUnitCSVReader.getUnitForMeasurementToVerifyDuplicateParameterForOU();
		String prioritySelection = OperatingUnitCSVReader.getPrioritySelectionForMeasurementToVerifyDuplicateParameterForOU();
		operatingUnitPage.addMeasurementParameter(tabName, measurementName, measurementParameter, metricOption, unit, prioritySelection);
	}
	
	/********************************************************************
   	* Description: Verify error message and no duplicate parmeter gets added
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see error message for the operating unit$")
	public void verifyErroMessageForOperatingUnit()
	{
		String parameterName = OperatingUnitCSVReader.getMeasurementNameToVerifyDuplicateParameterForOU();
		assertTrue("Error message is not proper or duplicate parameter gets created",operatingUnitPage.verifyErrorMessageForDuplicateParameterInMeasurementParameter(parameterName));
	}
	
	/********************************************************************
   	* Description: Select a customer to add alarm with an existing name
   	* Status: Completed
   	********************************************************************/
	@When("^I select customer to add alarm with an existing name$")
	public void whenISelectCustomerToAddAlarmWithAnExistingName()
	{
		String customer = OperatingUnitCSVReader.getCustomerToVerifyDuplicateParameterForOU();
		operatingUnitPage.selectCustomer(customer);
	}
	
	/********************************************************************
   	* Description: Select a model to add alarm with an existing name
   	* Status: Completed
   	********************************************************************/
	@When("^I select Model to add alarm with an existing name$")
	public void whenISelectModelToAddAlarmWithAnExistingName()
	{
		String Model = OperatingUnitCSVReader.getModelToVerifyDuplicateParameterForOU();
		operatingUnitPage.selectModelToAddOperatingUnit(Model);
	}
	
	/********************************************************************
   	* Description: Select operating to add alarm with an existing name
   	* Status: Completed
   	********************************************************************/
	@When("^I select operating unit to add alarm with an existing name$")
	public void selectOperatingUnitToAddAlarmWithAnExistingName()
	{
		String operatingUnit = OperatingUnitCSVReader.getOUToVerifyDuplicateParameterForOU();
		operatingUnitPage.selectOperatingUnitToAddOperatingUnit(operatingUnit);
	}
	
	/********************************************************************
   	* Description: Add Duplicate Alarm parameter to operating unit
   	* Status: Completed
   	********************************************************************/
	@When("^I add alarm parameter with an existing name$")
	public void addAlarmParameterToOperatingUnitWithAnExistingName()
	{
		String tabName = CSVHelper.getAlarmTab();
		String parameterName = OperatingUnitCSVReader.getAlarmParameterNameToVerifyDuplicateParameterForOU();
		String parameterSelection = OperatingUnitCSVReader.getAlarmParameterToVerifyDuplicateParameterForOU();
		operatingUnitPage.addParameter(tabName, parameterName, parameterSelection);
	}
	
	/********************************************************************
   	* Description: Verify error message and no duplicate parameter gets added
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see error message for the operating unit and no duplicate parameter gets added for alarm$")
	public void verifyErroMessageForOperatingUnitAndNoDuplicateParameterGetsAddedForAlarm()
	{
		String parameterName = OperatingUnitCSVReader.getAlarmParameterNameToVerifyDuplicateParameterForOU();
		assertTrue("Error message is not proper or duplicate parameter gets created",operatingUnitPage.verifyErrorMessageForDuplicateParameterInAlarmParameter(parameterName));
	}
	
	/********************************************************************
   	* Description: Select a customer to add alarm with an existing name
   	* Status: Completed
   	********************************************************************/
	@And("^I select customer to add trips with an existing name$")
	public void whenISelectCustomerToAddTripWithAnExistingName()
	{
		String customer = OperatingUnitCSVReader.getCustomerToVerifyDuplicateParameterForOU();
		operatingUnitPage.selectCustomer(customer);
	}
	
	/********************************************************************
   	* Description: Select a model to add trip with an existing name
   	* Status: Completed
   	********************************************************************/
	@And("^I select Model to add trips with an existing name$")
	public void whenISelectModelToAddTripWithAnExistingName()
	{
		String Model =  OperatingUnitCSVReader.getModelToVerifyDuplicateParameterForOU();
		operatingUnitPage.selectModelToAddOperatingUnit(Model);
	}
	
	/********************************************************************
   	* Description: Select operating to add trip with an existing name
   	* Status: Completed
   	********************************************************************/
	@And("^I select operating unit to add trips with an existing name$")
	public void selectOperatingUnitToAddTripWithAnExistingName()
	{
		String operatingUnit = OperatingUnitCSVReader.getOUToVerifyDuplicateParameterForOU();
		operatingUnitPage.selectOperatingUnitToAddOperatingUnit(operatingUnit);
	}
	
	/********************************************************************
   	* Description: Add Duplicate Trip parameter to operating unit
   	* Status: Completed
   	********************************************************************/
	@When("^I add trips parameter with an existing name$")
	public void addTripParameterToOperatingUnitWithAnExistingName()
	{
		String tabName = CSVHelper.getTripTab();
		String parameterName = OperatingUnitCSVReader.getTripParameterNameToVerifyDuplicateParameterForOU();
		String parameterSelection = OperatingUnitCSVReader.getTripParameterToVerifyDuplicateParameterForOU();
		operatingUnitPage.addParameter(tabName, parameterName, parameterSelection);
	}
	
	/********************************************************************
   	* Description: Verify error message and no duplicate parameter gets added
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see error message for the operating unit and no duplicate parameter gets added for trips$")
	public void verifyErroMessageForOperatingUnitAndNoDuplicateParameterGetsAddedForTrip()
	{
		String parameterName = OperatingUnitCSVReader.getTripParameterNameToVerifyDuplicateParameterForOU();
		assertTrue("Error message is not proper or duplicate parameter gets created",operatingUnitPage.verifyErrorMessageForDuplicateParameterInTripParameter(parameterName));
	}
	
	/********************************************************************
   	* Description: Select a customer to add fault with an existing name
   	* Status: Completed
   	********************************************************************/
	@And("^I select customer to add fault with an existing name$")
	public void whenISelectCustomerToAddFaultWithAnExistingName()
	{
		String customer = OperatingUnitCSVReader.getCustomerToVerifyDuplicateParameterForOU();
		operatingUnitPage.selectCustomer(customer);
	}
	
	/********************************************************************
   	* Description: Select a model to add fault with an existing name
   	* Status: Completed
   	********************************************************************/
	@And("^I select Model to add fault with an existing name$")
	public void whenISelectModelToAddFaultWithAnExistingName()
	{
		String Model =  OperatingUnitCSVReader.getModelToVerifyDuplicateParameterForOU();
		operatingUnitPage.selectModelToAddOperatingUnit(Model);
	}
	
	/********************************************************************
   	* Description: Select operating to add fault with an existing name
   	* Status: Completed
   	********************************************************************/
	@And("^I select operating unit to add fault with an existing name$")
	public void selectOperatingUnitToAddFaultWithAnExistingName()
	{
		String operatingUnit = OperatingUnitCSVReader.getOUToVerifyDuplicateParameterForOU();
		operatingUnitPage.selectOperatingUnitToAddOperatingUnit(operatingUnit);
	}
	
	/********************************************************************
   	* Description: Add Duplicate Fault parameter to operating unit
   	* Status: Completed
   	********************************************************************/
	@When("^I add fault parameter with an existing name$")
	public void addFaultParameterToOperatingUnitWithAnExistingName()
	{
		String tabName = CSVHelper.getFaultsTab();
		String parameterName = OperatingUnitCSVReader.getFaultParameterNameToVerifyDuplicateParameterForOU();
		String parameterSelection = OperatingUnitCSVReader.getFaultParameterToVerifyDuplicateParameterForOU();
		operatingUnitPage.addParameter(tabName, parameterName, parameterSelection);
	}
	
	/********************************************************************
   	* Description: Verify error message and no duplicate parameter gets added
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see error message for the operating unit and no duplicate parameter gets added for fault$")
	public void verifyErroMessageForOperatingUnitAndNoDuplicateParameterGetsAddedForFault()
	{
		String parameterName = OperatingUnitCSVReader.getFaultParameterNameToVerifyDuplicateParameterForOU();
		assertTrue("Error message is not proper or duplicate parameter gets created",operatingUnitPage.verifyErrorMessageForDuplicateParameterInFaultParameter(parameterName));
	}
	
	/********************************************************************
   	* Description: Select a customer to add function states with an existing name
   	* Status: Completed
   	********************************************************************/
	@And("^I select customer to add function states with an existing name$")
	public void whenISelectCustomerToAddFunctionStatesWithAnExistingName()
	{
		String customer = OperatingUnitCSVReader.getCustomerToVerifyDuplicateParameterForOU();
		operatingUnitPage.selectCustomer(customer);
	}
	
	/********************************************************************
   	* Description: Select a model to add function states with an existing name
   	* Status: Completed
   	********************************************************************/
	@And("^I select Model to add function states with an existing name$")
	public void whenISelectModelToAddFunctionStatesWithAnExistingName()
	{
		String Model =  OperatingUnitCSVReader.getModelToVerifyDuplicateParameterForOU();
		operatingUnitPage.selectModelToAddOperatingUnit(Model);
	}
	
	/********************************************************************
   	* Description: Select operating to add function states with an existing name
   	* Status: Completed
   	********************************************************************/
	@And("^I select operating unit to add function states with an existing name$")
	public void selectOperatingUnitToAddFunctionStatesWithAnExistingName()
	{
		String operatingUnit = OperatingUnitCSVReader.getOUToVerifyDuplicateParameterForOU();
		operatingUnitPage.selectOperatingUnitToAddOperatingUnit(operatingUnit);
	}
	
	/********************************************************************
   	* Description: Add Duplicate function states parameter to operating unit
   	* Status: Completed
   	********************************************************************/
	@When("^I add function states parameter with an existing name$")
	public void addFunctionStatesParameterToOperatingUnitWithAnExistingName()
	{
		String tabName = CSVHelper.getFunctionStatesTab();
		String parameterName = OperatingUnitCSVReader.getFunctionStatesParameterNameToVerifyDuplicateParameterForOU();
		String parameterSelection = OperatingUnitCSVReader.getFunctionStatesParameterToVerifyDuplicateParameterForOU();
		operatingUnitPage.addParameter(tabName, parameterName, parameterSelection);
	}
	
	/********************************************************************
   	* Description: Verify error message and no duplicate parameter gets added
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see error message for the operating unit and no duplicate parameter gets added for function states$")
	public void verifyErroMessageForOperatingUnitAndNoDuplicateParameterGetsAddedForFunctionStates()
	{
		String parameterName = OperatingUnitCSVReader.getFunctionStatesParameterNameToVerifyDuplicateParameterForOU();
		assertTrue("Error message is not proper or duplicate parameter gets created",operatingUnitPage.verifyErrorMessageForDuplicateParameterInFunctionStatesParameter(parameterName));
	}
	
	/********************************************************************
   	* Description: Select a customer to add calibration with an existing name
   	* Status: Completed
   	********************************************************************/
	@And("^I select customer to add calibration with an existing name$")
	public void whenISelectCustomerToAddCalibrationWithAnExistingName()
	{
		String customer = OperatingUnitCSVReader.getCustomerToVerifyDuplicateParameterForOU();
		operatingUnitPage.selectCustomer(customer);
	}
	
	/********************************************************************
   	* Description: Select a model to add calibration with an existing name
   	* Status: Completed
   	********************************************************************/
	@And("^I select Model to add calibration with an existing name$")
	public void whenISelectModelToAddCalibrationWithAnExistingName()
	{
		String Model =  OperatingUnitCSVReader.getModelToVerifyDuplicateParameterForOU();
		operatingUnitPage.selectModelToAddOperatingUnit(Model);
	}
	
	/********************************************************************
   	* Description: Select operating to add function states with an existing name
   	* Status: Completed
   	********************************************************************/
	@And("^I select operating unit to add calibration with an existing name$")
	public void selectOperatingUnitToAddCalibrationWithAnExistingName()
	{
		String operatingUnit = OperatingUnitCSVReader.getOUToVerifyDuplicateParameterForOU();
		operatingUnitPage.selectOperatingUnitToAddOperatingUnit(operatingUnit);
	}
	
	/********************************************************************
   	* Description: Add Duplicate function states parameter to operating unit
   	* Status: Completed
   	********************************************************************/
	@When("^I add calibration parameter with an existing name$")
	public void addCalibrationParameterToOperatingUnitWithAnExistingName()
	{
		String tabName = CSVHelper.getCalibrationTab();
		String parameterName = OperatingUnitCSVReader.getCalibrationParameterNameToVerifyDuplicateParameterForOU();
		String value = OperatingUnitCSVReader.getCalibrationValueToVerifyDuplicateParameterForOU();
		String parameterSelection = OperatingUnitCSVReader.getCalibrationParameterToVerifyDuplicateParameterForOU();
		String metricSelection = OperatingUnitCSVReader.getMetricSelectionToVerifyDuplicateParameterForOU();
	    String unit = OperatingUnitCSVReader.getUnitSelectionToVerifyDuplicateParameterForOU();
		operatingUnitPage.addParameterforCalibration(tabName, parameterName, value, parameterSelection, metricSelection, unit);
	}
	
	/********************************************************************
   	* Description: Verify error message and no duplicate parameter gets added
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see error message for the operating unit and no duplicate parameter gets added for calibration$")
	public void verifyErroMessageForOperatingUnitAndNoDuplicateParameterGetsAddedForCalibration()
	{
		String parameterName = OperatingUnitCSVReader.getCalibrationParameterNameToVerifyDuplicateParameterForOU();
		assertTrue("Error message is not proper or duplicate parameter gets created",operatingUnitPage.verifyErrorMessageForDuplicateParameterInCalibrationParameter(parameterName));
	}
	
	/********************************************************************
   	* Description: Select customer>>Select Model>>Select Operating unit to edit the parameter with an existing name
   	* Status: Completed
   	********************************************************************/
	@And("^Select customer>>Select Model>>Select Operating unit to edit the parameter with an existing name$")
	public void selectCustomerSelectModelSelectOperatingUnitToEditParameterWithExitingName()
	{
		String customer = OperatingUnitCSVReader.getCustomerToVerifyDuplicateParameterForOUWhileEditing();
		operatingUnitPage.selectCustomer(customer);
		String Model = OperatingUnitCSVReader.getModelToVerifyDuplicateParameterForOUWhileEditing();
		operatingUnitPage.selectModelToAddOperatingUnit(Model);
		String operatingUnit = OperatingUnitCSVReader.getOUToVerifyDuplicateParameterForOUWhileEditing();
		operatingUnitPage.selectOperatingUnitToAddOperatingUnit(operatingUnit);
	}
	
	/********************************************************************
   	* Description: Edit the parameter with an existing name and verify
   	* Status: Completed
   	********************************************************************/
	@And("^I edit the measurement with an existing name$")
	public void editMeasurementWithAnExistingName()
	{
		String tabName = CSVHelper.getMeasurementTab();
		String parameterName = OperatingUnitCSVReader.getMeausrementNameToVerifyDuplicateParameterForOUWhileEditing();
		String editParameter = OperatingUnitCSVReader.getUpdatedMeausrementNameToVerifyDuplicateParameterForOUWhileEditing();
		String metricSelection = OperatingUnitCSVReader.getMetricSelectionForMeasurementToVerifyDuplicateParameterForOUWhileEditing();
		String unitOfMeasurement = OperatingUnitCSVReader.getUnitForMeasurementToVerifyDuplicateParameterForOUWhileEditing();
		String LCLvalue = OperatingUnitCSVReader.getlclValueForMeasurementToVerifyDuplicateParameterForOUWhileEditing();
		String UCLvalue = OperatingUnitCSVReader.getuclValueForMeasurementToVerifyDuplicateParameterForOUWhileEditing();
		String minRange = OperatingUnitCSVReader.getminRangeForMeasurementToVerifyDuplicateParameterForOUWhileEditing();
		String maxRange = OperatingUnitCSVReader.getMaxRangeForMeasurementToVerifyDuplicateParameterForOUWhileEditing();
		String tagId = OperatingUnitCSVReader.getTagIdForMeasurementToVerifyDuplicateParameterForOUWhileEditing();
		String aggregator = OperatingUnitCSVReader.getAggregatorForMeasurementToVerifyDuplicateParameterForOUWhileEditing();
		String priorityFlag = OperatingUnitCSVReader.getPriorityFlagForMeasurementToVerifyDuplicateParameterForOUWhileEditing();
		String visibilityFlag = OperatingUnitCSVReader.getVisibilityFlagForMeasurementToVerifyDuplicateParameterForOUWhileEditing();
		operatingUnitPage.editParameterForMeasurement(tabName, parameterName, editParameter, metricSelection, unitOfMeasurement, LCLvalue, UCLvalue, minRange, maxRange, tagId, aggregator, priorityFlag, visibilityFlag);
	}
	
	/********************************************************************
   	* Description: Verify error message and no duplicate parameter should get created
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see error message and no duplicate parameter gets created for measurement$")
	public void verifyErrorMessageAndNoDuplicateParametrGetsCreated()
	{
		String parameterName = OperatingUnitCSVReader.getUpdatedMeausrementNameToVerifyDuplicateParameterForOUWhileEditing();
		assertTrue("Error message is not proper and duplicate parameter gets created",operatingUnitPage.verifyErrorMessageForDuplicateParameterInMeasurementParameterWhileUpdating(parameterName));
	}
	
	/********************************************************************
   	* Description: Edit alarm parameter in operating unit with a duplicate
   	* Status: Completed
   	********************************************************************/
	@When("^I edit the alarm with an existing name$")
	public void editAlarmParameterWithAnExistingName()
	{
		String tabName = CSVHelper.getAlarmTab();
		String parameterName = OperatingUnitCSVReader.getAlarmNameToEditToVerifyDuplicateParameterForOUWhileEditing();
		String editParameterName = OperatingUnitCSVReader.getUpdatedAlarmNameToVerifyDuplicateParameterForOUWhileEditing();
		operatingUnitPage.editParameterWithDuplicate(tabName, parameterName, editParameterName);
	}
	
	/********************************************************************
   	* Description: Verify the error message and no duplicate alarm parameter must get added
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see error message and no duplicate parameter gets created for alarm$")
	public void verifyErrorMessageAndNoDuplicateParameterGetsCreated()
	{
		String parameterName= OperatingUnitCSVReader.getUpdatedAlarmNameToVerifyDuplicateParameterForOUWhileEditing();
		assertTrue("Error message is not proper or duplicate parameter gets created",operatingUnitPage.verifyErrorMessageForDuplicateParameterInAlarmParameterWhileUpdating(parameterName));
	}
	
	/********************************************************************
   	* Description: Edit trip parameter in operating unit with a duplicate
   	* Status: Completed
   	********************************************************************/
	@And("^I edit the trip with an existing name$")
	public void editTripParameterWithAnExistingName()
	{
		String tabName = CSVHelper.getTripTab();
		String parameterName = OperatingUnitCSVReader.getTripNameToEditToVerifyDuplicateParameterForOUWhileEditing();
		String editParameterName = OperatingUnitCSVReader.getUpdatedTripNameToVerifyDuplicateParameterForOUWhileEditing();
		operatingUnitPage.editParameterWithDuplicate(tabName, parameterName, editParameterName);
	}
	
	/********************************************************************
   	* Description: Verify the error message and no duplicate trip parameter must get added
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see error message and no duplicate parameter gets created for trip$")
	public void verifyErrorMessageAndNoDuplicateParameterGetsCreatedForTripParameter()
	{
		String parameterName= OperatingUnitCSVReader.getUpdatedTripNameToVerifyDuplicateParameterForOUWhileEditing();
		assertTrue("Error message is not proper or duplicate parameter gets created",operatingUnitPage.verifyErrorMessageForDuplicateParameterInTripParameterWhileUpdating(parameterName));
	}
	
	/********************************************************************
   	* Description: Edit fault parameter in operating unit with a duplicate
   	* Status: Completed
   	********************************************************************/
	@And("^I edit the faults with an existing name$")
	public void editFaultParameterWithAnExistingName()
	{
		String tabName = CSVHelper.getFaultsTab();
		String parameterName = OperatingUnitCSVReader.getFaultNameToEditToVerifyDuplicateParameterForOUWhileEditing();
		String editParameterName = OperatingUnitCSVReader.getUpdatedFaultNameToVerifyDuplicateParameterForOUWhileEditing();
		operatingUnitPage.editParameterWithDuplicate(tabName, parameterName, editParameterName);
	}
	
	/********************************************************************
   	* Description: Verify the error message and no duplicate fault parameter must get added
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see error message and no duplicate parameter gets created for faults$")
	public void verifyErrorMessageAndNoDuplicateParameterGetsCreatedForFaultParameter()
	{
		String parameterName= OperatingUnitCSVReader.getUpdatedFaultNameToVerifyDuplicateParameterForOUWhileEditing();
		assertTrue("Error message is not proper or duplicate parameter gets created",operatingUnitPage.verifyErrorMessageForDuplicateParameterInTripParameterWhileUpdating(parameterName));
	}
	
	/********************************************************************
   	* Description: Edit function states parameter in operating unit with a duplicate
   	* Status: Completed
   	********************************************************************/
	@And("^I edit the function states with an existing name$")
	public void editFunctionStatesParameterWithAnExistingName()
	{
		String tabName = CSVHelper.getFunctionStatesTab();
		String parameterName = OperatingUnitCSVReader.getFunctionStatesNameToEditToVerifyDuplicateParameterForOUWhileEditing();
		String editParameterName = OperatingUnitCSVReader.getUpdatedFunctionStatesNameToVerifyDuplicateParameterForOUWhileEditing();
		operatingUnitPage.editParameterWithDuplicate(tabName, parameterName, editParameterName);
	}
	
	/********************************************************************
   	* Description: Verify the error message and no duplicate fault parameter must get added
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see error message and no duplicate parameter gets created for function states$")
	public void verifyErrorMessageAndNoDuplicateParameterGetsCreatedForFunctionStatesParameter()
	{
		String parameterName= OperatingUnitCSVReader.getUpdatedFunctionStatesNameToVerifyDuplicateParameterForOUWhileEditing();
		assertTrue("Error message is not proper or duplicate parameter gets created",operatingUnitPage.verifyErrorMessageForDuplicateParameterInFunctionStatesParameterWhileUpdating(parameterName));
	}
	
	/********************************************************************
   	* Description: Edit function states parameter in operating unit with a duplicate
   	* Status: Completed
   	********************************************************************/
	@And("^I edit the calibration with an existing name$")
	public void editCalibrationParameterWithAnExistingName()
	{
		String tabName = CSVHelper.getCalibrationTab();
		String parameterName = OperatingUnitCSVReader.getCalibrationNameToEditToVerifyDuplicateParameterForOUWhileEditing();
		String editParameterName = OperatingUnitCSVReader.getUpdatedCalibrationNameToVerifyDuplicateParameterForOUWhileEditing();
		operatingUnitPage.editParameterWithDuplicate(tabName, parameterName, editParameterName);
	}
	
	/********************************************************************
   	* Description: Verify the error message and no duplicate fault parameter must get added
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see error message and no duplicate parameter gets created for calibration$")
	public void verifyErrorMessageAndNoDuplicateParameterGetsCreatedForCalibrationParameter()
	{
		String parameterName= OperatingUnitCSVReader.getUpdatedCalibrationNameToVerifyDuplicateParameterForOUWhileEditing();
		assertTrue("Error message is not proper or duplicate parameter gets created",operatingUnitPage.verifyErrorMessageForDuplicateParameterInFunctionStatesParameterWhileUpdating(parameterName));
	}
	
	/********************************************************************
   	* Description: Select customer>>Select Model>>Select Operating unit to update visibility and priority flag for measurement parameter
   	* Status: Completed
   	********************************************************************/
	@And("^Select customer>>Select Model>>Select Operating unit to update visibility and priority flag for measurement parameter$")
	public void selectCustomerSelectModelSelectOperatingUnitToUpdateVisibilityAndPriorityFlag()
	{
		String customer = OperatingUnitCSVReader.getCustomerToUpdateVisibilityAndPriorityFlagForParameter();
		operatingUnitPage.selectCustomer(customer);
		String Model = OperatingUnitCSVReader.getModelToUpdateVisibilityAndPriorityFlagForParameter();
		operatingUnitPage.selectModelToAddOperatingUnit(Model);
		String operatingUnit = OperatingUnitCSVReader.getOperatingUnitToUpdateVisibilityAndPriorityFlagForParameter();
		operatingUnitPage.selectOperatingUnitToAddOperatingUnit(operatingUnit);
	}
	
	/********************************************************************
   	* Description: Update visibility and priority flag for measurement parameter
   	* Status: Completed
   	********************************************************************/
	@And("^I update visibility and priority flag for measurement parameter$")
	public void updateVisibilityAndPriorityFlagForMeasurementParameter()
	{
		String parameterName = OperatingUnitCSVReader.getMeasurementParameterToUpdateVisibilityAndPriorityFlag();
		String priorityFlag = OperatingUnitCSVReader.getPriorityFlagToUpdateMeasurement();
		String visibilityFlag = OperatingUnitCSVReader.getVisibilityFlagToUpdateMeasurement();
		String tabname = CSVHelper.getMeasurementTab();
		operatingUnitPage.updateVisibilityAndPriorityForParameter(tabname,parameterName, priorityFlag, visibilityFlag);
	}
	
	/********************************************************************
   	* Description: Visibility and priority flag for measurement parameter should get updated
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the visibility and priority flag gets updated$")
	public void verifyTheUpdatedVisibilityAndPriorityFlag()
	{
		String parameterName = OperatingUnitCSVReader.getMeasurementParameterToUpdateVisibilityAndPriorityFlag();
		String priorityFlag = OperatingUnitCSVReader.getPriorityFlagToUpdateMeasurement();
		String visibilityFlag = OperatingUnitCSVReader.getVisibilityFlagToUpdateMeasurement();
		assertTrue("Flag is not updated properly",operatingUnitPage.verifyUpdatedVisibilityAndPriorityFlag(parameterName, priorityFlag, visibilityFlag));
	}
	
	/********************************************************************
   	* Description: Select customer>>Select Model>>Select Operating unit to edit the parameter with blank
   	* Status: Completed
   	********************************************************************/
	@And("^Select customer>>Select Model>>Select Operating unit to edit the parameter with a blank$")
	public void selectCustomerSelectModelSelectOperatingUnitToEditTheParameterWithBlank()
	{
		String customer = OperatingUnitCSVReader.getCustomerToEditTheParameterWithBlank();
		operatingUnitPage.selectCustomer(customer);
		String Model = OperatingUnitCSVReader.getModelToEditTheParameterWithBlank();
		operatingUnitPage.selectModelToAddOperatingUnit(Model);
		String operatingUnit = OperatingUnitCSVReader.getOperatingUnitToEditTheParameterWithBlank();
		operatingUnitPage.selectOperatingUnitToAddOperatingUnit(operatingUnit);
	}
	
	/********************************************************************
   	* Description: Edit the measurement parameter with blank
   	* Status: Completed
   	********************************************************************/
	@And("^I edit the measurement parameter with a blank$")
	public void editMeasurementParameterWithBlank()
	{
		String tabname = CSVHelper.getMeasurementTab();
		String parameterName = OperatingUnitCSVReader.getMeasurementParameterToVerifyBlank();
		operatingUnitPage.editParameterWithBlank(tabname, parameterName);
	}
	
	/********************************************************************
   	* Description: Verify the submit button is getting enabled
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the submit button getting disabled$")
	public void thenICanSeeTheSubmitButtonGettingDisabled()
	{
		assertTrue("Submit Button is enabled",operatingUnitPage.verifySubmitButtonGettingDisabled());
	}
	
	/********************************************************************
   	* Description: Edit the alarm parameter with blank
   	* Status: Completed
   	********************************************************************/
	@And("^I edit the alarm parameter with a blank$")
	public void editAlarmParameterWithBlank()
	{
		String tabname = CSVHelper.getAlarmTab();
		String parameterName = OperatingUnitCSVReader.getAlarmParameterToVerifyBlank();
		operatingUnitPage.editParameterWithBlank(tabname, parameterName);
	}
	
	/********************************************************************
   	* Description: Edit the trip parameter with blank
   	* Status: Completed
   	********************************************************************/
	@And("^I edit the trip parameter with a blank$")
	public void editTripParameterWithBlank()
	{
		String tabname = CSVHelper.getTripTab();
		String parameterName = OperatingUnitCSVReader.getTripParameterToVerifyBlank();
		operatingUnitPage.editParameterWithBlank(tabname, parameterName);
	}
	
	/********************************************************************
   	* Description: Edit the fault parameter with blank
   	* Status: Completed
   	********************************************************************/
	@And("^I edit the fault parameter with a blank$")
	public void editFaultParameterWithBlank()
	{
		String tabname = CSVHelper.getFaultsTab();
		String parameterName = OperatingUnitCSVReader.getFaultParameterToVerifyBlank();
		operatingUnitPage.editParameterWithBlank(tabname, parameterName);
	}
	
	/********************************************************************
   	* Description: Edit the function states parameter with blank
   	* Status: Completed
   	********************************************************************/
	@And("^I edit the function states parameter with a blank$")
	public void editFunctionStatesParameterWithBlank()
	{
		String tabname = CSVHelper.getFunctionStatesTab();
		String parameterName = OperatingUnitCSVReader.getFunctionStatesParameterToVerifyBlank();
		operatingUnitPage.editParameterWithBlank(tabname, parameterName);
	}
	
	/********************************************************************
   	* Description: Edit the calibration parameter with blank
   	* Status: Completed
   	********************************************************************/
	@And("^I edit the calibration parameter with a blank$")
	public void editCalibrationParameterWithBlank()
	{
		String tabname = CSVHelper.getCalibrationTab();
		String parameterName = OperatingUnitCSVReader.getCalibrationParameterToVerifyBlank();
		operatingUnitPage.editParameterWithBlank(tabname, parameterName);
	}
	
	/********************************************************************
   	* Description: Select customer>>Select Model>>Select Operating unit to edit the parameter with blank
   	* Status: Completed
   	********************************************************************/
	@And("^Select customer>>Select Model>>Select Operating unit and go to Measurment Tab$")
	public void SelectOperatingUnitAndGoToMeasurmenTab()
	{
		String customer = OperatingUnitCSVReader.getCustomerToEditTheParameterWithBlank();
		operatingUnitPage.selectCustomer(customer);
		String Model = OperatingUnitCSVReader.getModelToEditTheParameterWithBlank();
		operatingUnitPage.selectModelToAddOperatingUnit(Model);
		String operatingUnit = OperatingUnitCSVReader.getOperatingUnitToEditTheParameterWithBlank();
		operatingUnitPage.selectOperatingUnitToAddOperatingUnit(operatingUnit);
	}
	
	/********************************************************************
   	* Description: Select customer>>Select Model>>Select Operating unit to edit the parameter with blank
   	* Status: Completed
   	********************************************************************/
	
	@And("^I Update the visibility and priority flag directlty by clicking on the checkbox$")
    public void i_update_the_visibility_and_priority_flag_directlty_by_clicking_on_the_checkbox() {
		String tabname = CSVHelper.getMeasurementTab();
		String MeasurementParameter = OperatingUnitCSVReader.getMeasurementNameForPriorityAndVisibilityCheck();
		String priorityFlag = OperatingUnitCSVReader.getPriorityFlag();
		String visibilityFlag = OperatingUnitCSVReader.getVisibilityFlag();
		operatingUnitPage.updateTheVisibilityAndPriorityFlag(tabname, priorityFlag, MeasurementParameter, visibilityFlag);

    }
	

	/********************************************************************
   	* Description: Verify the submit button is getting enabled
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the checkboxes are getting checked$")
	public void thenICanSeeTheCheckboxesAreGettingChecked()
	{
		String MeasurementParameter = OperatingUnitCSVReader.getMeasurementNameForPriorityAndVisibilityCheck();
		assertTrue("Click check box functionality not working",operatingUnitPage.verifyCheckBoxesAreSelecting(MeasurementParameter ));
	}
	
	@And("^Select customer>>Select Model>>Select Operating unit to add the subsystem for a disabled OU$")
	public void selectCustomerSelectModelSelectOperatingUnitToAddSubsystemForADisabledOU()
	{
		String customer = OperatingUnitCSVReader.getCustomerToAddSubsystemForDisabledOU();
		operatingUnitPage.selectCustomer(customer);
		String Model = OperatingUnitCSVReader.getModelToAddSubsystemForDisabledOU();
		operatingUnitPage.selectModelToAddOperatingUnit(Model);
//		String operatingUnit = OperatingUnitCSVReader.getOperatingUnitToAddSubsystemForDisabledOU();
//		operatingUnitPage.selectOperatingUnitToAddOperatingUnit(operatingUnit);
	} 
	
	/********************************************************************
   	* Description: Add subsystem for a disabled OU
   	* Status: Completed
   	********************************************************************/
	@And("^I add susbsystem for a disabled OU$")
	public void addSubystemForADisabledOU()
	{
		String OUName = OperatingUnitCSVReader.getOperatingUnitToAddSubsystemForDisabledOU();
		String modelName = OperatingUnitCSVReader.getmodelNameToAddSubsystemForDisabledOU();
		String gateWay = OperatingUnitCSVReader.getgatewayToAddSubsystemForDisabledOU();
		String count = OperatingUnitCSVReader.getCountToAddSubsystemForDisabledOU();
		operatingUnitPage.addSubsystemToADisabledOU(OUName, modelName, gateWay, count);
	}
	
	/********************************************************************
   	* Description: Verify error message
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see error message for it$")
	public void verifyErrorMessageToAddSubsystemForDisabledOU()
	{
		assertTrue("Dialog box is not displayed",operatingUnitPage.verifyErrorMessageWhileAddingSubsystemForDisabledOU());
	}
}
