package com.zysk.cerebra.steps;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import com.zysk.cerebra.csv_reader.CSVHelper;
import com.zysk.cerebra.csv_reader.DigitalMachineCSVReader;
import com.zysk.cerebra.csv_reader.ManufacturerAndModelCSVReader;
import com.zysk.cerebra.pages.DigitalMachinePage;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class DigitalMachineSteps {
	
	DigitalMachinePage digitalmachinepage;
	
	/********************************************************************
   	* Description: Select the Digital machine
   	* Status: Completed
   	********************************************************************/
	
	 @And("^I Select DigitalMachine$")
	    public void iSelectDigitalMachine(){
		 digitalmachinepage.clickOnDigitalMachine();	       
	    }
	 
    /********************************************************************
   	* Description: Customer list should be displayed
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see DigitalMachine page$")
	public void thenCustomerListWillBeDisplayed()
	{
		String expUrl = CSVHelper.getBaseUrl()+ DigitalMachineCSVReader.getDMUrl();
		assertTrue("Digital machine page with all the elements is not displayed", digitalmachinepage.verifyDigitalMachinePage(expUrl));
	}
	
	/********************************************************************
   	* Description: Select the Equipment
   	* Status: Completed
   	********************************************************************/
	 @And("^I select the Equipment$")
	 public void iSelectTheEquipment()
	{
		String EquipmentName = DigitalMachineCSVReader.getEquipmentName();
		digitalmachinepage.selectEquipment(EquipmentName);
	}
	
	/********************************************************************
   	* Description: Model List will be displayed
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the Model list$")
	public void iCanSeeTheModeList()
	{
		String expUrl= CSVHelper.getBaseUrl()+DigitalMachineCSVReader.getDigitalMachineModelUrl();
		String EquipmentName = DigitalMachineCSVReader.getEquipmentName();
		assertTrue("Model page is not loaded with all the elements",digitalmachinepage.verifyModelPage(expUrl, EquipmentName));
	}

	/********************************************************************
   	* Description: Select the Model
   	* Status: Completed
   	********************************************************************/
	 @And("^I select the Model$")
	    public void i_select_the_model() {
	        String modelFromCSV = DigitalMachineCSVReader.getModel();
			digitalmachinepage.selectTheModel(modelFromCSV );
	    }
	/********************************************************************
   	* Description: Digital machine page should be displayed
   	* Status: Completed
   	********************************************************************/ 
	 @Then("^I can see digital Machine page$")
	    public void i_can_see_digital_machine_page() {
		 String expUrl= CSVHelper.getBaseUrl()+DigitalMachineCSVReader.getDigitalMachineDetailsListlUrl();
			assertTrue("Digital Machine page is not loaded with all the elements",digitalmachinepage.verifyModelSelectedInDigitalMachinePage(expUrl)); 
	    }
	/********************************************************************
   	* Description: Select the Model
   	* Status: Completed
   	********************************************************************/
	 @And("^I add the Digital Machine$")
	    public void i_add_the_digital_machine() {
		 String DMName = DigitalMachineCSVReader.getDMName();
		digitalmachinepage.addDigitalMachine(DMName );	       
	    }
	 
	 /********************************************************************
	 * Description: Select the Model
	 * Status: Completed
	 ********************************************************************/
	 @Then("^I can see the added digital machine$")
	    public void i_can_see_the_added_digital_machine()  {
		 String DigitalmachineName = DigitalMachineCSVReader.getDMName();
		 assertTrue("Digital Machine page is not loaded with all the elements",digitalmachinepage.verifyAddedDigitalMachine(DigitalmachineName));        
	    }
	 /********************************************************************
	  * Description: Edit Digital Machine
	  * Status: Completed
	  ********************************************************************/
	 
	 @And("^I edit the Digital Machine$")
	 public void iEditTheDigitalMachine() {
		String existingDigitalMachineToEdit = DigitalMachineCSVReader.getDMName();
		String DigitalMachineToUpdate=DigitalMachineCSVReader.getUpdatedName();
		digitalmachinepage.editDigitalMachine(existingDigitalMachineToEdit, DigitalMachineToUpdate);
	 }
	 
	 /********************************************************************
	  * Description: Verify Digital machine updated successfully
	  * Status: Completed
	  ********************************************************************/
	 @Then("^I can see digital machine updated$")
	 public void iCanSeeDigitalMachineUpdated() {
		 String UpdatedDigitalMachineName = DigitalMachineCSVReader.getUpdatedName();
		 assertTrue("Digital Machine Name is not updated",digitalmachinepage.iCanSeeTheUpdatedDMName(UpdatedDigitalMachineName ));
		 
	 }
	 
	 /********************************************************************
	  * Description: Disable Digital Machine
	  * Status: Completed
	  ********************************************************************/
	 @And("^I select and Disable the Digital Machine$")
	 public void iSelectAndDisableTheDigitalMachine() {
		 String DigitalMachineToDisable = DigitalMachineCSVReader.getDMName();
		digitalmachinepage.disableDigitalMachine(DigitalMachineToDisable);	 
	 }
	 
	 /********************************************************************
	  * Description:Verify Digital Machine Disabled
	  * Status: Completed
	  ********************************************************************/
	 @Then("^I can see Digital Machine Disabled$")
	 public void iCanSeeDigitalMachineDisabled() {
		 String DigitalMachineToDisable = DigitalMachineCSVReader.getDMName();
		 assertTrue("Digital Machine Not Disabled",digitalmachinepage.digtalMachineDisabled(DigitalMachineToDisable)); 
	 }
	 
	 /********************************************************************
	  * Description: Enable Digital Machine
	  * Status: Completed
	  ********************************************************************/
	 @And("^I select and Enable the Digital Machine$")
	 public void iSelectAndEnableTheDigitalMachine() {
		 String DigitalMachineToEnable = DigitalMachineCSVReader.getDMName();
			digitalmachinepage.enableDigitalMachine(DigitalMachineToEnable);	 	 
	 }
	 
	 /********************************************************************
	  * Description:Verify Digital Machine Enabled
	  * Status: Completed
	  ********************************************************************/
	 @Then("^I can see Digital Machine Enabled$")
	 public void iCanSeeDigitalMachineEnabled() {
		 String DigitalMachineToEnable = DigitalMachineCSVReader.getDMName();
		 assertTrue("Digital Machine Not Enabled",digitalmachinepage.digtalMachineEnabled(DigitalMachineToEnable)); 
	 }
	 
	 /********************************************************************
	  * Description: Enable Digital Machine
	  * Status: Completed
	  ********************************************************************/
	 @And("^I Delete the Digital Machine$")
	 public void iDeleteTheDigitalMachine() {
		 
			String DigitalMachineToDelete = DigitalMachineCSVReader.getUpdatedName();
			digitalmachinepage.deleteDigitalMachine(DigitalMachineToDelete);	 	 
	 }
	 
	 /********************************************************************
	  * Description:Verify Digital Machine Enabled
	  * Status: Completed
	  ********************************************************************/
	 @Then("^I can see Digital Machine Deleted$")
	 public void iCanSeeDigitalMachineDeleted() {
		 String DigitalMachineToDelete = DigitalMachineCSVReader.getUpdatedName();
		 assertTrue("Digital Machine not deleted",digitalmachinepage.digtalMachineDeletedSuccessfully(DigitalMachineToDelete)); 
	 }
	 
	 /********************************************************************
	  * Description: Edit digital machine with existing name
	  * Status: Completed
	  ********************************************************************/
	 @And("^I Add the digital machine with the existing name$")
	 public void iAddTheDigitalMachineWithTheExistingName() {
		String DMName =  DigitalMachineCSVReader.getDMName();
		digitalmachinepage.addDigitalMachine(DMName);
		 
	 }
	 
	 /********************************************************************
	  * Description:Verify Digital Machine not edited
	  * Status: Completed
	  ********************************************************************/
	 @Then("^I can see digital machine not updated$")
	 public void iCanSeeDigitalMachineNotUpdated() {
		 String ExistingName =  DigitalMachineCSVReader.getDMName();
		 assertTrue("Digital Machine Updated successsfully",digitalmachinepage.digitalMachineNotUpdated(ExistingName));
		 
	 }
	 
	 /********************************************************************
	  * Description: Select digital machine 
	  * Status: Completed
	  ********************************************************************/
	 @And("^I select the Digital machine$")
	 public void iSelectTheDigitalMachine() {
		 String ExistingName =  DigitalMachineCSVReader.getUpdatedName();
		 digitalmachinepage.selectDigitalMachine(ExistingName);
		 
	 }
	 
	 /********************************************************************
	  * Description:Verify Digital Machine selected in subsystem
	  * Status: Completed
	  ********************************************************************/
	 @Then("^I can see the subsystem details$")
	 public void iCanSeeTheSubsystemDetails() {
		 String expUrl = CSVHelper.getBaseUrl()+DigitalMachineCSVReader.getDMSubsystemURL();
		 String SubsystemName =  DigitalMachineCSVReader.getDMName();
		assertTrue("Digital Machine Not selected and subsystems list not displaying",digitalmachinepage.subSystemDisplayingAfterSelectDigitalMacine(expUrl,SubsystemName ));
	 }
	 
	 /********************************************************************
	  * Description: Add subsystem
	  * Status: Completed
	  ********************************************************************/
	 @And("^I add the new subsystem$")
	 public void iAddTheNewSubsystem() {
		 String subsystemName = DigitalMachineCSVReader.getAddSubSystem();
		digitalmachinepage.addSubsystem(subsystemName);
	 }
	 
	 /********************************************************************
	  * Description:Verify subsystem added successfully
	  * Status: Completed
	  ********************************************************************/
	 @Then("^I can see subsystem added$")
	 public void iCanSeeSubsystemAdded() {
		 String subsystemName = DigitalMachineCSVReader. getAddSubSystem();
		 assertTrue("Subsystem not added",digitalmachinepage.subSystemAddedSuccessfully(subsystemName));
	 }
	 
	 /********************************************************************
	  * Description: Select subsystem
	  * Status: Completed
	  ********************************************************************/
	 @And("^I select SubSystem$")
	 public void iSelectSubsystem() {
		 String SsystemName = DigitalMachineCSVReader.getAddSubSystem();
		digitalmachinepage.selectSubsystem(SsystemName);
	 }
	 
	 /********************************************************************
	  * Description:Verify Operating Characteristics page displaying
	  * Status: Completed
	  ********************************************************************/
	 @Then("^I can see operating characteristics$")
		 public void iCanSeeOperatingCharacteristics() {
		 String expUrl = CSVHelper.getBaseUrl()+DigitalMachineCSVReader.getOperatingCharacteristicsURL();
		 assertTrue("OperaticCharacteristics page not displaying with all the details",digitalmachinepage.displayOperatingCharacteristics(expUrl));
	 }
	 
	 /********************************************************************
	  * Description: Select up to subsystem
	  * Status: Completed
	  ********************************************************************/
	  @And("^I Select DigitalMachine>>I select the Equipment>>I select the Model>>I select the Digital machine>>I select Subsytem$")
	  public void selectDigitalMachineEquipmentModelDigitalmachineSubsytem() {
		 digitalmachinepage.clickOnDigitalMachine();
		 String EquipmentName = DigitalMachineCSVReader.getEquipmentName();
		 digitalmachinepage.selectEquipment(EquipmentName);
		 String modelFromCSV = DigitalMachineCSVReader.getModel();
	     digitalmachinepage.selectTheModel(modelFromCSV );
	     String ExistingName =  DigitalMachineCSVReader.getDMName();
		 digitalmachinepage.selectDigitalMachine(ExistingName);
		 String SsystemName = DigitalMachineCSVReader.getDMName();
		 digitalmachinepage.selectSubsystem(SsystemName);
		 
	 }
	 
	 /********************************************************************
	  * Description: Select operating unit check boxes
	  * Status: Completed
	  ********************************************************************/
	 @And("^I select the operacting characteristics checkboxes$")
	 public void selectOperatingCharacteristicsCheckboxes() {
		 digitalmachinepage.selectOCCheckboxes();
		 
	 }
	 /********************************************************************
	  * Description: 
	  * Status: Completed
	  ********************************************************************/ 
	 @Then("^I Can See measurements are mapped to subsystem$")
	    public void i_can_see_measurements_are_mapped_to_subsystem()  {
	     assertTrue("Measurements are not mapped to Subsytem", digitalmachinepage.verifyMeasurementsMappedToSubsystem());
	    }
	 
	 /********************************************************************
	  * Description: 
	  * Status: Completed
	  ********************************************************************/ 
	  @And("^I Unslect the operacting characteristics checkboxes$")
	    public void i_unslect_the_operacting_characteristics_checkboxes() {
	        digitalmachinepage.unSelectOperaticUnitCheckboxes();
	    }
	 /********************************************************************
	  * Description: 
	  * Status: Completed
	  ********************************************************************/ 
	  @Then("^I Can See measurements are mapped to subsystem after unselect the operacting characteristics$")
	    public void i_can_see_measurements_are_mapped_to_subsystem_after_unselect_the_operacting_characteristics() {
		  assertTrue("Measurements are not mapped to Subsytem", digitalmachinepage.verifyMeasurementsMappedToSubsystemAfterUnselctOUCheckboxes());
	    }

	 /********************************************************************
	  * Description: Select up to digital machine
	  * Status: Completed
	  ********************************************************************/
	  @And("^I Select DigitalMachine>>I select the Equipment>>I select the Model>>I select the Digital machine$")
	  public void selectDigitalMachineEquipmentModelDigitalmachine() {
		 digitalmachinepage.clickOnDigitalMachine();
		 String EquipmentName = DigitalMachineCSVReader.getEquipmentName();
		 digitalmachinepage.selectEquipment(EquipmentName);
		 String modelFromCSV = DigitalMachineCSVReader.getModel();
	     digitalmachinepage.selectTheModel(modelFromCSV );
	     String ExistingName =  DigitalMachineCSVReader.getDMName();
		 digitalmachinepage.selectDigitalMachine(ExistingName);
	  }
	  /********************************************************************
	  * Description: add subsystem in levels
	  * Status: Completed
	  ********************************************************************/
	  @And("^I add subsystem in levels$")
	  public void addSubsystemInLevels() {
		  String subsystemName = DigitalMachineCSVReader.getDMName();
		String NewSubsystemToAdd = DigitalMachineCSVReader.getsubSystemInLevel();
		digitalmachinepage.addsubSystemToLevel(subsystemName,NewSubsystemToAdd);
	  }
	  
	  /********************************************************************
	  * Description: 
	  * Status: Completed
	  ********************************************************************/
	  @Then("^I can see subsystem added in level$")
	  public void iCanSeeSubsystemAddedToLevel() {
		 String subsystemName = DigitalMachineCSVReader.getsubSystemInLevel();
		 assertTrue("Subsystem not added to levels",digitalmachinepage.subSystemAddedToLevel(subsystemName));
	  }
	  /********************************************************************
	  * Description: 
	  * Status: Completed
	  ********************************************************************/
	  @And("^I delete subsystem in levels$")
	  public void deleteSubsystemInLevels() {
		  String subsystemName = DigitalMachineCSVReader.getsubSystemInLevel();
		digitalmachinepage.deleteSubSystem(subsystemName);
	  }
	  
	  /********************************************************************
	  * Description: 
	  * Status: Completed
	  ********************************************************************/
	  @Then("^I can see subsystem deletd in level$")
	  public void iCanSeeSubsystemDeletedInLevel() {
		 String subsystemName = DigitalMachineCSVReader.getsubSystemInLevel();
		 assertTrue("Subsystem not not deleted levels",digitalmachinepage.subSystemDeletedInLevel(subsystemName));
	  }
	  
	  /********************************************************************
	  * Description: 
	  * Status: Completed
	  ********************************************************************/
	  @And("^I search for Operating characteristics with valid value")
	  public void iSearchForOPCWithValidData() {
		  
		  String NameToSearch = DigitalMachineCSVReader.getValidOperaticUnitTOSearch();
		digitalmachinepage.searchForOperatingCharateristics(NameToSearch );
		  
	  }
	  
	  /********************************************************************
	  * Description: 
	  * Status: Completed
	  ********************************************************************/
	  @Then("^I can see search realated list$")
	  public void iCanSeeSearchReletedList() {
		  String NameToSearch = DigitalMachineCSVReader.getValidOperaticUnitTOSearch();
		 assertTrue("No result found",digitalmachinepage.operatingCharacteristicsSearched(NameToSearch));
		  
	  }
	  
	  /********************************************************************
	  * Description: 
	  * Status: Completed
	  ********************************************************************/
	  @And("^I search for Operating characteristics with Invalid value$")
	    public void i_search_for_operating_characteristics_with_invalid_value()  {
		  String NameToSearch = DigitalMachineCSVReader.getInValidOperaticUnitTOSearch();
			digitalmachinepage.searchForOperatingCharateristics(NameToSearch );
	    }
	  /********************************************************************
	  * Description: 
	  * Status: Completed
	  ********************************************************************/
	  @Then("^I can not see search realated list$")
	    public void i_can_not_see_search_realated_list()  {
		  String NameToSearch = DigitalMachineCSVReader.getInValidOperaticUnitTOSearch();
		  assertTrue("Result found",digitalmachinepage.operatingCharacteristicsSearchedForInvalidData(NameToSearch));
	    }
	  /********************************************************************
	  * Description: 
	  * Status: Completed
	  ********************************************************************/
	  @And("^I add value to Subsystem Name text field and click on cancel button")
	  public void iAddValueTosubsystemNameTextFieldAndClickOnCancelButton() {
		  String subsystemName = DigitalMachineCSVReader.getselectSubSystemAddInLevel();
			String subsystemNameToVerifyCancelButton = DigitalMachineCSVReader.getsubSystemInLevel();
		  digitalmachinepage.addValueToSubsystemTextField(subsystemName,subsystemNameToVerifyCancelButton);
	  }
	  
	  /********************************************************************
	  * Description: 
	  * Status: Completed
	  ********************************************************************/
	  @And("^I can see Subsystem Not added")
	  public void iCanSeeSubsystemNotAdded() {
		  assertTrue("Subsystem not added to levels",digitalmachinepage.subSystemNotAdded());
		  
	  }
	  /********************************************************************
	  * Description: 
	  * Status: Completed
	  ********************************************************************/
	  @And("^I add duplicate Subsystem Name")
	  public void iAddDuplicateSubsystemName() {
		  String subsystemName = DigitalMachineCSVReader.getDMName();
			String subsystemNameToduplicateName = DigitalMachineCSVReader.getDMName();
		  digitalmachinepage.addDuplicateSubsystemName(subsystemName,subsystemNameToduplicateName);
		  
	  }
	  
	  /********************************************************************
	  * Description: 
	  * Status: Completed
	  ********************************************************************/
	  @And("^I can see duplicate Subsystem added")
	  public void iCanSeeDuplicateSubsystemAdded() {
		  String subsystemName = DigitalMachineCSVReader.getDMName();
		  assertTrue("Duplicate Subsystem not added to levels",digitalmachinepage.duplicateSubSystemAdded(subsystemName));
		  
	  }
	  
	  /********************************************************************
	   * Description: select Digital Machine
	   * Status: Completed
	   ********************************************************************/
	@And("^I select Digital Machine$")
	    public void i_select_digital_machine()
	    {
	digitalmachinepage.clickDigitalMachine();
	    }

	/********************************************************************
	   * Description: search by entering valid data in search text field
	   * Status: Completed
	********************************************************************/
	@And("^I search by entering valid data in search text field$")
	    public void i_search_by_entering_valid_data_in_search_text_field()
	    {
         	String DataToSearch = DigitalMachineCSVReader.getDataToSearch();
	       digitalmachinepage.searchByValidData(DataToSearch);
	    }

	/********************************************************************
	   * Description: Verify list of machinename displayed
	   * Status: Completed
	********************************************************************/
	@Then("^Verify list of machinename displayed$")
	    public void verify_list_of_machinename_displayed()
	    {
	assertTrue("Related machine unit is not displayed", digitalmachinepage.VerifySearchByValidData());
	    }

	/********************************************************************
	   * Description: search by entering Invalid data in search text field
	   * Status: Completed
	********************************************************************/
	@And("^I search by entering Invalid data in search text field$")
	    public void i_search_by_entering_invalid_data_in_search_text_field()
	{
		String DataToSearch = DigitalMachineCSVReader.getInvalidDataToSearch();
	       digitalmachinepage.searchByInvalidData(DataToSearch);
	}

	/********************************************************************
	   * Description: Verify list of machinename not displayed
	   * Status: Completed
	********************************************************************/
	@Then("^Verify list of machinename not displayed$")
	    public void verify_list_of_machinename_not_displayed()
	    {
	assertFalse("Related machine unit is displayed", digitalmachinepage.VerifySearchByInValidData());
	    }

	/********************************************************************
	   * Description: click on any Equipment
	   * Status: Completed
	********************************************************************/
	@And("^I click on any Equipment$")
	    public void i_click_on_any_equipment()
	    {
	digitalmachinepage.clickOnEquipment();
	    }

	/********************************************************************
	   * Description: search by entering valid data in search text field in the models page
	   * Status: Completed
	********************************************************************/
	@And("^I search by entering valid data in search text field in the models page$")
	    public void i_search_by_entering_valid_data_in_search_text_field_in_the_models_page()
	    {
	String ValidDataToSearchModel = DigitalMachineCSVReader.getValidDataToSearchModel();
	digitalmachinepage.searchByValidDataForModels(ValidDataToSearchModel );
	    }

	/********************************************************************
	   * Description: Verify list of models displayed in the models page
	   * Status: Completed
	********************************************************************/
	@Then("^Verify list of models displayed in the models page$")
	    public void verify_list_of_models_displayed_in_the_models_page()
	{
	assertTrue("Related models is not displayed",digitalmachinepage.VerifySearchByValidDataForModels());
	}

	/********************************************************************
	   * Description: search by entering Invalid data in search text field in the models page
	   * Status: Completed
	********************************************************************/
	@And("^I search by entering Invalid data in search text field in the models page$")
	    public void i_search_by_entering_invalid_data_in_search_text_field_in_the_models_page()
	    {
		String InValidDataToSearchModel = DigitalMachineCSVReader.getInValidDataToSearchModel();
		digitalmachinepage.searchByInValidDataForModels(InValidDataToSearchModel );
	    }

	/********************************************************************
	   * Description: Verify list of models not displayed in the models page
	   * Status: Completed
	********************************************************************/
	@Then("^Verify list of models not displayed in the models page$")
	    public void verify_list_of_models_not_displayed_in_the_models_page()
	    {
	assertFalse("Related model is displayed", digitalmachinepage.VerifySearchByInValidDataForModels());
	    }

	/********************************************************************
	   * Description: click on any Model
	   * Status: Completed
	********************************************************************/
	@And("^I click on any Model$")
	    public void i_click_on_any_model()
	    {
	digitalmachinepage.clickOnModel();
	    }

	/********************************************************************
	   * Description: search by entering valid data in search text field in digital machine sub page
	   * Status: Completed
	********************************************************************/
	@And("^I search by entering valid data in search text field in digital machine sub page$")
	    public void i_search_by_entering_valid_data_in_search_text_field_in_digital_machine_sub_page()
	    {
	String ValidDigitalMachineNameToSearchInDigitalMachineTab = DigitalMachineCSVReader.getValidDigitalMachineNameToSearchInDigitalMachineTab();
	digitalmachinepage.searchByValidDataForDigitalMachineSubPage(ValidDigitalMachineNameToSearchInDigitalMachineTab );
	    }

	/********************************************************************
	   * Description: Verify list of digital machines displayed in the digital machine sub page
	   * Status: Completed
	********************************************************************/
	@Then("^Verify list of digital machines displayed in the digital machine sub page$")
	    public void verify_list_of_digital_machines_displayed_in_the_digital_machine_sub_page()
	    {
	assertTrue("Related digital machines is not displayed",digitalmachinepage.VerifySearchByValidDataForDigitalMachineSubPage());
	    }

	/********************************************************************
	   * Description: search by entering Invalid data in search text field in digital machine sub page
	   * Status: Completed
	********************************************************************/
	@And("^I search by entering Invalid data in search text field in digital machine sub page$")
	    public void i_search_by_entering_invalid_data_in_search_text_field_in_digital_machine_sub_page()
	    {
		String InValidDigitalMachineNameToSearchInDigitalMachineTab = DigitalMachineCSVReader.getInValidDigitalMachineNameToSearchInDigitalMachineTab();
		digitalmachinepage.searchByInvalidDataForDigitalMachineSubPage(InValidDigitalMachineNameToSearchInDigitalMachineTab );
	    }

	/********************************************************************
	   * Description: Verify list of digital machines not displayed in the digital machine sub page
	   * Status: Completed
	********************************************************************/
	    @Then("^Verify list of digital machines not displayed in the digital machine sub page$")
	    public void verify_list_of_digital_machines_not_displayed_in_the_digital_machine_sub_page()
	    {
	    assertFalse("Related digital machines is displayed", digitalmachinepage.VerifySearchByInValidDataForDigitalMachineSubPage());
	    }
	    
	    /********************************************************************
		   * Description: 
		   * Status: Completed
		********************************************************************/
		@And("^I add the data to Digital Machine text field and click on close icon$")
		    public void iAddTheDataToDigitalMachineTextfieldAndClickOnCloseIcon()
		    {
			 String DMName = DigitalMachineCSVReader.getDMName();
			digitalmachinepage.passValueToTextareafieldAndClickOnCloseIcon(DMName);
		    }
		
		 /********************************************************************
		   * Description: 
		   * Status: Completed
		********************************************************************/
		@Then("^I can see the digital machine not added$")
	    public void i_can_see_the_digital_machine_not_added() {
	        assertTrue("Close icon not working",digitalmachinepage.checkCloseIconInSubsystemPageORDigitalMachinePage());
	    }
	
}
