package com.zysk.cerebra.csv_reader;


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

public class CustomerCSVReader {
	
	

		private static String path = "src/test/resources/dataSources/CustomerData.csv";
		private static HashMap<String,String> data;
		
	   
	   public static void loadCSV(String target) {

		   data = new HashMap<String, String>();
		   String line;
		   String [] split;

		   target = path;
		   
		   try (BufferedReader br = new BufferedReader(new FileReader(target))) {

		   System.out.println("Reading from " + target);
		   while ((line = br.readLine()) != null) {
		   split = line.split(",");
		   String key = split[0];
		   String value = split[1];

		   if (System.getProperty(key) != null) {
		   value = System.getProperty(key);
		   System.out.println("Overriding key '" + key + "' with value '" + value + "'");
		   }

		   data.put(key,value);
		   }

		   } catch (IOException e) {
		   System.out.println("\n***** ERROR: CSV not found. *****\n");
		   }

		   }

	   public static String getKey(String key) {

		   if (data == null) loadCSV(path);

		   if (data.get(key) == null) return "ERROR: Key not found";

		   return data.get(key);

		   }
	   
	   public static String getCustomerListURL() {
		   return getKey("CustomerListURL");
	   }
	   
	   public static String getCustomerNameToAdd() {
		   return getKey("CustomerNameToAdd");
	   }
	   
	   public static String getCustomerPhoneNumberToAdd() {
		   return getKey("CustomerPhoneNumberToAdd");
	   }
	   
	   public static String getCustomerImagePathToADD() {
		   return getKey("CustomerImagePathToADD");
	   }

	   public static String getValidCustomerNameToSearch() {
		   return getKey("ValidCustomerNameNameToSearch");
	   }
	   
	   public static String getInValidCustomerNameToSearch() {
		   return getKey("InValidCustomerNameToSearch");
	   }
	   
	   public static String getSelectCustomerNameTOSelectAndVerify() {
		   return getKey("SelectCustomerNameToVerify");
	   }
	   
	   public static String getCustomerDetailsPageURL() {
		   return getKey("CustomerDetailsURL");
	   }
	   
	   public static String getCustomerContactName() {
		   return getKey("contactNameToAdd");
	   }
	   
	   public static String getCustomerContactMobile() {
		   return getKey("contactMobileToAdd");
	   }
	   
	   public static String getCustomerContactEmail() {
		   return getKey("contactEmailToAdd");
	   }
	   
	   public static String getCustomerLocation() {
		   return getKey("LocationNameTOAdd");
	   }
	   
	   public static String getCustomerLocationToSearch() {
		   return getKey("LocationNameToSearch");
	   }
	   
	   public static String getSelectCustomer() {
		   return getKey("SelectCustomer");
	   }
	   
	   public static String getlocationTypeSelection() {
		  return getKey("SelectLocationType");
	   }
	   
	   public static String getCustomerNameToDisableOrEnable() {
		   return getKey("CustomerNameToDisableOrEnable");
	   }
	   
	   public static String getCustomerNameToEdit() {
		   return getKey("customerNameToEdit");
	   }
	   
	   public static String getCustomerMobileNumberToEdit() {
		   return getKey("customerMobileNumberToEdit");
	   }
	   public static String getCustomerImagePath() {
		   return getKey("CustomerImagePath");
	   }
	   public static String getCustomerNameToverify() {
		   return getKey("CustomerNameToVerifydetails");
	   }
	   
	   public static String getCustomerMobileNumberToverify() {
		   return getKey("CustomerMobileNumberToVerifydetails");
	   }
	   
	   public static String getCustomerImageToverify() {
		   return getKey("CustomerIamgeToVerifydetails");
	   }
	   
	   public static String getInvalidCustomerName() {
		   return getKey("InvalidCustomerName");
	   }
		   
	   public static String getCustomerInvalidImage() {
		   return getKey("InvalidCustomerImage");
	   }
	   
	   public static String getDomainNameToAdd() {
		   return getKey("DomainNameToAdd");
	   }
	   
	   public static String  getDomainNameToEditAndVerify() {
		   return getKey("DomainNameToEditAndVerify");
	   }
	  
	   public static String getDomainNameEditToEdit() {
		   return getKey("DomainNameEditToEdit");
	   }
	   
	   public static String getDomainNameToVerifyDuplicate() {
		   return getKey("DomainDuplicateNameToVerify");
	   }
	   
	   public static String getDomainDuplicateName() {
		   return getKey("DomainExistingName");
	   }
	   
	   public static String getDomainNameToDisable() {
		   return getKey("DomainNameToDisable");
	   }
	   
	   public static String getDomainNameToEnable() {
		   return getKey("DomainNameToEnable");
	   }
	   
	   public static String getDomainNameToDelete() {
		   return getKey("DomainNameToDelete");
	   }
	   
	   public static String getCustomerNameToDelete() {
		   return getKey("CustomerNameToDelete");
	   }
	   
	   public static String getCustomerDuplicatename() {
		   return getKey("DuplicateCustomerName");
	   }
	   
	   public static String getCustomerNameToSelectContact() {
		   return getKey("CustomernameToSelectContact");
	   }
	   
	   public static String getCustomerNameToEditContactDetails() {
		   return getKey("CustomerNameToEditContactDetails");
	   }
	   
	   public static String getExistingContactNameToEdit() {
		   return getKey("ExistingContactNameToEditDetails");
	   }
	   
	   public static String getContactNameToEdit() {
		   return getKey("ContactNameToEdit");
	   }
	   
	   public static String getContactMobileToEdit() {
		   return getKey("ContactMobileToEdit");
	   }
	   
	   public static String getContactEmailToEdit() {
		   return getKey("ContactEmailToEdit");
	   }
	   
	   public static String getCustomerNameToDeleteContactDetails() {
		   return getKey("CustomerNameToDeleteContactDetails");
	   }
	   
	   public static String getExistingContactNameToDelete() {
		   return getKey("ExistingContactNameToDelete");
	   }
	   
	   public static String getCustomerToVerifyContactName() {
		   return getKey("CustomerToVerifyContactName");
	   }
	   
	   public static String getCustomerContactNameToVerifyContactname() {
		   return getKey("CustomerContactNameToVerifyContactname");
	   }
	   
	   public static String getCustomerToVerifyContactMobile() {
		   return getKey("CustomerToVerifyContactMobile");
	   }
	   
	   public static String getCustomerContactMobileToVerifyContactMobile () {
		   return getKey("CustomerContactMobileToVerifyContactMobile");
	   }
	   
	   public static String getCustomerToVerifyContactEmail() {
		   return getKey("CustomerToVerifyContactEmail");
	   }
	   
	   public static String getCustomerContactEmailToVerifyContactEmail() {
		   return getKey("CustomerContactEmailToVerifyContactEmail");
	   }
	   
	   public static String getCustomerToVerifyDuplicateContactDetails() {
		   return getKey("CustomerToVerifyDuplicateContactDetails");
	   }
	   
	   public static String getDuplicateContactName() {
		   return getKey("DuplicateContactName");
	   }
	   
	   public static String getDuplicateContactMobile() {
		   return getKey("DuplicateContactMobile");
	   }
	   
	   public static String getDuplicateContactEmail() {
		   return getKey("DuplicateContactEmail");
	   }
	   
	   public static String getCustomerNameToViewLocationDetails() {
		   return getKey("CustomerNameToViewLocationDetails");
	   }
	   
	   public static String getCustomerLocationDuplicateName() {
		   return getKey("CustomerLocationDuplicateName");
	   }
	   
	   public static String getInvalidLocationName() {
		   return getKey("InvalidLocationName");
	   }
	   
	   public static String getValidLocationNameToSearch() {
		   return getKey("ValidLocationNameToSearch");
	   }
	   
	   public static String getInValidLocationNameToSearch() {
		   return getKey("InValidLocationNameToSearch");
	   }
	   
	   public static String getCustomerLocationeNametoVerifyCancelbutton() {
		   return getKey("CustomerLocationeNametoVerifyCancelbutton");
	   }
	   
	   public static String getExistingLocationNameToEditDetails() {
		   return getKey("ExistingLocationNameToEditDetails");
	   }
	   
	   public static String getLocationNameToEdit() {
		   return getKey("LocationNameToEdit");
	   }
	   
	   public static String getlocationTypedropdownToEdit() {
		   return getKey("locationTypedropdownToEdit");
	   }
	   
	   public static String getLocationToSearchToEdit() {
		   return getKey("LocationToSearchToEdit");
	   }
	   
	   public static String getLocationNameToDelete() {
		   return getKey("LocationNameToDelete");
	   }
	   
	   public static String getCustomernameToVerifyCancelButton() {
		   return getKey("CustomernameToVerifyCancelButton");
	   }
	   
	   public static String getCustomerContactNameToVerifyCancelbuttonFeature() {
		   return getKey("CustomerContactNameToVerifyCancelbuttonFeature");
	   }
	   
	   public static String getLocationsLinkToVerifyErrorMessageForEmptyLocation() {
		   return getKey("LocationsLinkToVerifyErrorMessageForEmptyLocation");
	   }
	   
	   public static String getCustomerToVerifyContctTabTextFields() {
		   return getKey("CustomerToVerifyContctTabTextFields");
	   }
	   
	   public static String getMoreThanThreeContactCustomer() {
		   return getKey("MoreThanThreeContactCustomer");
	   }
	   
	   public static String getAddCustomerNameToEdit() {
		   return getKey("CustomerNameToEditAndVerify");
	   }
	   
	   public static String getAddCustomerPhoneNumberToEdit() {
		   return getKey("CustomerPhoneNumberToEditAndVerify");
	   }
	   
	   public static String getImagePathToEdit() {
		   return getKey("CustomerImageToEditAndVerify");
	   }
	   
	  
}

