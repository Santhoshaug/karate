package com.zysk.cerebra.pages;

import com.beust.jcommander.internal.Lists;
import com.gargoylesoftware.htmlunit.javascript.host.Iterator;
import com.zysk.cerebra.commonPages.CommonFunctions;

import jnr.ffi.Struct.key_t;

import java.util.ArrayList;
import java.util.List;

import org.hamcrest.core.IsEqual;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class DiagnosticWorkBenchPage extends CommonFunctions {
	
	/***********************Page element identifiers******************************/
	
	private By DiganosticLink = By.xpath("//div[contains(text(),' Diagnostics Workbench ')]//..//..//..//a[contains(text(),'Diagnostics')]");
	private By SearchBar = By.xpath("//input[@placeholder='Search Category/Equipment...']");
	private By DiagnosticPageTitle = By.xpath("//app-equipments//span[contains(text(),'Equipments')]");
	private By SearchListForValidation = By.xpath("//div[@class='row']//div//mat-card");
	private By ModelPageTitle = By.xpath("//app-models//span[contains(text(),'Models')]");
	private By ModelTabSearchBar = By.xpath("//input[@placeholder='Search..']");
	private By DiagnosticTestTab = By.xpath("//button//span[contains(text(),' Diagnostic Tests ')]");
	private By DiagnosticTestTabSearchBar = By.xpath("//input[@placeholder='Search Tests..']");
	private By AddTestButton = By.xpath("//button[@mattooltip='Add Test']//span");
	private By AddPackageButton = By.xpath("//span[contains(text(),' Add Package ')]");
	private By AddPackageNameField = By.xpath("//input[@placeholder='Name']");
	private By AddPackageSaveButton = By.xpath("//button[@mattooltip='Save']//mat-icon");
	private By AddPackageCancelButton = By.xpath("//button[@mattooltip='Close']//mat-icon");
	private By AddPackageEditButton = By.xpath("//mat-icon[@mattooltip='Edit']");
	private By AddPackagedescription = By.xpath("//div//input[@placeholder='Description']");
	private By SearchListForDiagnosticTestValidation = By.xpath("//mat-card//div[@class='title header-text']//..//../..//mat-card");
	private By testNameTextField = By.xpath("//input[@formcontrolname='testName']");
	private By testDescriptionTextField = By.xpath("//input[@formcontrolname='testDesc']");
	private By symptomDropdown = By.xpath("//div[@class='mat-select-trigger']//span[contains(text(),'Symptom Type')]");
	private By engineTypeDropdown = By.xpath("//div[@class='mat-select-trigger']//span[contains(text(),'Diagnostic Engine Type')]");
	private By diagnosticTestSeverityDropdown = By.xpath("//div[@class='mat-select-trigger']//span[contains(text(),'Diagnostic Test Severity')]");
	private By diagnosticTestPackageDropdown = By.xpath("//div[@class='mat-select-trigger']//span[contains(text(),'Diagnostic Test Package')]");
	
	private By ComparisionOperator = By.xpath("//span[contains(text(),'Comparison Operators')]");
	private By ComparisionOperatorEqualTo = By.xpath("//span[contains(text(),'Comparison Operators')]//..//..//div[@class='card-item level3 desc-text mat-ripple ng-star-inserted'][1]");
	private By ComparisionOperatorGreaterThanEqualTo = By.xpath("//span[contains(text(),'Comparison Operators')]//..//..//div[@class='card-item level3 desc-text mat-ripple ng-star-inserted'][2]");
	private By ComparisionOperatorLesserThanEqualTo = By.xpath("//span[contains(text(),'Comparison Operators')]//..//..//div[@class='card-item level3 desc-text mat-ripple ng-star-inserted'][3]");
	private By ComparisionOperatorNotEqualTo = By.xpath("//span[contains(text(),'Comparison Operators')]//..//..//div[@class='card-item level3 desc-text mat-ripple ng-star-inserted'][4]");
	private By ComparisionOperatorGreaterThan = By.xpath("//span[contains(text(),'Comparison Operators')]//..//..//div[@class='card-item level3 desc-text mat-ripple ng-star-inserted'][5]");
	private By ComparisionOperatorLesserThan = By.xpath("//span[contains(text(),'Comparison Operators')]//..//..//div[@class='card-item level3 desc-text mat-ripple ng-star-inserted'][6]");
	
	private By LogicalOperator = By.xpath("//span[contains(text(),' Logical Operators')]");
	private By LogiclOperatorNOT = By.xpath("//span[contains(text(),' Logical Operators')]//../..//div[@class='card-item level3 desc-text mat-ripple ng-star-inserted'][1]");
	private By LogiclOperatoANDOperator = By.xpath("//span[contains(text(),' Logical Operators')]//../..//div[@class='card-item level3 desc-text mat-ripple ng-star-inserted'][2]");
	private By LogiclOperatoOROperator = By.xpath("//span[contains(text(),' Logical Operators')]//../..//div[@class='card-item level3 desc-text mat-ripple ng-star-inserted'][3]");
	
	private By AirthematicOperator = By.xpath("//span[contains(text(),' Arithmetic Operators')]");
	private By AirthematicOperatorPlus = By.xpath("//span[contains(text(),' Arithmetic Operators')]//../..//div[@class='card-item level3 desc-text mat-ripple ng-star-inserted'][1]");
	private By AirthematicOperatorMinus = By.xpath("//span[contains(text(),' Arithmetic Operators')]//../..//div[@class='card-item level3 desc-text mat-ripple ng-star-inserted'][4]");
	private By AirthematicOperatorMultiply = By.xpath("//span[contains(text(),' Arithmetic Operators')]//../..//div[@class='card-item level3 desc-text mat-ripple ng-star-inserted'][2]");
	private By AirthematicOperatorDivide = By.xpath("//span[contains(text(),' Arithmetic Operators')]//../..//div[@class='card-item level3 desc-text mat-ripple ng-star-inserted'][3]");

	private By AditionalOperator = By.xpath("//span[contains(text(),' Additional Operators')]");
	private By AditionalOperatorOpenBracket = By.xpath("//span[contains(text(),' Additional Operators')]//../..//div[@class='card-item level3 desc-text mat-ripple ng-star-inserted'][1]");
	private By AditionalOperatorCloseBracket = By.xpath("//span[contains(text(),' Additional Operators')]//../..//div[@class='card-item level3 desc-text mat-ripple ng-star-inserted'][2]");
	private By AditionalOperatorDoublequotes = By.xpath("//span[contains(text(),' Additional Operators')]//../..//div[@class='card-item level3 desc-text mat-ripple ng-star-inserted'][3]");
	private By AditionalOperatorsinglequotes = By.xpath("//span[contains(text(),' Additional Operators')]//../..//div[@class='card-item level3 desc-text mat-ripple ng-star-inserted'][4]");
	private By AditionalOperatorPrev = By.xpath("//span[contains(text(),' Additional Operators')]//../..//div[@class='card-item level3 desc-text mat-ripple ng-star-inserted'][5]");
			
	private By validateButton = By.xpath("//span[contains(text(),' Validate ')]");
	private By AddRuleButton = By.xpath("//button//span[contains(text(),'Add Rule')]");
	private By EditTestDetails = By.xpath("//span[contains(text(),'Test Details')]/..//mat-icon[contains(text(),'edit')]");
	private By EditTestFrequency = By.xpath("//span[contains(text(),'Test Frequency')]/..//mat-icon[contains(text(),'edit')]");
	private By EditFindingNotifications = By.xpath("//span[contains(text(),'Finding Notifications')]/..//mat-icon[contains(text(),'edit')]");
	private By EditRecomendation = By.xpath("//span[contains(text(),'Recommendation')]/..//mat-icon[contains(text(),'edit')]");
	private By DisableTestDetails = By.xpath("//span[contains(text(),'Enabled')]//..//div[@class='mat-slide-toggle-thumb']");
	private By EnableTestDetails = By.xpath("//span[contains(text(),'Disabled')]//..//div[@class='mat-slide-toggle-thumb']");
	private By DeleteTest = By.xpath("//mat-icon[@mattooltip='Delete']");
	private By yesPopup = By.xpath("//button[contains(text(),'Yes, delete it!')]");
	private By cancelPopUp = By.xpath("");
	
	private By AnalysisTypesDropdown = By.xpath("//mat-select[@formcontrolname='analysisType']");
	private By AlgorithmDropdown = By.xpath("//mat-select[@formcontrolname='parameter']");
	private By SaveButton = By.xpath("//span[contains(text(),'Save')]");
	
	
	
	
	/********************************************************************
	* Description: Visit Diagnostic page by clicking on Diagnostic link
	* Param: NA
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void DiagnosticLink() {
		
		element(DiganosticLink).click();
		waitForElementToDisappear(loader);
	}

	/********************************************************************
	* Description: Verify Diagnostic page 
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/

	public boolean VerifyDiagnosticPage(String exptUrl) {
		String actUrl = getDriver().getCurrentUrl();
		if(actUrl.equals(exptUrl)&&
				element(SearchBar).isCurrentlyVisible()&&
				element(DiagnosticPageTitle).isCurrentlyVisible())
			return true;
		else
			return false;
		
	}
	/********************************************************************
	* Description: Pass valid data to Search bar
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public void SearchBarValidData(String ValidData) {
		element(SearchBar).sendKeys(ValidData);
	}

	/********************************************************************
	* Description: Verify Search bar with valid input
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public boolean VerifySearchBarValidData() {
		List<WebElement> EquipmentORcategoryList = getDriver().findElements(SearchListForValidation);
		int size = EquipmentORcategoryList.size();
		if(size>0) 
			return true;
		else 
			return false;
		
	}
	/********************************************************************
	* Description: Pass INvalid data to Search  bar
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public void SearchBarInValidData(String InValidData) {
		element(SearchBar).sendKeys(InValidData);
		}
	/********************************************************************
	* Description: Verify Search bar with Invalid input
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public boolean VerifySearchBarInValidData() {
			List<WebElement> EquipmentORcategoryList = getDriver().findElements(SearchListForValidation);
			int size = EquipmentORcategoryList.size();
			if(size==0) return true;
			else return false;
	}
	
	/********************************************************************
	* Description: Select Equipment in Diagnostic page
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public void SelectEquipmentInDiagnostic(String EquipmentName) {
		element(By.xpath("//mat-card-content//a[contains(text(),'"+EquipmentName+"')]")).click();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verify Equipment is selected in Diagnostic page and Models tab is displaying
	* Param: NA
	* Returns: 
	* Status: Completed
	 * @return 
	********************************************************************/
	public boolean VerifyEquipmentSelectedAndModelsTabDisplaying(String exptUrl, String EquipmentName) {
		String actUrl = getDriver().getCurrentUrl();
//		String ModelTitleWithEquipmentName = element(By.xpath("//app-models//span[contains(text(),'Models - "+EquipmentName+"')]"));
//		System.out.println(ModelTitleWithEquipmentName);
		if(actUrl.equals(exptUrl)&&
				element(ModelTabSearchBar).isCurrentlyVisible()&&
				element(ModelPageTitle).isCurrentlyVisible())
			return true;
			else
			return false;
	}
	
	/********************************************************************
	* Description: Select Model
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public void DiagnosticSelctModel(String ModelName) {
		element(By.xpath("//mat-card-content//a[contains(text(),'"+ModelName+"')]")).click();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verify Model is selected in Models tab and Diagnostic Tests Tab is displaying
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public boolean VerifyModelIsSelectedAndDiagnosticTestsTabTabDisplaying(String exptUrl) {
		String actUrl = getDriver().getCurrentUrl();
		if(actUrl.equals(exptUrl)&&
				element(DiagnosticTestTabSearchBar).isCurrentlyVisible()&&
				element(DiagnosticTestTab).isCurrentlyVisible())
			return true;
			else
			return false;
	}
	
	/********************************************************************
	* Description: Pass valid data to Search bar to search model
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public void SearchBarValidModelData(String ValidData) {
		element(ModelTabSearchBar).sendKeys(ValidData);
	}

	/********************************************************************
	* Description: Verify Search bar with valid input to search model
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public boolean VerifySearchBarValidModelData() {
		List<WebElement> ModelSearchList = getDriver().findElements(SearchListForValidation);
		int size = ModelSearchList.size();
		if(size>0) 
			return true;
		else 
			return false;
		
	}
	/********************************************************************
	* Description: Pass INvalid data to Search  bar to search model
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public void SearchBarInValidModelData(String InValidData) {
		element(ModelTabSearchBar).sendKeys(InValidData);
		}
	/********************************************************************
	* Description: Verify Search bar with Invalid input to search model
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public boolean VerifySearchBarInValidModelData() {
			List<WebElement> ModelSearchList = getDriver().findElements(SearchListForValidation);
			int size = ModelSearchList.size();
			if(size==0) return true;
			else return false;
	}
	
	/********************************************************************
	* Description: Pass valid data to Search bar to search model
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public void SearchBarValidDiagnosticTestData(String ValidData) {
		element(DiagnosticTestTabSearchBar).sendKeys(ValidData);
	}

	/********************************************************************
	* Description: Verify Search bar with valid input to search model
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public boolean VerifySearchBarValidDiagnosticTestData() {
		List<WebElement> diagnosticTestList = getDriver().findElements(SearchListForDiagnosticTestValidation);
		int size = diagnosticTestList.size();
		if(size>0) 
			return true;
		else 
			return false;
		
	}
	/********************************************************************
	* Description: Pass INvalid data to Search  bar to search model
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public void SearchBarInValidDiagnosticTestData(String InValidData) {
		element(DiagnosticTestTabSearchBar).sendKeys(InValidData);
		}
	/********************************************************************
	* Description: Verify Search bar with Invalid input to search model
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public boolean VerifySearchBarInValidDiagnosticTestData() {
			List<WebElement> diagnosticTestList = getDriver().findElements(SearchListForDiagnosticTestValidation);
			int size = diagnosticTestList.size();
			if(size==0) return true;
			else return false;
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public void dianosticTestTab(String EquipmentName, String ModelName) {
		element(DiganosticLink).click();
		waitForElementToDisappear(loader);
		element(By.xpath("//mat-card-content//a[contains(text(),'"+EquipmentName+"')]")).click();
		waitForElementToDisappear(loader);
		element(By.xpath("//mat-card-content//a[contains(text(),'"+ModelName+"')]")).click();
		waitForElementToDisappear(loader);
		
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Void 
	* Status: Completed
	 * @return 
	********************************************************************/
	public void ClickOnDiagnosticAddTestButton() {
		element(AddTestButton).click();
		waitForElementToDisappear(loader);
	}
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public boolean verifyAddTestTab(String exptUrl) {
		String AddTestTabUrl = getDriver().getCurrentUrl();
	if(AddTestTabUrl.equals(exptUrl)&& 
			element(By.xpath("//button//span[contains(text(),'Add Test')]//..//../../../../..//mat-card//span[contains(text(),'Test Details')]")).isCurrentlyVisible())
			return true;
	else
		return false;

	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public void clickOnRadioButtons() {
		element(By.xpath("//label[@class='mat-radio-label']//..//..//mat-radio-button[1]")).click();
		element(By.xpath("//label[@class='mat-radio-label']//..//..//mat-radio-button[2]")).click();
		element(By.xpath("//label[@class='mat-radio-label']//..//..//mat-radio-button[3]")).click();
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public boolean verifyRadioButtons() {
		if(element(By.xpath("//mat-radio-button[1]")).isCurrentlyVisible()&&
				element(By.xpath("//mat-radio-button[2]")).isCurrentlyVisible()&&
				element(By.xpath("//mat-radio-button[3]")).isCurrentlyVisible())
		return true;
		else
			return false;
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public void clickOnAddPackageButton() {
		element(AddPackageButton).click();
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public boolean VerifyAddPackageButton() {
		if(element(By.xpath("//mat-card[@class='mat-card']")).isCurrentlyVisible())
			return true;
		else
			return false;
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public void addTestPackage(String PackageName) {
		element(AddPackageNameField).sendKeys(PackageName); 
		element(AddPackageSaveButton).click();
		waitForElementToDisappear(loader);
		
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public boolean VerifyTestPackageAdded(String PackageName) {
		String ASMsg = element(By.xpath("//snack-bar-container//span")).getText();
		String ESMsg = ""+PackageName+" Created";
		element(AddTestButton).click();
		waitForElementToDisappear(loader);
		element(diagnosticTestPackageDropdown).click();
		if(ASMsg.equals(ESMsg)&&element(By.xpath("//span[contains(text(),'"+PackageName+"')]")).isCurrentlyVisible())
			return true;
		else
		return false;
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public void addDuplicatePackage(String PackageName) {
		element(AddPackageNameField).sendKeys(PackageName); 
		element(AddPackageSaveButton).click();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public boolean VerifyduplicateTestPackage(String PackageName) {
		String ASMsg = element(By.xpath("//snack-bar-container//span")).getText();
		String ESMsg = ""+PackageName+" already exists. Please choose another name";
		if(ASMsg.equals(ESMsg))
			return true;
		else
		return false;
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public void SymptomType(String symptomTypeName) {
		element(By.xpath("//label[@class='mat-radio-label']//..//..//mat-radio-button[2]")).click();
		element(AddPackageNameField).sendKeys(symptomTypeName); 
		element(AddPackageSaveButton).click();
		waitForElementToDisappear(loader);
		
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public boolean VerifySymptomTypeAdded(String symptomTypeName) {
		String ASMsg = element(By.xpath("//snack-bar-container//span")).getText();
		String ESMsg = ""+symptomTypeName+" Created";
		element(AddTestButton).click();
		waitForElementToDisappear(loader);
		element(diagnosticTestPackageDropdown).click();
		if(ASMsg.equals(ESMsg)&&element(By.xpath("//span[contains(text(),'"+symptomTypeName+"')]")).isCurrentlyVisible())
			return true;
		else
		return false;
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public void addDuplicateSymptomType(String symptomTypeName) {
		element(By.xpath("//label[@class='mat-radio-label']//..//..//mat-radio-button[3]")).click();
		element(AddPackageNameField).sendKeys(symptomTypeName); 
		element(AddPackageSaveButton).click();
		waitForElementToDisappear(loader);
		
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public boolean VerifyduplicateSymptomType(String symptomTypeName) {
		String ASMsg = element(By.xpath("//snack-bar-container//span")).getText();
		String ESMsg = ""+symptomTypeName+" already exists. Please choose another name";
		if(ASMsg.equals(ESMsg))
			return true;
		else
		return false;
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public void addEngineType(String engineTypeName) {
		element(By.xpath("//label[@class='mat-radio-label']//..//..//mat-radio-button[1]")).click();
		element(AddPackageNameField).sendKeys(engineTypeName); 
		element(AddPackageSaveButton).click();
		waitForElementToDisappear(loader);
		
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public boolean VerifyEngineTypeAdded(String engineTypeName) {
		String ASMsg = element(By.xpath("//snack-bar-container//span")).getText();
		String ESMsg = ""+engineTypeName+" Created";
		element(AddTestButton).click();
		waitForElementToDisappear(loader);
		element(diagnosticTestPackageDropdown).click();
		if(ASMsg.equals(ESMsg)&&element(By.xpath("//span[contains(text(),'"+engineTypeName+"')]")).isCurrentlyVisible())
			return true;
		else
		return false;
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public void addDuplicateEngineType(String engineTypeName) {
		element(By.xpath("//label[@class='mat-radio-label']//..//..//mat-radio-button[1]")).click();
		element(AddPackageNameField).sendKeys(engineTypeName); 
		element(AddPackageSaveButton).click();
		waitForElementToDisappear(loader);
		
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public boolean VerifyduplicateEngineType(String engineTypeName) {
		String ASMsg = element(By.xpath("//snack-bar-container//span")).getText();
		String ESMsg = ""+engineTypeName+" already exists. Please choose another name";
		if(ASMsg.equals(ESMsg))
			return true;
		else
		return false;
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public void addAllTheTestDetails(String Testname, String TestDescription, String SymptomName, String EngineTypeName, String diagnosticTestSeverityName, String diagnosticTestPackagName,
			String NotificationTag, String NotificationMessage, String RecomendationDescription) {
		element(testNameTextField).sendKeys(Testname);
		element(testDescriptionTextField).sendKeys(TestDescription);
		element(symptomDropdown).click();
		element(By.xpath("//mat-option//span[contains(text(),'"+SymptomName+"')]")).click();
		element(engineTypeDropdown).click();
		element(By.xpath("//mat-option//span[contains(text(),'"+EngineTypeName+"')]")).click();
		element(diagnosticTestSeverityDropdown).click();
		element(By.xpath("//mat-option//span[contains(text(),'"+diagnosticTestSeverityName+"')]")).click();	
		element(diagnosticTestPackageDropdown).click();
		element(By.xpath("//mat-option//span[contains(text(),'"+diagnosticTestPackagName+"')]")).click();
		element(By.xpath("//span[contains(text(),'Test Frequency')]/../..//div[@class='card-item card-param plain-title-text'][1]//div[@class='mat-slide-toggle-thumb']")).click();
		element(By.xpath("//span[contains(text(),'Test Frequency')]/../..//div[@class='card-item card-param plain-title-text'][2]//div[@class='mat-slide-toggle-thumb']")).click();
		element(By.xpath("//span[contains(text(),'Test Frequency')]/../..//div[@class='card-item card-param plain-title-text'][3]//div[@class='mat-slide-toggle-thumb']")).click();
		element(By.xpath("//span[contains(text(),'Test Frequency')]/../..//div[@class='card-item card-param plain-title-text'][4]//div[@class='mat-slide-toggle-thumb']")).click();
		
		element(By.xpath("//span[contains(text(),'Finding Notifications')]/../..//div[@class='card-item card-param plain-title-text'][1]//div[@class='mat-slide-toggle-thumb']")).click();
		element(By.xpath("//input[@placeholder='Notification Tag']")).sendKeys(NotificationTag);
		element(By.xpath("//input[@placeholder='Notification Message']")).sendKeys(NotificationMessage);
		
		element(By.xpath("//textarea[@placeholder='Enter Recommendations']")).sendKeys(RecomendationDescription);
		element(By.xpath("//button//span[contains(text(),'Next')]")).click();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public void AddValidRuleType(String RuleValue) {
		 List<WebElement> list = getDriver().findElements(By.xpath("//mat-expansion-panel//mat-expansion-panel-header"));
		 try {
		 for(int i=0;i<=list.size();i++)
		 {
			 if(element(By.xpath("//mat-expansion-panel//mat-expansion-panel-header[@aria-expanded='false']")).isCurrentlyVisible()==true)
			 {
				 list.get(i).click();
			 }
			 
		 }}
		 catch(Exception e) {
			 
		 }
	
		element(By.xpath("//a[@class='header-text cursor-notallowed ng-star-inserted']//../..//mat-tree-node[2]")).click();
		element(AirthematicOperatorPlus).click();
		element(By.xpath("//a[@class='header-text cursor-notallowed ng-star-inserted']//../..//mat-tree-node[3]")).click();
		element(ComparisionOperatorEqualTo).click();	
		element(By.xpath("//input[@formcontrolname='item']")).sendKeys(RuleValue);
		element(By.xpath("//input[@formcontrolname='item']")).sendKeys(Keys.ENTER);
		element(validateButton).click();
		waitForElementToDisappear(loader);
		element(AddRuleButton).click();
		waitForElementToDisappear(loader);
		
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public void AddInvalidRule() {
		element(By.xpath("//a[@class='header-text cursor-notallowed ng-star-inserted']//../..//mat-tree-node[2]")).click();
		element(By.xpath("//a[@class='header-text cursor-notallowed ng-star-inserted']//../..//mat-tree-node[2]")).click();
		element(validateButton).click();
		
	}
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public boolean verifyRuleIsInValid() {
		String ASMsg = element(By.xpath("//snack-bar-container//span")).getText();
		String ESMsg = "Rule is Not valid";
		if(ASMsg.equals(ESMsg))
			return true;
		else
		return false;
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public boolean verifyRuleIsAdded(String TestName, String ModelName) {
		if(element(By.xpath("//button//span[contains(text(),'Details')]")).isCurrentlyVisible()==true)
			return true;
		else
		return false;
		
	}
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public boolean verifyDuplicateRuleIsNotAdded(String testName) {
		String ASMsg = element(By.xpath("//snack-bar-container//span")).getText();
		String ESMsg = ""+testName+" already exists. Please choose another name";
		if(ASMsg.equals(ESMsg))
			return true;
		else
		return false;
	}
	
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public void addDetailsToAllTheFieldsToAddSecondTypeRule(String Testname, String TestDescription, String SymptomName, String EngineTypeName, String diagnosticTestSeverityName, String diagnosticTestPackagName,
			String NotificationTag, String NotificationMessage, String RecomendationDescription) {
		element(testNameTextField).sendKeys(Testname);
		element(testDescriptionTextField).sendKeys(TestDescription);
		element(symptomDropdown).click();
		element(By.xpath("//mat-option//span[contains(text(),'"+SymptomName+"')]")).click();
		element(engineTypeDropdown).click();
		element(By.xpath("//mat-option//span[contains(text(),'"+EngineTypeName+"')]")).click();
		element(diagnosticTestSeverityDropdown).click();
		element(By.xpath("//mat-option//span[contains(text(),'"+diagnosticTestSeverityName+"')]")).click();	
		element(diagnosticTestPackageDropdown).click();
		element(By.xpath("//mat-option//span[contains(text(),'"+diagnosticTestPackagName+"')]")).click();
		element(By.xpath("//span[contains(text(),'Test Frequency')]/../..//div[@class='card-item card-param plain-title-text'][1]//div[@class='mat-slide-toggle-thumb']")).click();
		element(By.xpath("//span[contains(text(),'Test Frequency')]/../..//div[@class='card-item card-param plain-title-text'][2]//div[@class='mat-slide-toggle-thumb']")).click();
		element(By.xpath("//span[contains(text(),'Test Frequency')]/../..//div[@class='card-item card-param plain-title-text'][3]//div[@class='mat-slide-toggle-thumb']")).click();
		element(By.xpath("//span[contains(text(),'Test Frequency')]/../..//div[@class='card-item card-param plain-title-text'][4]//div[@class='mat-slide-toggle-thumb']")).click();
		
		element(By.xpath("//span[contains(text(),'Finding Notifications')]/../..//div[@class='card-item card-param plain-title-text'][1]//div[@class='mat-slide-toggle-thumb']")).click();
		element(By.xpath("//input[@placeholder='Notification Tag']")).sendKeys(NotificationTag);
		element(By.xpath("//input[@placeholder='Notification Message']")).sendKeys(NotificationMessage);
		
		element(By.xpath("//textarea[@placeholder='Enter Recommendations']")).sendKeys(RecomendationDescription);
		element(By.xpath("//button//span[contains(text(),'Next')]")).click();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public void AddSecondTypeRule(String AnalysisType,String AlgorithmType) {
		element(By.xpath("//mat-select[@formcontrolname='analysisType']")).click();
		element(By.xpath("//mat-option//span[contains(text(),' "+AnalysisType+" ')]")).click();
		waitForElementToDisappear(loader);
		element(By.xpath("//mat-select[@formcontrolname='parameter']")).click();
		element(By.xpath("//mat-option//span[contains(text(),' "+AlgorithmType+" ')]")).click();
		waitForElementToDisappear(loader);
//		element(By.xpath("//a[@class='header-text cursor-notallowed ng-star-inserted']//../..//mat-tree-node[2]")).click();
		element(By.xpath("//a[@class='header-text cursor-notallowed ng-star-inserted']//../..//mat-tree-node[2]//div[@class='mat-slide-toggle-bar mat-slide-toggle-bar-no-side-margin']")).click();
		element(By.xpath("//a[@class='header-text cursor-notallowed ng-star-inserted']//../..//mat-tree-node[3]//div[@class='mat-slide-toggle-bar mat-slide-toggle-bar-no-side-margin']")).click();
		
		element(By.xpath("//button//span[contains(text(),'Save')]")).click();
		waitForElementToDisappear(loader);
		
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public boolean verifyRuleType2IsAdded() {
		if(element(By.xpath("//button//span[contains(text(),'Details')]")).isCurrentlyVisible()==true)
			return true;
		else
		return false;
		
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public void selectTestName(String TestName) {
		element(By.xpath("//div[contains(text(),'"+TestName+"')]")).click();
		waitForElementToDisappear(loader);
		
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public void EditTheDiagnosticRule(String RuleValue) {
		element(By.xpath("//div[contains(text(),'Rule')]/..//mat-icon[contains(text(),'edit')]")).click();
//		String items = element(By.xpath("//mat-expansion-panel-header//span")).getText();
//		System.out.println(items);
//		List<WebElement> all_spans = getDriver().findElements(By.xpath("//mat-expansion-panel-header//span"));
//				Object span;
//				for (span : all_spans)
//				    print span.text
		
		
//		  List<WebElement> list = getDriver().findElements(By.xpath("//mat-expansion-panel-header//span"));
//		    java.util.Iterator<WebElement> iterator = list.iterator();
//
//		    List<String> values = new ArrayList<String>();
//		    while (iterator.hasNext()){
//		        WebElement element = iterator.next();
//		        values.add(element.getText());
//		    }
//
//		    System.out.println(values.toString());
//		
		
		List<WebElement> Oplist = getDriver().findElements(By.xpath("//mat-expansion-panel//mat-expansion-panel-header"));
		 try {
		 for(int i=0;i<=Oplist.size();i++)
		 {
			 if(element(By.xpath("//mat-expansion-panel//mat-expansion-panel-header[@aria-expanded='false']")).isCurrentlyVisible()==true)
			 {
				 Oplist.get(i).click();
			 }
			 
		 }}
		 catch(Exception e) {
			 
		 }
		
		List<WebElement> RuleItemList = getDriver().findElements(By.xpath("//div[@class='tag__text inline']"));
		try {
		for(int i=1;i<=RuleItemList.size();i++) {
			element(By.xpath("//div[@class='tag-wrapper ng-star-inserted']//..//..//..//tag[1]//delete-icon//span")).click();
		}
		}
		catch(Exception e) {
			  //  Block of code to handle errors
			}
		
		
		element(By.xpath("//a[@class='header-text cursor-notallowed ng-star-inserted']//../..//mat-tree-node[3]")).click();
		element(AirthematicOperatorMultiply).click();
		element(By.xpath("//input[@formcontrolname='item']")).sendKeys(RuleValue);
		element(By.xpath("//input[@formcontrolname='item']")).sendKeys(Keys.ENTER);
		element(ComparisionOperatorEqualTo).click();
		element(By.xpath("//a[@class='header-text cursor-notallowed ng-star-inserted']//../..//mat-tree-node[2]")).click();
			
		
		element(validateButton).click();
		waitForElementToDisappear(loader);
		element(SaveButton).click();
		waitForElementToDisappear(loader);
		
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public boolean verifyRuleIsEdited(String TestName) {
			if(element(By.xpath("//button//span[contains(text(),'Details')]")).isCurrentlyVisible()==true)
				return true;
			else
			return false;
			
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public void selectSecondTypeTestName(String TestName) {
		element(By.xpath("//div[contains(text(),'"+TestName+"')]")).click();
		waitForElementToDisappear(loader);
		
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public void editTheSecondRuleType(String AnalysisType,String AlgorithmType) {
		element(By.xpath("//mat-icon[contains(text(),'edit')]//..//mat-icon[1]//..//..//div[@class='editicon ng-star-inserted']")).click();
		waitForElementToDisappear(loader);
		element(By.xpath("//mat-select[@formcontrolname='analysisType']")).click();
		element(By.xpath("//mat-option//span[contains(text(),' "+AnalysisType+" ')]")).click();
		waitForElementToDisappear(loader);
		element(By.xpath("//mat-select[@formcontrolname='parameter']")).click();
		element(By.xpath("//mat-option//span[contains(text(),' "+AlgorithmType+" ')]")).click();
		waitForElementToDisappear(loader);
		element(By.xpath("//a[@class='header-text cursor-notallowed ng-star-inserted']//../..//mat-tree-node[2]//div[@class='mat-slide-toggle-bar mat-slide-toggle-bar-no-side-margin']")).click();
		element(By.xpath("//a[@class='header-text cursor-notallowed ng-star-inserted']//../..//mat-tree-node[3]//div[@class='mat-slide-toggle-bar mat-slide-toggle-bar-no-side-margin']")).click();
		
		element(By.xpath("//button//span[contains(text(),'Save')]")).click();
		waitForElementToDisappear(loader);
		
		
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public boolean verifySecondRuleTypeEdited(String TestName) {
			String ASMsg = element(By.xpath("//snack-bar-container//span")).getText();
			String ESMsg = ""+TestName+" is updated ";
			if(ASMsg.equals(ESMsg))
				return true;
			else
			return false;
		
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public boolean verifyRuleIsNotEditedOnEditWithSameRule(String testName) {
		String ASMsg = element(By.xpath("//snack-bar-container//span")).getText();
		String ESMsg = ""+testName+" is updated ";
		if(ASMsg.equals(ESMsg))
			return true;
		else
		return false;
		
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Void
	* Status: Completed
	 * @return 
	********************************************************************/
	public boolean verifySecondTypeRuleIsNotEditedOnEditWithSameRule(String testName) {
		String ASMsg = element(By.xpath("//snack-bar-container//span")).getText();
		String ESMsg = ""+testName+" is updated ";
		if(ASMsg.equals(ESMsg))
			return true;
		else
		return false;
	}

	
		/********************************************************************
		* Description: 
		* Param: NA
		* Returns: Void
		* Status: Completed
		 * @return 
		********************************************************************/
		public void disableTheTestPackage() {
			element(DisableTestDetails).click();
			waitForElementToDisappear(loader);
			
		}
		
		/********************************************************************
		* Description: 
		* Param: NA
		* Returns: Void
		* Status: Completed
		 * @return 
		********************************************************************/
		public boolean verifyTestPackageDisabled(String TestName) {
			String ASMsg = element(By.xpath("//snack-bar-container//span")).getText();
			String ESMsg = "Rule '"+TestName+"' deactivated successfully";
			if(ASMsg.equals(ESMsg))
				return true;
			else
			return false;
		}
		
		/********************************************************************
		* Description: 
		* Param: NA
		* Returns: Void
		* Status: Completed
		 * @return 
		********************************************************************/
		public void enableTheTestpackage() {
			element(EnableTestDetails).click();
			waitForElementToDisappear(loader);	
		}

		/********************************************************************
		* Description: 
		* Param: NA
		* Returns: Void
		* Status: Completed
		 * @return 
		********************************************************************/
			public boolean verifyTestPackageEnabled(String TestName) {
				String ASMsg = element(By.xpath("//snack-bar-container//span")).getText();
				String ESMsg = "Rule '"+TestName+"' activated successfully.";
				if(ASMsg.equals(ESMsg))
					return true;
				else
				return false;
			}
			
		/********************************************************************
		* Description: 
		* Param: NA
		* Returns: Void
		* Status: Completed
		 * @return 
		********************************************************************/
		public void editTheTestPackageDetails(String Testname, String TestDescription, String SymptomName, String EngineTypeName, String diagnosticTestSeverityName, String diagnosticTestPackagName,
				String NotificationTag, String NotificationMessage, String RecomendationDescription) {
			element(By.xpath("//span[contains(text(),'Test Details')]//..//mat-icon[contains(text(),'edit')]")).click();
			element(By.xpath("//input[@placeholder='Name']")).clear();
			element(By.xpath("//input[@placeholder='Name']")).sendKeys(Testname);
			element(By.xpath("//input[@placeholder='Description']")).clear();
			element(By.xpath("//input[@placeholder='Description']")).sendKeys(TestDescription);
			
			
			
			element(By.xpath("//mat-select[@placeholder='Symptom Type']")).click();
			element(By.xpath("//mat-option//span[contains(text(),'"+SymptomName+"')]")).click();
			element(By.xpath("//mat-select[@placeholder='Diagnostic Engine Type']")).click();
			element(By.xpath("//mat-option//span[contains(text(),'"+EngineTypeName+"')]")).click();
			element(By.xpath("//mat-select[@placeholder='Diagnostic Test Severity']")).click();
			element(By.xpath("//mat-option//span[contains(text(),'"+diagnosticTestSeverityName+"')]")).click();	
			element(By.xpath("//mat-select[@placeholder='Diagnostic Test Package")).click();
			element(By.xpath("//mat-option//span[contains(text(),'"+diagnosticTestPackagName+"')]")).click();

			element(By.xpath("//span[contains(text(),'Test Frequency')]//..//mat-icon[contains(text(),'edit')]")).click();
			element(By.xpath("//span[contains(text(),'Test Frequency')]/../..//div[@class='card-item card-param plain-title-text'][1]//div[@class='mat-slide-toggle-thumb']")).click();
			element(By.xpath("//span[contains(text(),'Test Frequency')]/../..//div[@class='card-item card-param plain-title-text'][2]//div[@class='mat-slide-toggle-thumb']")).click();
			element(By.xpath("//span[contains(text(),'Test Frequency')]/../..//div[@class='card-item card-param plain-title-text'][3]//div[@class='mat-slide-toggle-thumb']")).click();
			element(By.xpath("//span[contains(text(),'Test Frequency')]/../..//div[@class='card-item card-param plain-title-text'][4]//div[@class='mat-slide-toggle-thumb']")).click();
			
			element(By.xpath("//span[contains(text(),'Finding Notifications')]/../..//div[@class='card-item card-param plain-title-text'][1]//div[@class='mat-slide-toggle-thumb']")).click();
			element(By.xpath("//input[@placeholder='Notification Tag']")).sendKeys(NotificationTag);
			element(By.xpath("//input[@placeholder='Notification Message']")).sendKeys(NotificationMessage);
			
			element(By.xpath("//textarea[@placeholder='Enter Recommendations']")).sendKeys(RecomendationDescription);
			element(By.xpath("//button//span[contains(text(),'Next')]")).click();
			waitForElementToDisappear(loader);
			
		}
		
		/********************************************************************
		* Description: 
		* Param: NA
		* Returns: Void
		* Status: Completed
		 * @return 
		********************************************************************/
		public boolean verifyTestPackageDetailsEdited(String TestNameToEdit) {
			String ASMsg = element(By.xpath("//snack-bar-container//span")).getText();
			String ESMsg = ""+TestNameToEdit+" is updated ";
			if(ASMsg.equals(ESMsg))
				return true;
			else
			return false;
		}
		
		/********************************************************************
		* Description: 
		* Param: NA
		* Returns: Void
		* Status: Completed
		 * @return 
		********************************************************************/
		public void DeleteTheTestPackage() {
			element(DeleteTest).click();
			element(yesPopup).click();
			waitForElementToDisappear(loader);
			
		}
		
		/********************************************************************
		* Description: 
		* Param: NA
		* Returns: Void
		* Status: Completed
		 * @return 
		********************************************************************/
		public boolean verifyTestPackageDeleted(String TestName) {
			if(!(element(By.xpath("//div[contains(text(),'"+TestName+"')]"))).isCurrentlyVisible()==true)
				return true;
			else
			return false;
		}
		
		/********************************************************************
		* Description: 
		* Param: NA
		* Returns: Void
		* Status: Completed
		 * @return 
		********************************************************************/
		public void deleteTheSecondTypeTestPackage() {
			element(DeleteTest).click();
			element(yesPopup).click();
			waitForElementToDisappear(loader);
			
		}
		/********************************************************************
		* Description: 
		* Param: NA
		* Returns: Void
		* Status: Completed
		 * @return 
		********************************************************************/
		public boolean verifySecondTypeTestPackageDeleted(String TestName) {
			String ASMsg = element(By.xpath("//snack-bar-container//span")).getText();
			String ESMsg = "Rule '"+TestName+"' deleted successfully";
			if(ASMsg.equals(ESMsg))
				return true;
			else
			return false;
		}

	
	
}
