package com.zysk.cerebra.steps;

import static org.junit.Assert.assertTrue;

import com.zysk.cerebra.csv_reader.AccessControlCSVReader;
import com.zysk.cerebra.csv_reader.DiagnosticsTestMappingCSVReader;
import com.zysk.cerebra.pages.DiagnosticsTestMappingPage;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class DiagnosticsTestMappingSteps {

	/******************************Page Objects**************************/
	
	DiagnosticsTestMappingPage diagnosticsTestMapping;
	
	/********************************************************************/
	
	/********************************************************************
	* Description: Select Access control link
	* Status: Completed
	********************************************************************/
	@And("^I click on Diagnostics Test mapping Link$")
    public void i_click_on_diagnostics_test_mapping_link()
    {
		diagnosticsTestMapping.clickdiagnosticsTestMapping();
    }

	/********************************************************************
	* Description: verify Diagnostics Test Mapping customer page
	* Status: Completed
	********************************************************************/
	@Then("^I can see the Diagnostics Test Mapping customer page$")
    public void i_can_see_the_diagnostics_test_mapping_customer_page() 
    {
		String diagnosticsTestMappingCustomerPageURL = DiagnosticsTestMappingCSVReader.getBaseUrl()+ DiagnosticsTestMappingCSVReader.getDTMCUrl();
    	assertTrue(diagnosticsTestMapping.diagnosticsTestMappingCustomerPage(diagnosticsTestMappingCustomerPageURL));
    }
	
	/********************************************************************
	* Description: click on Any customer card
	* Status: Completed
	********************************************************************/
	@And("^I click on Any customer card$")
    public void i_click_on_any_customer_card()
    {
		String customerName = DiagnosticsTestMappingCSVReader.getcustomerName();
		diagnosticsTestMapping.clickCustomer(customerName);
    }
	
	/********************************************************************
	* Description: verify Diagnostics Test Mapping Equipments page
	* Status: Completed
	********************************************************************/
	@Then("^I can see the Diagnostics Test Mapping Equipments page$")
    public void i_can_see_the_diagnostics_test_mapping_equipments_page()
    {
		String diagnosticsTestMappingEquipmentsPageURL = DiagnosticsTestMappingCSVReader.getBaseUrl()+ DiagnosticsTestMappingCSVReader.getEquipmentPageUrl();
		assertTrue(diagnosticsTestMapping.diagnosticsTestMappingEquipmentsPage(diagnosticsTestMappingEquipmentsPageURL));
    }
	
	/********************************************************************
	* Description: click on Any Equipment card
	* Status: Completed
	********************************************************************/
	@And("^I click on Any Equipment card$")
    public void i_click_on_any_equipment_card()
    {
		String EquipmentName = DiagnosticsTestMappingCSVReader.getEquipmentName();
		diagnosticsTestMapping.clickEquipmentCard(EquipmentName);
    }
	
	/********************************************************************
	* Description: verify Diagnostic Tests page
	* Status: Completed
	********************************************************************/
	@Then("^I can see the Diagnostics Test Mapping Diagnostic Tests page$")
    public void i_can_see_the_diagnostics_test_mapping_diagnostic_tests_page()
    {
		String diagnosticsTestMappingDiagnosticPageURL = DiagnosticsTestMappingCSVReader.getBaseUrl()+ DiagnosticsTestMappingCSVReader.getdiagnosticsPageUrl();
		assertTrue(diagnosticsTestMapping.diagnosticsTestMappingDiagnosticsPage(diagnosticsTestMappingDiagnosticPageURL));
    }
	
	/********************************************************************
	* Description: click on Any Diagnostic Tests card
	* Status: Completed
	********************************************************************/
	@And("^I click on Any Diagnostic Tests card$")
    public void i_click_on_any_diagnostic_tests_card()
    {
		String DiagnosticTestsName = DiagnosticsTestMappingCSVReader.getDiagnosticTestsName();
		diagnosticsTestMapping.clickDiagnosticTestsCard(DiagnosticTestsName);
    }
	
	/********************************************************************
	* Description: verify Operating Units page
	* Status: Completed
	********************************************************************/
	@Then("^I can see the Diagnostics Test Mapping Operating Units page$")
    public void i_can_see_the_diagnostics_test_mapping_operating_units_page()
    {
		String operatingUnitPageURL = DiagnosticsTestMappingCSVReader.getBaseUrl()+ DiagnosticsTestMappingCSVReader.getOperatingUnitPageUrl();
		assertTrue(diagnosticsTestMapping.diagnosticsTestMappingOperatingUnitPage(operatingUnitPageURL));
    }
	
	/********************************************************************
	* Description: click on Any Operating Units card
	* Status: Completed
	********************************************************************/
	@And("^I click on Any Operating Units card$")
    public void i_click_on_any_operating_units_card() 
    {
		String operatingUnitName = DiagnosticsTestMappingCSVReader.getoperatingUnitName();
		diagnosticsTestMapping.clickoperatingUnitCard(operatingUnitName);
    }
	
	/********************************************************************
	* Description: verify Test coverage page
	* Status: Completed
	********************************************************************/
	@Then("^I can see the Diagnostics Test Mapping Test Coverage page$")
    public void i_can_see_the_diagnostics_test_mapping_test_coverage_page() 
    {
		String testCoveragePageURL = DiagnosticsTestMappingCSVReader.getBaseUrl()+ DiagnosticsTestMappingCSVReader.getTestCoveragePageUrl();
		assertTrue(diagnosticsTestMapping.diagnosticsTestMappingtestCoveragePage(testCoveragePageURL));
    }
	
	/********************************************************************
	* Description: Enter valid data in DiagnosticsTestMapping customer search field
	* Status: Completed
	********************************************************************/
	@And("^I Enter valid data in DiagnosticsTestMapping customer search field$")
    public void i_enter_valid_data_in_diagnosticstestmapping_customer_search_field()
    {
		String validCustomerName = DiagnosticsTestMappingCSVReader.getsearchvalidCustomerName();
		diagnosticsTestMapping.searchValidCustomer(validCustomerName);
    }
	
	/********************************************************************
	* Description: verify list of customers in DiagnosticsTestMapping Customerpage
	* Status: Completed
	********************************************************************/
	@Then("^I can see list of customers in DiagnosticsTestMapping Customerpage$")
    public void i_can_see_list_of_customers_in_diagnosticstestmapping_customerpage() 
    {
		assertTrue("Search field is not working for valid input",diagnosticsTestMapping.verifyValidCustomer());
    }

	/********************************************************************
	* Description: Enter Invalid data in DiagnosticsTestMapping customer search field
	* Status: Completed
	********************************************************************/
	@And("^I Enter Invalid data in DiagnosticsTestMapping customer search field$")
    public void i_enter_invalid_data_in_diagnosticstestmapping_customer_search_field() 
    {
		String InvalidCustomerName = DiagnosticsTestMappingCSVReader.getsearchInvalidCustomerName();
		diagnosticsTestMapping.searchInValidCustomer(InvalidCustomerName);
    }
	
	/********************************************************************
	* Description: Verify empty list of customers in DiagnosticsTestMapping Customerpage
	* Status: Completed
	********************************************************************/
	@Then("^I can see empty list of customers in DiagnosticsTestMapping Customerpage$")
    public void i_can_see_empty_list_of_customers_in_diagnosticstestmapping_customerpage()
    {
		assertTrue("Search field is not working for invalid input",diagnosticsTestMapping.verifyInValidCustomer());
    }
	
	/********************************************************************
	* Description: Enter valid data in DiagnosticsTestMapping Equipment search field
	* Status: Completed
	********************************************************************/
	@And("^I Enter valid data in DiagnosticsTestMapping Equipment search field$")
    public void i_enter_valid_data_in_diagnosticstestmapping_equipment_search_field()
    {
		String validEquipmentName = DiagnosticsTestMappingCSVReader.getsearchvalidEquipmentName();
		diagnosticsTestMapping.searchValidEquipment(validEquipmentName);
    }
	
	/********************************************************************
	* Description: Verify list of customers in DiagnosticsTestMapping Equipmentpage
	* Status: Completed
	********************************************************************/
	@Then("^I can see list of items in DiagnosticsTestMapping Equipmentpage$")
    public void i_can_see_list_of_items_in_diagnosticstestmapping_equipmentpage()    {
		assertTrue("Search field is not working for valid input",diagnosticsTestMapping.verifyValidEquipment());
    }
	
	/********************************************************************
	* Description: Enter Invalid data in DiagnosticsTestMapping Equipment search field
	* Status: Completed
	********************************************************************/
	@And("^I Enter Invalid data in DiagnosticsTestMapping Equipment search field$")
    public void i_enter_invalid_data_in_diagnosticstestmapping_equipment_search_field()
    {
		String InvalidEquipmentName = DiagnosticsTestMappingCSVReader.getsearchInvalidEquipmentName();
		diagnosticsTestMapping.searchInValidEquipment(InvalidEquipmentName);
    }
	
	/********************************************************************
	* Description: Enter Invalid data in DiagnosticsTestMapping Equipment search field
	* Status: Completed
	********************************************************************/
	@Then("^I can see empty list of items in DiagnosticsTestMapping Equipmentpage$")
    public void i_can_see_empty_list_of_items_in_diagnosticstestmapping_equipmentpage()    
	{
		assertTrue("Search field is not working for invalid input",diagnosticsTestMapping.verifyInValidEquipment());
    }
	
	/********************************************************************
	* Description: Enter valid data in DiagnosticsTestMapping DiagnosticsTest search field
	* Status: Completed
	********************************************************************/
	@And("^I Enter valid data in DiagnosticsTestMapping DiagnosticsTest search field$")
    public void i_enter_valid_data_in_diagnosticstestmapping_diagnosticstest_search_field()
	{
		String validDiagnosticsTestName = DiagnosticsTestMappingCSVReader.getsearchvalidDiagnosticsTestName();
		diagnosticsTestMapping.searchValidDiagnosticsTest(validDiagnosticsTestName);
	}
	
	/*********************************************************************
	* Description: verify list of items in DiagnosticsTestMapping DiagnosticsTestpage
	* Status: Completed
	********************************************************************/
	@Then("^I can see list of items in DiagnosticsTestMapping DiagnosticsTestpage$")
    public void i_can_see_list_of_items_in_diagnosticstestmapping_diagnosticstestpage()
	{
		assertTrue("Search field is not working for valid input",diagnosticsTestMapping.verifyValidDiagnosticsTest());
	}
	
	/*********************************************************************
	* Description: Enter Invalid data in DiagnosticsTestMapping DiagnosticsTest search field
	* Status: Completed
	********************************************************************/
	@And("^I Enter Invalid data in DiagnosticsTestMapping DiagnosticsTest search field$")
    public void i_enter_invalid_data_in_diagnosticstestmapping_diagnosticstest_search_field()
	{
		String InvalidDiagnosticsTestName = DiagnosticsTestMappingCSVReader.getsearchInvalidDiagnosticsTestName();
		diagnosticsTestMapping.searchInValidDiagnosticsTest(InvalidDiagnosticsTestName);
	}
	
	/*********************************************************************
	* Description: verify empty list of items in DiagnosticsTestMapping DiagnosticsTestpage
	* Status: Completed
	********************************************************************/
	@Then("^I can see empty list of items in DiagnosticsTestMapping DiagnosticsTestpage$")
    public void i_can_see_empty_list_of_items_in_diagnosticstestmapping_diagnosticstestpage()
	{
		assertTrue("Search field is not working for invalid input",diagnosticsTestMapping.verifyInValidDiagnosticsTest());
	}
	
	/*********************************************************************
	* Description: Enter valid data in DiagnosticsTestMapping Operatingunit search field
	* Status: Completed
	********************************************************************/
	 @And("^I Enter valid data in DiagnosticsTestMapping Operatingunit search field$")
	    public void i_enter_valid_data_in_diagnosticstestmapping_operatingunit_search_field() 
	{
		 String validOperatingunitName = DiagnosticsTestMappingCSVReader.getsearchvalidOperatingunitName();
			diagnosticsTestMapping.searchValidOperatingunit(validOperatingunitName);
	}
	
	/*********************************************************************
	* Description: verify list of items in DiagnosticsTestMapping Operatingunitpage
	* Status: Completed
	********************************************************************/
	 @Then("^I can see list of items in DiagnosticsTestMapping Operatingunitpage$")
	    public void i_can_see_list_of_items_in_diagnosticstestmapping_operatingunitpage()
	{
		 assertTrue("Search field is not working for valid input",diagnosticsTestMapping.verifyValidOperatingunit());
	}
	 
    /*********************************************************************
	* Description: Enter Invalid data in DiagnosticsTestMapping Operatingunit search field
	* Status: Completed
	********************************************************************/
	 @And("^I Enter Invalid data in DiagnosticsTestMapping Operatingunit search field$")
	    public void i_enter_invalid_data_in_diagnosticstestmapping_operatingunit_search_field()
	 {
		 String InvalidOperatingunitName = DiagnosticsTestMappingCSVReader.getsearchInvalidOperatingunitName();
			diagnosticsTestMapping.searchInValidOperatingunit(InvalidOperatingunitName);
	 }
	 
	 /*********************************************************************
	* Description: verify empty list of items in DiagnosticsTestMapping Operatingunitpage
	* Status: Completed
	 ********************************************************************/
	 @Then("^I can see empty list of items in DiagnosticsTestMapping Operatingunitpage$")
	    public void i_can_see_empty_list_of_items_in_diagnosticstestmapping_operatingunitpage()
	 {
		 assertTrue("Search field is not working for Invalid input",diagnosticsTestMapping.verifyInValidOperatingunit());
	 }
	 
    /*********************************************************************
	* Description: enable disable the toggle bar in Testcoverage page
	* Status: Completed
	 ********************************************************************/
	 @And("^I disable the toggle bar in Testcoverage page$")
	    public void i_disable_the_toggle_bar_in_testcoverage_page()
	    {
		 String testCoveragematcardName = DiagnosticsTestMappingCSVReader.gettestCoveragematcardName();
		 diagnosticsTestMapping.enableDisableToggleinTestcoveragePage(testCoveragematcardName);
	    }
	
	/*********************************************************************
	* Description: verify the toggle bar is disabled
	* Status: Completed
	 ********************************************************************/
	 @Then("^verify the toggle bar is disabled in Testcoverage page$")
	    public void verify_the_toggle_bar_is_disabled_in_testcoverage_page()
	    {
		 String testCoveragematcardName = DiagnosticsTestMappingCSVReader.gettestCoveragematcardName();
		 assertTrue("Not disabled", diagnosticsTestMapping.verifyDisableToggleinTestcoveragePage(testCoveragematcardName));
	    }
		
		 /*********************************************************************
		* Description: enable  disable the toggle bar in Testcoverage page
		* Status: Completed
		 ********************************************************************/
		 @And("^I enable the toggle bar in Testcoverage page$")
		    public void i_enable_the_toggle_bar_in_testcoverage_page()
			    {
			 String testCoveragematcardName = DiagnosticsTestMappingCSVReader.gettestCoveragematcardName();
				 diagnosticsTestMapping.enableDisableToggleinTestcoveragePage(testCoveragematcardName);
			    }
			
		 /*********************************************************************
		* Description: verify the toggle bar is disabled
		* Status: Completed
		 ********************************************************************/
		 @Then("^verify the toggle bar is enabled in Testcoverage page$")
		    public void verify_the_toggle_bar_is_enabled_in_testcoverage_page()
		   {
			 String testCoveragematcardName = DiagnosticsTestMappingCSVReader.gettestCoveragematcardName();
			 assertTrue("Not enabled", diagnosticsTestMapping.verifyEnableToggleinTestcoveragePage(testCoveragematcardName));
	     }
}