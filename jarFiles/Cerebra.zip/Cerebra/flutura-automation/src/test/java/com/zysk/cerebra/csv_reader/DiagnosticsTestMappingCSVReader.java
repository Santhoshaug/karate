
package com.zysk.cerebra.csv_reader;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

import com.zysk.cerebra.commonPages.CommonFunctions;

public class DiagnosticsTestMappingCSVReader extends CommonFunctions {
	
	public static String target = "src/test/resources/dataSources/diagnosticsTestMappingData.csv";
	private static HashMap<String,String> data;

	 public static void loadCSV() {

		   data = new HashMap<String, String>();
		   String line;
		   String [] split;
		   
		   try (BufferedReader br = new BufferedReader(new FileReader(target))) {

		   System.out.println("Reading from " + target);
		   while ((line = br.readLine()) != null) {
		   split = line.split(",");
		   String key = split[0];
		   String value = split[1];

		   if (System.getProperty(key) != null) {
		   value = System.getProperty(key);
		   System.out.println("Overriding key '" + key + "' with value '" + value + "'");
		   }

		   data.put(key,value);
		   }

		   } catch (IOException e) {
		   System.out.println("\n***** ERROR: CSV not found. *****\n");
		   }

		   }

	   public static String getKey(String key) {

		   if (data == null) loadCSV();

		   if (data.get(key) == null) return "ERROR: Key not found";

		   return data.get(key);

		   }

	public static String getBaseUrl() 
	{
		return getKey("baseUrl");
	}

	public static String getDTMCUrl()
	{
		return getKey("customerpageURL");
	}

	public static String getcustomerName() 
	{
		return getKey("customerName");
	}

	public static String getEquipmentPageUrl()
	{
		return getKey("EquipmentPageUrl");
	}

	public static String getEquipmentName()
	{
		return getKey("EquipmentName");
	}

	public static String getdiagnosticsPageUrl() 
	{
		return getKey("diagnosticsPageUrl");
	}

	public static String getDiagnosticTestsName() 
	{
		return getKey("DiagnosticTestsName");
	}

	public static String getOperatingUnitPageUrl() 
	{
		return getKey("OperatingUnitPageUrl");
	}

	public static String getoperatingUnitName() 
	{
		return getKey("operatingUnitName");
	}

	public static String getTestCoveragePageUrl()
	{
		return getKey("TestCoveragePageUrl");
	}

	public static String getsearchvalidCustomerName() 
	{
		return getKey("searchvalidCustomerName");
	}

	public static String getsearchInvalidCustomerName() 
	{
		return getKey("searchInvalidCustomerName");
	}

	public static String getsearchvalidEquipmentName() 
	{
		return getKey("searchvalidEquipmentName");
	}

	public static String getsearchInvalidEquipmentName() 
	{
		return getKey("searchInvalidEquipmentName");
	}

	public static String getsearchvalidDiagnosticsTestName() 
	{
		return getKey("searchvalidDiagnosticsTestName");
	}

	public static String getsearchInvalidDiagnosticsTestName() 
	{
		return getKey("searchInvalidDiagnosticsTestName");
	}

	public static String getsearchvalidOperatingunitName() 
	{
		return getKey("searchvalidOperatingunitName");
	}

	public static String getsearchInvalidOperatingunitName() 
	{
		return getKey("searchInvalidOperatingunitName");
	}
	
	public static String gettestCoveragematcardName()
	{
		return getKey("testCoveragematcardName");
	}

}
