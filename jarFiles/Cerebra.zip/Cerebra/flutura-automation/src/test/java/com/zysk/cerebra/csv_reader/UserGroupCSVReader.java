package com.zysk.cerebra.csv_reader;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

public class UserGroupCSVReader {
	
	private static String path = "src/test/resources/dataSources/userGroup.csv";
	private static HashMap<String,String> data;
	
   
   public static void loadCSV(String target) {

	   data = new HashMap<String, String>();
	   String line;
	   String [] split;

	   target = path;
	   
	   try (BufferedReader br = new BufferedReader(new FileReader(target))) {

	   System.out.println("Reading from " + target);
	   while ((line = br.readLine()) != null) {
	   split = line.split(",");
	   String key = split[0];
	   String value = split[1];

	   if (System.getProperty(key) != null) {
	   value = System.getProperty(key);
	   System.out.println("Overriding key '" + key + "' with value '" + value + "'");
	   }

	   data.put(key,value);
	   }

	   } catch (IOException e) {
	   System.out.println("\n***** ERROR: CSV not found. *****\n");
	   }

	   }

   public static String getKey(String key) {

	   if (data == null) loadCSV(path);

	   if (data.get(key) == null) return "ERROR: Key not found";

	   return data.get(key);
   }

   public static String getValidCustomerName() {
		return getKey("ValidcustomerName");
	}
   
   public static String getInValidCustomerName() {
	   return getKey("InvalidCustomerName");
   }
   
   public static String getCustomerNameTOSelectAndVerify() {
	   return getKey("CustomerNameToSelectAndVerify");
   }
    
   public static String getUserGroupName() {
	   return getKey("UserGroupName");
   }
   
   public static String getValidUserGroupName() {
	   return getKey("ValidUserGroupNameToSearch");
   }
   
   public static String getInValidUserGroupName() {
	   return getKey("InValidUserGroupNameToSearch");
   }
   
   public static String getValidUserName() {
	   return getKey("ValidUserNameToSearch");
   }
   
   public static String getInValidUserName() {
	   return getKey("InValidUserNameToSearch");
   }
   
   public static String getUserNameToAddUserGroup() {
	   return getKey("UserNameToAddUserGroup");
   }
   
   public static String getUserNameToVerifyGroupAssigned() {
	   return getKey("UserNameToVerifyGroupAssigned");
   }
   
   public static String getUserGroupNameToDelete() {
	   return getKey("UserGroupNameToDelete");
   }
   
   public static String getSelectUserName() {
	   return getKey("SelectUserName");
   }
   
   public static String getUserGroupNameToVerifyCancel() {
	   return getKey("UserGroupNameToVerifyCancel");
   }
   
   public static String getInvalidDataToUserGroupTextField() {
	   return getKey("InvalidDataToUserGroupTextField");
   }
}
