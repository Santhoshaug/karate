package com.zysk.cerebra;


import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;
//import org.junit.runner.RunWith;
import net.serenitybdd.junit.runners.SerenityRunner;

@RunWith(CucumberWithSerenity.class)
//@CucumberOptions(features = "src/test/resources/features/Customer.feature",tags={"@Test22"})
//@CucumberOptions(features = "src/test/resources/features/Login.feature")
// @CucumberOptions(features = "src/test/resources/features/Users.feature",tags={"@Test40"})
//@CucumberOptions(features = "src/test/resources/features/UserGroup.feature",tags={"@Test1"})
//@CucumberOptions(features = {"src/test/resources/features/Equipment Structure.feature","src/test/resources/features/AccessControl.feature"})
//@CucumberOptions(features = {"src/test/resources/features/Equipment Structure.feature", "src/test/resources/features/ManufacturerAndModels.feature","src/test/resources/features/OperatingUnit.feature"})
//@CucumberOptions(features = "src/test/resources/features/Equipment Structure.feature",tags= {"@Test012"})
//@CucumberOptions(features = "src/test/resources/features/ManufacturerAndModels.feature", tags= {"@Test122"})
//@CucumberOptions(features = {"src/test/resources/features/OperatingUnit.feature","src/test/resources/features/AccessControl.feature","src/test/resources/features/DigitalMachine.feature"},tags= {"@Test"})
//@CucumberOptions(features = "src/test/resources/features/ManufacturerAndModels.feature", tags= {"@Test100"})
//@CucumberOptions(features = "src/test/resources/features/OperatingUnit.feature",tags= {"@Test111"})
//@CucumberOptions(features = {"src/test/resources/features/Equipment Structure.feature","src/test/resources/features/ManufacturerAndModels.feature"})
//@CucumberOptions(features = "src/test/resources/features/AccessControl.feature",tags= {"@Test"})
//@CucumberOptions(features = "src/test/resources/features", tags= {"@Configuration.feature", "@Customer.feature", "@Login.feature" , "@Users.feature"})
@CucumberOptions(features = "src/test/resources/features/DigitalMachine.feature",tags= {"@Test112"})
//@CucumberOptions(features = "src/test/resources/features/DiagnosticsWorkBench.feature",tags={"@Test10"})
//@CucumberOptions(features = "src/test/resources/features/DiagnosticsTestMapping.feature",tags={"@Test1"})


public class TestRunner {
	
	

}
