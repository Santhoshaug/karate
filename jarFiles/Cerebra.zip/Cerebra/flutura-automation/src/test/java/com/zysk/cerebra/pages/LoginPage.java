package com.zysk.cerebra.pages;


import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.zysk.cerebra.commonPages.CommonFunctions;
import com.zysk.cerebra.csv_reader.CSVHelper;
import com.zysk.cerebra.csv_reader.EquipmentStructureCSVReader;

import net.serenitybdd.core.pages.PageObject;

import net.thucydides.core.annotations.DefaultUrl;
//@DefaultUrl("https://cerebra.flutura.com/")
//@DefaultUrl("http://cerebra.cloudapp.net:3333/#/")
//@DefaultUrl("https://hearslivet.gtt.live/#/")
//@DefaultUrl("https://insitex-qas.lab.technipfmc.com/")
//@DefaultUrl("http://cerebra.cloudapp.net:82/")
@DefaultUrl("http://cerebra.cloudapp.net:3000/")
public class LoginPage extends CommonFunctions{
	
	/***********************Page element identifiers******************************/
	
	private By email = By.xpath("//input[@name='username']");
	private By password = By.xpath("//input[@name='password']");
	private By login=By.xpath("//button[contains(text(),'Login')]");
	private By statusbar=By.xpath("//div[@id='infoStusBar']");
	private By assetview=By.xpath("//multi-step-toggle[@id='toggleTabMapView']");
	private By map=By.xpath("//div[@id='mapContainer']");
	private By errorMsg=By.xpath("//span[contains(text(),'Invalid Credentials!')]");
	
	public By demoCustomer = By.xpath("//a[contains(text(),'Flutura - Demo Customer')]");
	
	private static String homePageUrl="http://cerebra.cloudapp.net:3000/cerebra/#/AssetMonitor/AssetMonitor";
	private By toolBar = By.xpath("//toolbar[@class='above cbr_toolbar_bg ng-star-inserted']");
	private By loader2 = By.xpath("//img[@id='splashScreenImage']");
	
	
	/********************************************************************
	* Description: Verify Login Page
	* Param: NA
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyLoginPage()
	{
		return element(email).isCurrentlyVisible() && element(password).isCurrentlyVisible() && element(login).isCurrentlyVisible();
	}
	
	/********************************************************************
	* Description: Enter valid credentials and Login
	* Param: NA
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void enterValidCredentials()
	{
		getDriver().manage().window().maximize();
		waitFor(5000);
		element(email).sendKeys(CSVHelper.getLoginEmail());
		element(password).sendKeys(CSVHelper.getLoginPassword());
		element(login).click();
		waitForElementToDisappear(loader2);
//		waitForElementToDisappear(loader);
//		waitSeconds(10);
	}
	
	/********************************************************************
	* Description: Verify Home page
	* Param: NA
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyHomePage() 
	{
		waitForElementToLoad(toolBar);
		//waitForPageToLoad();
		if (getDriver().getCurrentUrl().equals(homePageUrl)) return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Verify Asset Monitor Page
	* Param: NA
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean veirfyAssetMonitorElements()
	{
		if((element(statusbar).isCurrentlyVisible()) && (element(assetview).isCurrentlyVisible()) && (element(map).isCurrentlyVisible()) )
		return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Enter Invalid credentials and try login
	* Param: NA
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void enterInvalidCredentials()
	{
		element(email).sendKeys("jiki@flutura.com");
		element(password).sendKeys("User@1234");
		element(login).click();
	}
	
	/********************************************************************
	* Description: Verify error message by entering invalid credentials 
	* Param: NA
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyErrorMessage()
	{
		String expErrorMsg = "Invalid Credentials!";
		String actErrorMsg = element(errorMsg).getText();
		if (element(errorMsg).isCurrentlyVisible() && actErrorMsg.contains(expErrorMsg))  return true;
		else return false;
	}
	

}
