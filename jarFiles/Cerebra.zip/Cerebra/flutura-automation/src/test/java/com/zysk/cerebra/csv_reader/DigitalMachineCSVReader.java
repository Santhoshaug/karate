package com.zysk.cerebra.csv_reader;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

import com.zysk.cerebra.commonPages.CommonFunctions;

public class DigitalMachineCSVReader extends CommonFunctions {
	public static String target = "src/test/resources/dataSources/digitalMachine.csv";
	private static HashMap<String,String> data;

	 public static void loadCSV() {

		   data = new HashMap<String, String>();
		   String line;
		   String [] split;
		   
		   try (BufferedReader br = new BufferedReader(new FileReader(target))) {

		   System.out.println("Reading from " + target);
		   while ((line = br.readLine()) != null) {
		   split = line.split(",");
		   String key = split[0];
		   String value = split[1];

		   if (System.getProperty(key) != null) {
		   value = System.getProperty(key);
		   System.out.println("Overriding key '" + key + "' with value '" + value + "'");
		   }

		   data.put(key,value);
		   }

		   } catch (IOException e) {
		   System.out.println("\n***** ERROR: CSV not found. *****\n");
		   }

		   }

	   public static String getKey(String key) {

		   if (data == null) loadCSV();

		   if (data.get(key) == null) return "ERROR: Key not found";

		   return data.get(key);

		   }
	   
	   public static String getDMUrl()
	   {
		   return getKey("digitalMachineUrl");
	   }
	   
	   public static String getEquipmentName()
	   {
		   return getKey("equipmentName");
	   }
	   
	   public static String getDigitalMachineModelUrl()
	   {
		   return getKey("digitalMachineModelUrl");
	   }
	   
	   public static String getModel() {
		   return getKey("modelSelect");
		   
	   }
	   
	   public static String getDigitalMachineDetailsListlUrl()
	   {
		   return getKey("digitalMachineDetailsListlUrl");
	   }
	   
	   public static String getDMName() {
		   return getKey("digitalMachineName");
		   
	   }
	   
	   public static String getUpdatedName() {
		   return getKey("digitalMachiceUpdatedName");
	   }
	   
	   public static String getExistingDigitalMachine() {
		   return getKey("existingDigitalMachiceName");
	   }
	   
	   public static String getDMSubsystemURL() {
		   return getKey("digitalMachineSubSystemUrl");
	   }
	   
	   public static String getAddSubSystem() {
		   return getKey("subSystemName");
	   }
	   
	   public static String getOperatingCharacteristicsURL() {
		   return getKey("operatingCharacteristicsURL");
	   }
	   
	   public static String getsubSystemInLevel() {
		   return getKey("addSubsystemInLevels");
	   }
	   
	   public static String getselectSubSystemAddInLevel() {
		   return getKey("selectSubsysyemtoaddnewsubsysyteminlevels");
	   }
	   
	   public static String getselectSubSystemToDeleteInLevel() {
		   return getKey("selectSubsystemToDeleteInlevel");
	   }
	   
	   public static String getAddDuplicateSubsystemName() {
		   return getKey("DuplicateSubsystemName");
	   }
	   
	   public static String getDataToSearch() {
		   return getKey("ValidDataToSearchEquipments");
	   }
	   
	   public static String getInvalidDataToSearch() {
		   return getKey("InValidDataToSearchEquipments");
	   }
	   
	   public static String getValidDataToSearchModel() {
		   return getKey("ValidDataToSearchModels");
	   }
	   
	   public static String getInValidDataToSearchModel() {
		   return getKey("InValidDataToSearchModels");
	   }
	   
	   public static String getValidDigitalMachineNameToSearchInDigitalMachineTab() {
		   return getKey("ValidDigitalMachineNameToSearchInDigitalMachineTab");
	   }
	   
	   public static String getInValidDigitalMachineNameToSearchInDigitalMachineTab() {
		   return getKey("InValidDigitalMachineNameToSearchInDigitalMachineTab");
	   }
	   
	   public static String getDigitalMachineToDelete() {
		   return getKey("DigitalMachineToDelete");
	   }

	public static String getValidOperaticUnitTOSearch() {
		 return getKey("ValidOperaticUnitTOSearch");
	}
	
	public static String getInValidOperaticUnitTOSearch() {
		 return getKey("InValidOperaticUnitTOSearch");
	}
}
