package com.zysk.cerebra.pages;

import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.hamcrest.core.IsEqual;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.PageObjects;
import com.zysk.cerebra.commonPages.CommonFunctions;
import com.zysk.cerebra.csv_reader.CustomerCSVReader;
import com.zysk.cerebra.csv_reader.UserCSVReader;

import net.serenitybdd.core.pages.PageObject;

import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.interactions.Actions;


public class CustomerPage extends CommonFunctions{
	
	/***********************Page element identifiers******************************/
	
	private By customer = By.xpath("//a[text()=' Customer ']");
	private By customerTab = By.xpath("//span[contains(text(),' Customers')]");
	private By detailsTab = By.xpath("//span[contains(text(),'Details')]");
	private By contactsTab = By.xpath("//span[contains(text(),' Contacts ')]");
	private By locationstab = By.xpath("//span[contains(text(),' Locations ')]");
	private By addNewButton = By.xpath("//span[contains(text(),'Add New ')]");
	private By searchBar = By.xpath("//input[@placeholder='Search..']");
	private By customerNamefield = By.xpath("//input[@id='name']");
	private By customerNumberfield = By.xpath("//input[@id='number']");
	private By fileUpload = By.xpath("//input[@id='files']");
	private By removeButton = By.xpath("//a//span[contains(text(),'Remove')]");
	private By preview = By.xpath("//div[@class='col-lg-5 col-md-12']");
	private By add = By.xpath("//button[@type='submit']");
	private By customerTiles = By.xpath("//div[@class='row']");
	private By addNewContactButton = By.xpath("//span[contains(text(),'Add New')]");
	private By contactName = By.xpath("//input[@name='Contact Name']");
	private By contactMobile = By.xpath("//input[@name='Contact Mobile']");
	private By contactEmail = By.xpath("//input[@name='Contact Email']");
	private By submit = By.xpath("//span[text()=' Add ']");
	private By cancelButton = By.xpath("//button//span[text()=' Cancel ']");
	private By cNameField = By.xpath("(//span[@class='plain-title-text textoverFlow'])[1]");
	private By cNumberField = By.xpath("(//span[@class='plain-title-text textoverFlow'])[2]");
	private By cEmailField = By.xpath("(//span[@class='plain-title-text textoverFlow'])[3]");
	private By locationTab = By.xpath("//span[contains(text(),' Locations ')]");
	private By addNewLocation = By.xpath("//span[contains(text(),' Add New ')]");
	private By locationNameField = By.xpath("//input[@formcontrolname='name']");
	private By locationType = By.xpath("//span[text()='Select Gateway']");
	private By search = By.xpath("//input[@id='search']");
	private By submitLocation = By.xpath("//button[@type='submit']");
	private By listOfCustomer = By.xpath("//div[@class='row']/div");
	private By enableToggleButton = By.xpath("//div[@class='mat-slide-toggle-bar mat-slide-toggle-bar-no-side-margin']");
	private By locationPreview = By.xpath("//mat-card[@class='cursor mat-card mat-elevation-z8']");
	private By locationNamePreview = By.xpath("//span[@class='textoverFlow']");
	private By successfulORErrorMessage = By.xpath("//simple-snack-bar//span");
	private By customerCreateSuccessfulMessage = By.xpath("//simple-snack-bar//span");
	private By addDomain = By.xpath("//span[contains(text(),'Domains')]//..//a[contains(text(),' Add Domains ')]");
	private By homeIcon = By.xpath("//div//i[@class='fa fa-home custom-menu-icon']");
	private By customertab = By.xpath("//button//span[text()=' Customers ']");
    private static String customerName = "TestCustomer";
	public By customerCreated = By.xpath("//a[text()='"+customerName+"']");
	private By customerDisabled = By.xpath("//a[text()='"+customerName+"']/../..//div[@class='custom-top-border']");
	private By UpdateButton = By.xpath("//button//span[text()=' Update ']");
	private By CustomerNametextFieldErrorMessage = By.xpath("//mat-error//span");
	private By ImageErrorMessage = By.xpath("//input[@id='files']//..//span");
	private By addDomainPlaceholder = By.xpath("//input[@placeholder='Enter Domains']");
	private By addDomainOK = By.xpath("//mat-icon[text()='done']");
	private By addDomainClose = By.xpath("//mat-icon[text()='close']");
	private By popUpYesButton = By.xpath("//button[contains(text(),'Yes, delete it!')]");
	private By UpdateContact = By.xpath("//span[contains(text(),' Update ')]");
	private By CancelButton = By.xpath("//button//span[contains(text(),'Cancel')]");
	
	
	private static int customerNumber = 1234567890;
	private static String contactNameAdded = "Test";
	private static String contactNumberAdded = "9090909091";
	private static String contactEmailAdded = "test@testing.com";
	private static String locationName = "Test Location";
	private static String locationTypeSelection = "Headquarter"; 
	private By locationSelected = By.xpath("//mat-option//span[contains(text(),'"+locationTypeSelection+"')]");
	//private By locationSelected = By.xpath("//mat-option//span[contains(text(),'Headquarter')]");
	private static String CustomerUrl = "https://cerebra.flutura.com/configuration#/customers";
	
	

	
	
	
	/********************************************************************
	* Description: Visit customer page by clicking on Customer link
	* Param: NA
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void clickCustomerLink()
	{
		element(customer).click();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verify customer page
	* Param: NA
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyCustomerPage(String expUrl)
	{
		String actUrl = getDriver().getCurrentUrl();
		if (actUrl.contains(expUrl) &&
				element(customerTab).isCurrentlyEnabled() &&
				element(detailsTab).isCurrentlyVisible() &&
				element(contactsTab).isCurrentlyVisible()  && 
				element(locationstab).isCurrentlyVisible()  && 
				element(addNewButton).isCurrentlyEnabled() && 
				element(searchBar).isCurrentlyVisible() &&
				element(customerTiles).isCurrentlyVisible())
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Click on Add New button in customer page
	* Param: NA
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void clickAddNewButton()
	{
		element(addNewButton).click();
		waitForElementToDisappear(loader);
		//waitSeconds(5);
	}
	
	/********************************************************************
	* Description: Enter Customer Details in Add customer page
	* Param: NA
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void enterCustomerDetails(String customerNameToAdd, String CustomerNumberToAdd, String CustomerImage) 
	{
		element(customerNamefield).sendKeys(customerNameToAdd);
		element(customerNumberfield).sendKeys(CustomerNumberToAdd);
//		element(fileUpload).sendKeys("C:\\Users\\Admin\\Documents\\Automationdoc\\samplelogo.png");
		element(fileUpload).sendKeys(CustomerImage);
		element(add).click();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verify Customer is created
	* Param: NA
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyCustomerCreated(String AddedCustomerName)
	{
		String actSuccessfulMessage = element(successfulORErrorMessage).getText();
		String ActlResult = "New Customer '"+AddedCustomerName+"' added successfully";
		if(actSuccessfulMessage.equals(ActlResult))		
		return true;
		else
		return false;
		
	}
	
	/********************************************************************
	* Description: Verify search field by entering valid data 
	* Param: NA
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public void verifySearchField()
	{
		element(searchBar).sendKeys(CustomerCSVReader.getValidCustomerNameToSearch());
	}
	
	/**********************************************************************
	* Description: List of customer will be displayed based on entered data 
	* Param: NA
	* Returns: Boolean
	* Status: Completed
	***********************************************************************/
	public boolean verifySearchFieldForValidInputs(String CustomerName)
	{
		List<WebElement> customerList = getDriver().findElements(listOfCustomer);
		int s = customerList.size();
		if(element(By.xpath("//mat-card//div//a[contains(text(),'"+CustomerName+"')]")).isCurrentlyVisible()&&
				
		(s>0) )

		return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Verify search field by entering valid data 
	* Param: NA
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public void verifySearchFieldWithInvalidInput()
	{
		element(searchBar).sendKeys(CustomerCSVReader.getInValidCustomerNameToSearch());
	}
	
	
	/***********************************************************************
	* Description: List of customer will be displayed based on entered data 
	* Param: NA
	* Returns: Boolean
	* Status: Completed
	***********************************************************************/
	
	public boolean verifySearchFieldForInValidInputs(String CustomerName)
	{
		List<WebElement> customerList = getDriver().findElements(listOfCustomer);
		int s = customerList.size();
		if(!(element(By.xpath("//mat-card//div//a[contains(text(),'"+CustomerName+"')]"))).isCurrentlyVisible()&&
			
		(s==0) )

		return true;
		else return false;
	}
	
	
	/********************************************************************
	* Description: Click on Customer
	* Param: NA
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void selectCustomer(String customerName)
	{
		element(By.xpath("//mat-card//a[contains(text(),'"+customerName+"')]")).click();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verify customer details
	* Param: NA
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyCustomerDetails(String expUrl, String CustomerName)
	{
		String actUrl = getDriver().getCurrentUrl();
		if (actUrl.contains(expUrl) && 
				element(By.xpath("//p[contains(text(),'"+CustomerName+" - Details')]")).isCurrentlyVisible())
			return true;
		else return false;
		
	}

	/********************************************************************
	* Description: Click on Contacts tab
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void clickContacts()
	{
		element(contactsTab).click();
	    waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Click on Add new contact
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void clickAddNewContact()
	{
		element(addNewContactButton).click();
	}
	
	/********************************************************************
	* Description: Enter all contact details and submit it
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void enterContactDetails(String NewContactName,String NewContactMobile,String NewContactEmail)
	{
		element(contactName).sendKeys(NewContactName);
		element(contactMobile).sendKeys(NewContactMobile);
		element(contactEmail).sendKeys(NewContactEmail);
		element(submit).click();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verify Contact details
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyContactDetails(String contactNameAdded, String contactMobileAdded, String contactEmailAdded)
	{
		String actSuccessfulMessage = element(successfulORErrorMessage).getText();
		System.out.println(actSuccessfulMessage);
		String ExptMessage = "Contact saved successfully";
		if (actSuccessfulMessage.equals(ExptMessage))
			return true;
		else return false;
//		if(element(cNameField).getText().equals("'"+contactNameAdded+"'") &&
//		   element(cNumberField).getText().equals("'"+contactMobileAdded+"'") &&
//		   element(cEmailField).getText().equals("'"+contactEmailAdded+"'")) 
//			return true;
//		else return false;
	}
	
	
	/********************************************************************
	* Description: Click on Location tab
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void clickLocation()
	{
		element(locationTab).click();
	   waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Click on Add new button
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void clickAddNewLocationButton()
	{
		element(addNewButton).click();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Enter all location details and submit it
	* Param: NA
	* Returns: void
	* Status: In Progress
	********************************************************************/
	public void enterLocationDetails(String Location, String locationTypedropdown, String LocationToSearch)
	{
		element(locationNameField).sendKeys(Location);
		element(locationType).click();
		element(By.xpath("//mat-option//span[contains(text(),'"+locationTypedropdown+"')]")).click();
		element(search).sendKeys(LocationToSearch, Keys.ARROW_DOWN,Keys.ENTER);
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verify Location Preview
	* Param: NA
	* Returns: void
	* Status: In Progress
	********************************************************************/
	public boolean locationPreview()
	{
		String actSuccessfulMessage = element(successfulORErrorMessage).getText();
		System.out.println(actSuccessfulMessage);
		String ExptMessage = "Location saved successfully!";
		if (actSuccessfulMessage.equals(ExptMessage))
//		element(locationPreview).isCurrentlyVisible() &&
//				element(locationNamePreview).getText().equals(locationName)) 
				return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Disable the customer
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public void toggleCustomertToDisable()
	{
		if (element(By.xpath("//span[contains(text(),'Enabled')]")).isCurrentlyVisible()==true)
	element(enableToggleButton).click();
	waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verify disable customer
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyCustomerDisabled(String CustomerName)
	{
		String actSuccessfulMessage = element(successfulORErrorMessage).getText();
		String ExptMessage = "Customer '"+CustomerName+"' disabled";
		if (actSuccessfulMessage.equals(ExptMessage))
				return true;
		else return false;
		
//		if (element(customerNamefield).isCurrentlyEnabled() &&
//				element(customerNumberfield).isCurrentlyEnabled()) return true;
//		else return false;
	}
	
	/********************************************************************
	* Description: Click on customer tab
	* Param: NA
	* Returns: void
	* Status: 
	********************************************************************/
	public void clickCustomerTab()
	{
		element(customerTab).click();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: click on Dashboard
	* Param: NA
	* Returns: void
	* Status: 
	********************************************************************/
	public void clickOnHomeIcondashboard()
	{
		element(homeIcon).click();
		waitForElementToDisappear(loader);
	}
	

	/********************************************************************
	* Description: click on Customer Tab
	* Param: NA
	* Returns: void
	* Status: 
	********************************************************************/
	public void clickOnCustomerTab()
	{
		element(customertab).click();
		waitForElementToDisappear(loader);
	}
	
	
	/********************************************************************
	* Description: Disabled customer will be displayed as Disabled in customer list
	* Param: NA
	* Returns: Boolean
	* Status: 
	********************************************************************/
	public boolean verifyDisabledCustomerInCustomerList(String CustomerName)
	{
	
		if(element(By.xpath("//div//a[contains(text(),'"+CustomerName+"')]//..//..//div[contains(text(),'Disabled')]")).isCurrentlyVisible()) 
			return true;
			else 
			return false;
	}
	
	/********************************************************************
	* Description: Enable the customer
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public void toggleCustomerToEnable()
	{
		if (element(By.xpath("//span[contains(text(),'Disabled')]")).isCurrentlyVisible()==true)
	element(enableToggleButton).click();
	waitForElementToDisappear(loader);
	}
	
	
	/********************************************************************
	* Description: Enable customer
	* Param: NA
	* Returns: boolean
	* Status: 
	********************************************************************/
	public boolean verifyCustomerEnableCustomer(String CustomerName)
	{
		String actSuccessfulMessage = element(successfulORErrorMessage).getText();
		String ExptMessage = "Customer '"+CustomerName+"' enabled";
		if (actSuccessfulMessage.equals(ExptMessage))
				return true;
		else return false;
		
	}
	
	/********************************************************************
	* Description: After enabling customer, customer should get enabled
	* Param: NA
	* Returns: void
	* Status: 
	********************************************************************/
	public boolean verifyInCustomerListAfterEnabling(String CustomerName)
	{
		if(!(element(By.xpath("//div//a[contains(text(),'"+CustomerName+"')]//..//..//div[contains(text(),'Disabled')]")).isCurrentlyVisible())) 
			return true;
			else 
			return false;	
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public void editCustomerDetails(String customerNameToEdit, String CustomerNumberToEdit, String ImagePath)
	{
		element(customerNamefield).clear();
		element(customerNamefield).sendKeys(customerNameToEdit);
		element(customerNumberfield).clear();
		element(customerNumberfield).sendKeys(CustomerNumberToEdit);
		element(removeButton).click();
		element(fileUpload).sendKeys(ImagePath);
		element(UpdateButton).click();
		waitForElementToDisappear(loader);
	}
	
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: boolean
	* Status: 
	********************************************************************/
	public boolean verifyCustomerDetailsEdited(String CustomerEditedName)
	{
		String actSuccessfulMessage = element(successfulORErrorMessage).getText();
		String ExptMessage = "Details for '"+CustomerEditedName+"' updated successfully";
		if (actSuccessfulMessage.equals(ExptMessage))
				return true;
		else return false;
		 
		
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: Completed
	********************************************************************/
	public void addCustomerDetailsToVerify(String customerName, String CustomerNumber, String ImagePath)
	{
		element(customerNamefield).sendKeys(customerName);
		element(customerNumberfield).sendKeys(CustomerNumber);
		element(fileUpload).sendKeys(ImagePath);
		
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns:
	* Status: Completed
	********************************************************************/
	public void clickOnCancelButton() {
		element(cancelButton).click();
		waitForElementToDisappear(loader);
	}
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: boolean
	* Status: 
	********************************************************************/
	public boolean verifyCustomerDetailsNotAdded(String CustomerName)
	{
		if(!(element(By.xpath("//div//a[contains(text(),'"+CustomerName+"')]"))).isCurrentlyVisible())
			return true;
		else
				return false;
		
		
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: Completed
	********************************************************************/
	public void invalidDateToCustomerNameField(String customerName)
	{
		element(customerNamefield).sendKeys(customerName);
		element(customerNumberfield).click();
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: boolean
	* Status: 
	********************************************************************/
	public boolean verifyErrorMessageToCustomerNameField()
	{
		String actErrorMessage = element(CustomerNametextFieldErrorMessage).getText();
		System.out.println(actErrorMessage);
		String ExptErrorMessage = "Customer Name is invalid";
		if (actErrorMessage.equals(ExptErrorMessage))
				return true;
		else return false;
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: Completed
	********************************************************************/
	public void invalidImage(String CustomerName, String CustomerNumber, String ImagePath)
	{
		element(customerNamefield).sendKeys(CustomerName);
		element(customerNumberfield).sendKeys(CustomerNumber);
		element(fileUpload).sendKeys(ImagePath);
		
	}
	
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: boolean
	* Status: 
	********************************************************************/
	public boolean verifyInvalidImage()
	{
		String actErrorMessage = element(ImageErrorMessage).getText();
		System.out.println(actErrorMessage);
		String ExptErrorMessage = "Customer image should be png, jpg or jpeg format.";
		if (actErrorMessage.equals(ExptErrorMessage))
				return true;
		else return false;
		
		
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns:
	* Status: Completed
	********************************************************************/
	public void addDomain(String DomainName)
	{
		element(addDomain).click();
		element(addDomainPlaceholder).sendKeys(DomainName);
		element(addDomainOK).click();
		waitForElementToDisappear(loader);
	}
	
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: boolean
	* Status: 
	********************************************************************/
	public boolean verifyDomainAdded(String DomainName)
	{
		String actErrorMessage = element(successfulORErrorMessage).getText();
		System.out.println(actErrorMessage);
		String ExptErrorMessage = "Domain - '"+DomainName+"'' saved successfully";
		if (actErrorMessage.equals(ExptErrorMessage))
				return true;
		else return false;
		
		
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public void editDomain(String DomainName, String DomainNameEdit)
	{
		element(By.xpath("//mat-list-item//a[contains(text(),'"+DomainName+"')]/../..//mat-icon[contains(text(),'edit')]")).click();
		element(addDomainPlaceholder).clear();
		element(addDomainPlaceholder).sendKeys(DomainNameEdit);
		element(addDomainOK).click();
		waitForElementToDisappear(loader);
	}
	
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: boolean
	* Status: 
	********************************************************************/
	public boolean verifyDomainEdited()
	{
		String actErrorMessage = element(successfulORErrorMessage).getText();
		System.out.println(actErrorMessage);
		String ExptErrorMessage = "Domain Name updated successfully";
		if (actErrorMessage.equals(ExptErrorMessage))
				return true;
		else return false;
		
		
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: Completed
	********************************************************************/
	public void EditDomainWithDuplicateName(String DomainName, String ExistingDomainName)
	{
		element(By.xpath("//mat-list-item//a[contains(text(),'"+DomainName+"')]/../..//mat-icon[contains(text(),'edit')]")).click();
		element(addDomainPlaceholder).clear();
		element(addDomainPlaceholder).sendKeys(ExistingDomainName);
		element(addDomainOK).click();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: boolean
	* Status: 
	********************************************************************/
	public boolean verifyDomainNotEditedToExistingName(String ExistingDomainName)
	{
		String actErrorMessage = element(successfulORErrorMessage).getText();
		System.out.println(actErrorMessage);
		String ExptErrorMessage = ""+ExistingDomainName+" already exists. Please enter another name";
		if (actErrorMessage.equals(ExptErrorMessage))
				return true;
		else return false;
		
		
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public void disableDomain(String DomainNameToDisable)
	{
		if(element(By.xpath("//mat-slide-toggle[@class='mat-slide-toggle mat-primary mat-checked']")).isCurrentlyVisible())
		element(By.xpath("//a[contains(text(),'"+DomainNameToDisable+"')]/../..//mat-slide-toggle[@class=\"mat-slide-toggle mat-primary mat-checked\"]")).click();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: boolean
	* Status: 
	********************************************************************/
	public boolean verifyDomainDisabled(String DomainNameToDisable)
	{
		String actSuccessfulMessage = element(successfulORErrorMessage).getText();
		System.out.println(actSuccessfulMessage);
		String ExptSuccessfulMessage= "'"+DomainNameToDisable+"' disabled successfully";
		if (actSuccessfulMessage.equals(ExptSuccessfulMessage))
				return true;
		else return false;
		
		
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public void enableDomain(String DomainNameToEnable)
	{

		if(element(By.xpath("//mat-slide-toggle[@class='mat-slide-toggle mat-primary']")).isCurrentlyVisible())
		element(By.xpath("//a[contains(text(),'"+DomainNameToEnable+"')]/../..//mat-slide-toggle[@class='mat-slide-toggle mat-primary']")).click();
		waitForElementToDisappear(loader);
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: boolean
	* Status: 
	********************************************************************/
	public boolean VerifyDomainEnabled(String DomainNameToEnable)
	{
		String actSuccessfulMessage = element(successfulORErrorMessage).getText();
		System.out.println(actSuccessfulMessage);
		String ExptSuccessfulMessage= "'"+DomainNameToEnable+"'enabled successfully";
		if (actSuccessfulMessage.equals(ExptSuccessfulMessage))
				return true;
		else return false;
		
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public void deleteDomain(String DomainNameToDelete)
	{
		element("//a[contains(text(),'"+DomainNameToDelete+"')]/../../..//button[@mattooltip='Delete']").click();
		element(popUpYesButton).click();
		waitForElementToDisappear(loader);
	}
	
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: boolean
	* Status: 
	********************************************************************/
	public boolean verifyDomainDeleted(String DomainNameToDelete)
	{
		String actSuccessfulMessage = element(successfulORErrorMessage).getText();
		System.out.println(actSuccessfulMessage);
		String ExptSuccessfulMessage= "'"+DomainNameToDelete+"' deleted successfully";
		if (actSuccessfulMessage.equals(ExptSuccessfulMessage))
				return true;
		else return false;
		
		
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public void deleteTheCustomer()
	{
		element(By.xpath("//mat-slide-toggle//..//span[@mattooltip='Delete Customer']")).click();
		element(popUpYesButton).click();
		waitForElementToDisappear(loader);

	}
	
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: boolean
	* Status: 
	********************************************************************/
	public boolean verifyCustomerDeleted(String CustomerNameToDelete)
	{
	
		String actSuccessfulMessage = element(successfulORErrorMessage).getText();
		System.out.println(actSuccessfulMessage);
		String ExptSuccessfulMessage= "Customer '"+CustomerNameToDelete+"' deleted successfully";
		if (actSuccessfulMessage.equals(ExptSuccessfulMessage))
				return true;
		else return false;
		
		
		
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/

	public void existingCustomerName(String DuplicateCustomerNameToAdd,String CustomerNumberToAdd,String CustomerImage) {
		element(customerNamefield).sendKeys(DuplicateCustomerNameToAdd);
		element(customerNumberfield).sendKeys(CustomerNumberToAdd);
		element(fileUpload).sendKeys(CustomerImage);
		element(add).click();
		waitForElementToDisappear(loader);
		
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/
	
	public boolean VerifyCustomerDuplicateName(String DuplicateCustomerName) {
		String actSuccessfulMessage = element(successfulORErrorMessage).getText();
		String ExptErrorlMessage = "Customer with name '"+DuplicateCustomerName+"' already exists";
		System.out.println(actSuccessfulMessage);
		if (actSuccessfulMessage.equals(ExptErrorlMessage))
				return true;
		else return false;
		
		
	}

	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/
	public void ClickOnCustomerLink(String CustomerNameToViewContact) {
		element(By.xpath("//a[contains(text(),'"+CustomerNameToViewContact+"')]//..//..//..//span[contains(text(),'Contacts')]")).click();
		waitForElementToDisappear(loader);
		
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/
	public boolean VerifyEmptyContactdetails() {
		String actSuccessfulMessage = element(successfulORErrorMessage).getText();
		String ExptErrorlMessage = "No contacts exist for this customer";
		System.out.println(actSuccessfulMessage);
		if (actSuccessfulMessage.equals(ExptErrorlMessage))
				return true;
		else return false;
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/

	public boolean VerifyNotallowedToAddMoreThanThreeCustomerContacts() {
		if(element(By.xpath("//span[contains(text(),'Max 3 Contacts')]")).isCurrentlyVisible()&&
				element(By.xpath("//button//span[contains(text(),' Add New ')]")).isCurrentlyVisible())
		return true;
		else
			return false;
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/

	public void ClickOnCustomerLinkToEditTheDetails(String customerNameToEditContactDetails) {
		element(By.xpath("//a[contains(text(),'"+customerNameToEditContactDetails+"')]//..//..//..//span[contains(text(),'Contacts')]")).click();
		waitForElementToDisappear(loader);
		
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/

	public void editAndUpdateCustomerContactDetails(String ExistingContactname, String ContactNameToEdit, String ContactMobileToEdit, String ContactEmailToEdit) {
		element(By.xpath("//span[contains(text(),'"+ExistingContactname+"')]/..//span[contains(text(),'Contact Name')]/../../..//mat-icon[contains(text(),'edit')]")).click();
		element(contactName).clear();
		element(contactName).sendKeys(ContactNameToEdit);
		element(contactMobile).clear();
		element(contactMobile).sendKeys(ContactMobileToEdit);
		element(contactEmail).clear();
		element(contactEmail).sendKeys(ContactEmailToEdit);
		element(UpdateContact).click();
		waitForElementToDisappear(loader);
		
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/
	public boolean verifyConatctDetailsAreUpdated(String UpdateContactname, String UpdatedMobileNumber, String UpdatedEmail) {
		String actSuccessfulMessage = element(successfulORErrorMessage).getText();
		String ExpectedSuccessfulMessage = "Contact updated successfully";
		if (actSuccessfulMessage.equals(ExpectedSuccessfulMessage)&&
				element(By.xpath("//span[contains(text(),'"+UpdateContactname+"')]/..//span[contains(text(),'Contact Name')]")).isCurrentlyVisible()&&
				element(By.xpath("//span[contains(text(),' "+UpdatedMobileNumber+" ')]/..//span[contains(text(),' Contact Number ')]")).isCurrentlyVisible()&&
				element(By.xpath("//span[contains(text(),'"+UpdatedEmail+"')]/..//span[contains(text(),'Contact Email')]")).isCurrentlyVisible())
				return true;
		else 
			return false;
		
		
	}


	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/
	public void clickOnCustomerContactLinkToDeleteDetails(String customerNameToDContactDetails) {
		element(By.xpath("//a[contains(text(),'"+customerNameToDContactDetails+"')]//..//..//..//span[contains(text(),'Contacts')]")).click();
		waitForElementToDisappear(loader);
		
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/

	public void deleteContactDetails(String ExistingContactnameToDelete) {
		element(By.xpath("//span[contains(text(),'"+ExistingContactnameToDelete+"')]/..//span[contains(text(),'Contact Name')]/../../..//mat-icon[contains(text(),'delete')]")).click();
		element(popUpYesButton).click();
		waitForElementToDisappear(loader);
		
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/
	public boolean verifyCustomerContactDeleted(String ExistingContactnameToDelete) {
		String actSuccessfulMessage = element(successfulORErrorMessage).getText();
		String ExpectedSuccessfulMessage = "Contact deleted successfully";
		if (actSuccessfulMessage.equals(ExpectedSuccessfulMessage)&&
				!(element(By.xpath("//span[contains(text(),'"+ExistingContactnameToDelete+"')]/..//span[contains(text(),'Contact Name')]")).isCurrentlyVisible()))
				return true;
		else 
			return false;
		
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/
	public void EnterInvalidDataToContactNameTextField(String InvalidContactname) {
		element(contactName).sendKeys(InvalidContactname);
		element(contactMobile).click();
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/
	public boolean VerifyContactNameTextField() {
		String ActErrMsg = element(By.xpath("//mat-error//span")).getText();
		String ExpectedErrMsg = "Contact Name is invalid";
		if(ActErrMsg.equals(ExpectedErrMsg))
			return true;
		else
		return false;
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/
	public void EnterInvalidDataToContactMobileTextField(String invalidContactMobile) {
		element(contactName).sendKeys(CustomerCSVReader.getCustomerContactName());
		element(contactMobile).sendKeys(invalidContactMobile);
		element(contactEmail).click();
		
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/
	public boolean VerifyCustomerMobileToVerifyContactMobile() {
			String ActErrMsg = element(By.xpath("//mat-error//span")).getText();
			String ExpectedErrMsg = "Contact Mobile is invalid";
			if(ActErrMsg.equals(ExpectedErrMsg))
				return true;
			else
			return false;
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/

	public void EnterInvalidDataToContactEmailTextField(String invalidContactEmail) {
		element(contactName).sendKeys(CustomerCSVReader.getCustomerContactName());
		element(contactMobile).sendKeys(CustomerCSVReader.getCustomerContactMobile());
		element(contactEmail).sendKeys(invalidContactEmail);
		element(contactMobile).click();
		
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/
	public boolean verifyContactEmailIdTextField() {
		String ActErrMsg = element(By.xpath("//mat-error")).getText();
		String ExpectedErrMsg = "Please enter a valid email address";
		if(ActErrMsg.equals(ExpectedErrMsg))
			return true;
		else
		return false;
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/
	public void EnterDuplicateContactDetails(String duplicateName, String duplicateMobile, String duplicateEmail) {
		
		element(contactName).sendKeys(duplicateName);
		element(contactMobile).sendKeys(duplicateMobile);
		element(contactEmail).sendKeys(duplicateEmail);
		element(submit).click();
		waitForElementToDisappear(loader);
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/
	public boolean verifyDuplicateContactDetailsAdded() {
		String ActSuccessfulMsg = element(successfulORErrorMessage).getText();
		String ExpectedSuccessfulMsg = "Contact saved successfully";
		if(ActSuccessfulMsg.equals(ExpectedSuccessfulMsg))
			return true;
		else
		return false;
	}
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/
	public void clickOnLocationLink(String CustomerNameToViewLocation) {
		element(By.xpath("//a[contains(text(),'"+CustomerNameToViewLocation+"')]//..//..//..//span[contains(text(),'Locations')]")).click();
		waitForElementToDisappear(loader);
		
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/
	public boolean verifyDuplicateLocationNotAdded(String DuplicateLocationName) {
		String ActErrMsg = element(successfulORErrorMessage).getText();
		String ExpectedErrMsg = ""+DuplicateLocationName+" already exists. Please choose another name";
		if(ActErrMsg.equals(ExpectedErrMsg))
			return true;
		else
		return false;
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/
	public void enterInvalidLocationName(String InvalidLocationName) {
		element(locationNameField).sendKeys(InvalidLocationName);
		element(locationType).click();
		
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/
	public boolean VerifyInvalidLocationName() {
		String ActErrMsg = element(By.xpath("//mat-error")).getText();
		String ExpectedErrMsg = "Location Name is invalid";
		if(ActErrMsg.equals(ExpectedErrMsg))
			return true;
		else
		return false;
	}


	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/
	public void SearchLocationName(String LocationToSearch) {
		element(By.xpath("//input[@placeholder='Search..']")).sendKeys(LocationToSearch);
	
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/
	public boolean verifyLocationSearchedForValidData() {
		List<WebElement> LocationSearchList = getDriver().findElements(By.xpath("//mat-card"));
		if((LocationSearchList.size()>0 )&&
				element(By.xpath("//mat-card")).isCurrentlyVisible())
		return true;
		else
			return false;
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/
	public boolean verifyLocationSearchedForInValidData() {
		List<WebElement> LocationSearchList = getDriver().findElements(By.xpath("//mat-card"));
		if((LocationSearchList.size()==0 )&&
				!(element(By.xpath("//mat-card")).isCurrentlyVisible()))
		return true;
		else
			return false;
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/
	public void addlocationDetailsANdClickOnCancelButton(String LocationNameToVerifyCancel, String locationTypedropdown) {
		element(locationNameField).sendKeys(LocationNameToVerifyCancel);
		element(locationType).click();
		element(By.xpath("//mat-option//span[contains(text(),'"+locationTypedropdown+"')]")).click();
		element(By.xpath("//button//span[contains(text(),'Cancel')]")).click();
		waitForElementToDisappear(loader);
		
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/
	public boolean verifyLocationTabCancelButton(String LocationNameToVerifyCancel) {
		if(!(element(By.xpath("//mat-card-header//span[contains(text(),'"+LocationNameToVerifyCancel+"')]")).isCurrentlyVisible()))
			return true;
		else
			return false;
		
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/

	public void editLocationDetails(String ExistinglocationName, String LocationNameToEdit, String locationTypedropdownToEdit,String LocationToSearchToEdit) {
		element(By.xpath("//span[contains(text(),'"+ExistinglocationName+"')]//..//..//mat-icon[contains(text(),'edit')]")).click();
		element(locationNameField).clear();
		element(locationNameField).sendKeys(LocationNameToEdit);
		element(By.xpath("//div[@class='mat-select-arrow']")).click();
		element(By.xpath("//mat-option//span[contains(text(),'"+locationTypedropdownToEdit+"')]")).click();
		element(By.xpath("//input[@placeholder='search for location']")).clear();
		element(By.xpath("//input[@placeholder='search for location']")).sendKeys(LocationToSearchToEdit, Keys.ARROW_DOWN,Keys.ENTER);
		waitForElementToDisappear(loader);
		
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/

	public boolean verifyLocationEditedSuccessfully(String LocationNameToEdit) {
		String ActSuccessfulMsg = element(successfulORErrorMessage).getText();
		String ExpectedSuccessfulMsg = "Location updated successfully!";
		if(ActSuccessfulMsg.equals(ExpectedSuccessfulMsg)&&
				element(By.xpath("//span[contains(text(),'"+LocationNameToEdit+"')]")).isCurrentlyVisible())
			return true;
		else
		return false;
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/
	public void deleteLocation(String LocationNameToDelete) {
		element(By.xpath("//span[contains(text(),'"+LocationNameToDelete+"')]//..//..//mat-icon[contains(text(),'delete')]")).click();
		element(popUpYesButton).click();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/

	public boolean VerifyDeleteLocation(String DeletedLocationName) {
		if(!(element(By.xpath("//span[contains(text(),'"+DeletedLocationName+"')]")).isCurrentlyVisible()))
			return true;
		else
		return false;
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/
	public void ClickOnContactLinkToVerifyCancelbutton(String CustomerNameToViewContact) {
		element(By.xpath("//a[contains(text(),'"+CustomerNameToViewContact+"')]//..//..//..//span[contains(text(),'Contacts')]")).click();
		waitForElementToDisappear(loader);
		
	}
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/
	public void enterContactDetailsToVerifyCancelButton(String ConatctNameToVerifyCancelButton) {
		element(contactName).sendKeys(ConatctNameToVerifyCancelButton);
		element(contactMobile).sendKeys(CustomerCSVReader.getCustomerContactMobile());
		element(contactEmail).sendKeys(CustomerCSVReader.getCustomerContactEmail());
		element(CancelButton).click();	
	}

	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/

	public boolean verifyCancelButtonInContactTab(String ConatctNameToVerifyCancelButton) {
		if(!(element(By.xpath("//span[contains(text(),'"+ConatctNameToVerifyCancelButton+"')]/..//span[contains(text(),'Contact Name')]")).isCurrentlyVisible()))
			return true;
		else
			return false;
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/
	public boolean verifyLocationTabForEmptyDetails() {
		String ActErrMsg = element(successfulORErrorMessage).getText();
		String ExpectedErrMsg = "No locations exist for this customer";
		if(ActErrMsg.equals(ExpectedErrMsg))
			return true;
		else
		return false;
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/
	public void clickOnEachFieldsOfAddCustomerTab() {
		element(customerNamefield).click();
		element(customerNumberfield).click();
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/
	public boolean VerifyAddCustomerTextFieldErrormessages() {
		String ActErrMsg = element(successfulORErrorMessage).getText();
		String ExpectedErrMsg = "Customer Name is required.";
		if(ActErrMsg.equals(ExpectedErrMsg))
			return true;
		else
		return false;
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/
	public void clickOnAlltheFieldsOfContactTab() {
		element(contactName).click();
		element(contactMobile).click();
		element(contactEmail).click();
		element(contactName).click();
		
	}

	public void SelectCustomerTOVerifyThreeContactFeature(String CustomerNameToViewContact) {
		element(By.xpath("//a[contains(text(),'"+CustomerNameToViewContact+"')]//..//..//..//span[contains(text(),'Contacts')]")).click();
		waitForElementToDisappear(loader);
		
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/
	public void DisableTheCustomer() {
		element(By.xpath("//span[contains(text(),'Enabled')]//..//div[@class='mat-slide-toggle-bar mat-slide-toggle-bar-no-side-margin']")).click();
		waitForElementToDisappear(loader);
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/
	public void EnableTheCustomer() {
		element(By.xpath("//span[contains(text(),'Disabled')]//..//div[@class='mat-slide-toggle-bar mat-slide-toggle-bar-no-side-margin']")).click();
		waitForElementToDisappear(loader);
		
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/
	public void addCustomerDetailsVerifyEdit(String CusterName,String customerNumber,String ImpagePath) {
		element(addNewButton).click();
		waitForElementToDisappear(loader);
		element(customerNamefield).sendKeys(CusterName);
		element(customerNumberfield).sendKeys(customerNumber);
		element(fileUpload).sendKeys(ImpagePath);
		element(add).click();
		waitForElementToDisappear(loader);
		
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: 
	********************************************************************/
	public boolean verifyCustomerCreatedToVerifyEdit(String AddedCustomerName) {
		String actSuccessfulMessage = element(successfulORErrorMessage).getText();
		String ActlResult = "New Customer '"+AddedCustomerName+"' added successfully";
		if(actSuccessfulMessage.equals(ActlResult))		
		return true;
		else
		return false;
	}
	
//	/********************************************************************
//	* Description: 
//	* Param: NA
//	* Returns: 
//	* Status: 
//	********************************************************************/
//	public boolean verifyContactTabErrMsgforEmptyFields() {
//		String CName = element(successfulORErrorMessage).getText();
//		
//	}
//
//	/********************************************************************
//	* Description: 
//	* Param: NA
//	* Returns: 
//	* Status: 
//	********************************************************************/
//	public void clickOnAlltheFieldsOfLocationTab() {
//		element(locationNameField).click();
//		element(locationType).click();
//		element(locationNameField).click();		
//	}
//	

	
}
