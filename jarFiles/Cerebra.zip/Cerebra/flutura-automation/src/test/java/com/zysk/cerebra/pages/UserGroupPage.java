package com.zysk.cerebra.pages;

import java.util.List;
import java.util.function.IntPredicate;

import com.headius.invokebinder.transform.Catch;
import com.zysk.cerebra.commonPages.CommonFunctions;
import com.zysk.cerebra.csv_reader.CustomerCSVReader;
import com.zysk.cerebra.csv_reader.UserGroupCSVReader;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class UserGroupPage extends CommonFunctions{
	
	private By UserGroupLink = By.xpath("//div[contains(text(),' Customer & User Group Management ')]/../../..//a[contains(text(),' User Group ')]");
	private By  UserGroupCustomerTab = By.xpath("//input[@placeholder='Search..']");
	private By CustomerName = By.xpath("//app-user-group-customers//div//span[contains(text(),'Customers')]");
	private By searchBar = By.xpath("//input[@placeholder='Search..']");
	private By listOfCustomer = By.xpath("//div[@class='row']/div");
	private By groupTab = By.xpath("//button//span[contains(text(),'Groups')]");
	private By UserGroupAddNewButton = By.xpath("//button//span[contains(text(),'Add New')]");
	private By AddGroupTextField = By.xpath("//input[@placeholder='Enter Group Name']");
	private By AddGroupcancelButton = By.xpath("//button//span[contains(text(),'Cancel')]");
	private By AddGroupAddButton = By.xpath("//button[@mattooltip='Add']//span[contains(text(),'Add')]");
	private By SuccessfulMessageOrErrorMessage = By.xpath("//simple-snack-bar//span");
	private By UserGroupSearchBar = By.xpath("//input[@placeholder='Search Groups..']");
	private By UserNameSearchBar = By.xpath("//input[@placeholder='Search Users..']");
	private By AddUserButton = By.xpath("//button//span[contains(text(),'Add User')]");
	private By AddUserToGroupButton = By.xpath("//button[@mattooltip='Add']//span[contains(text(),'Add')]");
	private By DashboardLink = By.xpath("//div[@mattooltip='Dashboard']");
	private By enableToggleButton = By.xpath("//div[@class='mat-slide-toggle-bar mat-slide-toggle-bar-no-side-margin']");
	private By popUpYesButton = By.xpath("//button[contains(text(),'Yes, delete it!')]");
	private By AddGroupCancelButton = By.xpath("//span[contains(text(),'Cancel')]");
	
	// remove user------ //span[contains(text(),'')]/..//a[@mattooltip="Remove" and contains(text(),'Remove')] 
	// if condition to check disable item ==== //mat-slide-toggle[@class="mat-slide-toggle mat-primary ng-star-inserted"]
	// if condition to check enable item ==== //mat-slide-toggle[@class="mat-slide-toggle mat-primary mat-checked ng-star-inserted"]
	//toggle enable or disable ==== //span[contains(text(),'test 2')]/..//div[@class="mat-slide-toggle-thumb"]
	
	//duplicate name error ======= User group is already exists
	//add user successful message ======== New group 'test333' added successfully
	//disable usergroup ====== Group 'test333' disabled 
	//enable usergroup ===== Group 'test333' enabled
	//delete usergroup ==== Group 'test333' deleted successfully
	//add user to group scc ==== User 'Demo Aramco' added to group 'Control Center'
	//remove user to grop ==== User 'Demo Aramco' removed from the group 'Control Center'
	
	
	/****************************************************************************************************************************************/
	
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void clickUserGroupLink() {
		element(UserGroupLink).click();
		waitForElementToDisappear(loader);
		
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	
	public boolean verifyUserPage() {
		if(element(By.xpath("//mat-card")).isCurrentlyVisible()&&
		element(UserGroupCustomerTab).isCurrentlyVisible()&&
		element(CustomerName).isCurrentlyEnabled())
			return true;
		else
			return false;
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void verifySearchField(String DataToSearch) {
		element(searchBar).sendKeys(DataToSearch);
		
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifySearchFieldForValidInputs(String CustomerName) {
		List<WebElement> customerList = getDriver().findElements(listOfCustomer);
		int s = customerList.size();
		if(element(By.xpath("//mat-card//div//a[contains(text(),'"+CustomerName+"')]")).isCurrentlyVisible()&&
				
		(s>0) )

		return true;
		else return false;
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifySearchFieldForInValidInputs(String CustomerName) {
		List<WebElement> customerList = getDriver().findElements(listOfCustomer);
		int s = customerList.size();
		if(!(element(By.xpath("//mat-card//div//a[contains(text(),'"+CustomerName+"')]"))).isCurrentlyVisible()&&
			
		(s==0) )

		return true;
		else return false;
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void selectCustomer(String customerName) {
		
		element(By.xpath("//mat-card//a[contains(text(),'"+customerName+"')]")).click();
		waitForElementToDisappear(loader);
		
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyGroupTab(String CustomerName) {
		
		if((element(groupTab).isCurrentlyVisible())&&
				element(By.xpath("//span[contains(text(),'"+CustomerName+" - Group')]")).isCurrentlyVisible())
		
		return true;
		else
			return false;
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void clickOnNewButtonToAddGroup() {
		element(UserGroupAddNewButton).click();
		waitForElementToDisappear(loader);
		
	}


	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/

	public void addUserGroup(String UserGroupName) {
		element(AddGroupTextField).sendKeys(UserGroupName);
		element(AddGroupAddButton).click();
		waitForElementToDisappear(loader);
	
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void verifySearchFieldOfUserGroup(String DataToSearch) {
		element(UserGroupSearchBar).sendKeys(DataToSearch);
		
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/

	public boolean verifyNewUserGroupAdded(String UserGroupName) {
		String SuccessfulMessage = element(SuccessfulMessageOrErrorMessage).getText();
		String ExpectedMessage = "New group '"+UserGroupName+"' added successfully";
		if(SuccessfulMessage.equals(ExpectedMessage))
			return true;
		else 
			return false;
		
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: Completed
	********************************************************************/

	public boolean verifyUserGroupSearchForValidInput() {
		List<WebElement> customerList = getDriver().findElements(By.xpath("//input[@placeholder='Search Groups..']//..//..//mat-list//mat-divider//..//span"));
		int s = customerList.size();
		if((s>0) )
		return true;
		else return false;
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void verifySearchFieldOfUserName(String DataToSearch) {
		element(UserNameSearchBar).sendKeys(DataToSearch);
		
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: Completed
	********************************************************************/

	public boolean verifyUserGroupSearchForInValidInput() {
		List<WebElement> customerList = getDriver().findElements(By.xpath("//input[@placeholder='Search Groups..']//..//..//mat-list//mat-divider//..//span"));
		int s = customerList.size();
		if((s==0) )
		return true;
		else return false;
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: Completed
	********************************************************************/
	public boolean verifyUserNameSearchForValidInput() {
		List<WebElement> customerList = getDriver().findElements(By.xpath("//input[@placeholder='Search Users..']//..//..//mat-list//mat-divider//..//span"));
		int s = customerList.size();
		if((s>0) )
		return true;
		else return false;
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: Completed
	********************************************************************/
	public boolean verifyUserNameSearchForInValidInput() {
		List<WebElement> customerList = getDriver().findElements(By.xpath("//input[@placeholder='Search Users..']//..//..//mat-list//mat-divider//..//span"));
		int s = customerList.size();
		if((s==0) )
		return true;
		else return false;
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: Completed
	********************************************************************/
	public void selectUserGroup(String UserGroup) {
		element(By.xpath("//input[@placeholder='Search Groups..']//..//..//mat-list//mat-divider//..//span[contains(text(),'"+UserGroup+"')]")).click();
		waitForElementToDisappear(loader);	
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: Completed
	********************************************************************/

	public void clickOnAddUserButton() {
		element(AddUserButton).click();	
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: Completed
	********************************************************************/
	public void selectAndAddTheUserToUserGroup(String UserName) {
		element(By.xpath("//input[@placeholder='Select User']")).click();
		List<WebElement>UserList = getDriver().findElements(By.xpath("//mat-option//span"));
		try {
		for(int i=1; i<UserList.size();i++)
		{
			if(UserList.get(i).getText().equals(UserName))
				UserList.get(i).click();
		}
		
	}
		catch (Exception e) {
			
		}
		
		element(AddUserToGroupButton).click();
		waitForElementToDisappear(loader);
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: Completed
	********************************************************************/
	public boolean verifyUserAddedToUserGroup(String UserName) {
		String SuccessfulMessage = element(SuccessfulMessageOrErrorMessage).getText();
		String ExpectedMessage = "User '"+UserName+"' added to group 'TestingGroup'";
		if(SuccessfulMessage.equals(ExpectedMessage))
			return true;
		else 
			return false;
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: Completed
	********************************************************************/
	public void clickOnDashboardLink() {
		element(DashboardLink).click();
		waitForElementToDisappear(loader);
		
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: Completed
	********************************************************************/
	public void selectUserToVerifyGroupAssigned(String UserName) {
	element(By.xpath("//a[contains(text(),'"+UserName+"')]")).click();
	waitForElementToDisappear(loader);
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: Completed
	********************************************************************/
	public boolean verifyUserGroupShowingAsAssignedInUserDetailsPage(String UserGroup) {
		if(element(By.xpath("//input[@aria-checked='true']/../..//span[contains(text(),'"+UserGroup+"')]")).isCurrentlyVisible())
			return true;
		else
			return false;
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: Completed
	********************************************************************/
	public boolean verifyUserGroupInAccessLevel(String UserGroupName) {
	if(element(By.xpath("//input[@placeholder='Search Groups']//..//..//mat-action-list//mat-list-item//..//span[contains(text(),'"+UserGroupName+"')]")).isCurrentlyVisible())
		return true;
	else
		return false;
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: Completed
	********************************************************************/
	public void disableUserGroup(String GroupNameToDisable) {
		element(By.xpath("//span[contains(text(),'"+GroupNameToDisable+"')]//..//div[@class='mat-slide-toggle-bar mat-slide-toggle-bar-no-side-margin']")).click();
		waitForElementToDisappear(loader);
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: Completed
	********************************************************************/
	public boolean VerifyUserGroupDisabled(String GroupName) {
		String actSuccessfulMessage = element(SuccessfulMessageOrErrorMessage).getText();
		String ExptSuccessfulMessage= "Group '"+GroupName+"' disabled";
		if (actSuccessfulMessage.equals(ExptSuccessfulMessage))
				return true;
		else return false;
	} 
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: Completed
	********************************************************************/
	public void enableUserGroup(String GroupNameToEnable) {
		element(By.xpath("//input[@placeholder='Search Groups..']//..//..//mat-list//mat-divider//..//span[contains(text(),'Test Group')]/..//mat-slide-toggle[@class='mat-slide-toggle mat-primary ng-star-inserted']")).click();
		waitForElementToDisappear(loader);
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: Completed
	********************************************************************/
	public boolean VerifyUserGroupEnabled(String GroupName) {
		String actSuccessfulMessage = element(SuccessfulMessageOrErrorMessage).getText();
		String ExptSuccessfulMessage= "Group '"+GroupName+"' enabled";
		if (actSuccessfulMessage.equals(ExptSuccessfulMessage))
				return true;
		else return false;
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: Completed
	********************************************************************/
	public void DeleteUserGroup(String DeleteUserGroup) {
	element(By.xpath("//span[contains(text(),'"+DeleteUserGroup+"')]//..//i[@mattooltip=\"Delete\"]")).click();
	element(popUpYesButton).click();
	waitForElementToDisappear(loader);
		
	} 
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: Completed
	********************************************************************/
	public boolean verifyDeleteUserGroup(String UserGroupToDelete) {
		String actSuccessfulMessage = element(SuccessfulMessageOrErrorMessage).getText();
		String ExptSuccessfulMessage= "Group '"+UserGroupToDelete+"' deleted successfully";
		if (actSuccessfulMessage.equals(ExptSuccessfulMessage))
			return true;
			else
			return false;
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: Completed
	********************************************************************/
	public void selectUserToRemoveFromGroup(String UserName) {
		element(By.xpath("//input[@placeholder='Search Users..']//..//..//mat-list//mat-divider//..//span[contains(text(),'"+UserName+"')]")).click();
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: Completed
	********************************************************************/
	public void removeUserGroup(String UserName) {
		element(By.xpath("//input[@placeholder='Search Users..']//..//..//mat-list//mat-divider//..//span[contains(text(),'"+UserName+"')]//..//a[@mattooltip='Remove']")).click();
		element(popUpYesButton).click();
		waitForElementToDisappear(loader);
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: Completed
	********************************************************************/
	public boolean verifyUserNameRemovedFromGroup(String UserName) {
		String actSuccessfulMessage = element(SuccessfulMessageOrErrorMessage).getText();
		String ExptSuccessfulMessage= "User '"+UserName+"' removed from the group 'TestingGroup'";
		if (actSuccessfulMessage.equals(ExptSuccessfulMessage))
			return true;
			else
				return false;
		
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: Completed
	********************************************************************/
	public void addDuplicateUserGroup(String DuplicateUserGroupName) {
		element(AddGroupTextField).sendKeys(DuplicateUserGroupName);
		element(AddGroupAddButton).click();
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: Completed
	********************************************************************/
	public boolean verifyDuplicateUserGroupname() {
		String actErrorMessage = element(SuccessfulMessageOrErrorMessage).getText();
		String ExptErrorMessage= "User group is already exists";
		if (actErrorMessage.equals(ExptErrorMessage))
			return true;
			else
				return false;
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: Completed
	********************************************************************/
	public void AddUserNameAndClickOnCancel(String UserGroupNameToVerifyCancel) {
		element(AddGroupTextField).sendKeys(UserGroupNameToVerifyCancel);
		element(AddGroupCancelButton).click();
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: Completed
	********************************************************************/
	public boolean VerifyUserGroupCancelButton(String UserGroupNameToVerifyCancel) {
		if(!(element(By.xpath("//input[@placeholder='Search Groups..']//..//..//mat-list//mat-divider//..//span[contains(),'"+UserGroupNameToVerifyCancel+"')]"))).isCurrentlyVisible())	
			return true;
		else
			return false;
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: Completed
	********************************************************************/
	public void addInvalidDataInAddUserGroupTextField(String InvalidData) {
		element(AddGroupTextField).sendKeys(InvalidData);
		element(By.xpath("//p[contains(text(),'Add Group')]")).click();
	}
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: Completed
	********************************************************************/

	public boolean verifyErrorMessageForUserGroupTextField() {
		String actErrorMessage = element(By.xpath("//mat-error")).getText();
		String ExptErrorMessage= "Group name is invalid";
		if (actErrorMessage.equals(ExptErrorMessage))
			return true;
			else
				return false;
	}

	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: Completed
	********************************************************************/
	public boolean verifyUserGroupNotShowingAssignOnRemoveUserAndDeleteUserGroup(String UserGroupName) {
		if(element(By.xpath("//input[@aria-checked='false']/../..//span[contains(text(),'"+UserGroupName+"')]")).isCurrentlyVisible())
			return true;
		else
			return false;
	}
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: 
	* Status: Completed
	********************************************************************/

	public boolean verifyUserGroupNotShowInAccessLevelOnDisableAndDeleteOfUserGroup(String UserGroupName) {
		if(!(element(By.xpath("//input[@placeholder='Search Groups']//..//..//mat-action-list//mat-list-item//..//span[contains(text(),'"+UserGroupName+"')]"))).isCurrentlyVisible())
			return true;
		else
			return false;
	}	
	
}