package com.zysk.cerebra.steps;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertTrue;

import com.zysk.cerebra.csv_reader.CSVHelper;
import com.zysk.cerebra.csv_reader.CustomerCSVReader;
import com.zysk.cerebra.csv_reader.UserCSVReader;
import com.zysk.cerebra.pages.CustomerPage;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.steps.ScenarioSteps;

@SuppressWarnings("serial")
public class CustomerSteps extends ScenarioSteps {
	
	CustomerPage customerPage;
	
	/********************************************************************
	* Description: Click on customer link
	* Status: Completed
	********************************************************************/
	@And ("^I click on Customer Link$")
	public void andIClickOnCustomerLink()
	{
		customerPage.clickCustomerLink();
	}
	
	/********************************************************************
	* Description: Verify customer page
	* Status: Completed
	********************************************************************/
	@Then("^I am on Customer page$")
    public void thenIAmOnCustomerPage()
    {
		String expUrl = CSVHelper.getBaseUrl()+CustomerCSVReader.getCustomerListURL();
		assertTrue("Customer List page not displaying",customerPage.verifyCustomerPage(expUrl));
    }
	
	/********************************************************************
	* Description: Click on Add New button in customer list
	* Status: Completed
	********************************************************************/
	@And("^I click on Add New button$")
	public void andIClickOnAddNewButton()
	{
		customerPage.clickAddNewButton();
	}
	
	/********************************************************************
	* Description: Enter customer details and Submit it
	* Status: Completed
	********************************************************************/
	@And("^I add all the details and submit it$")
	public void andIAddAllTheDetailsAndSubmitIt()
	{
		String customerNameToAdd = CustomerCSVReader.getCustomerNameToAdd();
		String CustomerNumberToAdd = CustomerCSVReader.getCustomerPhoneNumberToAdd();
		String CustomerImage = CustomerCSVReader.getCustomerImagePathToADD();
		customerPage.enterCustomerDetails(customerNameToAdd,CustomerNumberToAdd,CustomerImage );
	}
	
	/********************************************************************
	* Description: Verify Customer created in the customer list  
	* Status: Completed
	********************************************************************/
	@Then("^I can see customer added in the list$")
	public void thenICanSeeCustomerAddedInTheList()
	{
		String AddedCustomerName = CustomerCSVReader.getCustomerNameToAdd();
		assertTrue("Customer not created",customerPage.verifyCustomerCreated(AddedCustomerName));
	}
	
	/********************************************************************
	* Description: Verify search field by entering valid data 
	* Status: Completed
	********************************************************************/
	@When("^I enter valid data in search text field$")
	public void whenIEnterValidDataInSearchTextField()
	{
		customerPage.verifySearchField();
	}
	
	/********************************************************************
	* Description: On entering valid data list of customer will be displayed
	*              based on added input 
	* Status: Completed
	********************************************************************/
	@Then("^I can see list of customer based on entered data$")
	public void thenICanSeeListOfCustomerBasedOnEnteredData()
	{
		String CustomerName = CustomerCSVReader.getValidCustomerNameToSearch();
		assertTrue("Customer Not present/Search is not working",customerPage.verifySearchFieldForValidInputs(CustomerName ));
	}
	
	/********************************************************************
	* Description: Verify search field by entering invalid data 
	* Status: Completed
	********************************************************************/
	@When("^I enter invalid data in search text field$")
	public void IEnterInvalidDataInSearchTextField()
	{
		customerPage.verifySearchFieldWithInvalidInput();
	}
	
	/********************************************************************
	* Description: On entering invalid data no data will be displayed
	* Status: Completed
	********************************************************************/
	@Then("^No data displayed$")
	public void thenNoDataDisplayed ()
	{
		String CustomerName = CustomerCSVReader.getInValidCustomerNameToSearch();
		assertTrue("Search bar not working",customerPage.verifySearchFieldForInValidInputs(CustomerName));
	}
	
	/*****************************************************************************
	* Description: On clicking on customer, customer details should be displayed
	* Status: Completed
	******************************************************************************/
	@When("^I click on customer$")
	public void WhenIClickOnCustomer()
	{
		String customerName = CustomerCSVReader.getSelectCustomerNameTOSelectAndVerify();
		customerPage.selectCustomer(customerName );
	}
	
	/*****************************************************************************
	* Description: On clicking on customer, customer details should be displayed
	* Status: Completed
	******************************************************************************/
	@Then("^I can see the customer details$")
	public void ThenICanSeeTheCustomerDetails()
	{
		String expUrl = CSVHelper.getBaseUrl()+CustomerCSVReader.getCustomerDetailsPageURL();
		String CustomerName = CustomerCSVReader.getSelectCustomerNameTOSelectAndVerify();
		assertTrue("Customer Not Selected",customerPage.verifyCustomerDetails(expUrl,CustomerName));
	}
	
	/*****************************************************************************
	* Description: On clicking on contacts tab, contacts page should be displayed
	* Status: Completed
	******************************************************************************/
	@And("^I click on Contacts tab$")
	public void AndIClickOnContacts()
	{
		customerPage.clickContacts();
	}
	
	/*****************************************************************************
	* Description: On clicking on Add New, add new contacts page should be displayed
	* Status: Completed
	******************************************************************************/
	@And("^I click on Add new contact$")
	public void AndIClickOnAddNewContact()
	{
		customerPage.clickAddNewContact();
	}
	
	/*****************************************************************************
	* Description: Enter all the contact details and submit it
	* Status: Completed
	******************************************************************************/
	@And("^I entered all the contact details and submit it$")
	public void AndIEnteredAllTheDetailsAndSubmitIt()
	{
		String NewContactName = CustomerCSVReader.getCustomerContactName();
		String NewContactMobile = CustomerCSVReader.getCustomerContactMobile();
		String NewContactEmail = CustomerCSVReader.getCustomerContactEmail();
		customerPage.enterContactDetails(NewContactName,NewContactMobile,NewContactEmail);
	}
	
	/*****************************************************************************
	* Description: Contact details gets added
	* Status: Completed
	******************************************************************************/
	@Then("^I can see the contacts getting added$")
	public void thenICanSeeTheContactsGettingAdded()
	{
		String contactNameAdded = CustomerCSVReader.getCustomerContactName();
		String contactMobileAdded = CustomerCSVReader.getCustomerContactMobile();
		String contactEmailAdded = CustomerCSVReader.getCustomerContactEmail();
		assertTrue("contanct details not added successfully",customerPage.verifyContactDetails(contactNameAdded,contactMobileAdded,contactEmailAdded));
	}
	
	/*****************************************************************************
	* Description: Select the customer
	* Status: Completed
	******************************************************************************/
	@When("^I select the customer$")
	public void whenISelectTheCustomer()
	{
		String customerName = CustomerCSVReader.getSelectCustomerNameTOSelectAndVerify();
		customerPage.selectCustomer(customerName);
	}
	
	/*****************************************************************************
	* Description: On clicking on Locations tab, Location page will be displayed
	* Status: Completed
	******************************************************************************/
	@And("^I click on Location$")
	public void AndIClickOnLocation()
	{
		customerPage.clickLocation();
	}
	
	/************************************************************************************
	* Description: On clicking on Add new button, add new location page will be displayed
	* Status: 
	*************************************************************************************/
	@And("^I click on Add new Button$")
	public void AndIClickOnAddNewButton()
	{
		customerPage.clickAddNewLocationButton();
	}
	
	/************************************************************************************
	* Description: Enter all the location details and submit it
	* Status: 
	*************************************************************************************/
	@And("^I entered all the location details and Submit it$")
	public void AndIEnteredAllTheLocationDetailsAndSubmitIt()
	{
		String Location = CustomerCSVReader.getCustomerLocation();
		String locationTypedropdown = CustomerCSVReader.getlocationTypeSelection();
		String LocationToSearch = CustomerCSVReader.getCustomerLocationToSearch();
		customerPage.enterLocationDetails(Location,locationTypedropdown,LocationToSearch);
	}
	
	/************************************************************************************
	* Description: Added Location will be displayed
	* Status: 
	*************************************************************************************/
	@Then("^I can see the location getting added$")
	public void ThenICanSeeTheLocationGettingAdded()
	{
		assertTrue("Location Not added successfully",customerPage.locationPreview());
	}
	
	/************************************************************************************
	* Description: Disable customer
	* Status: 
	*************************************************************************************/
	@When("^I disable the customer$")
	public void andIDisableTheCustomer()
	{	
		customerPage.DisableTheCustomer();
	}
	
	/************************************************************************************
	* Description: Customer will be disabled successfully
	* Status: 
	*************************************************************************************/
	@Then("^I can see the customer is disabled$")
	public void thenICanSeeTheCustomerIsDisabled()
	{
		String CustomerName = CustomerCSVReader.getSelectCustomerNameTOSelectAndVerify();
		assertTrue("Customer Not disabled",customerPage.verifyCustomerDisabled(CustomerName ));
		
	}
	
	/************************************************************************************
	* Description:Go to Dashboard
	* Status: 
	*************************************************************************************/
	
	@And("^I go to Dashboard$")
	public void andIGoToDashboard()
	{
		customerPage.clickOnHomeIcondashboard();
	}
	
	/************************************************************************************
	* Description:Go to Customer tab
	* Status: 
	*************************************************************************************/
	
	@And("^I click on customer Tab$")
	public void andIClickOnCustomerTab()
	{
		customerPage.clickOnCustomerTab();
	}
	
	/************************************************************************************
	* Description: Customer will be displayed as disabled on the list
	* Status: 
	*************************************************************************************/
	@Then("^I can see the customer is displayed as disable$")
	public void thenICanSeeTheCustomerIsDisplayedAsDisabled()
	{
		String CustomerName = CustomerCSVReader.getSelectCustomerNameTOSelectAndVerify();
		assertTrue("Customer Not displayed as disabled in customer List",customerPage.verifyDisabledCustomerInCustomerList(CustomerName));
		
	}
	
	/************************************************************************************
	* Description: Enable the disabled customer
	* Status: 
	*************************************************************************************/
	@When("^I enable the customer$")
	public void whenIEnableTheCustomer()
	{
		customerPage.EnableTheCustomer();
	}
	
	/************************************************************************************
	* Description: Customer enabled
	* Status: 
	*************************************************************************************/
	@Then("^I can see the customer is enabled$")
	public void thenICanSeeTheCustomerIsEnabled()
	{
		String CustomerName = CustomerCSVReader.getSelectCustomerNameTOSelectAndVerify();
		assertTrue("Customer Not enabled",customerPage.verifyCustomerEnableCustomer(CustomerName));
	}
	
	/************************************************************************************
	* Description: Customer 
	* Status: 
	*************************************************************************************/
	@Then("^I can see the customer is not displayed as disabled$")
	public void thenICanSeeTheCustomerIsNotDisplayedAsDisabled()
	{
		String CustomerName = CustomerCSVReader.getSelectCustomerNameTOSelectAndVerify();
		assertTrue("Customer Not enabled",customerPage.verifyInCustomerListAfterEnabling(CustomerName));
	}
	
	/************************************************************************************
	* Description:
	* Status: 
	*************************************************************************************/
	 @And("^I click on customer to Edit$")
	    public void i_click_on_customer_to_edit() {
		 String customerName = CustomerCSVReader.getAddCustomerNameToEdit();
			customerPage.selectCustomer(customerName );
	    }
	/************************************************************************************
	* Description:
	* Status: 
	*************************************************************************************/
	@And("^I edit the Customer details$")
    public void i_edit_the_customer_details()  {
        String customerNameToEdit = CustomerCSVReader.getCustomerNameToEdit();
		String CustomerNumberToEdit = CustomerCSVReader.getCustomerMobileNumberToEdit();
		String ImagePath = CustomerCSVReader.getCustomerImagePath();
		customerPage.editCustomerDetails(customerNameToEdit,CustomerNumberToEdit,ImagePath);
    }
	
	/************************************************************************************
	* Description:
	* Status: 
	*************************************************************************************/
    @Then("^I can See Customer details Updated$")
    public void i_can_see_customer_details_updated()  {
       String CustomerEditedName = CustomerCSVReader.getCustomerNameToEdit();
	  assertTrue("Edited Customer details not updated",customerPage.verifyCustomerDetailsEdited(CustomerEditedName));
    }
    
    /************************************************************************************
	* Description:
	* Status: 
	*************************************************************************************/
    @And("^I Add the Customer details$")
    public void i_add_the_customer_details()  {
       String customerName = CustomerCSVReader.getCustomerNameToverify();
	String CustomerNumber = CustomerCSVReader.getCustomerMobileNumberToverify();
	String ImagePath = CustomerCSVReader.getCustomerImageToverify();
	customerPage.addCustomerDetailsToVerify(customerName,CustomerNumber,ImagePath);
    }
    
    /************************************************************************************
	* Description:
	* Status: 
	*************************************************************************************/
    @And("^I click on cancel button$")
    public void i_click_on_cancel_button()  {
    	customerPage.clickOnCancelButton();
    }
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
   @Then("^I can See Customer details not Updated$")
   public void i_can_see_customer_details_not_updated()   {
        String CustomerName = CustomerCSVReader.getCustomerNameToverify();
        assertTrue("Customer details added successfully afetr clcik on cancel button",customerPage.verifyCustomerDetailsNotAdded(CustomerName));
   }
   
    /************************************************************************************
	* Description:
	* Status: 
	*************************************************************************************/

    @And("^I enter the invalid data to customer Name Text field$")
    public void i_enter_the_invalid_data_to_customer_name_text_field()  {
       String customerName = CustomerCSVReader.getInvalidCustomerName();
      customerPage.invalidDateToCustomerNameField(customerName);
    }

    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
       @Then("^I can see Error message is showing for Customer Name field$")
       public void i_can_see_error_message_is_showing_for_customer_name_field()   {
    	   assertTrue("Error message is not showing and accepting invalid customer Name",customerPage.verifyErrorMessageToCustomerNameField());
       }

      
    /************************************************************************************
	* Description:
	* Status: 
	*************************************************************************************/
    @And("^I enter the invalid image/video$")
    public void i_enter_the_invalid_imagevideo() {
        String CustomerName = CustomerCSVReader.getCustomerNameToverify();
		String CustomerNumber = CustomerCSVReader.getCustomerMobileNumberToverify();
		String ImagePath = CustomerCSVReader.getCustomerInvalidImage();
		customerPage.invalidImage(CustomerName,CustomerNumber,ImagePath);
    }
    
    /************************************************************************************
	* Description:
	* Status: 
	*************************************************************************************/
    @Then("^I can see Error message is showing for Image field$")
    public void i_can_see_error_message_is_showing_for_image_field()   {
    	 assertTrue("Error message is not showing and accepting invalid customer Image",customerPage.verifyInvalidImage());
    }

    /************************************************************************************
	* Description:
	* Status: 
	*************************************************************************************/
    @And("^I add the Domain$")
    public void i_add_the_domain()  {
        String DomainName = CustomerCSVReader.getDomainNameToAdd();
		customerPage.addDomain(DomainName );
    }
    
    /************************************************************************************
 	* Description:
 	* Status: 
 	*************************************************************************************/
     @Then("^I can see Domain added successfully$")
     public void i_can_see_domain_added_successfully()   {
    	 String DomainName = CustomerCSVReader.getDomainNameToAdd();
         assertTrue("Domain Name Not Added successfully",customerPage.verifyDomainAdded(DomainName));
     }

    /************************************************************************************
	* Description:
	* Status: 
	*************************************************************************************/
    @And("^I Edit the Domain$")
    public void i_edit_the_domain()  {
       String DomainName = CustomerCSVReader.getDomainNameToAdd();
       String DomainNameEdit = CustomerCSVReader.getDomainNameEditToEdit();
	customerPage.editDomain(DomainName,DomainNameEdit);
    }

    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @Then("^I can see Domain edited successfully$")
    public void i_can_see_domain_edited_successfully()   {
       assertTrue("Domain name Not Edited",customerPage.verifyDomainEdited());
    }
   
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @And("^I Edit the Domain with Duplicate name$")
    public void i_edit_the_domain_with_duplicate_name()  {
       String DomainName = CustomerCSVReader.getDomainNameEditToEdit();
       String ExistingDomainName = CustomerCSVReader.getDomainNameEditToEdit();
		customerPage.EditDomainWithDuplicateName(DomainName, ExistingDomainName);
    }
    
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @Then("^I can see duplicate domain Error message is showing to Customer$")
    public void i_can_see_duplicate_domain_error_message_is_showing_to_customer()  {
    	String ExistingDomainName = CustomerCSVReader.getDomainNameEditToEdit();
    	assertTrue("Domain name edited with existing Name",customerPage.verifyDomainNotEditedToExistingName(ExistingDomainName));
    }
    
    /************************************************************************************
	* Description:
	* Status: 
	*************************************************************************************/
    @And("^I disable the Domain$")
    public void i_disable_the_domain()  {
    	String DomainNameToDisable = CustomerCSVReader.getDomainNameEditToEdit();
    	customerPage.disableDomain(DomainNameToDisable);
    }

    /************************************************************************************
	* Description:
	* Status: 
	*************************************************************************************/
    @Then("^I can see Domain disabled successfully$")
    public void i_can_see_domain_disabled_successfully()   {
    	String DomainNameToDisable = CustomerCSVReader.getDomainNameEditToEdit();
		assertTrue("Domain Not disabled Successfully",customerPage.verifyDomainDisabled(DomainNameToDisable));
    }
    /************************************************************************************
	* Description:
	* Status: 
	*************************************************************************************/
    @And("^I Enable the Domain$")
    public void i_enable_the_domain()  {
    	String DomainNameToEnable = CustomerCSVReader.getDomainNameEditToEdit();
		customerPage.enableDomain(DomainNameToEnable);
    }

    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
       @Then("^I can see Domain Enabled successfully$")
       public void i_can_see_domain_enabled_successfully()   {
    	   String DomainNameToEnable = CustomerCSVReader.getDomainNameEditToEdit();
		assertTrue("Domain Not enabled successfully",customerPage.VerifyDomainEnabled(DomainNameToEnable));
       }
    
    /************************************************************************************
	* Description:
	* Status: 
	*************************************************************************************/
    @And("^I Delete the Domain$")
    public void i_delete_the_domain() {
        String DomainNameToDelete = CustomerCSVReader.getDomainNameEditToEdit();
		customerPage.deleteDomain(DomainNameToDelete);
    }
    
    /************************************************************************************
	* Description:
	* Status: 
	*************************************************************************************/
    @Then("^I can see Domain deleted successfully$")
    public void i_can_see_domain_deleted_successfully()   {
         String DomainNameToDelete = CustomerCSVReader.getDomainNameEditToEdit();
		assertTrue("Domain not Deleted",customerPage.verifyDomainDeleted(DomainNameToDelete));
    }

    /************************************************************************************
	* Description:
	* Status: 
	*************************************************************************************/
    @And("^I delete the customer$")
    public void i_delete_the_customer()  {
    	customerPage.deleteTheCustomer();
    }

     /************************************************************************************
	* Description:
	* Status: 
	*************************************************************************************/
    @Then("^I can see customer deleted successfully$")
    public void i_can_see_customer_deleted_successfully()   {
    	String CustomerNameToDelete = CustomerCSVReader.getAddCustomerNameToEdit();
		assertTrue("Customer not deleted",customerPage.verifyCustomerDeleted(CustomerNameToDelete));
    }


    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    
    @And("^I add Customer Name with Existing Name$")
    public void i_add_customer_name_with_existing_name() {
    	String DuplicateCustomerNameToAdd = CustomerCSVReader.getCustomerNameToEdit();
		String CustomerNumberToAdd = CustomerCSVReader.getCustomerMobileNumberToEdit();
		String CustomerImage = CustomerCSVReader.getCustomerImagePath();
		customerPage.existingCustomerName(DuplicateCustomerNameToAdd,CustomerNumberToAdd,CustomerImage);
    }
    
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @Then("^I can see error message is showing and Customer not added$")
    public void i_can_error_message_is_showing_and_customer_not_added(){
      String DuplicateCustomerName = CustomerCSVReader.getCustomerNameToEdit();
	assertTrue("Customer added successfully with duplicate Name",customerPage.VerifyCustomerDuplicateName(DuplicateCustomerName));
    }
    
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @And("^I click on customer Contacts link$")
    public void i_click_on_customer_contacts_link() {
        String CustomerNameToViewContact = CustomerCSVReader.getSelectCustomerNameTOSelectAndVerify();
		customerPage.ClickOnCustomerLink(CustomerNameToViewContact );
    }
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    
    @Then("^I can see no contact added info error message$")
    public void i_can_see_no_contact_added_info_error_message() {
        assertTrue("Error message is not showing for empty contact details",customerPage.VerifyEmptyContactdetails());
    }
   
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @Then("^I can see add button disabled and not able to add customer contact details$")
    public void i_can_see_add_button_disabled_and_not_able_to_add_customer_contact_details()  {
        assertTrue("User able to add more than three contact details",customerPage.VerifyNotallowedToAddMoreThanThreeCustomerContacts());
    }
    
    
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @And("^I click on customer Contacts link to edit details$")
    public void i_click_on_customer_contacts_link_to_edit_details()  {
    	String customerNameToEditContactDetails = CustomerCSVReader.getCustomerNameToEditContactDetails();
		customerPage.ClickOnCustomerLinkToEditTheDetails(customerNameToEditContactDetails );
    }
    
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @And("^I edit the customer contact details$")
    public void i_edit_the_customer_contact_details() {
        String ExistingContactname = CustomerCSVReader.getCustomerContactName();
		String ContactNameToEdit = CustomerCSVReader.getContactNameToEdit();
		String ContactMobileToEdit = CustomerCSVReader.getContactMobileToEdit();
		String ContactEmailToEdit = CustomerCSVReader.getContactEmailToEdit();
		customerPage.editAndUpdateCustomerContactDetails(ExistingContactname,ContactNameToEdit,ContactMobileToEdit,ContactEmailToEdit );
    }
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/

    @Then("^I can see customer contact details are edited$")
    public void i_can_see_customer_contact_details_are_edited()  {
        String UpdateContactname = CustomerCSVReader.getContactNameToEdit();
		String UpdatedMobileNumber = CustomerCSVReader.getContactMobileToEdit();
		String UpdatedEmail = CustomerCSVReader.getContactEmailToEdit();
		assertTrue("Contact details are not edited",customerPage.verifyConatctDetailsAreUpdated(UpdateContactname,UpdatedMobileNumber,UpdatedEmail));
    }
    
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @And("^I click on customer Contacts link to delete the details$")
    public void i_click_on_customer_contacts_link_to_delete_the_details(){
        String customerNameToDContactDetails = CustomerCSVReader.getCustomerNameToDeleteContactDetails();
		customerPage.clickOnCustomerContactLinkToDeleteDetails(customerNameToDContactDetails );
    }
    
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @And("^I delete the customer contact details$")
    public void i_delete_the_customer_contact_details(){
        String ExistingContactnameToDelete = CustomerCSVReader.getContactNameToEdit();
		customerPage.deleteContactDetails(ExistingContactnameToDelete );
    }

    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @Then("^I can see customer contact details are deleted$")
    public void i_can_see_customer_contact_details_are_deleted(){
    	 String ExistingContactnameToDelete = CustomerCSVReader.getContactNameToEdit();
        assertTrue("Customer Contact details not deleted",customerPage.verifyCustomerContactDeleted(ExistingContactnameToDelete));
    }
    
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    
    @And("^I click on customer Contacts link to verify contact name text field$")
    public void i_click_on_customer_contacts_link_to_verify_contact_name_text_field(){
    	String CustomerNameToViewContact = CustomerCSVReader.getCustomerToVerifyContactName();
		customerPage.ClickOnCustomerLink(CustomerNameToViewContact);
    }
    
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    
    @And("^I enter the Invalid Contact Name in contact name text field$")
    public void i_enter_the_invalid_contact_name_in_contact_name_text_field(){
    	String InvalidContactname = CustomerCSVReader.getCustomerContactNameToVerifyContactname();
    	customerPage.EnterInvalidDataToContactNameTextField(InvalidContactname);
    }
    
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @Then("^I can see contact name text field showing an error$")
    public void i_can_see_contact_name_text_field_showing_an_error() {
        assertTrue("Contact name text field accepting Invalid data",customerPage.VerifyContactNameTextField());
    }
    
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @And("^I click on customer Contacts link to verify contact mobile text field$")
    public void i_click_on_customer_contacts_link_to_verify_contact_mobile_text_field() {
    	String CustomerNameToViewContact = CustomerCSVReader.getCustomerToVerifyContactMobile();
		customerPage.ClickOnCustomerLink(CustomerNameToViewContact);
    }
    
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @And("^I enter the Invalid Contact mobile in contact mobile text field$")
    public void i_enter_the_invalid_contact_mobile_in_contact_mobile_text_field() {
    	String InvalidContactMobile = CustomerCSVReader.getCustomerContactMobileToVerifyContactMobile();
    	customerPage.EnterInvalidDataToContactMobileTextField(InvalidContactMobile);
    }
    
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @Then("^I can see contact mobile text field showing an error$")
    public void i_can_see_contact_mobile_text_field_showing_an_error() {
        assertTrue("Invalid mobile number added",customerPage.VerifyCustomerMobileToVerifyContactMobile());
    }

    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @And("^I click on customer Contacts link to verify contact email text field$")
    public void i_click_on_customer_contacts_link_to_verify_contact_email_text_field() {
    	String CustomerNameToViewContact = CustomerCSVReader.getCustomerToVerifyContactEmail();
		customerPage.ClickOnCustomerLink(CustomerNameToViewContact);
    }
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @And("^I enter the Invalid Contact Email in contact email text field$")
    public void i_enter_the_invalid_contact_email_in_contact_email_text_field() {
    	String InvalidContactEmail = CustomerCSVReader.getCustomerContactEmailToVerifyContactEmail();
    	customerPage.EnterInvalidDataToContactEmailTextField(InvalidContactEmail);
    }
    
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @Then("^I can see contact email text field showing an error$")
    public void i_can_see_contact_email_text_field_showing_an_error() {
        assertTrue("Invalid email Id Accepted",customerPage.verifyContactEmailIdTextField());
    }
    
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @And("^I click on customer Contacts link to verify duplicate details can be added$")
    public void i_click_on_customer_contacts_link_to_verify_duplicate_details_can_be_added()  {
    	String CustomerNameToViewContact = CustomerCSVReader.getCustomerToVerifyDuplicateContactDetails();
		customerPage.ClickOnCustomerLink(CustomerNameToViewContact);
    }
    
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @And("^I enter the existing Name,Mobile number and Email id$")
    public void i_enter_the_existing_namemobile_number_and_email_id()  {
    	String DuplicateName = CustomerCSVReader.getContactNameToEdit();
    	String DuplicateMobile = CustomerCSVReader.getContactMobileToEdit();
    	String DuplicateEmail = CustomerCSVReader.getContactEmailToEdit();
    	customerPage.EnterDuplicateContactDetails(DuplicateName,DuplicateMobile,DuplicateEmail);

    }
    
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @Then("^I can see contact Name,Mobile number and Email id can be added$")
    public void i_can_see_contact_namemobile_number_and_email_id_can_be_added() {
      assertTrue("Duplicate contact details not added",customerPage.verifyDuplicateContactDetailsAdded());
    }
    
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @And("^I click on customer Locations link to verify location details$")
    public void i_click_on_customer_locations_link_to_verify_location_details() {
       String CustomerNameToViewLocation = CustomerCSVReader.getCustomerNameToViewLocationDetails();
       customerPage.clickOnLocationLink(CustomerNameToViewLocation );
    }
    
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @And("^I enter the existing location Name and Click on add button$")
    public void i_enter_the_existing_location_name_and_click_on_add_button() {
    	String Location = CustomerCSVReader.getCustomerLocation();
    	String locationTypedropdown = CustomerCSVReader.getlocationTypeSelection();
    	String LocationToSearch = CustomerCSVReader.getCustomerLocationToSearch();
    	customerPage.enterLocationDetails(Location,locationTypedropdown,LocationToSearch);
    }
    
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @Then("^I can see Location not added$")
    public void i_can_see_location_not_added() {
      String DuplicateLocationName = CustomerCSVReader.getCustomerLocation();
	assertTrue("Duplicate location Added",customerPage.verifyDuplicateLocationNotAdded(DuplicateLocationName ));
    }
    
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @And("^I add the Invalid Location Name$")
    public void i_add_the_invalid_location_name()  {
        String InvalidLocationName = CustomerCSVReader.getInvalidLocationName();
		customerPage.enterInvalidLocationName(InvalidLocationName);
    }

    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @Then("^I can see Location name Text field showing an error$")
    public void i_can_see_location_name_text_field_showing_an_error()  {
       assertTrue("Invalid Location Name accepted",customerPage.VerifyInvalidLocationName()); 
    }
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @And("^I Search for Location with valid name$")
    public void i_search_for_location_with_valid_name() {
       String LocationToSearch = CustomerCSVReader.getValidLocationNameToSearch();
	customerPage.SearchLocationName(LocationToSearch );
    }
    
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @Then("^I can see Location name related to search result$")
    public void i_can_see_location_name_related_to_search_result() {
       assertTrue("Location is not searched",customerPage.verifyLocationSearchedForValidData());
    }
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @And("^I Search for Location with Invalid name$")
    public void i_search_for_location_with_invalid_name() {
       String LocationToSearch = CustomerCSVReader.getInValidLocationNameToSearch();
	customerPage.SearchLocationName(LocationToSearch );
    }
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @Then("^I can see no Locations are showing to Search result$")
    public void i_can_see_no_locations_are_showing_to_search_result() {
       assertTrue("Location is not searched",customerPage.verifyLocationSearchedForInValidData());
    }
    
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @And("^I enter the data for all the required fields in Location tab and Click on Cancel button$")
    public void i_enter_the_data_for_all_the_required_fields_in_location_tab_and_click_on_cancel_button()  {
    String LocationNameToVerifyCancel = CustomerCSVReader.getCustomerLocationeNametoVerifyCancelbutton();
	String locationTypedropdown = CustomerCSVReader.getlocationTypeSelection();
	customerPage.addlocationDetailsANdClickOnCancelButton(LocationNameToVerifyCancel,locationTypedropdown);
    }
    
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @Then("^I can see no Locations is added$")
    public void i_can_see_no_locations_is_added()  {
      String LocationNameToVerifyCancel = CustomerCSVReader.getCustomerLocationeNametoVerifyCancelbutton();
	assertTrue("Customer location cancel button not working",customerPage.verifyLocationTabCancelButton(LocationNameToVerifyCancel)); 
    }
    
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @And("^I edit and update the location details$")
    public void i_edit_and_update_the_location_details() {
        String ExistinglocationName = CustomerCSVReader.getExistingLocationNameToEditDetails();
		String LocationNameToEdit = CustomerCSVReader.getLocationNameToEdit();
		String locationTypedropdownToEdit = CustomerCSVReader.getlocationTypedropdownToEdit();
		String LocationToSearchToEdit = CustomerCSVReader.getLocationToSearchToEdit();
		customerPage.editLocationDetails(ExistinglocationName,LocationNameToEdit,locationTypedropdownToEdit,LocationToSearchToEdit);
    }
    
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @Then("^I can see Location edited details Updated successfully$")
    public void i_can_see_location_edited_details_updated_successfully() {
      String LocationNameToEdit = CustomerCSVReader.getLocationNameToEdit();
	assertTrue("LocationName Not edited successfully",customerPage.verifyLocationEditedSuccessfully(LocationNameToEdit));
    }
    
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @And("^I delete the location details$")
    public void i_delete_the_location_details() {
        String LocationNameToDelete = CustomerCSVReader.getLocationNameToDelete();
		customerPage.deleteLocation(LocationNameToDelete );
    }
    
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @Then("^I can see Location deleted successfully$")
    public void i_can_see_location_deleted_successfully()  {
    	String DeletedLocationName = CustomerCSVReader.getLocationNameToDelete();
       assertTrue("Location Not deleted",customerPage.VerifyDeleteLocation(DeletedLocationName));
    }
    
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @And("^I click on contact Link to verify Cancel button$")
    public void i_click_on_contact_link_to_verify_cancel_button() {
        String CustomerNameToViewContact = CustomerCSVReader.getSelectCustomerNameTOSelectAndVerify();
		customerPage.ClickOnContactLinkToVerifyCancelbutton(CustomerNameToViewContact);
    }
    
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @And("^I enter the data for all the required fields in contact tab and Click on Cancel button$")
    public void i_enter_the_data_for_all_the_required_fields_in_contact_tab_and_click_on_cancel_button() {
    	String ConatctNameToVerifyCancelButton = CustomerCSVReader.getCustomerContactNameToVerifyCancelbuttonFeature();
        customerPage.enterContactDetailsToVerifyCancelButton(ConatctNameToVerifyCancelButton);
    }

    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @Then("^I can see no conatct is added$")
    public void i_can_see_no_conatct_is_added() {
    String ConatctNameToVerifyCancelButton = CustomerCSVReader.getCustomerContactNameToVerifyCancelbuttonFeature();
    assertTrue("Cancel button not working in Contact tab",customerPage.verifyCancelButtonInContactTab(ConatctNameToVerifyCancelButton));    
    }
    
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @And("^I click on customer Locations link to verify error message for empty location$")
    public void i_click_on_customer_locations_link_to_verify_error_message_for_empty_location()  {
       String CustomerNameToViewLocation = CustomerCSVReader.getSelectCustomerNameTOSelectAndVerify();
	 customerPage.clickOnLocationLink(CustomerNameToViewLocation  );
    }

    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @Then("^I see error messages for empty Location$")
    public void i_see_error_messages_for_empty_location() {
      assertTrue("Error message is not showing for Empty Location",customerPage.verifyLocationTabForEmptyDetails());
    }
    
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @And("^I click on all add customer text fields$")
    public void i_click_on_all_add_customer_text_fields() {
        customerPage.clickOnEachFieldsOfAddCustomerTab();
    }
    
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @Then("^I see error messages for add customer fields$")
    public void i_see_error_messages_for_add_customer_fields() {
       assertTrue("Error message is not showing for empty fields",customerPage.VerifyAddCustomerTextFieldErrormessages());
    }
   
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @And("^I click on customer Contacts link to verify not able to add more than three contact$")
    public void i_click_on_customer_contacts_link_to_verify_not_able_to_add_more_than_three_contact() {
    	String CustomerNameToViewContact = CustomerCSVReader.getMoreThanThreeContactCustomer();
		customerPage.SelectCustomerTOVerifyThreeContactFeature(CustomerNameToViewContact );
        
    }
    
//    /************************************************************************************
//   	* Description:
//   	* Status: 
//   	*************************************************************************************/
//    @And("^select customer to verify contact tab text fields error message$")
//    public void select_customer_to_verify_contact_tab_text_fields_error_message()  {
//        String customerName = CustomerCSVReader.getCustomerToVerifyContctTabTextFields();
//		customerPage.selectCustomer(customerName);
//    }
//    
//    /************************************************************************************
//   	* Description:
//   	* Status: 
//   	*************************************************************************************/
//    @And("^I click on all the fields of contacts Tab$")
//    public void i_click_on_all_the_fields_of_contacts_tab()  {
//    	customerPage.clickOnAlltheFieldsOfContactTab();
//    }
//    /************************************************************************************
//   	* Description:
//   	* Status: 
//   	*************************************************************************************/
//    @Then("^I can see error messages in contact Tab of empty fields$")
//    public void i_can_see_error_messages_in_contact_tab_of_empty_fields()  {
//    	assertTrue("In contact tab error messages is not showing for required fields",customerPage.verifyContactTabErrMsgforEmptyFields());
//    }
    
    /************************************************************************************
   	* Description:
   	* Status: 
   	*************************************************************************************/
    @And("^I add customer details To Edit$")
    public void i_add_customer_details_to_edit()  {
    	String CusterName = CustomerCSVReader.getAddCustomerNameToEdit();
		String customerNumber = CustomerCSVReader.getAddCustomerPhoneNumberToEdit();
		String ImpagePath = CustomerCSVReader.getImagePathToEdit();
		customerPage.addCustomerDetailsVerifyEdit(CusterName,customerNumber,ImpagePath );
       
    }
    /************************************************************************************
	* Description:
	* Status: 
	*************************************************************************************/
    @Then("^I can See Customer details are added to edit$")
    public void i_can_see_customer_details_are_added_to_edit()  {
    	String AddedCustomerName = CustomerCSVReader.getAddCustomerNameToEdit();
		assertTrue("Customer not created",customerPage.verifyCustomerCreatedToVerifyEdit(AddedCustomerName));
    }

   
}
