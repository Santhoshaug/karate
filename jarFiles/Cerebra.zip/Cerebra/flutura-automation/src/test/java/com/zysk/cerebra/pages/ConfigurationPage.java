package com.zysk.cerebra.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.zysk.cerebra.commonPages.CommonFunctions;

import net.serenitybdd.core.pages.PageObject;

public class ConfigurationPage extends CommonFunctions {
	
	/***********************Page element identifiers******************************/
	
	private By admin = By.xpath("//span[@class='username' and contains(text(),'Admin')]");
	private By configuration = By.xpath("//span[contains(text(),'Configuration')]");
	private By userGroupTile = By.xpath("//div[contains(text(),'Customer & User Group Management')]");
	private By digitalTwinTile = By.xpath("//div[contains(text(),'Digital Twin Workbench')]");
	private By securityNotifTile = By.xpath("//div[contains(text(),'Security & Notification')]");
	private By dropDownMenu = By.xpath("//div[@class='mat-menu-content']");
	private By configToolBar = By.xpath("//mat-toolbar-row[@class='mat-toolbar-row']");
	
	
	private static String ConfigUrl="https://cerebra.flutura.com/configuration#/dashboard";
	
	/********************************************************************
	* Description: Visit Configuration
	* Param: NA
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void selectConfiguration()
	{
		List<WebElement> l1 = (List<WebElement>) getJavascriptExecutor().executeScript("return document.querySelectorAll('.username');");
		for(int i=0 ; i<l1.size();i++)
		{
			if(l1.get(i).getText().contains("GTT"))
			{
				waitSeconds(5);
				l1.get(i).click();
			    break;
			}
		}
		
//		for(int i=1;i<10;i++)
//		{
//			try {
//			String str = ((String) getJavascriptExecutor().executeScript("return document.querySelector('#rightAlignedItems button:nth-child("+i+") span .username').textContent"));
//
//			if (str.contains("GTT"))
//			{
//				getJavascriptExecutor().executeScript("document.querySelector('#rightAlignedItems button:nth-child("+ i +") span .username').click();");
//				break;
//			}
//			}
//			catch(Exception e)
//			{
//				System.out.println("Exception found");
//				i++;
//			}
//	
//		}
		
		waitForElementToAppear(dropDownMenu);
		Actions act = new Actions(getDriver());
		act.moveToElement(element(configuration)).click().perform();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verify Configuration page
	* Param: NA
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyConfigurationPage()
	{
		waitForElementToAppear(configToolBar);
		if (getDriver().getCurrentUrl().equals(ConfigUrl) && 
			element(userGroupTile).isCurrentlyVisible() && 
			element(digitalTwinTile).isCurrentlyVisible() && 
			element(securityNotifTile).isCurrentlyVisible()) return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Go to Configuration Dashboard by passing URL in the browser
	* Param: NA
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	
	public void configurationDashboard(String dashboardURL) {
		 getDriver().navigate().to(dashboardURL);
		 waitForElementToDisappear(loader);
	}
}
