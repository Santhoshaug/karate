package com.zysk.cerebra.steps;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertTrue;

import org.openqa.selenium.By;

import com.zysk.cerebra.csv_reader.AccessControlCSVReader;
import com.zysk.cerebra.csv_reader.EquipmentStructureCSVReader;
import com.zysk.cerebra.pages.AccessControlPage;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.steps.ScenarioSteps;

@SuppressWarnings("serial")
public class AccessControlSteps extends ScenarioSteps{
    
	 AccessControlPage accessControlPage;
	 
	 /********************************************************************
		* Description: Select Access control link
		* Status: Completed
		********************************************************************/
	    @And("^I select Access Control$")
	    public void andISelectAccessControl()
	    {
	    	accessControlPage.clickAccessControl();
	    }
	    
	    /********************************************************************
		* Description: I select the logged in customer
		* Status: Completed
		********************************************************************/
	    @And("^I select the logged in customer$")
	    public void andISelectTheLoggedInCustomer()
	    {
	    	String customerName = AccessControlCSVReader.getCustomerNameForCustomerSelection();
	    	accessControlPage.selectDemoCustomer(customerName);
	    }
	 
		/********************************************************************
		* Description: Select user group
		* Status: Completed
		********************************************************************/
	    @And("^I select the user group$")
	    public void andISelectTheUserGroup()
	    {
	    	String userGroup = AccessControlCSVReader.getUserGroup();
	    	accessControlPage.selectUserGroup(userGroup);
	    }
		
	    /********************************************************************
		* Description: Select machine unit tab
		* Status: Completed
		********************************************************************/
	    @And("^I select the Machine Unit tab$")
	    public void andISelectTheMachineUnitTab()
	    {
	    	accessControlPage.clickMachineUnitTab();
	    }
	    
	   
	    /********************************************************************
		* Description: Assign the machine Unit
		* Status: Completed
		********************************************************************/
	    @When("^I assign machine unit$")
	    public void whenIassignMachineUnit()
	    {
	    	accessControlPage.assignMachineUnit();
	    }
	    
	    /********************************************************************
		* Description: I can see the machine unit in the Assign machine unit list
		* Status: Completed
		********************************************************************/
	    @Then("^I can see machine unit in the list$")
	    public void thenICanSeeTheMachineUnitInTheList()
	    {
	    	assertTrue("Assigned Machine Unit is not present in the list",accessControlPage.verifyMachineUnit());
	    }
	    	    
		/********************************************************************
		* Description: Machine unit must be added in the list
		* Status: Completed
		********************************************************************/
		@Then("^I can see machine unit getting listed$")
		public void thenICanSeeMachineUnitGettingListed()
		{
			String machineUnit = EquipmentStructureCSVReader.getMachineUnitName();
			assertTrue("Equipment Structure Not Assigned",accessControlPage.verifyMachineUnits(machineUnit));
		}
		
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	    
		
	    
	   
	    
	    /********************************************************************
		* Description: Select machine unit tab
		* Status: Completed
		********************************************************************/
	    @And("^I select the Asset$")
	    public void andISelectTheAsset()
	    {
	    	accessControlPage.clickAssetTab();
	    }
	    
	    /********************************************************************
 		* Description: Assign asset
 		* Status: Completed
 		********************************************************************/
	    
	    @When("^I assign Asset$")
	    public void whenIassignasset()
	    {
	    	accessControlPage.assignAsset();
	    }
	    
	    /********************************************************************
		* Description: I can see the machine unit in the Assign machine unit list
		* Status: Completed
		********************************************************************/
	    @Then("^I can see machine asset in the list$")
	    public void thenICanSeeTheAssetInTheList()
	    {
	    	assertTrue("Assigned Asset is not present in the list",accessControlPage.verifyAssets());
	    }
	    
	    /********************************************************************
	   	* Description: Navigate to dashboard and end app
	   	* Status: Completed
	   	********************************************************************/ 
	    @And("^I go to end application$")
	    public void i_go_to_end_application()  {
	    	accessControlPage.goTOEndApplication();
	        
	    }
	    /********************************************************************
	   	* Description: Check for asset
	   	* Status: Completed
	   	********************************************************************/ 
	    @Then("^I can see the Asset is showing in the dropdown$")
	    public void i_can_see_the_asset_is_showing_in_the_dropdown() {
	    	
	    	assertTrue("Assigned Asset is not present in the list",accessControlPage.verifyAssetInEndApp());
	    }
	    
	   
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
}
