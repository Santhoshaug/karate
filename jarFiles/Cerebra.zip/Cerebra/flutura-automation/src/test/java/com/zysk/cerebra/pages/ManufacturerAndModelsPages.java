package com.zysk.cerebra.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.zysk.cerebra.commonPages.CommonFunctions;

public class ManufacturerAndModelsPages extends CommonFunctions {

	/***********************Page element identifiers******************************/
	private By manufacturermodels = By.xpath("//a[contains(text(),'Manufacturer & Model')]");
	private By categoriesHeader = By.xpath("//span[@class='page-header align-self-center' and contains(text(),'Categories')]");
	private By searchBar = By.xpath("//span[@class='search-bar']");
	private By addNewButton = By.xpath("//span[contains(text(),'Add New')]");
	private By manufacturerName = By.xpath("//input[@id='input']");	
	private By manufacturerNameField = By.xpath("//input[@type='text' and @id='input']");
	private By manufacturerCode = By.xpath("//input[@formcontrolname='code']");
	private By submitManufacturer = By.xpath("//span[@class='mat-button-wrapper' and text()=' Add ']");
	private By manufacturerList = By.xpath("//form[@class='ng-untouched ng-pristine ng-valid ng-star-inserted']");
	private By manufacturerDropdown = By.xpath("//div[@role='listbox']");
	private By manufacturerListLocator = By.xpath("//div[@class='mat-autocomplete-panel mat-autocomplete-visible ng-star-inserted']//span");
	private By deleteConfirmation = By.xpath("//button[text()='Yes, delete it!']");
	private By modelName = By.xpath("//input[@id='name']");
	private By modelCode = By.xpath("//input[@id='code']");
	private By fileUpload = By.xpath("//input[@id='files']");
	private By listOfEquipments = By.xpath("//div[@class='cdk-overlay-pane']//mat-option/span");
	private By machineUnitField = By.xpath("//span[text()='Machine Unit']");
	private By modelField = By.xpath("//span[text()='Select Model']");
	private By countField = By.xpath("//input[@type='number']");
	private By machineUnitList = By.xpath("//div[@class='cdk-overlay-pane']//mat-option//span");
	private By modelList = By.xpath("//div[@class='cdk-overlay-pane']//mat-option//span");
	private By designParameterTab = By.xpath("//a[contains(text(),'Design Parameters')]");
	private By measurementsTab = By.xpath("//a[contains(text(),'Measurements')]");
	private By alarmsTab = By.xpath("//mat-card//div//a[contains(text(),'Alarms')]");
	private By tripsTab = By.xpath("//a[contains(text(),'Trips')]");
	private By faultsTab = By.xpath("//a[contains(text(),'Faults')]");
	private By functionStatesTab = By.xpath("//a[contains(text(),'Function States')]");
	private By calibrationTab = By.xpath("//a[contains(text(),'Calibration')]");
	private By virtualSensorTab = By.xpath("//a[contains(text(),'Virtual Sensor')]");
	private By physicsEqnTab = By.xpath("//a[contains(text(),'Virtual Sensor')]");
	private By performanceCurveTable = By.xpath("//a[contains(text(),'Performance Curve/Table')]");
	private By gatewayConfigurationTab = By.xpath("//a[contains(text(),'Gateway Configuration')]");
	private By moreOption = By.xpath("//mat-icon[text()='more_vert']");
	private By selectParameter = By.xpath("//mat-select[@id='measurements']");
	private By selectParameterForCalibration = By.xpath("//mat-select[@id='calibration']");
	private By dropdownOptions = By.xpath("//div//mat-option//span");
	private By metricUnitField = By.xpath("//input[@id='metric_unit']");
	private By usUnitField = By.xpath("//input[@id='us_unit']");
	private By additiveField = By.xpath("//input[@placeholder='Additive']");
	private By subtractiveField = By.xpath("//input[@placeholder='Subractive']");
	private By multiplicativeField = By.xpath("//input[@placeholder='Multiplicative']");
	private By divisionField = By.xpath("//input[@placeholder='Division']");
	private By add = By.xpath("//span[text()=' Add ']");
	private By configurationTab = By.xpath("//span[contains(text(),'Configurations')]");
	private By unitDropdown = By.xpath("//mat-select[@id='unit']//div[@class='mat-select-value']");
	private By parameterNameField = By.xpath("//input[@name='name']");
	private By parameterValueField = By.xpath("//input[@name='value']");
	private By designparameterDropdown = By.xpath("//mat-select[@id='measurements']");
	private By parameterDropdown = By.xpath("//mat-select[@role='listbox']");
	private By sysytemUnit = By.xpath("//mat-select[@id='systemUnits']");
	private By unitdropdown = By.xpath("//mat-select[@id='unit']");
	private By list = By.xpath("//mat-row");
	private By gatewayConfiguration = By.xpath("//a[contains(text(),'Gateway Configuration')]");
	private By parameterNameEditField = By.xpath("//input[@placeholder='Enter Name']");
	private By parameterValueEditField = By.xpath("//input[@placeholder='Enter Value']");
	private By severityField = By.xpath("//mat-select[@aria-label='Select Severity']");
	private By relatedMeasurementField = By.xpath("//mat-select[@aria-label='Select Related Measurements']");
	private By recommendation = By.xpath("//textarea");
	private By updateField = By.xpath("//span[contains(text(),'Update')]");
	private By searchField = By.xpath("//input[@type='text']");
	private By updateButton = By.xpath("//button[@type='submit']");
	private By addnewbutton = By.xpath("//span[contains(text(),'Add New')]");
	
	
	/********************************************************************
	* Description: Select Manufacturer and models
	* Param: NA
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void selectManufacturerAndModels()
	{
		element(manufacturermodels).click();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verify category list on selecting manufacturer and models
	* Param: NA
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public boolean verifyCategoryPage()
	{
		if(element(categoriesHeader).isCurrentlyVisible() &&
				element(searchBar).isCurrentlyVisible()) return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Select the machine unit
	* Param: NA
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void selectMachineunit(String machineunit)
	{
		if(element(By.xpath("//div[@class='dx-test-item ng-star-inserted']//div[normalize-space(text())='"+machineunit+"']")).isCurrentlyVisible()) {
		element(By.xpath("//div[@class='dx-test-item ng-star-inserted']//div[normalize-space(text())='"+machineunit+"']")).click();
		waitForElementToAppear(addNewButton);
		}
	}
	
	/********************************************************************
	* Description: Verify machine unit page
	* Param: NA
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public boolean verifyMachineUnitPage()
	{
		if(element(addNewButton).isCurrentlyVisible() &&
				element(searchBar).isCurrentlyVisible()) return true;
		else return false;
	}
	

	/********************************************************************
	* Description: Add new manufacturer
	* Param: Manufacturer name, Manufacturer code
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void addManufacturer(String newManufacturerName, String code)
	{
		if(!element(By.xpath("//a[contains(text(),'"+newManufacturerName+"')]")).isCurrentlyVisible())
		{
			element(addNewButton).click();
			waitForElementToDisappear(loader);
			element(manufacturerNameField).click();
			
			element(By.xpath("//input[@placeholder='Enter Manufacturer Name']")).sendKeys(newManufacturerName);
			element(By.xpath("//input[@placeholder='Enter Manufacturer Code']")).sendKeys(code);
			element(submitManufacturer).click();
			waitForElementToDisappear(loader);	
			
		String ActMsg = element(By.xpath("//simple-snack-bar//span")).getText();
		String ExpMsgAlreadyExist = "Manufacturer with name '"+newManufacturerName+"' already exists";
		String ExpMsgNewlyAdded = "Manufacturer 'Engine' added successfuly";
		String ExpMsgExistAdd = "Manufacturer 'CUMMINS' is already mapped to Vinod";
		
		
		if(ActMsg.equals(ExpMsgAlreadyExist)) {
			element(addNewButton).click();
			waitForElementToDisappear(loader);
			element(manufacturerNameField).click();

			List<WebElement>  manufacturerList  = getDriver().findElements(By.xpath("//span[@class='mat-option-text']"));
			int s= manufacturerList.size();
			System.out.println("count"+s);
			try {
			for(int i=1; i<s;i++)
			{
				if(manufacturerList.get(i).getText().equals(newManufacturerName))
					manufacturerList.get(i).click();
			}
			}
			catch(StaleElementReferenceException e)
			{
				System.out.println("Exception handled");
			}
			element(submitManufacturer).click();
			waitForElementToDisappear(loader);	
		}
			
		}
}
	
	/********************************************************************
	* Description: Verify added manufacturer in the list
	* Param: NA
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public boolean verifyAddedManufacturerNameInTheList(String newManufacturerName)
	{
		if(element(manufacturerList).isCurrentlyVisible() &&
				element(By.xpath("//a[contains(text(),'"+newManufacturerName+"')]")).isCurrentlyVisible())
			return true;
		else return false;
		
	}
	
	/********************************************************************
	* Description: Verify added manufacturer in the list which is added from dropdown
	* Param: NA
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public boolean verifyAddedManufacturerNameInTheListAddedByDropdown(String newManufacturerName)
	{
		if(element(manufacturerList).isCurrentlyVisible() 
//				&& element(By.xpath("//a[contains(text(),'"+newManufacturerName+"')]")).isCurrentlyVisible()
				)
			return true;
		else return false;
	}
	/********************************************************************
	* Description: Disable the manufacturer
	* Param: Manufacturer name
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void disableManufacturer(String manufacturerName)
	{
		if(element(By.xpath("//a[contains(text(),'"+manufacturerName+"')]")).isCurrentlyVisible()) {
			WebElement element = getDriver().findElement(By.xpath("//a[contains(text(),'"+manufacturerName+"')]//..//..//mat-slide-toggle"));
			String ActclassValue = element.getAttribute("class");
			String ExpclassValue = "mat-slide-toggle mat-primary mat-checked";
			
			if(ActclassValue.equals(ExpclassValue)) {
				element(By.xpath("//a[contains(text(),'"+manufacturerName+"')]/../..//div[@class='mat-slide-toggle-bar mat-slide-toggle-bar-no-side-margin']")).click();
				waitForElementToDisappear(loader);
			}
		}
	}
	
	/********************************************************************
	* Description: Delete the manufacturer
	* Param: Manufacturer name
	* Returns: Void
	* Status: Completed
	********************************************************************/
	
	public boolean verifyManufactureDisabled(String manufacturerName) {
		if(element(By.xpath("//a[contains(text(),'"+manufacturerName+"')]//..//..//mat-slide-toggle[@class='mat-slide-toggle mat-primary']")).isCurrentlyVisible())	
			return true;
			else
				return false;
		}
	
	/********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
	public void enableManufacturer(String manufacturerName) {
	
		if(element(By.xpath("//a[contains(text(),'"+manufacturerName+"')]")).isCurrentlyVisible()) {
			WebElement element = getDriver().findElement(By.xpath("//a[contains(text(),'"+manufacturerName+"')]//..//..//mat-slide-toggle"));
			String ActclassValue = element.getAttribute("class");
			String ExpclassValue = "mat-slide-toggle mat-primary";
			
			if(ActclassValue.equals(ExpclassValue)) {
				element(By.xpath("//a[contains(text(),'"+manufacturerName+"')]/../..//div[@class='mat-slide-toggle-bar mat-slide-toggle-bar-no-side-margin']")).click();
				waitForElementToDisappear(loader);
			}
	}
}

	/********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
	public boolean verifyManufacturerEnabled(String manufacturerName) {
		if(element(By.xpath("//a[contains(text(),'"+manufacturerName+"')]//..//..//mat-slide-toggle[@class='mat-slide-toggle mat-primary']")).isCurrentlyVisible())	
			return true;
			else
				return false;
	}

	/********************************************************************
	* Description: Delete the manufacturer
	* Param: Manufacturer name
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void deleteManufacturer(String manufacturerName)
	{
		if(element(By.xpath("//a[contains(text(),'"+manufacturerName+"')]")).isCurrentlyVisible()) {
		element(By.xpath("//a[contains(text(),'"+manufacturerName+"')]/../..//mat-icon[contains(text(),'delete')]")).click();
		element(deleteConfirmation).click();
		waitForElementToDisappear(loader);
		}
	}
	
	/********************************************************************
	* Description: Verify the manufacturer gets deleted
	* Param: Manufacturer name
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public boolean verifyManufacturerDeleted(String manufacturerName)
	{
		if(!element(By.xpath("//a[contains(text(),'"+manufacturerName+"')]")).isCurrentlyVisible()) 
			return true;
		else
			return false;
	}
	
	/********************************************************************
	* Description: Select manufacturer to add models
	* Param: Manufacturer name
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void selectManufacturer(String manufacturerName)
	{
		if(element(By.xpath("//a[contains(text(),'"+manufacturerName+"')]")).isCurrentlyVisible()) {
		Actions act = new Actions(getDriver());
		act.moveToElement(element(By.xpath("//a[contains(text(),'"+manufacturerName+"')]"))).click().perform();
		//element(By.xpath("//a[contains(text(),'"+manufacturerName+"')]")).click();
		waitForElementToDisappear(loader);
	}}
	
	/********************************************************************
	* Description: Verify models page
	* Param: Manufacturer name
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public boolean verifyModelsPage()
	{
		if(element(By.xpath("//span[contains(text(),'Models-')]")).isCurrentlyVisible() &&
				!element(By.xpath("//mat-list[@class='p-0 mat-list mat-list-base ng-star-inserted']")).isCurrentlyVisible()) return true;
		else return false;
	}
	
	
	/********************************************************************
	* Description: Add models to the manufacturer
	* Param: Manufacturer name
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void addModelName(String modelNameValue,String modelCodeValue,String filepath)
	{
		if(!element(By.xpath("//div[@class='mat-list-text']//..//a[contains(text(),' "+modelNameValue+"')]")).isCurrentlyVisible())
		{
		element(addNewButton).click();
		element(modelName).sendKeys(modelNameValue);
		element(modelCode).sendKeys(modelCodeValue);
		element(fileUpload).sendKeys(filepath);
		waitFor(2);
		element(submitManufacturer).click();
		waitForElementToDisappear(loader);
		}
	}
	

	/********************************************************************
	* Description: Verify the models added
	* Param: modelName
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyModelsAdded(String modelName)
	{
		if(element(By.xpath("//a[contains(text(),'"+modelName+"')]")).isCurrentlyVisible()) return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Edit the model
	* Param: modelToEdit,updateModelName,updateModelCode,updateFilepath
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void editModel(String modelToEdit,String updateModelName, String updateModelCode, String updateFilepath)
	{
		if(element(By.xpath("//div[@class='mat-list-text']//..//a[contains(text(),' "+modelToEdit+"')]")).isCurrentlyVisible() && 
				!element(By.xpath("//div[@class='mat-list-text']//..//a[contains(text(),' "+updateModelName+"')]")).isCurrentlyVisible()) 
		{
		element(By.xpath("//a[contains(text(),'"+modelToEdit+"')]/..//mat-icon[text()='edit']")).click();
		element(modelName).clear();
		element(modelName).sendKeys(updateModelName);
		element(modelCode).clear();
		element(modelCode).sendKeys(updateModelCode);
		element(By.xpath("//span[text()='Remove']")).click();
		element(fileUpload).sendKeys(updateFilepath);
		element(By.xpath("//span[contains(text(),'Update')]")).click();
		waitForElementToAppear(By.xpath("//a[contains(text(),'"+updateModelName+"')]"));
		}
	}
	
	/********************************************************************
	* Description: Verify the updated model
	* Param: updateModelName
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public boolean verifyUpdateModel(String updateModelName)
	{
		if(element(By.xpath("//a[contains(text(),'"+updateModelName+"')]")).isCurrentlyVisible()) return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Disable the model Param: modelName Returns: Void Status:
	* Completed
	********************************************************************/
	public void disableTheModel(String modelName) {
	if (element(By.xpath("//a[contains(text()," + modelName + ")]")).isCurrentlyVisible()) {
	WebElement element = getDriver()
	.findElement(By.xpath("//a[contains(text(),'" + modelName + "')]//..//..//mat-slide-toggle"));
	String ActClassValue = element.getAttribute("class");
	String ExpctClassValue = "align-middle mat-slide-toggle mat-primary mat-checked";

	if (ActClassValue.equals(ExpctClassValue)) {
	element(By.xpath("//a[contains(text(),'" + modelName
	+ "')]//..//div[@class='mat-slide-toggle-bar mat-slide-toggle-bar-no-side-margin']")).click();
	waitForElementToDisappear(loader);
		}
	}
}

	/********************************************************************
	* Description: Verify disabled model Param: modelName Returns: Void Status:
	* Completed
	********************************************************************/
	public boolean verifyModelDisabled(String modelName) {

	if (!element(By.xpath("//a[contains(text(),'"+modelName+"')]/..//mat-icon[text()='edit']"))
	.isCurrentlyVisible())
	return true;
	else
	return false;

	}
	
	/********************************************************************
	* Description: Disable the model Param: modelName Returns: Void Status:
	* Completed
	********************************************************************/
	public void enableTheModel(String modelName) {
	if (element(By.xpath("//a[contains(text()," + modelName + ")]")).isCurrentlyVisible()) {
	WebElement element = getDriver()
	.findElement(By.xpath("//a[contains(text(),'" + modelName + "')]//..//..//mat-slide-toggle"));
	String ActClassValue = element.getAttribute("class");
	String ExpctClassValue = "align-middle mat-slide-toggle mat-primary";

	if (ActClassValue.equals(ExpctClassValue)) {
	element(By.xpath("//a[contains(text(),'" + modelName
	+ "')]//..//div[@class='mat-slide-toggle-bar mat-slide-toggle-bar-no-side-margin']")).click();
	waitForElementToDisappear(loader);
		}}
	}
	/********************************************************************
	* Description: Verify disabled model Param: modelName Returns: Void Status:
	* Completed
	********************************************************************/
	public boolean verifyModelEnabled(String modelName) {
		if (element(By.xpath("//a[contains(text(),'"+modelName+"')]/..//mat-icon[text()='edit']"))
				.isCurrentlyVisible())
				return true;
				else
				return false;
	}


	/********************************************************************
	* Description: Delete the model Param: modelName Returns: Void Status:
	* Completed
	********************************************************************/
	public void deleteModel(String modelName, String editedModelName) {
		if(element(By.xpath("//a[contains(text(),'" + modelName + "')]")).isCurrentlyVisible()){
	element(By.xpath("//a[contains(text(),'" + modelName + "')]/..//mat-icon[text()='delete']")).click();
	element(deleteConfirmation).click();
	waitForElementToDisappear(loader);
	}
		
		if(element(By.xpath("//a[contains(text(),'" + editedModelName + "')]")).isCurrentlyVisible()){
			element(By.xpath("//a[contains(text(),'" + editedModelName + "')]/..//mat-icon[text()='delete']")).click();
			element(deleteConfirmation).click();
			waitForElementToDisappear(loader);
	}
}
	/********************************************************************
	* Description:  Param: Returns: Void Status:
	* Completed
	********************************************************************/
	
	public void selectTheUpdatedModel(String updateModelName) {
		
		if(element(By.xpath("//div[@class='mat-list-text']//..//a[contains(text(),' "+updateModelName+"')]")).isCurrentlyVisible()) 
		{
			element(By.xpath("//div[@class='mat-list-text']//..//a[contains(text(),' "+updateModelName+"')]")).click();
			waitForElementToDisappear(loader);
		}
	}
	
	/********************************************************************
	* Description:  Param: Returns: Void Status:
	* Completed
	********************************************************************/
	public void addSubsystemInSubsystemPage(String MachineUnitName,String ModelName) {
		if(element(By.xpath("//mat-card")).isCurrentlyVisible()) {			
			if(element(By.xpath("//mat-icon[contains(text(),' chevron_right ')]")).isCurrentlyVisible()) {
			element(By.xpath("//mat-icon[contains(text(),' chevron_right ')]")).click();
			List<WebElement> count = getDriver().findElements(By.xpath("//mat-icon[contains(text(),' chevron_right ')]"));
			try {
			for(int i=1;i<=count.size();i++) {
//				if(element(By.xpath("//mat-tree-node[@aria-expanded='false']//span[@class='mat-button-wrapper']/mat-icon[contains(text(),' chevron_right ')]")).isCurrentlyVisible()){
					element(By.xpath("//mat-icon[contains(text(),' chevron_right ')]")).click();
					waitFor(2000);
				
//				}
			}}
			catch(Exception e) {
				
			}
		
			List<WebElement> list = getDriver().findElements(By.xpath("//mat-tree-node"));
			
			try {
			for(int j=2;j<=list.size();j++) {
				
				if(!element(By.xpath("//mat-tree-node[@aria-expanded='false']//span[@class='mat-button-wrapper']/mat-icon[contains(text(),' chevron_right ')]")).isCurrentlyVisible()) {
				
				element(By.xpath("//mat-tree-node["+j+"]//mat-select[@placeholder='select']/div/div//span")).click();
				waitFor(2000);
				if(element(By.xpath("//mat-option[2]//span")).isCurrentlyVisible()) {
				Actions action = new Actions(getDriver()); 
				getDriver().findElement(By.xpath("//mat-option[2]//span"));

				action.moveToElement(element(By.xpath("//mat-option[2]//span"))).click();
			}}}
			}
			catch(Exception e) {
				
			}
			}
		}
		
	}
	/********************************************************************
	* Description: Select model to add subsystem Param: Returns: Void Status:
	* Completed
	********************************************************************/
	public void selectModel(String model) {
	element(By.xpath("//a[contains(text(),'" + model + "')]")).click();
	waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Select model to add subsystem Param: Returns: Void Status:
	* Completed
	********************************************************************/
	public void ClickOnModel(String model) {
	element(By.xpath("//a[contains(text(),'" + model + "')]")).click();
	waitForElementToDisappear(loader);
	}

	
	/********************************************************************
	* Description: Add subsystem to the model Param: Battery,Engine,AirIntakeSystem
	* Returns: Void Status: Completed
	********************************************************************/
	public void addSubsystem(String Battery, String Engine, String AirIntakeSystem) {
	element(By.xpath("//mat-icon[contains(text(),'chevron_right')]")).click();
	element(By.xpath("//span[text()='select']")).click();
	List<WebElement> l1 = getDriver().findElements(listOfEquipments);
	int s1 = l1.size();
	for (int i = 1; i < s1; i++) {
	if (l1.get(i).getText().equals(Battery))
	l1.get(i).click();
	waitSeconds(3);
	}

	element(By.xpath("//mat-icon[contains(text(),'chevron_right')]")).click();
	element(By.xpath("//span[text()='select']")).click();
	List<WebElement> l2 = getDriver().findElements(listOfEquipments);
	int s2 = l2.size();
	for (int i = 1; i < s2; i++) {
	if (l2.get(i).getText().equals(Engine))
	l2.get(i).click();
	waitSeconds(3);
	}

	element(By.xpath("//mat-icon[contains(text(),'chevron_right')]")).click();
	element(By.xpath("//span[text()='select']")).click();
	waitSeconds(2);
	List<WebElement> l3 = getDriver().findElements(listOfEquipments);
	int s3 = l3.size();
	for (int i = 1; i < s3; i++) {
	if (l3.get(i).getText().equals(AirIntakeSystem))
	l3.get(i).click();
	waitSeconds(3);
	}

	element(By.xpath("//span[contains(text(),'Add Subsystems')]")).click();
	// waitSeconds(6);
	waitForElementToDisappear(loader);
	}

	/********************************************************************
	* Description: Verify the subsystem in the list Param:
	* Battery,Engine,AirIntakeSystem Returns: Boolean Status: Completed
	********************************************************************/
	public boolean verifySubsystemAdded(String Battery, String Engine, String AirIntakeSystem) {
	element(By.xpath("//mat-icon[contains(text(),'chevron_right')]")).click();
	boolean result = false;
	if (element(By.xpath("//a[contains(text(),'" + Battery + "')]")).isCurrentlyVisible()) {
	result = true;
	element(By.xpath("//mat-icon[contains(text(),'chevron_right')]")).click();
	if (element(By.xpath("//a[contains(text(),'" + Engine + "')]")).isCurrentlyVisible()) {
	result = true;
	element(By.xpath("//mat-icon[contains(text(),'chevron_right')]")).click();
	if (element(By.xpath("//a[contains(text(),'" + AirIntakeSystem + "')]")).isCurrentlyVisible()) {
	result = true;
	System.out.println("result1" + result);
	} else
	result = false;
	System.out.println("result2" + result);
	} else
	result = false;
	System.out.println("result3" + result);
	} else
	result = false;
	System.out.println("result4" + result);
	return result;
	}

	/********************************************************************
	* Description: Add subsystem with count more than 1 Param:
	* Battery,Engine,Engine_model,count Returns: Void Status: Completed
	********************************************************************/
	public void addSubsystemWithCountMoreThan1(String Battery, String Engine, String Engine_model, String count) {
	element(By.xpath("//mat-icon[contains(text(),'chevron_right')]")).click();
	element(By.xpath("//a[contains(text(),'" + Battery + "')]/..//mat-icon[text()='add']")).click();
	By addSubsystemPopup = By.xpath("//h1[text()='Add Subsystem']");
	waitForElementToAppear(addSubsystemPopup);
	element(machineUnitField).click();
	List<WebElement> l1 = getDriver().findElements(machineUnitList);
	int s1 = l1.size();
	for (int i = 1; i < s1; i++) {
	if (l1.get(i).getText().contains(Engine))
	l1.get(i).click();
	waitSeconds(3);
	}
	element(modelField).click();
	List<WebElement> l2 = getDriver().findElements(modelList);
	int s2 = l2.size();
	try {
	for (int i = 1; i < s2; i++) {
	if (l2.get(i).getText().contains(Engine_model))
	l2.get(i).click();
	waitSeconds(2);
	}
	} catch (StaleElementReferenceException e) {
	System.out.println("Exception Handled");
	}
	element(countField).sendKeys(count);
	element(submitManufacturer).click();
	// waitSeconds(3);
	waitForElementToDisappear(loader);
	}

	/********************************************************************
	* Description: Add subsystem with count more than 1 Param:
	* Battery,Engine,Engine_model,count Returns: Boolean Status: Completed
	********************************************************************/
	public boolean verifyAddedSubsystem(String subsystem) {
	element(By.xpath("//mat-icon[contains(text(),'chevron_right')]")).click();
	element(By.xpath("//mat-icon[contains(text(),'chevron_right')]")).click();
	By addedsubsystem = By.xpath("//a[contains(text(),'" + subsystem + "')]");
	List<WebElement> l1 = getDriver().findElements(addedsubsystem);
	int s1 = l1.size();
	if (element(By.xpath("//a[contains(text(),'" + subsystem + "')]")).isCurrentlyVisible() && s1 > 1)
	return true;
	else
	return false;
	}

	/********************************************************************
	* Description: Disable the model at the subsystem level Param: model Returns:
	* Void Status: Completed
	********************************************************************/
	public void disableModelAtSubsystem(String model) {
	while (element(By.xpath("//mat-icon[contains(text(),'chevron_right')]")).isCurrentlyVisible()) {
	element(By.xpath("//mat-icon[contains(text(),'chevron_right')]")).click();
	}
	try {
	element(By.xpath("//a[contains(text(),'" + model
	+ "')]/..//span//mat-icon[@class='toggle-icon mat-icon toggle-enable material-icons']")).click();
	} catch (Exception e) {
	System.out.println("Exception handled");
	}
	// waitSeconds(5);
	waitForElementToDisappear(loader);
	}

	/********************************************************************
	* Description: Verify disabled model at subsystem level Param: Model Returns:
	* Void Status: Completed
	********************************************************************/
	public boolean verifyDisabledModel(String model) {
	while (element(By.xpath("//mat-icon[contains(text(),'chevron_right')]")).isCurrentlyVisible()) {
	element(By.xpath("//mat-icon[contains(text(),'chevron_right')]")).click();
	}
	String actToggleStatus = element(By.xpath("//a[contains(text(),'" + model
	+ "')]/..//span//mat-icon[@class='toggle-icon mat-icon toggle-disable material-icons']")).getText();
	String expToggleStatus = "toggle_off";
	String actclassName = element(By.xpath("//a[contains(text(),'" + model + "')]")).getAttribute("class");
	if (actToggleStatus.contains(expToggleStatus) && actclassName.contains("disabled-card"))
	return true;
	else
	return false;
	}

	/********************************************************************
	* Description: Enable the model at the subsystem level Param: model Returns:
	* Void Status: Completed
	********************************************************************/
	public void enableModelAtSubsystem(String model) {
	while (element(By.xpath("//mat-icon[contains(text(),'chevron_right')]")).isCurrentlyVisible()) {
	element(By.xpath("//mat-icon[contains(text(),'chevron_right')]")).click();
	}

	element(By.xpath("//a[contains(text(),'" + model
	+ "')]/..//span//mat-icon[@class='toggle-icon mat-icon toggle-disable material-icons']")).click();

	System.out.println("Exception Handled");
	waitForElementToDisappear(loader);
	// waitSeconds(6);
	}

	/********************************************************************
	* Description: Verify enabled model at subsystem level Param: Model Returns:
	* Void Status: Completed
	********************************************************************/
	public boolean verifyEnabledModel(String model) {
	while (element(By.xpath("//mat-icon[contains(text(),'chevron_right')]")).isCurrentlyVisible()) {
	element(By.xpath("//mat-icon[contains(text(),'chevron_right')]")).click();
	}
	String actToggleStatus = element(By.xpath("//a[contains(text(),'" + model
	+ "')]/..//span//mat-icon[@class='toggle-icon mat-icon toggle-enable material-icons']")).getText();
	String expToggleStatus = "toggle_on";
	if (actToggleStatus.contains(expToggleStatus))
	return true;
	else
	return false;
	}

	/********************************************************************
	* Description: Delete the model at subsystem level Param: Subsystem Returns:
	* Void Status: Completed
	********************************************************************/
	public void deleteSubsystem(String subsystem) {
	while (element(By.xpath("//mat-icon[contains(text(),'chevron_right')]")).isCurrentlyVisible()) {
	element(By.xpath("//mat-icon[contains(text(),'chevron_right')]")).click();
	}
	element(By.xpath("//a[contains(text(),'" + subsystem + "')]/..//mat-icon[contains(text(),'delete')]")).click();
	element(deleteConfirmation).click();
	// waitSeconds(5);
	waitForElementToDisappear(loader);
	}

	/********************************************************************
	* Description: Verify the deleted subsystem Param: Subsystem Returns: Void
	* Status: Completed
	********************************************************************/
	public boolean verifyDeletedSubsystem(String subsystem) {
	while (element(By.xpath("//mat-icon[contains(text(),'chevron_right')]")).isCurrentlyVisible()) {
	element(By.xpath("//mat-icon[contains(text(),'chevron_right')]")).click();
	}
	if (!element(By.xpath("//a[contains(text(),'" + subsystem + "')]")).isCurrentlyVisible())
	return true;
	else
	return false;
	}

	/********************************************************************
	* Description: Select subsystem to view configuration Param: Subsystem Returns:
	* Void Status: Completed
	********************************************************************/
	public void selectSubsystem(String subsystem) {
	while (element(By.xpath("//mat-icon[contains(text(),'chevron_right')]")).isCurrentlyVisible()) {
	element(By.xpath("//mat-icon[contains(text(),'chevron_right')]")).click();
	}
	element(By.xpath("//a[contains(text(),'" + subsystem + "')]")).click();
	// waitSeconds(5);
	waitForElementToDisappear(loader);
	}

	/********************************************************************
	* Description: Verify the configuration page
	* Param: expUrl
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyConfigurationPage(String expUrl)
	{
		String actConfigUrl = getDriver().getCurrentUrl();
		if (actConfigUrl.contains(expUrl) &&
				element(designParameterTab).isCurrentlyVisible()  &&
				element(measurementsTab).isCurrentlyVisible() &&
				element(alarmsTab).isCurrentlyVisible() &&
				element(tripsTab).isCurrentlyVisible() &&
				element(faultsTab).isCurrentlyVisible() &&
				element(functionStatesTab).isCurrentlyVisible() &&
				element(calibrationTab).isCurrentlyVisible() &&
				element(virtualSensorTab).isCurrentlyVisible() &&
				element(physicsEqnTab).isCurrentlyVisible() &&
				element(performanceCurveTable).isCurrentlyVisible() &&
				element(gatewayConfigurationTab).isCurrentlyVisible())
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Add unit for design parameter,Measurement
	* Param: tabname,parameter,metricUnit,usUnit,additive,subtractive,multiplicative,division
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void addUnit(String tabname,String parameter,String metricUnit,String usUnit,String additive,String subtractive,String multiplicative,String division)
	{
		if(tabname.equals("Design Parameters")) {
		}
		else {
			element(By.xpath("//a[text()='"+tabname+"']")).click();
			//waitSeconds(3);
			waitForElementToDisappear(loader);
			//waitForElementToAppear(addNew);
		}
		
		element(addNewButton).click();
		element(selectParameter).click();
		List<WebElement> l1 = getDriver().findElements(dropdownOptions);
		int s1 = l1.size();
		try {
		for(int i=1;i<s1;i++)
		{
			if(l1.get(i).getText().equals(parameter))
			{
				l1.get(i).click();
			}
		}
		}
		catch(StaleElementReferenceException e)
		{
			System.out.println("Exception handled");
		}
		waitSeconds(3);
		try
		{
		element(moreOption).click();
		}
		catch(StaleElementReferenceException e)
		{
			System.out.println("Exception handled");
		}
		//waitSeconds(4);
		waitForElementToDisappear(loader);
		element(addNewButton).click();
		element(metricUnitField).sendKeys(metricUnit);
		element(usUnitField).sendKeys(usUnit);
		element(additiveField).sendKeys(additive);
		element(subtractiveField).sendKeys(subtractive);
		element(multiplicativeField).sendKeys(multiplicative);
		element(divisionField).sendKeys(division);
		element(add).click();
		//waitSeconds(6);
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verify the added unit for the design parameter,Measurement
	* Param: metricUnit,usUnit
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyAddedUnit(String metricUnit, String usUnit)
	{
		if (element(By.xpath("//span[contains(text(),'"+metricUnit+" - "+usUnit+"')]")).isCurrentlyVisible())
		return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Verify the added unit for the design parameter,measurement in the dropdown
	* Param: metricUnit,usUnit,parameter,tabname
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyAddedUnitInDropdown(String tabname,String parameter,String metricUnit)
	{
		waitSeconds(7);
		//waitForElementToDisappear(loader);
		element(configurationTab).click();
		waitForElementToDisappear(loader);
		if(tabname.equals("Design Parameters")) {
		}
		else {
			element(By.xpath("//a[text()='"+tabname+"']")).click();
			//waitSeconds(3);
			waitForElementToDisappear(loader);
			//waitForElementToAppear(addNew);
		}
		element(addNewButton).click();
		element(selectParameter).click();
		List<WebElement> l1 = getDriver().findElements(dropdownOptions);
		int s1 = l1.size();
		try {
		for(int i=1;i<s1;i++)
		{
			if(l1.get(i).getText().equals(parameter))
			{
				l1.get(i).click();
			}
		}
		}
		catch(StaleElementReferenceException e)
		{
			System.out.println("Exception handled");
		}
		waitSeconds(3);
		element(unitDropdown).click();
		List<WebElement> l2 = getDriver().findElements(dropdownOptions);
		int s2 = l2.size();
		boolean result = false;
		try {
		for(int i=1;i<s2;i++)
		{
			if(l2.get(i).getText().equals(metricUnit))
		     return result = true;
		}
		}
		catch(StaleElementReferenceException e)
		{
			System.out.println("Exception Handled");
		}
		return result;
	}
	
	/********************************************************************
	* Description: Add unit for Calibration
	* Param: tabname,parameter,metricUnit,usUnit,additive,subtractive,multiplicative,division
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void addCalibrationUnit(String tabname,String parameter,String metricUnit,String usUnit,String additive,String subtractive,String multiplicative,String division)
	{
		if(tabname.equals("Design Parameters")) {
		}
		else {
			element(By.xpath("//a[text()='"+tabname+"']")).click();
			//waitSeconds(3);
			waitForElementToDisappear(loader);
			//waitForElementToAppear(addNew);
		}
		
		element(addNewButton).click();
		element(By.xpath("//span[contains(text(),'Select Calibration')]")).click();
		List<WebElement> l1 = getDriver().findElements(dropdownOptions);
		int s1 = l1.size();
		try {
		for(int i=1;i<s1;i++)
		{
			if(l1.get(i).getText().equals(parameter))
			{
				l1.get(i).click();
			}
		}
		}
		catch(StaleElementReferenceException e)
		{
			System.out.println("Exception handled");
		}
		waitSeconds(3);
		try
		{
		element(moreOption).click();
		}
		catch(StaleElementReferenceException e)
		{
			System.out.println("Exception handled");
		}
		waitSeconds(4);
		element(addNewButton).click();
		element(metricUnitField).sendKeys(metricUnit);
		element(usUnitField).sendKeys(usUnit);
		element(additiveField).sendKeys(additive);
		element(subtractiveField).sendKeys(subtractive);
		element(multiplicativeField).sendKeys(multiplicative);
		element(divisionField).sendKeys(division);
		element(add).click();
		//waitSeconds(6);
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verify the added unit for the Caibration in the dropdown
	* Param: metricUnit,usUnit,parameter,tabname
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyAddedCalibrationUnitInDropdown(String tabname,String parameter,String metricUnit)
	{
		waitSeconds(7);
		element(configurationTab).click();
		waitForElementToDisappear(loader);
		if(tabname.equals("Design Parameters")) {
		}
		else {
			element(By.xpath("//a[text()='"+tabname+"']")).click();
			//waitSeconds(3);
			waitForElementToDisappear(loader);
			//waitForElementToAppear(addNew);
		}
		element(addNewButton).click();
		element(By.xpath("//span[contains(text(),'Select Calibration')]")).click();
		List<WebElement> l1 = getDriver().findElements(dropdownOptions);
		int s1 = l1.size();
		try {
		for(int i=1;i<s1;i++)
		{
			if(l1.get(i).getText().equals(parameter))
			{
				l1.get(i).click();
			}
		}
		}
		catch(StaleElementReferenceException e)
		{
			System.out.println("Exception handled");
		}
		waitSeconds(3);
		element(unitDropdown).click();
		List<WebElement> l2 = getDriver().findElements(dropdownOptions);
		int s2 = l2.size();
		boolean result = false;
		try {
		for(int i=1;i<s2;i++)
		{
			if(l2.get(i).getText().equals(metricUnit))
		     return result = true;
		}
		}
		catch(StaleElementReferenceException e)
		{
			System.out.println("Exception Handled");
		}
		return result;
	}
	
	/********************************************************************
	* Description: Disable the unit for deisgn parameter,measurement
	* Param: tabname,parameter,unit
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public void disableUnit(String tabname,String parameter,String unit)
	{
		if(tabname.equals("Design Parameters")) {
		}
		else {
			element(By.xpath("//a[text()='"+tabname+"']")).click();
			//waitSeconds(3);
			waitForElementToDisappear(loader);
		}
		
		element(addNewButton).click();
		element(selectParameter).click();
		List<WebElement> l1 = getDriver().findElements(dropdownOptions);
		int s1 = l1.size();
		try {
		for(int i=1;i<s1;i++)
		{
			if(l1.get(i).getText().equals(parameter))
			{
				l1.get(i).click();
			}
		}
		}
		catch(StaleElementReferenceException e)
		{
			System.out.println("Exception handled");
		}
		waitSeconds(3);
		try
		{
		element(moreOption).click();
		}
		catch(StaleElementReferenceException e)
		{
			System.out.println("Exception handled");
		}
		waitSeconds(4);
	    By disableElement = By.xpath("//span[contains(text(),'"+unit+"')]/..//div[@class='mat-slide-toggle-thumb-container']");
		Actions act = new Actions(getDriver());
		act.moveToElement(element(disableElement)).click().perform();
		//element(By.xpath("//span[contains(text(),'"+unit+"')]/..//div[@class='mat-slide-toggle-bar']")).click();
		//waitSeconds(5);
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verify the disabled the unit for design parameter,measurement
	* Param: tabname,parameter,unit
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyEnabledUnit(String tabname, String parameter,String metricunit)
	{
		waitSeconds(7);
		element(configurationTab).click();
		//waitSeconds(5);
		waitForElementToDisappear(loader);
		if(tabname.equals("Design Parameters")) {
		}
		else {
			element(By.xpath("//a[text()='"+tabname+"']")).click();
			waitForElementToDisappear(loader);
			//waitForElementToAppear(addNew);
		}
		element(addNewButton).click();
		element(selectParameter).click();
		List<WebElement> l1 = getDriver().findElements(dropdownOptions);
		int s1 = l1.size();
		try {
		for(int i=1;i<s1;i++)
		{
			if(l1.get(i).getText().equals(parameter))
			{
				l1.get(i).click();
			}
		}
		}
		catch(StaleElementReferenceException e)
		{
			System.out.println("Exception handled");
		}
		waitSeconds(3);
		try {
		element(unitDropdown).click();
		}
		catch(StaleElementReferenceException e)
		{
			System.out.println("Exception handled");
		}
		List<WebElement> l2 = getDriver().findElements(dropdownOptions);
		int s2 = l2.size();
		boolean result = false;
		try {
		for(int i=1;i<s2;i++)
		{
			System.out.println(l2.get(i).getText());
			if(l2.get(i).getText().equals(metricunit))
		     return result = true;
		}
		}
		catch(StaleElementReferenceException e)
		{
			System.out.println("Exception Handled");
		}
		return result;
	}
	
	/********************************************************************
	* Description: Disable the unit for Calibration
	* Param: tabname,parameter,unit
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public void disableUnitForCalibration(String tabname,String parameter,String unit)
	{
		if(tabname.equals("Design Parameters")) {
		}
		else {
			element(By.xpath("//a[text()='"+tabname+"']")).click();
			//waitSeconds(3);
			waitForElementToDisappear(loader);
		}
		
		element(addNewButton).click();
		element(By.xpath("//span[contains(text(),'Select Calibration')]")).click();
		List<WebElement> l1 = getDriver().findElements(dropdownOptions);
		int s1 = l1.size();
		try {
		for(int i=1;i<s1;i++)
		{
			if(l1.get(i).getText().equals(parameter))
			{
				l1.get(i).click();
			}
		}
		}
		catch(StaleElementReferenceException e)
		{
			System.out.println("Exception handled");
		}
		waitSeconds(3);
		try
		{
		element(moreOption).click();
		}
		catch(StaleElementReferenceException e)
		{
			System.out.println("Exception handled");
		}
		waitSeconds(4);
		element(By.xpath("//span[contains(text(),'"+unit+"')]/..//div[@class='mat-slide-toggle-bar']")).click();
		//waitSeconds(5);
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verify the disabled unit for the Calibration 
	* Param: metricUnit,parameter,tabname
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyEnabledUnitInDropdownForCalibration(String tabname,String parameter,String metricUnit)
	{
		waitSeconds(7);
		element(configurationTab).click();
		//waitSeconds(5);
		waitForElementToDisappear(loader);
		if(tabname.equals("Design Parameters")) {
		}
		else {
			element(By.xpath("//a[text()='"+tabname+"']")).click();
			//waitSeconds(3);
			waitForElementToDisappear(loader);
		}
		element(addNewButton).click();
		element(By.xpath("//span[contains(text(),'Select Calibration')]")).click();
		List<WebElement> l1 = getDriver().findElements(dropdownOptions);
		int s1 = l1.size();
		try {
		for(int i=1;i<s1;i++)
		{
			if(l1.get(i).getText().equals(parameter))
			{
				l1.get(i).click();
			}
		}
		}
		catch(StaleElementReferenceException e)
		{
			System.out.println("Exception handled");
		}
		waitSeconds(3);
		element(unitDropdown).click();
		List<WebElement> l2 = getDriver().findElements(dropdownOptions);
		int s2 = l2.size();
		boolean result = false;
		try {
		for(int i=1;i<s2;i++)
		{
			if(l2.get(i).getText().equals(metricUnit))
		     return result = true;
		}
		}
		catch(StaleElementReferenceException e)
		{
			System.out.println("Exception Handled");
		}
		return result;
	}
	
	/********************************************************************
	* Description: Delete the unit for Designparameter,Measurement
	* Param: tabname,parameter,unit
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public void deleteUnit(String tabname,String parameter,String unit)
	{
		if(tabname.equals("Design Parameters")) {
		}
		else {
			element(By.xpath("//a[text()='"+tabname+"']")).click();
			//waitSeconds(3);
			waitForElementToDisappear(loader);
		}
		
		element(addNewButton).click();
		element(selectParameter).click();
		List<WebElement> l1 = getDriver().findElements(dropdownOptions);
		int s1 = l1.size();
		try {
		for(int i=1;i<s1;i++)
		{
			if(l1.get(i).getText().equals(parameter))
			{
				l1.get(i).click();
				break;
			}
		}
		}
		catch(StaleElementReferenceException e)
		{
			System.out.println("Exception handled");
		}
		waitSeconds(3);
		try
		{
		element(moreOption).click();
		}
		catch(StaleElementReferenceException e)
		{
			System.out.println("Exception handled");
		}
		waitSeconds(4);
		element(By.xpath("//span[contains(text(),'"+unit+"')]/../..//mat-icon[contains(text(),'delete')]")).click();
		element(deleteConfirmation).click();
		//waitSeconds(3);
		waitForElementToDisappear(loader);
	}
	

	/********************************************************************
	* Description: Verify deleted unit in the list
	* Param: unit
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyDeletedUnit(String unit)
	{
		if (element(By.xpath("//span[contains(text(),'"+unit+"')]")).isCurrentlyVisible()) 
		return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Delete the unit for Calibration
	* Param: tabname,parameter,unit
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public void deleteUnitForCalibration(String tabname,String parameter,String unit)
	{
		if(tabname.equals("Design Parameters")) {
		}
		else {
			element(By.xpath("//a[text()='"+tabname+"']")).click();
			//waitSeconds(3);
			waitForElementToDisappear(loader);
		}
		
		element(addNewButton).click();
		element(By.xpath("//span[contains(text(),'Select Calibration')]")).click();
		List<WebElement> l1 = getDriver().findElements(dropdownOptions);
		int s1 = l1.size();
		try {
		for(int i=1;i<s1;i++)
		{
			if(l1.get(i).getText().equals(parameter))
			{
				l1.get(i).click();
			}
		}
		}
		catch(StaleElementReferenceException e)
		{
			System.out.println("Exception handled");
		}
		waitSeconds(3);
		try
		{
		element(moreOption).click();
		}
		catch(StaleElementReferenceException e)
		{
			System.out.println("Exception handled");
		}
		waitSeconds(4);
		element(By.xpath("//span[contains(text(),'"+unit+"')]/../..//mat-icon[contains(text(),'delete')]")).click();
		element(deleteConfirmation).click();
		//waitSeconds(3);
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Add parameter
	* Param: tabname,paramaterName,parameterValue,parameter,sysUnit,unit
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void addDesignParamater(String tabname,String paramaterName,String parameterValue,String parameter,String sysUnit,String unit)
	{
		if(tabname.equals("Design Parameters")) {
		}
		else {
			element(By.xpath("//a[text()='"+tabname+"']")).click();
			//waitSeconds(3);
			waitForElementToDisappear(loader);
		}
		element(addNewButton).click();
		element(parameterNameField).sendKeys(paramaterName);
		element(parameterValueField).sendKeys(parameterValue);
		element(designparameterDropdown).click();
		List<WebElement> l1 = getDriver().findElements(dropdownOptions);
		int s1 = l1.size();
		try {
		for(int i=1;i<s1;i++)
		{
			if(l1.get(i).getText().contains(parameter))
			{
				l1.get(i).click();
			}
		}
		}
		catch(StaleElementReferenceException e)
		{
			System.out.println("Exception handled");
		}
		
		waitSeconds(4);
		Actions act = new Actions(getDriver());
		act.click(element(sysytemUnit)).build().perform();
		List<WebElement> l2 = getDriver().findElements(dropdownOptions);
		int s2 = l2.size();
		for(int i=1;i<s2;i++)
		{
			if(l2.get(i).getText().contains(sysUnit))
			{
				l2.get(i).click();
			}
		}
		
		waitSeconds(4);
		Actions act1 = new Actions(getDriver());
		act1.click(element(unitdropdown)).build().perform();
		List<WebElement> l3 = getDriver().findElements(dropdownOptions);
		int s3 = l3.size();
		for(int i=1;i<s3;i++)
		{
			if(l3.get(i).getText().contains(unit))
			{
				l3.get(i).click();
			}
		}
		element(add).click();
		//waitSeconds(5);
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verify added parameter
	* Param: tabname,paramaterName,parameterValue,parameter,sysUnit,unit
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyAddedParameter(String paramaterName)
	{
		List<WebElement> l1 = getDriver().findElements(By.xpath("//mat-row"));
		int s1 = l1.size();
		if(s1>=1 && 
				element(By.xpath("//span[contains(text(),'"+paramaterName+"')]")).isCurrentlyVisible())
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Add measurement parameter
	* Param: tabname,parameter,sysUnit,unit,parameterName
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void addMeasurementParamater(String tabname,String parameterName,String parameter,String sysUnit,String unit)
	{
		if(tabname.equals("Design Parameters")) {
		}
		else {
			element(By.xpath("//a[text()='"+tabname+"']")).click();
			waitSeconds(3);
		}
		element(addNewButton).click();
		element(parameterNameField).sendKeys(parameterName);
		element(designparameterDropdown).click();
		List<WebElement> l1 = getDriver().findElements(dropdownOptions);
		int s1 = l1.size();
		try {
		for(int i=1;i<s1;i++)
		{
			if(l1.get(i).getText().contains(parameter))
			{
				l1.get(i).click();
			}
		}
		}
		catch(StaleElementReferenceException e)
		{
			System.out.println("Exception handled");
		}
		
		waitSeconds(4);
		Actions act = new Actions(getDriver());
		act.click(element(sysytemUnit)).build().perform();
		List<WebElement> l2 = getDriver().findElements(dropdownOptions);
		int s2 = l2.size();
		for(int i=1;i<s2;i++)
		{
			if(l2.get(i).getText().contains(sysUnit))
			{
				l2.get(i).click();
			}
		}
		
		waitSeconds(4);
		Actions act1 = new Actions(getDriver());
		act1.click(element(unitdropdown)).build().perform();
		List<WebElement> l3 = getDriver().findElements(dropdownOptions);
		int s3 = l3.size();
		for(int i=1;i<s3;i++)
		{
			if(l3.get(i).getText().contains(unit))
			{
				l3.get(i).click();
				break;
			}
		}
		element(add).click();
		waitSeconds(5);
	}
	
	/********************************************************************
	* Description: Add alarms,trips,faults,function states parameter
	* Param: tabname,parameter,sysUnit,unit,parameterName
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void addParameter(String tabname,String parameterName,String selectParmeter)
	{
		if(tabname.equals("Design Parameters")) {
		}
		else {
			element(By.xpath("//a[text()='"+tabname+"']")).click();
			waitSeconds(3);
		}
		element(addNewButton).click();
		element(parameterNameField).sendKeys(parameterName);
		element(parameterDropdown).click();
		List<WebElement> l1 = getDriver().findElements(dropdownOptions);
		int s1 = l1.size();
		try {
		for(int i=1;i<s1;i++)
		{
			if(l1.get(i).getText().contains(selectParmeter)) {
				l1.get(i).click();
			}
		}
		}
		catch(StaleElementReferenceException e)
		{
			System.out.println("Exception handled");
		}
		
		element(add).click();
		waitSeconds(4);
	}
	
	/********************************************************************
	* Description: Add Calibration
	* Param: tabname,parameter,sysUnit,unit,parameterName
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void addCalibrationParamater(String tabname,String parameterName,String parameter,String sysUnit,String unit)
	{
		if(tabname.equals("Design Parameters")) {
		}
		else {
			element(By.xpath("//a[text()='"+tabname+"']")).click();
			waitSeconds(3);
		}
		element(addNewButton).click();
		element(parameterNameField).sendKeys(parameterName);
		element(By.xpath("//span[contains(text(),'Select Calibration')]")).click();
		List<WebElement> l1 = getDriver().findElements(dropdownOptions);
		int s1 = l1.size();
		try {
		for(int i=1;i<s1;i++)
		{
			if(l1.get(i).getText().contains(parameter))
			{
				l1.get(i).click();
			}
		}
		}
		catch(StaleElementReferenceException e)
		{
			System.out.println("Exception handled");
		}
		
		waitSeconds(4);
		Actions act = new Actions(getDriver());
		act.click(element(sysytemUnit)).build().perform();
		List<WebElement> l2 = getDriver().findElements(dropdownOptions);
		int s2 = l2.size();
		for(int i=1;i<s2;i++)
		{
			if(l2.get(i).getText().contains(sysUnit))
			{
				l2.get(i).click();
			}
		}
		
		waitSeconds(4);
		Actions act1 = new Actions(getDriver());
		act1.click(element(unitdropdown)).build().perform();
		List<WebElement> l3 = getDriver().findElements(dropdownOptions);
		int s3 = l3.size();
		try
		{
		for(int i=1;i<s3;i++)
		{
			if(l3.get(i).getText().contains(unit))
			{
				l3.get(i).click();
			}
		}
		}
		catch(StaleElementReferenceException e)
		{
			System.out.println("Exception handled");
		}
		element(add).click();
		waitSeconds(5);
	}
	
	/********************************************************************
	* Description: Disable the parameter
	* Param: tabname,parameterName
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void disableParameter(String tabname, String parameterName)
	{
		if(tabname.equals("Design Parameters")) {
		}
		else {
			element(By.xpath("//a[text()='"+tabname+"']")).click();
			//waitSeconds(3);
			waitForElementToDisappear(loader);
		}
		Actions act = new Actions(getDriver());
		act.moveToElement(element(By.xpath("//span[contains(text(),'"+parameterName+"')]/../..//div[@class='mat-slide-toggle-bar mat-slide-toggle-bar-no-side-margin']")))
	    .click().build().perform();
	    //waitSeconds(5);
	    waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verify Disabled the parameter
	* Param: parameterName
	* Returns: void
	* Status: Completed
	********************************************************************/
	public boolean verifyDisabledParameter(String parameterName)
	{
		String expClass = "mat-slide-toggle mat-primary";
		String actClass = element(By.xpath("//span[contains(text(),'"+parameterName+"')]/../..//mat-slide-toggle")).getAttribute("class");
		if (actClass.equals(expClass))
			return true;
		return false;
	}
	
	/********************************************************************
	* Description: Verify Enabled the parameter
	* Param:parameterName
	* Returns: void
	* Status: Completed
	********************************************************************/
	public boolean verifyEnabledParameter(String parameterName)
	{
		String expClass = "mat-slide-toggle mat-primary mat-checked";
		String actClass = element(By.xpath("//span[contains(text(),'"+parameterName+"')]/../..//mat-slide-toggle")).getAttribute("class");
		if (actClass.equals(expClass))
			return true;
		return false;
	}
	
	/********************************************************************
	* Description: Delete the added parameter
	* Param: tabname,parameterName
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void deleteParameter(String tabname, String parameterName)
	{
		if(tabname.equals("Design Parameters")) {
		}
		else {
			element(By.xpath("//a[text()='"+tabname+"']")).click();
			waitForElementToDisappear(loader);
		}
		element("//span[contains(text(),'"+parameterName+"')]/../..//mat-icon[contains(text(),'delete')]").click();
		element(deleteConfirmation).click();
		waitForElementToDisappear(loader);
		waitSeconds(2);
	}
	
	/********************************************************************
	* Description: Delete the added parameter
	* Param: parameterName
	* Returns: void
	* Status: Completed
	********************************************************************/
	public boolean verifyDeletedParameter(String parameterName)
	{
		if(element(By.xpath("//span[contains(text(),'"+parameterName+"')]")).isCurrentlyVisible())
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Select gateway configuration
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void selectGatewayConfiguration()
	{
		element(gatewayConfiguration).click();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verify gateway configuration
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyGatewayConfiguration()
	{
		if(element(By.xpath("//mat-card[@class='eqn-card mat-card']")).isCurrentlyVisible())
		return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Select a gateway
	* Param: Gateway
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void selectAGateway(String Gateway)
	{
		element(By.xpath("//mat-list[@class='mat-list mat-list-base ng-star-inserted']//a[contains(text(),'"+Gateway+"')]")).click();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Add tags for the parameter
	* Param: measurementParameter,measurementTag,alarmParameter,alarmTag,tripParameter,tripTag,faultParameter,
	*        faultTag,functionStateParameter,functionStateTag,calibrationParameter,calibrationTag
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void addtagsForParameter(String measurementParameter,String measurementTag,String alarmParameter,String alarmTag,String tripParameter,String tripTag,String faultParameter,String faultTag,String functionStateParameter,String functionStateTag,String calibrationParameter, String calibrationTag)
	{
		if(element(By.xpath("//mat-panel-title[contains(text(),'Measurement')]")).isCurrentlyVisible())
		{
			element(By.xpath("//mat-panel-title[contains(text(),'Measurement')]")).click();
			element(By.xpath("//label[contains(text(),'"+measurementParameter+"')]/..//input")).sendKeys(measurementTag);
			element(By.xpath("//mat-panel-title[contains(text(),'Measurement')]/../../..//span[text()='Save']")).click();
			waitForElementToDisappear(loader);
		}
		
		if(element(By.xpath("//mat-panel-title[contains(text(),'Alarm')]")).isCurrentlyVisible())
		{
			element(By.xpath("//mat-panel-title[contains(text(),'Alarm')]")).click();
			element(By.xpath("//label[contains(text(),'"+alarmParameter+"')]/..//input")).sendKeys(alarmTag);
			element(By.xpath("//mat-panel-title[contains(text(),'Alarm')]/../../..//span[text()='Save']")).click();
			waitForElementToDisappear(loader);
		}
		
		if(element(By.xpath("//mat-panel-title[contains(text(),'Trip')]")).isCurrentlyVisible())
		{
			element(By.xpath("//mat-panel-title[contains(text(),'Trip')]")).click();
			element(By.xpath("//label[contains(text(),'"+tripParameter+"')]/..//input")).sendKeys(tripTag);
			element(By.xpath("//mat-panel-title[contains(text(),'Trip')]/../../..//span[text()='Save']")).click();
			waitForElementToDisappear(loader);
		}
		
		if(element(By.xpath("//mat-panel-title[contains(text(),'Fault')]")).isCurrentlyVisible())
		{
			element(By.xpath("//mat-panel-title[contains(text(),'Fault')]")).click();
			element(By.xpath("//label[contains(text(),'"+faultParameter+"')]/..//input")).sendKeys(faultTag);
			element(By.xpath("//mat-panel-title[contains(text(),'Fault')]/../../..//span[text()='Save']")).click();
			waitForElementToDisappear(loader);
		}
		
		if(element(By.xpath("//mat-panel-title[contains(text(),'Function State')]")).isCurrentlyVisible())
		{
			element(By.xpath("//mat-panel-title[contains(text(),'Function State')]")).click();
			element(By.xpath("//label[contains(text(),'"+functionStateParameter+"')]/..//input")).sendKeys(functionStateTag);
			element(By.xpath("//mat-panel-title[contains(text(),'Function State')]/../../..//span[text()='Save']")).click();
			waitForElementToDisappear(loader);
		}
		
		if(element(By.xpath("//mat-panel-title[contains(text(),'Calibration')]")).isCurrentlyVisible())
		{
			element(By.xpath("//mat-panel-title[contains(text(),'Calibration')]")).click();
			element(By.xpath("//label[contains(text(),'"+calibrationParameter+"')]/..//input")).sendKeys(calibrationTag);
			element(By.xpath("//mat-panel-title[contains(text(),'Calibration')]/../../..//span[text()='Save']")).click();
			waitForElementToDisappear(loader);
		}
	}
	
	/********************************************************************
	* Description: Edit tags for the parameter
	* Param: measurementParameter,measurementTag,alarmParameter,alarmTag,tripParameter,tripTag,faultParameter,
	*        faultTag,functionStateParameter,functionStateTag,calibrationParameter,calibrationTag
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void editTags(String measurementParameter, String updateMeasurementTag,String alarmParameter,String updateAlarmTag,String tripParameter,String updateTripTag ,String faultParameter,String updateFaultTag,String functionStateParameter,String updateFunctionStateTag,String calibrationParameter,String updateCalibrationTag  )
	{
		if(element(By.xpath("//mat-panel-title[contains(text(),'Measurement')]")).isCurrentlyVisible())
		{
			element(By.xpath("//mat-panel-title[contains(text(),'Measurement')]")).click();
			element(By.xpath("//label[contains(text(),'"+measurementParameter+"')]/..//input")).clear();
			element(By.xpath("//label[contains(text(),'"+measurementParameter+"')]/..//input")).sendKeys(updateMeasurementTag);
			element(By.xpath("//mat-panel-title[contains(text(),'Measurement')]/../../..//span[text()='Save']")).click();
			waitForElementToDisappear(loader);
		}
		
		if(element(By.xpath("//mat-panel-title[contains(text(),'Alarm')]")).isCurrentlyVisible())
		{
			element(By.xpath("//mat-panel-title[contains(text(),'Alarm')]")).click();
			element(By.xpath("//label[contains(text(),'"+alarmParameter+"')]/..//input")).clear();
			element(By.xpath("//label[contains(text(),'"+alarmParameter+"')]/..//input")).sendKeys(updateAlarmTag);
			element(By.xpath("//mat-panel-title[contains(text(),'Alarm')]/../../..//span[text()='Save']")).click();
			waitForElementToDisappear(loader);
		}
		
		if(element(By.xpath("//mat-panel-title[contains(text(),'Trip')]")).isCurrentlyVisible())
		{
			element(By.xpath("//mat-panel-title[contains(text(),'Trip')]")).click();
			element(By.xpath("//label[contains(text(),'"+tripParameter+"')]/..//input")).clear();
			element(By.xpath("//label[contains(text(),'"+tripParameter+"')]/..//input")).sendKeys(updateTripTag);
			element(By.xpath("//mat-panel-title[contains(text(),'Trip')]/../../..//span[text()='Save']")).click();
			waitForElementToDisappear(loader);
		}
		
		if(element(By.xpath("//mat-panel-title[contains(text(),'Fault')]")).isCurrentlyVisible())
		{
			element(By.xpath("//mat-panel-title[contains(text(),'Fault')]")).click();
			element(By.xpath("//label[contains(text(),'"+faultParameter+"')]/..//input")).clear();
			element(By.xpath("//label[contains(text(),'"+faultParameter+"')]/..//input")).sendKeys(updateFaultTag);
			element(By.xpath("//mat-panel-title[contains(text(),'Fault')]/../../..//span[text()='Save']")).click();
			waitForElementToDisappear(loader);
		}
		
		if(element(By.xpath("//mat-panel-title[contains(text(),'Function State')]")).isCurrentlyVisible())
		{
			element(By.xpath("//mat-panel-title[contains(text(),'Function State')]")).click();
			element(By.xpath("//label[contains(text(),'"+functionStateParameter+"')]/..//input")).clear();
			element(By.xpath("//label[contains(text(),'"+functionStateParameter+"')]/..//input")).sendKeys(updateFunctionStateTag);
			element(By.xpath("//mat-panel-title[contains(text(),'Function State')]/../../..//span[text()='Save']")).click();
			waitForElementToDisappear(loader);
		}
		
		if(element(By.xpath("//mat-panel-title[contains(text(),'Calibration')]")).isCurrentlyVisible())
		{
			element(By.xpath("//mat-panel-title[contains(text(),'Calibration')]")).click();
			element(By.xpath("//label[contains(text(),'"+calibrationParameter+"')]/..//input")).clear();
			element(By.xpath("//label[contains(text(),'"+calibrationParameter+"')]/..//input")).sendKeys(updateCalibrationTag);
			element(By.xpath("//mat-panel-title[contains(text(),'Calibration')]/../../..//span[text()='Save']")).click();
			waitForElementToDisappear(loader);
		}
	}
	
	/********************************************************************
	* Description: Edit parameter
	* Param: measurementParameter,measurementTag,alarmParameter,alarmTag,tripParameter,tripTag,faultParameter,
	*        faultTag,functionStateParameter,functionStateTag,calibrationParameter,calibrationTag
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void editParameter(String tabname,String parameterNameToEdit, String updateParameterName,String updateParameterValue,String unitType,String unit,String LCLvalue, String UCLvalue, String minRange,String maxRange,String priorityFlag,String visibilityFlag,String aggregator,String severity,String tagId,String relatedMeasurement,String recommendationMessage)
	{
		if(tabname.equals("Design Parameters")) {
		}
		else {
			element(By.xpath("//a[text()='"+tabname+"']")).click();
			waitForElementToDisappear(loader);
		}
		
		element(By.xpath("//span[contains(text(),'"+parameterNameToEdit+"')]/../..//mat-icon[contains(text(),'mode_edit')]")).click();
		waitForElementToDisappear(loader);
		element(parameterNameEditField).clear();
		element(parameterNameEditField).sendKeys(updateParameterName);
		waitSeconds(2);
		if(element(parameterValueEditField).isCurrentlyVisible())
		{
		element(parameterValueEditField).clear();
		element(parameterValueEditField).sendKeys(updateParameterValue);
		}
		
		if(element(By.xpath("(//mat-select[@aria-label='Select Unit Type'])[1]")).isCurrentlyVisible())
		{
			try {
			element(By.xpath("(//mat-select[@aria-label='Select Unit Type'])[1]")).click();
			List<WebElement> l1 = getDriver().findElements(By.xpath("//div//mat-option//span"));
			for(int i=0;i<l1.size();i++)
			{
				if(l1.get(i).getText().equals(unitType))
				{
					l1.get(i).click();
					waitForElementToDisappear(loader);
					break;
				}
			}
			}
			catch(Exception e)
			{
				System.out.println("Exception Found");
			}
		}
		
		if(element(By.xpath("(//mat-select[@aria-label='Select Unit Type'])[2]")).isCurrentlyVisible())
		{
			try {
			element(By.xpath("(//mat-select[@aria-label='Select Unit Type'])[2]")).click();
			List<WebElement> l2 = getDriver().findElements(By.xpath("//div//mat-option//span"));
			for(int i=0;i<l2.size();i++)
			{
				if(l2.get(i).getText().equals(unitType))
				{
					l2.get(i).click();
					waitForElementToDisappear(loader);
					break;
				}
			}
			}
			catch(Exception e)
			{
				System.out.println("Exception Found");
			}
		}
		waitSeconds(3);
		if(element(By.xpath("(//mat-select[@aria-label='Select Unit of Measurement'])[1]")).isCurrentlyVisible())
		{
			try {
			element(By.xpath("(//mat-select[@aria-label='Select Unit of Measurement'])[1]")).click();
			List<WebElement> l3 = getDriver().findElements(By.xpath("//div//mat-option//span"));
			for(int i=0;i<l3.size();i++)
			{
				if(l3.get(i).getText().equals(unitType))
				{
					l3.get(i).click();
					waitForElementToDisappear(loader);
					break;
				}
			}
			}
			catch(Exception e)
			{
				System.out.println("Exception Found");
			}
		}
		
		if(element(By.xpath("(//mat-select[@aria-label='Select Unit of Measurement'])[2]")).isCurrentlyVisible())
		{
			//try {
			element(By.xpath("(//mat-select[@aria-label='Select Unit of Measurement'])[2]")).click();
			List<WebElement> l4 = getDriver().findElements(By.xpath("//div//mat-option//span"));
			for(int i=0;i<l4.size();i++)
			{
				if(l4.get(i).getText().equals(unitType))
				{
					l4.get(i).click();
					waitForElementToDisappear(loader);
					break;
				}
			}
//			}
//			catch(Exception e)
//			{
//				System.out.println("Exception Found");
//			}
		}
		waitSeconds(3);
		if(element(By.xpath("//input[@placeholder='Enter LCL']")).isCurrentlyVisible())
		{
				element(By.xpath("//input[@placeholder='Enter LCL']")).clear();
				element(By.xpath("//input[@placeholder='Enter LCL']")).sendKeys(LCLvalue);
		}
		
		if(element(By.xpath("//input[@placeholder='Enter UCL']")).isCurrentlyVisible())
		{
			element(By.xpath("//input[@placeholder='Enter UCL']")).clear();
			element(By.xpath("//input[@placeholder='Enter UCL']")).sendKeys(UCLvalue);
		}
		
		if(element(By.xpath("//input[@placeholder='Enter Signal Range(Min)']")).isCurrentlyVisible())
		{
			element(By.xpath("//input[@placeholder='Enter Signal Range(Min)']")).clear();
			element(By.xpath("//input[@placeholder='Enter Signal Range(Min)']")).sendKeys(minRange);
		}
		
		if(element(By.xpath("//input[@placeholder='Enter Signal Range(Max)']")).isCurrentlyVisible())
		{
		element(By.xpath("//input[@placeholder='Enter Signal Range(Max)']")).clear();
		element(By.xpath("//input[@placeholder='Enter Signal Range(Max)']")).sendKeys(maxRange);
		}
		
		if(element(By.xpath("//input[@placeholder='Enter Name']/../../../../../../..//input[@type='checkbox' and @name='priority_flag']")).isCurrentlyVisible())
		{
			String actStatus = element(By.xpath("//input[@placeholder='Enter Name']/../../../../../../..//input[@type='checkbox' and @name='priority_flag']")).getAttribute("aria-checked");
			System.out.println("Status1"+actStatus);
			if(actStatus.equals("false") && priorityFlag.equals("ON"))
			{
				System.out.println("Click oper1");
				Actions act = new Actions(getDriver());
				act.moveToElement(element(By.xpath("//input[@placeholder='Enter Name']/../../../../../../..//input[@type='checkbox' and @name='priority_flag']/.."))).doubleClick().build().perform();
				waitForElementToDisappear(loader);
			    //element(By.xpath("//input[@placeholder='Enter Name']/../../../../../../..//input[@type='checkbox' and @name='priority_flag']/..")).click();
			}
			else if(actStatus.equals("true") && priorityFlag.equals("OFF"))
			{
				System.out.println("Status1again"+actStatus);
				System.out.println("Click oper1");
				Actions act = new Actions(getDriver());
				act.moveToElement(element(By.xpath("//input[@placeholder='Enter Name']/../../../../../../..//input[@type='checkbox' and @name='priority_flag']/.."))).click().build().perform();
				waitForElementToDisappear(loader);
			}
		}
		
		if(element(By.xpath("//input[@placeholder='Enter Name']/../../../../../../..//input[@type='checkbox' and @name='visible_flag']")).isCurrentlyVisible())
		{
			String actVisibilty = element(By.xpath("//input[@placeholder='Enter Name']/../../../../../../..//input[@type='checkbox' and @name='visible_flag']")).getAttribute("aria-checked");
			System.out.println("Status2"+actVisibilty);
			if(actVisibilty.equals("false") && visibilityFlag.equals("ON"))
			{
				System.out.println("Click oper2");
				Actions act = new Actions(getDriver());
				act.moveToElement(element(By.xpath("//input[@placeholder='Enter Name']/../../../../../../..//input[@type='checkbox' and @name='visible_flag']/.."))).click().build().perform();
				waitForElementToDisappear(loader);
			}
			else if(actVisibilty.equals("true") && visibilityFlag.equals("OFF"))
			{
				System.out.println("Click oper2");
				System.out.println("Status2again"+actVisibilty);
				Actions act = new Actions(getDriver());
				act.moveToElement(element(By.xpath("//input[@placeholder='Enter Name']/../../../../../../..//input[@type='checkbox' and @name='visible_flag']/.."))).click().build().perform();
				waitForElementToDisappear(loader);
			}
		}
		
		if(element(By.xpath("//mat-select[@aria-label='Select Aggregator']//div[@class='mat-select-value']")).isCurrentlyVisible())
		{
			Actions act = new Actions(getDriver());
			act.moveToElement(element(By.xpath("//mat-select[@aria-label='Select Aggregator']//div[@class='mat-select-value']"))).click().perform();
			//element(By.xpath("//mat-select[@aria-label='Select Aggregator']//div[@class='mat-select-value']")).click();
			List<WebElement> l5 = getDriver().findElements(By.xpath("//div//mat-option//span"));
			int s3 = l5.size();
			for(int i=1;i<s3;i++)
			{
				if(l5.get(i).getText().equals(aggregator))
				{
					l5.get(i).click();
					break;
				}
			}
		}
		waitSeconds(3);
		if(element(relatedMeasurementField).isCurrentlyVisible())
		{
			//getJavascriptExecutor().executeScript("document.querySelectorAll('.mat-select-value')[1].click();");
			element(relatedMeasurementField).click();
          waitSeconds(3);
			List<WebElement> l6 = getDriver().findElements(By.xpath("//div//mat-option//span"));
			for(int j=0;j<l6.size();j++)
			{
				if(l6.get(j).getText().equals(relatedMeasurement)) l6.get(j).click();
				//break;
			}
		}
		waitSeconds(3);
		element(By.xpath("//html")).click();
		
		
		if(element(severityField).isCurrentlyVisible())
		{
			getJavascriptExecutor().executeScript("document.querySelector('.mat-select-value').click();");
		waitSeconds(2);
		
		List<WebElement> l7 = getDriver().findElements(By.xpath("//div//mat-option//span"));
		int s1= l7.size();
			for(int i=0;i<s1;i++)
			{
				if(l7.get(i).getText().equals(severity))
				{
				l7.get(i).click();
				break;
				}
			}	
		}
		waitSeconds(3);
		element(By.xpath("//html")).click();
		
		if(element(By.xpath("//input[@placeholder='Enter Tag Id']")).isCurrentlyVisible())
		{
			element(By.xpath("//input[@placeholder='Enter Tag Id']")).clear();
			element(By.xpath("//input[@placeholder='Enter Tag Id']")).sendKeys(tagId);
		}
		waitSeconds(3);
		
		
		if(element(recommendation).isCurrentlyVisible())
		{
		element(recommendation).clear();
		element(recommendation).sendKeys(recommendationMessage);
		}
		waitSeconds(5);
		element(By.xpath("//mat-icon[contains(text(),'done')]")).click();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verify edited design parameter
	* Param: updatedParameterName,updatedValue,updatedUnit
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyEditedDesignParameter(String updatedParameterName,String updatedValue,String updatedUnit)
	{
		if(element(By.xpath("//span[contains(text(),'"+updatedParameterName+"')]")).isCurrentlyVisible() &&
				element(By.xpath("//span[contains(text(),'"+updatedValue+"')]")).isCurrentlyVisible() &&
				element(By.xpath("//span[contains(text(),'"+updatedUnit+"')]")).isCurrentlyVisible())
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Verify edited measurement parameter
	* Param: updatedParameterName,updatedValue,updatedUnit
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyEditedMeasurementParameter(String updatedParameterName,String updatedUnit,String LCLValue,String UCLValue,String minRange,String maxRange,String priorityFlag,String visibilityFlag,String aggregator)
	{
		boolean result1 = false;
		if(element(By.xpath("//span[contains(text(),'"+updatedParameterName+"')]")).isCurrentlyVisible() &&
				element(By.xpath("//span[contains(text(),'"+updatedUnit+"')]")).isCurrentlyVisible() &&
				element(By.xpath("//span[contains(text(),'"+LCLValue+"')]")).isCurrentlyVisible() &&
				element(By.xpath("//span[contains(text(),'"+UCLValue+"')]")).isCurrentlyVisible() &&
				element(By.xpath("//span[contains(text(),'"+minRange+"')]")).isCurrentlyVisible() &&
				element(By.xpath("//span[contains(text(),'"+maxRange+"')]")).isCurrentlyVisible() &&
				element(By.xpath("//span[contains(text(),'"+aggregator+"')]")).isCurrentlyVisible())
		result1 = true;	
		boolean result2 = false;
		String actStatus = element(By.xpath("//span[contains(text(),'"+updatedParameterName+"')]/../..//input[@name='priority_flag']")).getAttribute("aria-checked");
		System.out.println("Actual ppriorty status"+actStatus);
		if (priorityFlag.equals("ON"))
		{
			if(actStatus.equals("true"))
			result2 = true;	
		}
		else if (priorityFlag.equals("OFF"))
		{
			if(actStatus.equals("false"))
			result2 = true;	
		}
		System.out.println("Element priority status"+result2);
		boolean result3 = false;
		String actVisibiltyStatus = element(By.xpath("//span[contains(text(),'"+updatedParameterName+"')]/../..//input[@name='visible_flag']")).getAttribute("aria-checked");
		System.out.println("VisibilityStatus"+actVisibiltyStatus);
		if (visibilityFlag.equals("ON"))
		{
			if(actVisibiltyStatus.equals("true"))
				result3 = true;	
		}
		else if (visibilityFlag.equals("OFF"))
		{
			if(actVisibiltyStatus.equals("false"))
				result3 = true;	
		}
		System.out.println("Element visibility status"+result3);
		if(result1==true && result2==true && result3==true)
			return true;
			else return false;
	}
	
	/********************************************************************
	* Description: Verify edited alarm,trip,fault parameter
	* Param: updatedParameterName,updatedValue,updatedUnit
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyEditedAlarmTripFaultParameter(String editParameterName,String relatedMeasurement,String severity ,String recommendationtext)
	{
		boolean result1 = false;
		if(element(By.xpath("//span[contains(text(),'"+editParameterName+"')]")).isCurrentlyVisible() &&
				element(By.xpath("//span[contains(text(),'"+relatedMeasurement+"')]")).isCurrentlyVisible())
		{
			result1 = true;
		}
		System.out.println("Status1111"+result1);
		boolean result2 = false;
		if(element(By.xpath("//button[contains(text(),'Severity')]")).isCurrentlyVisible())
		{
			if(element(By.xpath("//span[contains(text(),'"+editParameterName+"')]/../..//span[contains(text(),'"+severity+"')]")).isCurrentlyVisible())
				result2 = true;
		}
		System.out.println("Severity status"+result2);
		boolean result3 = false;
		if(element(By.xpath("//button[contains(text(),'Recommendation')]")).isCurrentlyVisible())
		{
			if(element(By.xpath("//span[contains(text(),'"+editParameterName+"')]/../..//span[contains(text(),'"+recommendationtext+"')]")).isCurrentlyVisible())
				result3 = true;
		}
		System.out.println("Recommendation status"+result3);
		if(result1==true && result2==true && result3==true)
			return true;
			else return false;
	}
	
	/********************************************************************
	* Description: Verify edited calibration parameter
	* Param: updatedParameterName,updatedValue,updatedUnit
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyEditedCalibrationParameter(String editParameterName,String relatedMeasurement,String unitofMeasurement)
	{
		if(element(By.xpath("//span[contains(text(),'"+editParameterName+"')]")).isCurrentlyVisible() &&
				element(By.xpath("//span[contains(text(),'"+editParameterName+"')]/../..//span[contains(text(),'"+unitofMeasurement+"')]")).isCurrentlyVisible() &&
				element(By.xpath("//span[contains(text(),'"+editParameterName+"')]/../..//span[contains(text(),'"+relatedMeasurement+"')]")).isCurrentlyVisible())
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Verify edited fucntion states parameter
	* Param: updatedParameterName,updatedValue,updatedUnit
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyEditedFSParameter(String editParameterName,String relatedMeasurement)
	{
		System.out.println("1"+element(By.xpath("//span[contains(text(),'"+editParameterName+"')]")).isCurrentlyVisible());
		System.out.println("2"+element(By.xpath("//span[contains(text(),'"+editParameterName+"')]/../..//span[contains(text(),'"+relatedMeasurement+"')]")).isCurrentlyVisible());
		if(element(By.xpath("//span[contains(text(),'"+editParameterName+"')]")).isCurrentlyVisible() &&
				element(By.xpath("//span[contains(text(),'"+editParameterName+"')]/../..//span[contains(text(),'"+relatedMeasurement+"')]")).isCurrentlyVisible())
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Verify error message and no duplicate manufacturer should get added
	* Param: manufacturerName,machineUnitName
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyErrorMessageWhileAddingDuplicateManufacturer(String manufacturerName,String machineUnitName)
	{
		String actErrMsg = element(By.xpath("//simple-snack-bar[@class='mat-simple-snackbar ng-star-inserted']//span")).getText();
		String expErrMsg = "Manufacturer '"+manufacturerName+"' is already mapped to "+machineUnitName+"";
		System.out.println("Actua message"+actErrMsg);
		List<WebElement> l1 = getDriver().findElements(By.xpath("//form//a[@class='mat-line ng-star-inserted']"));
		int c=0;
		for (int i=0;i<l1.size();i++)
		{
			if(l1.get(i).getText().equals(manufacturerName))
				c++;
		}
		System.out.println("Count"+c);
		if(actErrMsg.equals(expErrMsg) && c==1)
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Verify error message and no duplicate model should get added
	* Param: modelName
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyErrorMessageWhileAddingDuplicateModel(String modelName)
	{
		String actErrMsg = element(By.xpath("//simple-snack-bar[@class='mat-simple-snackbar ng-star-inserted']//span")).getText();
		String expErrMsg = "Model with name '"+modelName+"' already exists";
		System.out.println("actmsg"+actErrMsg);
		List<WebElement> l1 = getDriver().findElements(By.xpath("//mat-card//mat-list//a"));
		int c=0;
		for (int i=0;i<l1.size();i++)
		{
			if(l1.get(i).getText().equals(modelName))
				c++;
		}
		System.out.println("Count"+c);
		if(actErrMsg.equals(expErrMsg) && c==1)
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Add negative count while adding subsystem
	* Param: count
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public void addNegativeCountToSubsystem(String count)
	{
		element(By.xpath("//mat-icon[contains(text(),'add')]")).click();
		element(countField).sendKeys(count);
		element(machineUnitField).click();
		
	}
	
	/********************************************************************
	* Description: Add negative count while adding subsystem
	* Param: count
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyErrorMessageWhenCountIsNegative()
	{
		List<WebElement> l1 = (List<WebElement>) getJavascriptExecutor().executeScript("return document.querySelectorAll('.mat-error');");
		boolean result = false;
		for(int i=0 ; i<l1.size();i++)
		{
			if(l1.get(i).getText().contains("Count invalid and should be greater than 0"))
				result = true;
		}
		return result;
	}
	
	/********************************************************************
	* Description: Verify error message and no parameter gets added
	* Param: count
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyErrorMessageAndNoDuplicateParameterGetsCreated(String duplicateParameter)
	{
		String actmessage = element(By.xpath("//simple-snack-bar[@class='mat-simple-snackbar ng-star-inserted']//span")).getText();
		String expMessage = "Design parameter with name '"+duplicateParameter+"' already exists";
		System.out.println("act message"+actmessage);
		List<WebElement> l1 = getDriver().findElements(By.xpath("//mat-row//mat-cell[@class='plain-title-text mat-cell cdk-column-manufacturer_model_design_parameter_name mat-column-manufacturer_model_design_parameter_name ng-star-inserted']//span"));
		int c=0;
		for (int i=0;i<l1.size();i++)
		{
			if(l1.get(i).getText().equals(duplicateParameter))
				c++;
		}
		System.out.println("Count"+c);
		if(actmessage.equals(expMessage) && c==1)
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Add measurement parameter
	* Param: tabname,parameter,sysUnit,unit,parameterName
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void addMeasurementParamaterToVerifyDuplicate(String tabname,String parameterName,String parameter,String sysUnit,String unit)
	{
		if(tabname.equals("Design Parameters")) {
		}
		else {
			element(By.xpath("//a[text()='"+tabname+"']")).click();
			waitSeconds(3);
		}
		element(addNewButton).click();
		element(parameterNameField).sendKeys(parameterName);
		element(designparameterDropdown).click();
		List<WebElement> l1 = getDriver().findElements(dropdownOptions);
		int s1 = l1.size();
		try {
		for(int i=1;i<s1;i++)
		{
			if(l1.get(i).getText().contains(parameter))
			{
				l1.get(i).click();
			}
		}
		}
		catch(StaleElementReferenceException e)
		{
			System.out.println("Exception handled");
		}
		
		waitSeconds(4);
		Actions act = new Actions(getDriver());
		act.click(element(sysytemUnit)).build().perform();
		List<WebElement> l2 = getDriver().findElements(dropdownOptions);
		int s2 = l2.size();
		for(int i=1;i<s2;i++)
		{
			if(l2.get(i).getText().contains(sysUnit))
			{
				l2.get(i).click();
			}
		}
		
		waitSeconds(4);
		Actions act1 = new Actions(getDriver());
		act1.click(element(unitdropdown)).build().perform();
		List<WebElement> l3 = getDriver().findElements(dropdownOptions);
		int s3 = l3.size();
		for(int i=1;i<s3;i++)
		{
			if(l3.get(i).getText().contains(unit))
			{
				l3.get(i).click();
			}
		}
		element(add).click();
	}
	
	/********************************************************************
	* Description: Verify error message and no parameter gets added
	* Param: count
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyErrorMessageAndNoDuplicateMeasurementParameterGetsCreated(String duplicateParameter)
	{
		String actmessage = element(By.xpath("//simple-snack-bar[@class='mat-simple-snackbar ng-star-inserted']//span")).getText();
		String expMessage = "'"+duplicateParameter+"' already exists";
		System.out.println("act message"+actmessage);
		List<WebElement> l1 = getDriver().findElements(By.xpath("//mat-table//mat-row//mat-cell[@class='plain-title-text mat-cell cdk-column-MeasurementName mat-column-MeasurementName ng-star-inserted']//span"));
		int c=0;
		for (int i=0;i<l1.size();i++)
		{
			if(l1.get(i).getText().equals(duplicateParameter))
				c++;
		}
		System.out.println("Count"+c);
		if(actmessage.equals(expMessage) && c==1)
			return true;
		else return false;
	}
	

	/********************************************************************
	* Description: Verify error message and no parameter gets added
	* Param: count
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyErrorMessageAndNoDuplicateAlarmParameterGetsCreated(String duplicateParameter)
	{
		String actmessage = element(By.xpath("//simple-snack-bar[@class='mat-simple-snackbar ng-star-inserted']//span")).getText();
		String expMessage = "'"+duplicateParameter+"' already exists";
		System.out.println("act message"+actmessage);
		List<WebElement> l1 = getDriver().findElements(By.xpath("//mat-table//mat-row//mat-cell[@class='plain-title-text mat-cell cdk-column-EventName mat-column-EventName ng-star-inserted']//span"));
		int c=0;
		for (int i=0;i<l1.size();i++)
		{
			if(l1.get(i).getText().equals(duplicateParameter))
				c++;
		}
		System.out.println("Count"+c);
		if(actmessage.equals(expMessage) && c==1)
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Verify error message and no parameter gets added
	* Param: count
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyErrorMessageAndNoDuplicateFunctionStatesParameterGetsCreated(String duplicateParameter)
	{
		String actmessage = element(By.xpath("//simple-snack-bar[@class='mat-simple-snackbar ng-star-inserted']//span")).getText();
		String expMessage = "'"+duplicateParameter+"' already exists";
		System.out.println("act message"+actmessage);
		List<WebElement> l1 = getDriver().findElements(By.xpath("//mat-table//mat-row//mat-cell[@class='plain-title-text mat-cell cdk-column-FunctionStateName mat-column-FunctionStateName ng-star-inserted']//span"));
		int c=0;
		for (int i=0;i<l1.size();i++)
		{
			if(l1.get(i).getText().equals(duplicateParameter))
				c++;
		}
		System.out.println("Count"+c);
		if(actmessage.equals(expMessage) && c==1)
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Verify error message and no parameter gets added
	* Param: count
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyErrorMessageAndNoDuplicateCalibrationParameterGetsCreated(String duplicateParameter)
	{
		String actmessage = element(By.xpath("//simple-snack-bar[@class='mat-simple-snackbar ng-star-inserted']//span")).getText();
		String expMessage = "'"+duplicateParameter+"' already exists";
		System.out.println("act message"+actmessage);
		List<WebElement> l1 = getDriver().findElements(By.xpath("//mat-table//mat-row//mat-cell[@class='plain-title-text mat-cell cdk-column-CalibrationName mat-column-CalibrationName ng-star-inserted']//span"));
		int c=0;
		for (int i=0;i<l1.size();i++)
		{
			if(l1.get(i).getText().equals(duplicateParameter))
				c++;
		}
		System.out.println("Count"+c);
		if(actmessage.equals(expMessage) && c==1)
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Add Calibration
	* Param: tabname,parameter,sysUnit,unit,parameterName
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void addCalibrationParamaterToVerifyDuplicate(String tabname,String parameterName,String parameter,String sysUnit,String unit)
	{
		if(tabname.equals("Design Parameters")) {
		}
		else {
			element(By.xpath("//a[text()='"+tabname+"']")).click();
			waitSeconds(3);
		}
		element(addNewButton).click();
		element(parameterNameField).sendKeys(parameterName);
		element(By.xpath("//span[contains(text(),'Select Calibration')]")).click();
		List<WebElement> l1 = getDriver().findElements(dropdownOptions);
		int s1 = l1.size();
		try {
		for(int i=1;i<s1;i++)
		{
			if(l1.get(i).getText().contains(parameter))
			{
				l1.get(i).click();
			}
		}
		}
		catch(StaleElementReferenceException e)
		{
			System.out.println("Exception handled");
		}
		
		waitSeconds(4);
		Actions act = new Actions(getDriver());
		act.click(element(sysytemUnit)).build().perform();
		List<WebElement> l2 = getDriver().findElements(dropdownOptions);
		int s2 = l2.size();
		for(int i=1;i<s2;i++)
		{
			if(l2.get(i).getText().contains(sysUnit))
			{
				l2.get(i).click();
			}
		}
		
		waitSeconds(4);
		Actions act1 = new Actions(getDriver());
		act1.click(element(unitdropdown)).build().perform();
		List<WebElement> l3 = getDriver().findElements(dropdownOptions);
		int s3 = l3.size();
		try
		{
		for(int i=1;i<s3;i++)
		{
			if(l3.get(i).getText().contains(unit))
			{
				l3.get(i).click();
			}
		}
		}
		catch(StaleElementReferenceException e)
		{
			System.out.println("Exception handled");
		}
		element(add).click();
	}
	
	/********************************************************************
	* Description: Verify error message and no parameter gets added while editing with duplicate parameter
	* Param: count
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyErrorMessageAndNoDuplicateDesignParameterGetsCreatedWhileEditing(String duplicateParameter)
	{
		String actmessage = element(By.xpath("//simple-snack-bar[@class='mat-simple-snackbar ng-star-inserted']//span")).getText();
		String expMessage = "The design paramter with name '"+duplicateParameter+"' already exists. Please provide a different name";
		System.out.println("act message"+actmessage);
		List<WebElement> l1 = getDriver().findElements(By.xpath("//mat-row//mat-cell[@class='plain-title-text mat-cell cdk-column-manufacturer_model_design_parameter_name mat-column-manufacturer_model_design_parameter_name ng-star-inserted']//span"));
		int c=0;
		for (int i=0;i<l1.size();i++)
		{
			if(l1.get(i).getText().equals(duplicateParameter))
				c++;
		}
		System.out.println("Count"+c);
		if(actmessage.equals(expMessage) && c==1)
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Verify error message and no parameter gets added while editing with duplicate parameter
	* Param: count
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyErrorMessageAndNoDuplicateMeasurementParameterGetsCreatedWhileEditing(String duplicateParameter)
	{
		String actmessage = element(By.xpath("//simple-snack-bar[@class='mat-simple-snackbar ng-star-inserted']//span")).getText();
		String expMessage = "The measurement with name '"+duplicateParameter+"' already exists. Please provide a different name";
		System.out.println("act message"+actmessage);
		List<WebElement> l1 = getDriver().findElements(By.xpath("//mat-row//mat-cell[@class='plain-title-text mat-cell cdk-column-MeasurementName mat-column-MeasurementName ng-star-inserted']//span"));
		int c=0;
		for (int i=0;i<l1.size();i++)
		{
			if(l1.get(i).getText().equals(duplicateParameter))
				c++;
		}
		System.out.println("Count"+c);
		if(actmessage.equals(expMessage) && c==1)
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Verify error message and no parameter gets added while editing alarm with duplicate parameter
	* Param: duplicateParameter
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyErrorMessageAndNoDuplicateAlarmParameterGetsCreatedWhileEditing(String duplicateParameter)
	{
		String actmessage = element(By.xpath("//simple-snack-bar[@class='mat-simple-snackbar ng-star-inserted']//span")).getText();
		String expMessage = "'"+duplicateParameter+"'- Alarm already exists.Please provide a different name";
		System.out.println("act message"+actmessage);
		List<WebElement> l1 = getDriver().findElements(By.xpath("//mat-row//mat-cell[@class='plain-title-text mat-cell cdk-column-EventName mat-column-EventName ng-star-inserted']//span"));
		int c=0;
		for (int i=0;i<l1.size();i++)
		{
			if(l1.get(i).getText().equals(duplicateParameter))
				c++;
		}
		System.out.println("Count"+c);
		if(actmessage.equals(expMessage) && c==1)
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Verify error message and no parameter gets added while editing trip with duplicate parameter
	* Param: duplicateParameter
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyErrorMessageAndNoDuplicateTripParameterGetsCreatedWhileEditing(String duplicateParameter)
	{
		String actmessage = element(By.xpath("//simple-snack-bar[@class='mat-simple-snackbar ng-star-inserted']//span")).getText();
		String expMessage = "'"+duplicateParameter+"'- Trip already exists.Please provide a different name";
		System.out.println("act message"+actmessage);
		List<WebElement> l1 = getDriver().findElements(By.xpath("//mat-row//mat-cell[@class='plain-title-text mat-cell cdk-column-EventName mat-column-EventName ng-star-inserted']//span"));
		int c=0;
		for (int i=0;i<l1.size();i++)
		{
			if(l1.get(i).getText().equals(duplicateParameter))
				c++;
		}
		System.out.println("Count"+c);
		if(actmessage.equals(expMessage) && c==1)
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Verify error message by clicking on more option without selecting the parameters
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void verifyErrorMessageByClickingOnMoreOptionwithoutSelectingTheParameters(String tabname)
	{
		if(tabname.equals("Design Parameters")) {
		}
		else {
			element(By.xpath("//a[text()='"+tabname+"']")).click();
			waitSeconds(3);
		}
		element(addNewButton).click();
		element(moreOption).click();
		waitSeconds(2);
	}
	
	/********************************************************************
	* Description: Verify error message by clicking on more option without selecting the design parameters
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyErrorMessageOnClickingOnMoreOptionWithoutSelectingDesignParameter()
	{
		String actMsg = element(By.xpath("//div[@class='swal2-header']//h2")).getText();
		String expMsg = "Please select design-parameters";
		if(actMsg.equals(expMsg)) return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Verify error message by clicking on more option without selecting the measurement parameters
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyErrorMessageOnClickingOnMoreOptionWithoutSelectingMeasurementParameter()
	{
		String actMsg = element(By.xpath("//div[@class='swal2-header']//h2")).getText();
		String expMsg = "Please select measurements";
		if(actMsg.equals(expMsg)) return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Verify error message by clicking on more option without selecting the calibration parameters
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyErrorMessageOnClickingOnMoreOptionWithoutSelectingCalibrationParameter()
	{
		String actMsg = element(By.xpath("//div[@class='swal2-header']//h2")).getText();
		String expMsg = "Please select calibration";
		if(actMsg.equals(expMsg)) return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Edit the unit for design parameter
	* Param: tabname,parameter,unit,addValue,subValue,multiValue,divValue
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void editUnitForDesignParameter(String tabname,String parameter,String unit,String addValue,String subValue,String multiValue,String divValue)
	{
		if(tabname.equals("Design Parameters")) {
		}
		else {
			element(By.xpath("//a[text()='"+tabname+"']")).click();
			//waitSeconds(3);
			waitForElementToDisappear(loader);
			//waitForElementToAppear(addNew);
		}
		
		element(addNewButton).click();
		if(element(selectParameter).isCurrentlyVisible())
		{
				element(selectParameter).click();
		}
		else if(element(selectParameterForCalibration).isCurrentlyVisible())
		{
			element(selectParameterForCalibration).click();
		}
		List<WebElement> l1 = getDriver().findElements(dropdownOptions);
		int s1 = l1.size();
		try {
		for(int i=1;i<s1;i++)
		{
			if(l1.get(i).getText().equals(parameter))
			{
				l1.get(i).click();
			}
		}
		}
		catch(StaleElementReferenceException e)
		{
			System.out.println("Exception handled");
		}
		waitSeconds(3);
		try
		{
		element(moreOption).click();
		}
		catch(StaleElementReferenceException e)
		{
			System.out.println("Exception handled");
		}
		//waitSeconds(4);
		waitForElementToDisappear(loader);
		element(By.xpath("//div[@class='ng-star-inserted']/div//span[normalize-space(text())='"+unit+"']/ancestor::div[@class='col-lg-4 col-md-6 my-2 ng-star-inserted']//button//mat-icon[contains(text(),'edit')]")).click();
		waitSeconds(2);
		element(additiveField).clear();
		element(additiveField).sendKeys(addValue);
		element(subtractiveField).clear();
		element(subtractiveField).sendKeys(subValue);
		element(multiplicativeField).clear();
		element(multiplicativeField).sendKeys(multiValue);
		element(divisionField).clear();
		element(divisionField).sendKeys(divValue);
		element(updateField).click();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verify edited parameter
	* Param: tabname,parameter,unit,addValue,subValue,multiValue,divValue
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyEditedUnitForParameter(String unit,String addValue,String subValue,String multiValue,String divValue)
	{
		String actAddValue = (element(By.xpath("//div[@class='ng-star-inserted']/div//span[normalize-space(text())='"+unit+"']/ancestor::div[@class='col-lg-4 col-md-6 my-2 ng-star-inserted']//span[contains(text(),'Additive Factor')]/preceding-sibling::span")).getText()).trim();
		String expAddValue = addValue;
		String actSubValue = (element(By.xpath("//div[@class='ng-star-inserted']/div//span[normalize-space(text())='"+unit+"']/ancestor::div[@class='col-lg-4 col-md-6 my-2 ng-star-inserted']//span[contains(text(),'Subtractive Factor')]/preceding-sibling::span")).getText()).trim();
		String expSubValue = subValue;
		String actMultiValue = (element(By.xpath("//div[@class='ng-star-inserted']/div//span[normalize-space(text())='"+unit+"']/ancestor::div[@class='col-lg-4 col-md-6 my-2 ng-star-inserted']//span[contains(text(),'Multiplicative Factor')]/preceding-sibling::span")).getText()).trim();
		String expMulValue = multiValue;
		String actDivValue = (element(By.xpath("//div[@class='ng-star-inserted']/div//span[normalize-space(text())='"+unit+"']/ancestor::div[@class='col-lg-4 col-md-6 my-2 ng-star-inserted']//span[contains(text(),'Division Factor')]/preceding-sibling::span")).getText()).trim();
		String expDivValue = divValue;
		if(expAddValue.equals(0)) 
			{
			actAddValue = " ";
			}
		if(expSubValue.equals(0)) 
		{
		actAddValue = " ";
		}
		if(expMulValue.equals(0)) 
		{
		actAddValue = " ";
		}
		if(actDivValue.equals(0)) 
		{
		actAddValue = " ";
		}

		if(actAddValue.equals(expAddValue) &&
				actSubValue.equals(expSubValue) &&
				actMultiValue.equals(expMulValue) &&
				actDivValue.equals(expDivValue)) return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Add Model with image of different format and verify
	* Param: manufacturerName,modelNameValue,modelCodeValue,filepath
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void addModelNameWithAFileOFDifferentFormat(String manufacturerName,String modelNameValue,String modelCodeValue,String filepath)
	{
		element(addNewButton).click();
		element(modelName).sendKeys(modelNameValue);
		element(modelCode).sendKeys(modelCodeValue);
		element(fileUpload).sendKeys(filepath);
		waitSeconds(3);
	}
	
	/********************************************************************
	* Description: Verify error message while uploading wrong image
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyErrorMessageWhileUploadingWrongFile()
	{
		String actErrMsg = element(By.xpath("//input[@id='file']/following-sibling::span")).getText();
		String expErrMsg = "Model Image should be png, jpg or jpeg format.";
		if(actErrMsg.equals(expErrMsg)) return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Update visibility and priority flag
	* Param: parameterName,priorityFlag,visibilityFlag
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public void updateVisibilityAndPriorityFlag(String parameterName,String priorityFlag,String visibilityFlag)
	{
		element(By.xpath("//a[text()='Measurements']")).click();
		waitForElementToDisappear(loader);
		String actpriorityFlag = element(By.xpath("//span[contains(text(),'"+parameterName+"')]/../..//mat-checkbox//input[@name='priority_flag']")).getAttribute("aria-checked");
		System.out.println("Status1"+actpriorityFlag);
		if(actpriorityFlag.equals("false") && priorityFlag.equals("ON"))
		{
			System.out.println("Click oper1");
			waitSeconds(2);
			//element(By.xpath("//span[contains(text(),'"+parameterName+"')]/../..//mat-checkbox//input[@name='priority_flag']")).click();
			Actions act = new Actions(getDriver());
			act.moveToElement(element(By.xpath("//span[contains(text(),'"+parameterName+"')]/../..//mat-checkbox//input[@name='priority_flag']/.."))).click().build().perform();
			waitForElementToDisappear(loader);
		}
		else if(actpriorityFlag.equals("true") && priorityFlag.equals("OFF"))
		{
			System.out.println("Click oper2");
			waitSeconds(2);
			System.out.println("Status2again"+actpriorityFlag);
			element(By.xpath("//span[contains(text(),'"+parameterName+"')]/../..//mat-checkbox//input[@name='priority_flag']")).click();
			Actions act = new Actions(getDriver());
			act.moveToElement(element(By.xpath("//span[contains(text(),'"+parameterName+"')]/../..//mat-checkbox//input[@name='priority_flag']/.."))).click().build().perform();
			waitForElementToDisappear(loader);
		}
		
		String actvisibilityFlag = element(By.xpath("//span[contains(text(),'"+parameterName+"')]/../..//mat-checkbox//input[@name='visible_flag']")).getAttribute("aria-checked");
		System.out.println("Status1"+actvisibilityFlag);
		if(actvisibilityFlag.equals("false") && visibilityFlag.equals("ON"))
		{
			System.out.println("Click oper3");
			waitSeconds(2);
			//element(By.xpath("//span[contains(text(),'"+parameterName+"')]/../..//mat-checkbox//input[@name='visible_flag']")).click();
			Actions act = new Actions(getDriver());
			act.moveToElement(element(By.xpath("//span[contains(text(),'"+parameterName+"')]/../..//mat-checkbox//input[@name='visible_flag']/.."))).click().build().perform();
			waitForElementToDisappear(loader);
		}
		else if(actvisibilityFlag.equals("true") && visibilityFlag.equals("OFF"))
		{
			System.out.println("Click oper4");
			waitSeconds(2);
			//element(By.xpath("//span[contains(text(),'"+parameterName+"')]/../..//mat-checkbox//input[@name='visible_flag']")).click();
			System.out.println("Status2again"+actvisibilityFlag);
			Actions act = new Actions(getDriver());
			act.moveToElement(element(By.xpath("//span[contains(text(),'"+parameterName+"')]/../..//mat-checkbox//input[@name='visible_flag']/.."))).click().build().perform();
			waitForElementToDisappear(loader);
		}	
	}
	
	/********************************************************************
	* Description: Verify the priority and visibility flag
	* Param: parameterName,priorityFlag,visibilityFlag
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyUpdatedPriorityAndVisibilityFlag(String parameterName,String priorityFlag,String visibilityFlag)
	{
		String actpriorityFlag = element(By.xpath("//span[contains(text(),'"+parameterName+"')]/../..//mat-checkbox//input[@name='priority_flag']")).getAttribute("aria-checked");
		System.out.println("Status1"+actpriorityFlag);
		String actvisibilityFlag = element(By.xpath("//span[contains(text(),'"+parameterName+"')]/../..//mat-checkbox//input[@name='visible_flag']")).getAttribute("aria-checked");
		System.out.println("Status1"+actvisibilityFlag);
		boolean result = false;
		if(priorityFlag.equals("ON"))
		{
			if(actpriorityFlag.equals("true"))
			return result = true;
		}
		else if(priorityFlag.equals("OFF"))
		{
			if(actpriorityFlag.equals("false"))
			return result = true;
		}
		
		boolean result1=false;
		if(visibilityFlag.equals("ON"))
		{
			if(actvisibilityFlag.equals("true"))
			return result1 = true;
		}
		else if(visibilityFlag.equals("OFF"))
		{
			if(actvisibilityFlag.equals("false"))
			return result1 = true;
		}
		
		if(result==true && result1==true)
		return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Update the parameter with blank
	* Param: tabname,parameterToUpdate
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public void updateParameterWithBlank(String tabname,String parameterToUpdate)
	{
		if(tabname.equals("Design Parameters")) {
		}
		else {
			element(By.xpath("//a[text()='"+tabname+"']")).click();
			waitForElementToDisappear(loader);
		}
		element(By.xpath("//span[contains(text(),'"+parameterToUpdate+"')]/../..//mat-icon[@class='edit-icon mat-icon material-icons']")).click();
		waitForElementToDisappear(loader);
		element(By.xpath("//input[@placeholder='Enter Name']")).clear();
	}
	
	/********************************************************************
	* Description: Verify error message while updating the parameters with blank
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifySubmitButtonWhenTheParameterIsUpdatedWithBlank()
	{
		System.out.println(element(By.xpath("//button[@type='submit']")).isEnabled());
		return (!element(updateButton).isEnabled());
	}
	
	/********************************************************************
	* Description: Verify error message while updating the function states parameter with blank
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyErrorMessageWhileUpdatingTheFunctionStatesParameterWithBlank()
	{
		String actErrMsg = element(By.xpath("//simple-snack-bar[@class='mat-simple-snackbar ng-star-inserted']//span")).getText();
		String expErrMsg = "Please provide function-states name";
		List<WebElement> l1 = getDriver().findElements(By.xpath("//mat-table//mat-row//mat-cell[@class='plain-title-text mat-cell cdk-column-FunctionStateName mat-column-FunctionStateName ng-star-inserted']//span"));
		boolean result = true;
		for(int i=1;i<l1.size();i++)
		{
			if(l1.get(i).getText().equals(" "))
				result = false;
		}
		if(actErrMsg.equals(expErrMsg) && result == true) return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Verify error message while updating the calibration parameter with blank
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyErrorMessageWhileUpdatingTheCalibrationParameterWithBlank()
	{
		String actErrMsg = element(By.xpath("//simple-snack-bar[@class='mat-simple-snackbar ng-star-inserted']//span")).getText();
		String expErrMsg = "Please provide calibration name";
		List<WebElement> l1 = getDriver().findElements(By.xpath("//mat-table//mat-row//mat-cell[@class='plain-title-text mat-cell cdk-column-CalibrationName mat-column-CalibrationName ng-star-inserted']//span"));
		boolean result = true;
		for(int i=1;i<l1.size();i++)
		{
			if(l1.get(i).getText().equals(" "))
				result = false;
		}
		if(actErrMsg.equals(expErrMsg) && result == true) return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Verify search field for all parameters
	* Param: validParameterName
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void verifySearchFieldForParameter(String validParameterName,String tabname)
	{
		if(tabname.equals("Design Parameters")) {
		}
		else {
			element(By.xpath("//a[text()='"+tabname+"']")).click();
			waitForElementToDisappear(loader);
		}
		element(searchField).sendKeys(validParameterName);
		waitSeconds(3);
	}
	
	/********************************************************************
	* Description: Verify on entering valid input proper list should be displayed
	* Param: validInput
	* Returns: void
	* Status: Completed
	********************************************************************/
	public boolean verifySearchFieldForValidInputInDesignParameter(String validInput)
	{
		List<WebElement> l1 = getDriver().findElements(By.xpath("//mat-table//mat-row//mat-cell[@class='plain-title-text mat-cell cdk-column-manufacturer_model_design_parameter_name mat-column-manufacturer_model_design_parameter_name ng-star-inserted']//span[contains(text(),'"+validInput+"')]"));
		boolean result = false;
		for(int i=0;i<l1.size();i++)
		{
			if(l1.get(i).getText().contains(validInput))
				result = true;
		}
		System.out.println("Result"+result);
		System.out.println("1"+element(By.xpath("//mat-row")).isCurrentlyVisible());
		if(element(By.xpath("//mat-row")).isCurrentlyVisible() && result == true)
			return true;
		else return false;
		
	}
	
	/********************************************************************
	* Description: Verify on entering invalid input empty list will be displayed
	* Param: validInput
	* Returns: void
	* Status: Completed
	********************************************************************/
	public boolean verifySearchFieldForInvalidInputInDesignParameter()
	{
		if(!element(By.xpath("//mat-row")).isCurrentlyVisible())
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Verify on entering valid input proper list should be displayed
	* Param: validInput
	* Returns: void
	* Status: Completed
	********************************************************************/
	public boolean verifySearchFieldForValidInputInMeasurementParameter(String validInput)
	{
		List<WebElement> l1 = getDriver().findElements(By.xpath("//mat-table//mat-row//mat-cell[@class='plain-title-text mat-cell cdk-column-MeasurementName mat-column-MeasurementName ng-star-inserted']//span[contains(text(),'"+validInput+"')]"));
		boolean result = false;
		for(int i=0;i<l1.size();i++)
		{
			if(l1.get(i).getText().contains(validInput))
				result = true;
		}
		System.out.println("Result"+result);
		System.out.println("1"+element(By.xpath("//mat-row")).isCurrentlyVisible());
		if(element(By.xpath("//mat-row")).isCurrentlyVisible() && result == true)
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Verify on entering valid input proper list should be displayed
	* Param: validInput
	* Returns: void
	* Status: Completed
	********************************************************************/
	public boolean verifySearchFieldForValidInputInAlarmTripFaultParameter(String validInput)
	{
		List<WebElement> l1 = getDriver().findElements(By.xpath("//mat-table//mat-row//mat-cell[@class='plain-title-text mat-cell cdk-column-EventName mat-column-EventName ng-star-inserted']//span[contains(text(),'"+validInput+"')]"));
		boolean result = false;
		for(int i=0;i<l1.size();i++)
		{
			if(l1.get(i).getText().contains(validInput))
				result = true;
		}
		System.out.println("Result"+result);
		System.out.println("1"+element(By.xpath("//mat-row")).isCurrentlyVisible());
		if(element(By.xpath("//mat-row")).isCurrentlyVisible() && result == true)
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Verify on entering valid input proper list should be displayed
	* Param: validInput
	* Returns: void
	* Status: Completed
	********************************************************************/
	public boolean verifySearchFieldForValidInputInFunctionStatesParameter(String validInput)
	{
		List<WebElement> l1 = getDriver().findElements(By.xpath("//mat-table//mat-row//mat-cell[@class='plain-title-text mat-cell cdk-column-FunctionStateName mat-column-FunctionStateName ng-star-inserted']//span[contains(text(),'"+validInput+"')]"));
		boolean result = false;
		for(int i=0;i<l1.size();i++)
		{
			if(l1.get(i).getText().contains(validInput))
				result = true;
		}
		System.out.println("Result"+result);
		System.out.println("1"+element(By.xpath("//mat-row")).isCurrentlyVisible());
		if(element(By.xpath("//mat-row")).isCurrentlyVisible() && result == true)
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Verify on entering valid input proper list should be displayed
	* Param: validInput
	* Returns: void
	* Status: Completed
	********************************************************************/
	public boolean verifySearchFieldForValidInputInCalibrationParameter(String validInput)
	{
		List<WebElement> l1 = getDriver().findElements(By.xpath("//mat-table//mat-row//mat-cell[@class='plain-title-text mat-cell cdk-column-CalibrationName mat-column-CalibrationName ng-star-inserted']//span[contains(text(),'"+validInput+"')]"));
		boolean result = false;
		for(int i=0;i<l1.size();i++)
		{
			if(l1.get(i).getText().contains(validInput))
				result = true;
		}
		System.out.println("Result"+result);
		System.out.println("1"+element(By.xpath("//mat-row")).isCurrentlyVisible());
		if(element(By.xpath("//mat-row")).isCurrentlyVisible() && result == true)
			return true;
		else return false;
	}
	

	/********************************************************************
	* Description: Edit the parameter with an existing name
	* Param: validInput
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void editParameter(String tabname,String parameterNameToEdit, String updateParameterName)
	{
			if(tabname.equals("Design Parameters")) {
			}
			else {
				element(By.xpath("//a[text()='"+tabname+"']")).click();
				waitForElementToDisappear(loader);
			}
			
			element(By.xpath("//span[contains(text(),'"+parameterNameToEdit+"')]/../..//mat-icon[contains(text(),'mode_edit')]")).click();
			waitForElementToDisappear(loader);
			element(parameterNameEditField).clear();
			element(parameterNameEditField).sendKeys(updateParameterName);
			waitSeconds(2);
			element(By.xpath("//mat-icon[contains(text(),'done')]")).click();
			waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verify error message while updating the calibration parameter with blank
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyErrorMessageWhileUpdatingTheCalibrationParameterWithDuplicate(String parameterName)
	{
		String actErrMsg = element(By.xpath("//simple-snack-bar[@class='mat-simple-snackbar ng-star-inserted']//span")).getText();
		String expErrMsg = "The calibration with name '"+parameterName+"' already exists. Please provide a different name";
		System.out.println("1"+actErrMsg);
		System.out.println("2"+expErrMsg);
		List<WebElement> l1 = getDriver().findElements(By.xpath("//mat-table//mat-row//mat-cell[@class='plain-title-text mat-cell cdk-column-CalibrationName mat-column-CalibrationName ng-star-inserted']//span"));
		int c=0;
		for (int i=0;i<l1.size();i++)
		{
			if(l1.get(i).getText().equals(parameterName))
				c++;
		}
		System.out.println("Count"+c);
		if(actErrMsg.equals(expErrMsg) && c==1)
			return true;
		else return false;
	}
	

	/********************************************************************
	* Description: Edit the FunctionStates parameter with an existing name
	* Param: validInput
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void editParameterFunctionStates(String tabname,String parameterNameToEdit, String updateParameterName)
	{
			if(tabname.equals("Design Parameters")) {
			}
			else {
				element(By.xpath("//a[text()='"+tabname+"']")).click();
				waitForElementToDisappear(loader);
			}
			
			element(By.xpath("//span[contains(text(),'"+parameterNameToEdit+"')]/../..//mat-icon[contains(text(),'mode_edit')]")).click();
			waitForElementToDisappear(loader);
			element(parameterNameEditField).clear();
			element(parameterNameEditField).sendKeys(updateParameterName);
			waitSeconds(2);
			element(By.xpath("//mat-icon[contains(text(),'done')]")).click();
			waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verify error message while updating the functionStates parameter with blank
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/

	public boolean verifyErrorMessageWhileUpdatingTheFunctionStatesParameterWithDuplicate(String parameterName)
	{
		String actErrMsg = element(By.xpath("//simple-snack-bar[@class='mat-simple-snackbar ng-star-inserted']//span")).getText();
		String expErrMsg = "The functionstate with name '"+parameterName+"' already exists. Please provide a different name";
		System.out.println("1"+actErrMsg);
		System.out.println("2"+expErrMsg);
		List<WebElement> l1 = getDriver().findElements(By.xpath("//mat-table//mat-row//mat-cell[@class='plain-title-text mat-cell cdk-column-CalibrationName mat-column-CalibrationName ng-star-inserted']//span"));
		int c=0;
		for (int i=0;i<l1.size();i++)
		{
			if(l1.get(i).getText().equals(parameterName))
				c++;
		}
		System.out.println("Count"+c);
		if(actErrMsg.equals(expErrMsg) && c==1)
			return true;
		else return false;
	}

	/********************************************************************
	* Description: Verify error message while updating the functionStates parameter with blank
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public void addManufacturerFromTheDropdown(String selectManufacturer)
	{
		element(addNewButton).click();
//		waitForElementToAppear(manufacturerName);
//		element(manufacturerNameField).click();
//		waitForElementToAppear(manufacturerList);
		waitForElementToAppear(By.xpath("//input[@placeholder='Enter Manufacturer Name']"));
		element(By.xpath("//input[@placeholder='Enter Manufacturer Name']")).click();
		List<WebElement>  manufacturerList  = getDriver().findElements(By.xpath("//span[@class='mat-option-text']"));
//		List<WebElement> manufacturerList = getDriver().findElements(manufacturerListLocator);
		int s= manufacturerList.size();
		System.out.println("count"+s);
		try {
		for(int i=1; i<s;i++)
		{
			if(manufacturerList.get(i).getText().equals(selectManufacturer))
				manufacturerList.get(i).click();
		}
		}
		catch(StaleElementReferenceException e)
		{
			System.out.println("Exception handled");
		}
		element(submitManufacturer).click();
		waitForElementToAppear(By.xpath("//a[contains(text(),'"+selectManufacturer+"')]"));
	}

	
/**************************************************************************************************************************/
	
	
	

	/********************************************************************
	 * Description: Add Design Paramter Param: NA Returns: void Status: Completed
	 * 
	 * @param unitname
	 ********************************************************************/

	public void AddDesignParamter(String designParameterName, String value, String metricUnitSystem,
			String uSUnitSystem, String number, String unitname) {

		if (!element(By.xpath(
				"//mat-cell[@class='plain-title-text mat-cell cdk-column-manufacturer_model_design_parameter_name mat-column-manufacturer_model_design_parameter_name ng-star-inserted']//span[contains(text(),'"+designParameterName+"')]"))
						.isCurrentlyVisible()) {

			element(addnewbutton).click();

			element(By.xpath("//mat-select[@aria-label='Select Design Parameter']")).click();

			List<WebElement> EDPL = getDriver().findElements(By.xpath("//mat-option"));

			if (EDPL.size() > 1) {
				element(By.xpath("//mat-option[2]//span")).click();
				waitForElementToDisappear(loader);
				element(By.xpath("//span[contains(text(),'Select Unit')]")).click();
				List<WebElement> UnitsCount = getDriver().findElements(By.xpath("//mat-option"));

				if (UnitsCount.size() > 1) {
					element(By.xpath("//mat-option[2]//span")).click();
					waitForElementToDisappear(loader);
					element(By.xpath("//input[@name='name']")).sendKeys(designParameterName);
					element(By.xpath("//input[@name='value']")).sendKeys(value);
					Actions action = new Actions(getDriver());
					action.moveToElement(element(By.xpath("//button[@type='submit']"))).click().perform();
					waitForElementToDisappear(loader);
				}

				else {
					Actions act = new Actions(getDriver());
					WebElement ele = getDriver().findElement(By.xpath("//mat-icon[contains(text(),'more_vert')]"));
					act.doubleClick(ele).perform();
					waitForElementToDisappear(loader);

					element(By.xpath("//span[contains(text(),'Add New')]")).click();
					element(By.xpath("//input[@placeholder='Enter Metric Unit System']")).sendKeys(metricUnitSystem);
					element(By.xpath("//input[@placeholder='Enter US Unit System']")).sendKeys(uSUnitSystem);
					element(By.xpath("//input[@placeholder='Additive']")).sendKeys(number);
					element(By.xpath("//input[@placeholder='Subractive']")).sendKeys(number);
					element(By.xpath("//input[@placeholder='Multiplicative']")).sendKeys(number);
					element(By.xpath("//input[@placeholder='Division']")).sendKeys(number);
					Actions action = new Actions(getDriver());
					action.moveToElement(element(By.xpath("//button[@type='submit']"))).click().perform();
					waitForElementToDisappear(loader);

					getDriver().navigate().back();
					waitForElementToDisappear(loader);

					element(addnewbutton).click();

					element(By.xpath("//input[@name='name']")).sendKeys(designParameterName);
					element(By.xpath("//input[@name='value']")).sendKeys(value);
					element(By.xpath("//mat-select[@aria-label='Select Design Parameter']")).click();
					element(By.xpath("//mat-option[2]//span")).click();
					waitForElementToDisappear(loader);
					element(By.xpath("//span[contains(text(),'Select Unit')]")).click();
					element(By.xpath("//mat-option[2]//span")).click();
					waitForElementToDisappear(loader);
					Actions action2 = new Actions(getDriver());
					action2.moveToElement(element(By.xpath("//button[@type='submit']"))).click().perform();
					waitForElementToDisappear(loader);
				}

			}
		}
	}

	/********************************************************************
	 * Description: Edit Enable Disable Design parameter 
	 * Param: NA 
	 * Returns: void
	 * Status: Completed
	 ********************************************************************/
	public void EditDesignParameter(String updatedDesignParamter, String updatedValue, String designParameterName) {
		if (element(By.xpath(
				"//mat-cell[@class='plain-title-text mat-cell cdk-column-manufacturer_model_design_parameter_name mat-column-manufacturer_model_design_parameter_name ng-star-inserted']//span[contains(text(),'"
						+ designParameterName + "')]")).isCurrentlyVisible()
				&& !element(By.xpath(
						"//mat-cell[@class='plain-title-text mat-cell cdk-column-manufacturer_model_design_parameter_name mat-column-manufacturer_model_design_parameter_name ng-star-inserted']//span[contains(text(),'"
								+ updatedDesignParamter + "')]")).isCurrentlyVisible()) {
			element(By.xpath(
					"//mat-cell[@class='plain-title-text mat-cell cdk-column-manufacturer_model_design_parameter_name mat-column-manufacturer_model_design_parameter_name ng-star-inserted']//span[contains(text(),'"
							+ designParameterName
							+ "')]//..//..//mat-icon[@class='edit-icon mat-icon material-icons']")).click();
			waitForElementToDisappear(loader);

			element(By.xpath("//div//input[@placeholder='Enter Name']")).clear();
			element(By.xpath("//div//input[@placeholder='Enter Name']")).sendKeys(updatedDesignParamter);

			element(By.xpath("//div//input[@placeholder='Enter Code']")).clear();
			element(By.xpath("//div//input[@placeholder='Enter Code']")).sendKeys(updatedValue);

			element(By.xpath("//div//input[@placeholder='Enter Value']")).clear();
			element(By.xpath("//div//input[@placeholder='Enter Value']")).sendKeys(updatedValue);

			element(By.xpath("//mat-form-field[2]//..//mat-form-field[1]//div[@class='mat-select-arrow-wrapper']")).click();
			element(By.xpath("//mat-option[1]//span")).click();

			element(By.xpath("//mat-form-field[2]//div[@class='mat-select-arrow-wrapper']")).click();
			try {
				element(By.xpath("//mat-option[1]//span")).click();
			} catch (Exception e) {
				System.out.println("Exception handled");
			}

			element(By.xpath("//textarea[@placeholder='Enter Description']")).clear();
			element(By.xpath("//textarea[@placeholder='Enter Description']")).sendKeys(updatedDesignParamter);

			try {
				element(By.xpath("//button//span//mat-icon[contains(text(),'done')]")).click();
				waitForElementToDisappear(loader);
			} catch (Exception e) { 
				System.out.println("Exception handled");
			}
		}

	}

	/********************************************************************
	 * Description: Verify added design parameter
	 *  Param: NA 
	 *  Returns: boolean
	 *  Status: Completed
	 ********************************************************************/
	public boolean verifyaddedDesignParameter(String designParameterName) {

		if (element(By.xpath(
				"//mat-cell[@class='plain-title-text mat-cell cdk-column-manufacturer_model_design_parameter_name mat-column-manufacturer_model_design_parameter_name ng-star-inserted']//span[contains(text(),'"
						+ designParameterName + "')]")).isCurrentlyVisible())

			return true;
		else
			return false;
	}

	/********************************************************************
	 * Description: Verify edited design parameter 
	 * Param: NA 
	 * Returns: boolean
	 * Status: Completed 
	 ********************************************************************/
	public boolean verifyEditedDesignParameter(String updatedDesignParamter) {
		if (element(By.xpath(
				"//mat-cell[@class='plain-title-text mat-cell cdk-column-manufacturer_model_design_parameter_name mat-column-manufacturer_model_design_parameter_name ng-star-inserted']//span[contains(text(),'"
						+ updatedDesignParamter + "')]")).isCurrentlyVisible())

			return true;
		else
			return false;
	}

/********************************************************************
 * Description: 
 * Param: NA 
 * Returns: void
 * Status: Completed 
 ********************************************************************/
	public void disableDesignParameter(String updatedDesignParamter) {
		if (element(By.xpath("//mat-row//mat-cell[1]//span[contains(text(),'" + updatedDesignParamter
				+ "')]//..//..//mat-slide-toggle[@class='mat-slide-toggle mat-primary mat-checked']"))
						.isCurrentlyVisible()) {
			element(By.xpath("//mat-row//mat-cell[1]//span[contains(text(),'" + updatedDesignParamter
					+ "')]//..//..//mat-slide-toggle[@class='mat-slide-toggle mat-primary mat-checked']")).click();
			waitForElementToDisappear(loader);
		}
		else {
			element(By.xpath("//mat-row//mat-cell[1]//span[contains(text(),'" + updatedDesignParamter
					+ "')]//..//..//mat-slide-toggle[@class='mat-slide-toggle mat-primary']")).click();
			waitForElementToDisappear(loader);
		}
	}
	
	/********************************************************************
	 * Description: 
	 * Param: 
	 * Returns: void
	 * Status: Completed 
	 ********************************************************************/
public boolean verifyDesignParameterDisabled(String updatedDesignParamter) {
	
	if (element(By.xpath("//mat-row//mat-cell[1]//span[contains(text(),'" + updatedDesignParamter
			+ "')]//..//..//mat-slide-toggle[@class='mat-slide-toggle mat-primary mat-checked']"))
					.isCurrentlyVisible()) 
		return true;
		else
			return false;
}
	/********************************************************************
	 * Description: I select Measurements
	 * Param: NA 
	 * Returns: void
	 * Status: Completed 
	 ********************************************************************/
	public void SelectMeasurements() {
			
			element(By.xpath("//a[contains(text(),'Measurements')]")).click();
			waitForElementToDisappear(loader);

	}
	/********************************************************************
	 * Description: Add New Measurements
	 * Param: NA 
	 * Returns: void
	 * Status: Completed 
	 ********************************************************************/
	public void AddMeasurements(String designParameterName, String metricUnitSystem, String uSUnitSystem,
			String number) {
		if (!element(By.xpath(
				"//mat-cell[@class=plain-title-text mat-cell cdk-column-MeasurementName mat-column-MeasurementName ng-star-inserted]//span[contains(text(),'"
						+ designParameterName + "')]")).isCurrentlyVisible()) {
			element(addnewbutton).click();

			element(By.xpath("//dropdown//div//span[contains(text(),'Select measurements')]")).click();

			List<WebElement> MMD = getDriver().findElements(By.xpath("//mat-option"));
			if (MMD.size() > 1) {
				element(By.xpath("//mat-option[2]//span")).click();
				waitForElementToDisappear(loader);
				
				element(By.xpath("//span[contains(text(),'Select unit')]")).click();
				List<WebElement> UnitsCount2 = getDriver().findElements(By.xpath("//mat-option"));

				if (UnitsCount2.size() > 1) {
					element(By.xpath("//mat-option[2]//span")).click();
					waitForElementToDisappear(loader);
					element(By.xpath("//input[@name='name']")).sendKeys(designParameterName);

					element(By.xpath("//span[contains(text(),'Priority')]")).click();
					Actions action = new Actions(getDriver());
					action.moveToElement(element(By.xpath("//button[@type='submit']"))).click().perform();
					waitForElementToDisappear(loader);
				} else {
					Actions act = new Actions(getDriver());
					WebElement ele = getDriver().findElement(By.xpath("//mat-icon[contains(text(),'more_vert')]"));
					act.doubleClick(ele).perform();
					waitForElementToDisappear(loader);

					element(By.xpath("//span[contains(text(),'Add New')]")).click();
					element(By.xpath("//input[@placeholder='Enter Metric Unit System']")).sendKeys(metricUnitSystem);
					element(By.xpath("//input[@placeholder='Enter US Unit System']")).sendKeys(uSUnitSystem);
					element(By.xpath("//input[@placeholder='Additive']")).sendKeys(number);
					element(By.xpath("//input[@placeholder='Subractive']")).sendKeys(number);
					element(By.xpath("//input[@placeholder='Multiplicative']")).sendKeys(number);
					element(By.xpath("//input[@placeholder='Division']")).sendKeys(number);
					Actions action = new Actions(getDriver());
					action.moveToElement(element(By.xpath("//button[@type='submit']"))).click().perform();
					waitForElementToDisappear(loader);

					getDriver().navigate().back();
					waitForElementToDisappear(loader);

					element(addnewbutton).click();

					element(By.xpath("//input[@name='name']")).sendKeys(designParameterName);

					element(By.xpath("//dropdown//div//span[contains(text(),'Select measurements')]")).click();
					element(By.xpath("//mat-option[2]//span")).click();
					waitForElementToDisappear(loader);
					element(By.xpath("//span[contains(text(),'Select unit')]")).click();
					element(By.xpath("//mat-option[2]//span")).click();
					waitForElementToDisappear(loader);

					Actions action2 = new Actions(getDriver());
					action2.moveToElement(element(By.xpath("//button[@type='submit']"))).click().perform();
					waitForElementToDisappear(loader);
				}

			}
		}
	}
	
	/********************************************************************
	 * Description: Verify Add New Measurements
	 * Param: NA 
	 * Returns: boolean
	 * Status: Completed 
	 ********************************************************************/
	public boolean verifyMeasurements(String designParameterName) {
	
		if (element(By.xpath(
				"//mat-cell[@class=\"plain-title-text mat-cell cdk-column-MeasurementName mat-column-MeasurementName ng-star-inserted\"]//span[contains(text(),'"
						+ designParameterName + "')]")).isCurrentlyVisible())

			return true;
		else
			return false;
	
	}
	/********************************************************************
	 * Description: Edit Enable and disable Add New Measurements
	 * Param: NA 
	 * Returns: boolean
	 * Status: Completed 
	 ********************************************************************/
	public void EditEnableDisableMeasurements(String updatedDesignParamter, String updatedValue,
			String designParameterName) {
		if (element(By.xpath(
				"//mat-cell[@class='plain-title-text mat-cell cdk-column-MeasurementName mat-column-MeasurementName ng-star-inserted']//span[contains(text(),'"
						+ designParameterName + "')]")).isCurrentlyVisible()
				&& !element(By.xpath(
						"//mat-cell[@class='plain-title-text mat-cell cdk-column-MeasurementName mat-column-MeasurementName ng-star-inserted']//span[contains(text(),'"
								+ updatedDesignParamter + "')]")).isCurrentlyVisible())
		{
			element(By.xpath("//mat-row//mat-cell//span[contains(text(),'"+designParameterName+"')]//..//..//mat-cell//button//mat-icon[@aria-label='Edit icon-button with a pencil icon']"))
					.click();
			waitForElementToDisappear(loader);
	
		
		element(By.xpath("//input[@placeholder='Enter Name']")).clear();
		element(By.xpath("//input[@placeholder='Enter Name']")).sendKeys(updatedDesignParamter);
		
		element(By.xpath("//mat-form-field[1]//mat-select[@aria-label='Select Unit of Measurement']")).click();
		element(By.xpath("//mat-option[1]")).click();
		
		element(By.xpath("//mat-form-field[2]//mat-select[@aria-label='Select Unit of Measurement']")).click();
		Actions action3 = new Actions(getDriver());
		action3.moveToElement(element(By.xpath("//mat-option[1]"))).click().perform();
		
		element(By.xpath("//input[@placeholder='Enter LCL']")).clear();
		element(By.xpath("//input[@placeholder='Enter LCL']")).sendKeys(updatedValue);
		
		element(By.xpath("//input[@placeholder='Enter UCL']")).clear();
		element(By.xpath("//input[@placeholder='Enter UCL']")).sendKeys(updatedValue);
		
		element(By.xpath("//input[@placeholder='Enter Signal Range(Min)']")).sendKeys(updatedValue);
		
		element(By.xpath("//input[@placeholder='Enter Signal Range(Max)']")).sendKeys(updatedValue);
		
		element(By.xpath("//textarea[@placeholder='Enter Description']")).clear();
		element(By.xpath("//textarea[@placeholder='Enter Description']")).sendKeys(updatedDesignParamter);
		 
		Actions actionss = new Actions(getDriver());
		actionss.moveToElement(element(By.xpath("//input[@placeholder='Enter Signal Range(Max)']//..//..//..//..//..//..//..//input[@name='priority_flag']"))).click().perform();	
		waitForElementToAppear(loader);
		
		Actions actionsss = new Actions(getDriver());
		actionsss.moveToElement(element(By.xpath("//input[@placeholder='Enter Signal Range(Max)']//..//..//..//..//..//..//..//input[@name='visible_flag']"))).click().perform();
		waitForElementToDisappear(loader);
		
		element(By.xpath("//input[@placeholder='Enter Signal Range(Max)']//..//..//..//..//..//..//..//span[contains(text(),'Average')]")).click();
		Actions action5 = new Actions(getDriver());
		action5.moveToElement(element(By.xpath("//mat-option[1]"))).click().perform();		
		
		Actions action4 = new Actions(getDriver());
		action4.moveToElement(element(By.xpath("//button[@type='submit']"))).click().perform();
		waitForElementToDisappear(loader);		
			
		}		
	}

	/********************************************************************
	 * Description: Verify Edited Measurements.
	 * Param: NA 
	 * Returns: boolean
	 * Status: Completed 
	 ********************************************************************/
	
	public boolean verifyEditedMeasurements(String updatedDesignParameterName) {
		if (element(By.xpath(
				"//mat-cell[@class=\"plain-title-text mat-cell cdk-column-MeasurementName mat-column-MeasurementName ng-star-inserted\"]//span[contains(text(),'"
						+ updatedDesignParameterName + "')]")).isCurrentlyVisible())

			return true;
		else
			return false;
	}
	
	/********************************************************************
	 * Description: Enable Disable Measurements.
	 * Param: NA 
	 * Returns: void
	 * Status: Completed 
	 ********************************************************************/

	public void EnableDisableMeasurements(String updatedDesignParamter, String updatedValue,
			String designParameterName) {

		if (!element(By.xpath("//mat-row//mat-cell[1]//span[contains(text(),'"
				+ 	updatedDesignParamter + "')]//..//..//mat-slide-toggle[@class='mat-slide-toggle mat-primary']"))
						.isCurrentlyVisible()) {
			
			Actions action4 = new Actions(getDriver());
			action4.moveToElement(element(By.xpath("//mat-row//mat-cell[1]//span[contains(text(),'" + updatedDesignParamter
					+ "')]//..//..//mat-slide-toggle[@class='mat-slide-toggle mat-primary mat-checked']"))).click().perform();
			waitForElementToDisappear(loader);

			element(By.xpath("//mat-row//mat-cell[1]//span[contains(text(),'" + updatedDesignParamter
					+ "')]//..//..//mat-slide-toggle[@class='mat-slide-toggle mat-primary']")).click();
			waitForElementToDisappear(loader);

		} else {
			element(By.xpath("//mat-row//mat-cell[1]//span[contains(text(),'" + updatedDesignParamter
					+ "')]//..//..//mat-slide-toggle[@class='mat-slide-toggle mat-primary']")).click();
			waitForElementToDisappear(loader);
		}
		
	}
	
	/********************************************************************
	 * Description: Enable Disable Measurements.
	 * Param: NA 
	 * Returns: void
	 * Status: Completed 
	 ********************************************************************/
	public void SelectAlarms() {

		try {
			element(By.xpath("//a[contains(text(),'Alarms')]")).click();
		} catch (Exception e) {
		}
	}

	/********************************************************************
	 * Description: Add New Alarms
	 * Param: NA 
	 * Returns: void
	 * Status: Completed 
	 ********************************************************************/
	public void AddAlarms(String designParameterName) {
		if (!element(By.xpath(
				"//mat-cell[@class='plain-title-text mat-cell cdk-column-EventName mat-column-EventName ng-star-inserted']//span[contains(text(),'"
						+ designParameterName + "')]")).isCurrentlyVisible()) {

			element(By.xpath("//button//span[contains(text(),'Add New')]")).click();

			element(By.xpath("//mat-form-field//input[@name='name']")).sendKeys(designParameterName);

			element(By.xpath("//mat-select")).click();

			List<WebElement> DD = getDriver().findElements(By.xpath("//mat-option"));
			if (DD.size() > 1) {
				element(By.xpath("//mat-option[2]//span")).click();
				waitForElementToDisappear(loader);

				Actions Submit = new Actions(getDriver());
				Submit.moveToElement(element(By.xpath("//button[@type='submit']"))).click().perform();

			}

		else {
			try {
				Actions acti = new Actions(getDriver());
				WebElement ele = getDriver().findElement(By.xpath("//mat-icon[contains(text(),'more_vert')]"));
				acti.doubleClick(ele).perform();
				waitForElementToDisappear(loader);
			} catch (Exception e) {
				System.out.println("Exception handled");
			}

			element(By.xpath("//app-list-items//span[contains(text(),'Add')]")).click();

			element(By.xpath("//input[@name='category']")).sendKeys(designParameterName);

			element(By.xpath("//mat-icon[contains(text(),'done')]")).click();
			waitForElementToDisappear(loader);

			element(By.xpath("//input[@placeholder='Enter Name']")).sendKeys(designParameterName);

			Actions Submit = new Actions(getDriver());
			Submit.moveToElement(element(By.xpath("//button[@type='submit']"))).click().perform();
		}

	}
}
	
	/********************************************************************
	 * Description:Verify Newly added
	 * Param: NA 
	 * Returns: boolean
	 * Status: Completed 
	 ********************************************************************/
	public boolean verifyNewAlarm(String designParameterName) {
		if (element(By.xpath(
				"//mat-cell[@class='plain-title-text mat-cell cdk-column-name mat-column-name ng-star-inserted']//span[contains(text(),'"
						+ designParameterName + "')]")).isCurrentlyVisible())

			return true;
		else
			return false;
		
	}

	/********************************************************************
	 * Description:Edit Alarms
	 * Param: NA 
	 * Returns: boolean
	 * Status: Completed 
	 ********************************************************************/
	public void EditAlarms(String updatedDesignParamter, String updatedValue, String designParameterName) {
		if (element(By.xpath(
				"//mat-cell[@class='plain-title-text mat-cell cdk-column-EventName mat-column-EventName ng-star-inserted']//span[contains(text(),'"
						+ designParameterName + "')]")).isCurrentlyVisible()
				&& !element(By.xpath(
						"//mat-cell[@class='plain-title-text mat-cell cdk-column-EventName mat-column-EventName ng-star-inserted']//span[contains(text(),'"
								+ updatedDesignParamter + "')]")).isCurrentlyVisible()) {
			element(By.xpath("//mat-row//mat-cell//span[contains(text(),'" + designParameterName
					+ "')]//..//..//mat-cell//button//mat-icon[@aria-label='Edit icon-button with a pencil icon']"))
							.click();
			waitForElementToDisappear(loader);

			element(By.xpath("//input[@placeholder='Enter Name']")).clear();
			element(By.xpath("//input[@placeholder='Enter Name']")).sendKeys(updatedDesignParamter);

			try {
				element(By.xpath("//mat-cell[2]//mat-select")).click();
				element(By.xpath("//mat-option[1]")).click();
			} catch (Exception e) {
			}
			
				element(By.xpath("//mat-cell[3]//mat-select")).click();
				Actions action10 = new Actions(getDriver());
				action10.moveToElement(element(By.xpath("//mat-option[1]"))).click().perform();
		
            element(By.xpath("//textarea")).clear();
			element(By.xpath("//textarea")).sendKeys(designParameterName);
			
			try {
				Actions action11 = new Actions(getDriver());
				WebElement elem = getDriver().findElement(By.xpath("//mat-cell//span[2]//button[@type='submit']"));
				action11.doubleClick(elem).perform();
				waitForElementToDisappear(loader);
			} catch (Exception r) {
			}
		}
	}

	/********************************************************************
	 * Description:Verify edited Alarms
	 * Param: NA 
	 * Returns: boolean
	 * Status: Completed 
	 ********************************************************************/
	public boolean verifyEditedAlarm(String updatedDesignParameter) {
		if(element(By.xpath(
						"//mat-cell[@class='plain-title-text mat-cell cdk-column-name mat-column-name ng-star-inserted']//span[contains(text(),'"
								+ updatedDesignParameter + "')]")).isCurrentlyVisible())
				return true;
		else
			return false;
		
	}

	/********************************************************************
	 * Description:Enable and Disable Alarms
	 * Param: NA 
	 * Returns: void
	 * Status: Completed 
	 ********************************************************************/
	public void EnableDisableAlarms(String updatedDesignParamter, String updatedValue, String designParameterName) {
		if (!element(By.xpath("//mat-row//mat-cell[1]//span[contains(text(),'"
				+ 	updatedDesignParamter + "')]//..//..//mat-slide-toggle[@class='mat-slide-toggle mat-primary']"))
						.isCurrentlyVisible()) {
			
			Actions action4 = new Actions(getDriver());
			action4.moveToElement(element(By.xpath("//mat-row//mat-cell[1]//span[contains(text(),'" + updatedDesignParamter
					+ "')]//..//..//mat-slide-toggle[@class='mat-slide-toggle mat-primary mat-checked']"))).click().perform();
			waitForElementToDisappear(loader);

			element(By.xpath("//mat-row//mat-cell[1]//span[contains(text(),'" + updatedDesignParamter
					+ "')]//..//..//mat-slide-toggle[@class='mat-slide-toggle mat-primary']")).click();
			waitForElementToDisappear(loader);

		} else {
			element(By.xpath("//mat-row//mat-cell[1]//span[contains(text(),'" + updatedDesignParamter
					+ "')]//..//..//mat-slide-toggle[@class='mat-slide-toggle mat-primary']")).click();
			waitForElementToDisappear(loader);
		}
	
	}
	/********************************************************************
	 * Description:Select Trips
	 * Param: NA 
	 * Returns: void
	 * Status: Completed 
	 ********************************************************************/
	public void SelectTrips() {
		try {
			element(By.xpath("//a[contains(text(),'Trips')]")).click();
		} catch (Exception e) {
		}
	}
	/********************************************************************
	 * Description:Select Failure Mode
	 * Param: NA 
	 * Returns: void
	 * Status: Completed 
	 ********************************************************************/
	public void SelectFailureMode() {
		try {
			element(By.xpath("//a[contains(text(),'Failure Mode')]")).click();
		} catch (Exception e) {
		}
	}
	
	/********************************************************************
	 * Description:Select Function States
	 * Param: NA 
	 * Returns: void
	 * Status: Completed 
	 ********************************************************************/
	public void SelectFuncitonStates() {
		try {
			element(By.xpath("//a[contains(text(),'Function States')]")).click();
		} catch (Exception e) {
		}
	}

	/********************************************************************
	 * Description:Select Function States
	 * Param: NA 
	 * Returns: void
	 * Status: Completed 
	 ********************************************************************/
	public void EditFunctionStates(String updatedDesignParamter, String updatedValue, String designParameterName) {
		if (element(By.xpath(
				"//mat-cell[@class='plain-title-text mat-cell cdk-column-FunctionStateName mat-column-FunctionStateName ng-star-inserted']//span[contains(text(),'"
						+ designParameterName + "')]")).isCurrentlyVisible()
				&& !element(By.xpath(
						"//mat-cell[@class='plain-title-text mat-cell cdk-column-FunctionStateName mat-column-FunctionStateName ng-star-insertedd']//span[contains(text(),'"
								+ updatedDesignParamter + "')]")).isCurrentlyVisible()) {
			element(By.xpath("//mat-row//mat-cell//span[contains(text(),'" + designParameterName
					+ "')]//..//..//mat-cell//button//mat-icon[@aria-label='Edit icon-button with a pencil icon']"))
							.click();
			waitForElementToDisappear(loader);

			element(By.xpath("//input[@placeholder='Enter Name']")).clear();
			element(By.xpath("//input[@placeholder='Enter Name']")).sendKeys(updatedDesignParamter);

			element(By.xpath("//mat-cell[2]//mat-select")).click();
			Actions action10 = new Actions(getDriver());
			action10.moveToElement(element(By.xpath("//mat-option[1]"))).click().perform();

			try {
				Actions action11 = new Actions(getDriver());
				WebElement eleme = getDriver().findElement(By.xpath("//mat-cell//span[2]//button[@type='submit']"));
				action11.doubleClick(eleme).perform();
				waitForElementToDisappear(loader);
			} catch (Exception r) {
			}
		}
	}
	
	/********************************************************************
	 * Description:Select Function States
	 * Param: NA 
	 * Returns: void
	 * Status: Completed 
	 ********************************************************************/
	public void AddFunctionStates(String designParameterName) {
		if (!element(By.xpath(
				"//mat-cell[@class='plain-title-text mat-cell cdk-column-FunctionStateName mat-column-FunctionStateName ng-star-inserted']//span[contains(text(),'"
						+ designParameterName + "')]")).isCurrentlyVisible()) {

			element(By.xpath("//button//span[contains(text(),'Add New')]")).click();

			element(By.xpath("//mat-form-field//input[@name='name']")).sendKeys(designParameterName);

			element(By.xpath("//mat-select")).click();

			List<WebElement> DD = getDriver().findElements(By.xpath("//mat-option"));
			if (DD.size() > 1) {
				element(By.xpath("//mat-option[2]//span")).click();
				waitForElementToDisappear(loader);

				Actions Submit = new Actions(getDriver());
				Submit.moveToElement(element(By.xpath("//button[@type='submit']"))).click().perform();

			}

			else {
				try {
					Actions acti = new Actions(getDriver());
					WebElement ele = getDriver().findElement(By.xpath("//mat-icon[contains(text(),'more_vert')]"));
					acti.doubleClick(ele).perform();
					waitForElementToDisappear(loader);
				} catch (Exception e) {
					System.out.println("Exception handled");
				}

				element(By.xpath("//app-list-items//span[contains(text(),'Add')]")).click();

				element(By.xpath("//input[@name='category']")).sendKeys(designParameterName);

				element(By.xpath("//mat-icon[contains(text(),'done')]")).click();
				waitForElementToDisappear(loader);

				element(By.xpath("//input[@placeholder='Enter Name']")).sendKeys(designParameterName);

				Actions Submit = new Actions(getDriver());
				Submit.moveToElement(element(By.xpath("//button[@type='submit']"))).click().perform();
			}

		}
	}

	/********************************************************************
	 * Description:Verify Edited Function States
	 * Param: NA 
	 * Returns: void
	 * Status: Completed 
	 ********************************************************************/
	public boolean verifyEditedFunctionStates(String updatedDesignParameter) {
		 {
			if(element(By.xpath(
							"//mat-cell[@class='plain-title-text mat-cell cdk-column-FunctionStateName mat-column-FunctionStateName ng-star-inserted']//span[contains(text(),'"
									+ updatedDesignParameter + "')]")).isCurrentlyVisible())
					return true;
			else
				return false;
			
		}
	}
	
	/********************************************************************
	 * Description:Verify new Added Function States
	 * Param: NA 
	 * Returns: boolean
	 * Status: Completed 
	 ********************************************************************/
	public boolean verifyFunctionStates(String designParameterName) {
		if (element(By.xpath(
				"//mat-cell[@class='plain-title-text mat-cell cdk-column-FunctionStateName mat-column-FunctionStateName ng-star-inserted']//span[contains(text(),'"
						+ designParameterName + "')]")).isCurrentlyVisible())
			return true;
		else
			return false;
	}


	/********************************************************************
	 * Description:Enable and Disable Function States
	 * Param: NA 
	 * Returns: boolean
	 * Status: Completed 
	 ********************************************************************/
public void EnableDisableFunctionStates(String updatedDesignParamter, String updatedValue, String designParameterName) {
	if (!element(By.xpath("//mat-row//mat-cell[1]//span[contains(text(),'"
			+ 	updatedDesignParamter + "')]//..//..//mat-slide-toggle[@class='mat-slide-toggle mat-primary']"))
					.isCurrentlyVisible()) {
		
		Actions action4 = new Actions(getDriver());
		action4.moveToElement(element(By.xpath("//mat-row//mat-cell[1]//span[contains(text(),'" + updatedDesignParamter
				+ "')]//..//..//mat-slide-toggle[@class='mat-slide-toggle mat-primary mat-checked']"))).click().perform();
		waitForElementToDisappear(loader);

		element(By.xpath("//mat-row//mat-cell[1]//span[contains(text(),'" + updatedDesignParamter
				+ "')]//..//..//mat-slide-toggle[@class='mat-slide-toggle mat-primary']")).click();
		waitForElementToDisappear(loader);

	} else {
		element(By.xpath("//mat-row//mat-cell[1]//span[contains(text(),'" + updatedDesignParamter
				+ "')]//..//..//mat-slide-toggle[@class='mat-slide-toggle mat-primary']")).click();
		waitForElementToDisappear(loader);
	}

}


/********************************************************************
 * Description:Select Calibration
 * Param: NA 
 * Returns: void
 * Status: Completed 
 ********************************************************************/
public void SelectCalibrations() {
	try {
		element(By.xpath("//a[contains(text(),'Calibration')]")).click();
	} catch (Exception e) {
	}
}

/********************************************************************
 * Description: Add New Calibration
 * Param: NA 
 * Returns: void
 * Status: Completed 
 ********************************************************************/
public void AddCalibration(String designParameterName, String value, String metricUnitSystem, String uSUnitSystem,
		String number, String unitname) {
	if (!element(By.xpath(
			"//mat-cell[@class='plain-title-text mat-cell cdk-column-CalibrationName mat-column-CalibrationName ng-star-inserted']//span[contains(text(),'"+designParameterName+"')]"))
					.isCurrentlyVisible()) {

		element(addnewbutton).click();

		element(By.xpath("//mat-select[@aria-label='Select Calibration']")).click();

		List<WebElement> CD = getDriver().findElements(By.xpath("//mat-option"));

		if (CD.size() > 1) {
			element(By.xpath("//mat-option[2]//span")).click();
			waitForElementToDisappear(loader);
			element(By.xpath("//span[contains(text(),'Select Unit')]")).click();
			List<WebElement> UnitsCount = getDriver().findElements(By.xpath("//mat-option"));

			if (UnitsCount.size() > 1) {
				element(By.xpath("//mat-option[2]//span")).click();
				waitForElementToDisappear(loader);
				element(By.xpath("//input[@name='name']")).sendKeys(designParameterName);
				Actions action21 = new Actions(getDriver());
				action21.moveToElement(element(By.xpath("//button[@type='submit']"))).click().perform();
				waitForElementToDisappear(loader);
			}

			else {
				Actions act = new Actions(getDriver());
				WebElement elee = getDriver().findElement(By.xpath("//mat-icon[contains(text(),'more_vert')]"));
				act.doubleClick(elee).perform();
				waitForElementToDisappear(loader);

				element(By.xpath("//span[contains(text(),'Add New')]")).click();
				element(By.xpath("//input[@placeholder='Enter Metric Unit System']")).sendKeys(metricUnitSystem);
				element(By.xpath("//input[@placeholder='Enter US Unit System']")).sendKeys(uSUnitSystem);
				element(By.xpath("//input[@placeholder='Additive']")).sendKeys(number);
				element(By.xpath("//input[@placeholder='Subractive']")).sendKeys(number);
				element(By.xpath("//input[@placeholder='Multiplicative']")).sendKeys(number);
				element(By.xpath("//input[@placeholder='Division']")).sendKeys(number);
				Actions action = new Actions(getDriver());
				action.moveToElement(element(By.xpath("//button[@type='submit']"))).click().perform();
				waitForElementToDisappear(loader);

				getDriver().navigate().back();
				waitForElementToDisappear(loader);

				element(addnewbutton).click();

				element(By.xpath("//input[@name='name']")).sendKeys(designParameterName);
				element(By.xpath("//mat-select[@aria-label='Select Calibration']")).click();
				element(By.xpath("//mat-option[2]//span")).click();
				waitForElementToDisappear(loader);
				element(By.xpath("//span[contains(text(),'Select Unit')]")).click();
				element(By.xpath("//mat-option[2]//span")).click();
				waitForElementToDisappear(loader);
				Actions action22 = new Actions(getDriver());
				action22.moveToElement(element(By.xpath("//button[@type='submit']"))).click().perform();
				waitForElementToDisappear(loader);
			}

		}
	}}

/********************************************************************
 * Description: Verify New Added Calibration
 * Param: NA 
 * Returns: boolean
 * Status: Completed 
 ********************************************************************/
public boolean verifyCalibration(String designParameterName) {
	if (element(By.xpath(
			"//mat-cell[@class='plain-title-text mat-cell cdk-column-CalibrationName mat-column-CalibrationName ng-star-inserted']//span[contains(text(),'"
					+ designParameterName + "')]")).isCurrentlyVisible())
		return true;
	else
		return false;
}


/********************************************************************
 * Description: Edit added Calibration
 * Param: NA 
 * Returns: boolean
 * Status: Completed 
 ********************************************************************/
public void EditCalibration(String updatedDesignParamter, String updatedValue, String designParameterName) {

	if (element(By.xpath(
			"//mat-cell[@class='plain-title-text mat-cell cdk-column-CalibrationName mat-column-CalibrationName ng-star-inserted']//span[contains(text(),'"
					+ designParameterName + "')]")).isCurrentlyVisible()
			&& !element(By.xpath(
					"//mat-cell[@class='plain-title-text mat-cell cdk-column-CalibrationName mat-column-CalibrationName ng-star-inserted']//span[contains(text(),'"
							+ updatedDesignParamter + "')]")).isCurrentlyVisible()) {
		element(By.xpath(
				"//mat-cell[@class='plain-title-text mat-cell cdk-column-CalibrationName mat-column-CalibrationName ng-star-inserted']//span[contains(text(),'"
						+ designParameterName + "')]//..//..//mat-icon[@class='edit-icon mat-icon material-icons']"))
								.click();
		waitForElementToDisappear(loader);

		element(By.xpath("//div//input[@placeholder='Enter Name']")).clear();
		element(By.xpath("//div//input[@placeholder='Enter Name']")).sendKeys(updatedDesignParamter);

		element(By.xpath("//mat-form-field[2]//..//mat-form-field[1]//div[@class='mat-select-arrow-wrapper']")).click();
		element(By.xpath("//mat-option[1]//span")).click();
		
		try {
			Actions actionfr = new Actions(getDriver());
			actionfr.moveToElement(element(By.xpath("//mat-form-field[2]//..//mat-form-field[2]//div[@class='mat-select-arrow-wrapper']"))).click().perform();
			
			Actions actionhf = new Actions(getDriver());
			actionhf.moveToElement(element(By.xpath("//mat-option[1]//span"))).click().perform();
			
		} catch (Exception e) {
			System.out.println("Exception handled");
		}
		
		try {
			Actions actionf = new Actions(getDriver());
			actionf.moveToElement(element(By.xpath("//mat-cell[3]//mat-select"))).click().perform();
			
			Actions actionff = new Actions(getDriver());
			actionff.moveToElement(element(By.xpath("//mat-option[1]//span"))).click().perform();
			
		} catch (Exception e) {
			System.out.println("Exception handled");
		}

		try {
			Actions Done = new Actions(getDriver());
			WebElement done = getDriver().findElement(By.xpath("//button//span//mat-icon[contains(text(),'done')]"));
			Done.doubleClick(done).perform();
			waitForElementToDisappear(loader);
		} catch (Exception e) {
			System.out.println("Exception handled");
		}
	}
}

/********************************************************************
 * Description: Verify Edited Calibration
 * Param: NA 
 * Returns: boolean
 * Status: Completed 
 ********************************************************************/
public boolean verifyEditedCalibration(String updatedDesignParameter) {
	{
		if (element(By.xpath(
				"//mat-cell[@class='plain-title-text mat-cell cdk-column-CalibrationName mat-column-CalibrationName ng-star-inserted']//span[contains(text(),'"
						+ updatedDesignParameter + "')]")).isCurrentlyVisible())
			return true;
		else
			return false;

	}
}

/********************************************************************
 * Description: Enable and Disable Calibration
 * Param: NA 
 * Returns: 
 * Status: Completed 
 ********************************************************************/
public void EnableDisableCalibrations(String updatedDesignParamter, String designParameterName) {
	if (!element(By.xpath("//mat-row//mat-cell[1]//span[contains(text(),'" + updatedDesignParamter
			+ "')]//..//..//mat-slide-toggle[@class='mat-slide-toggle mat-primary']")).isCurrentlyVisible()) {

		Actions action4 = new Actions(getDriver());
		action4.moveToElement(element(By.xpath("//mat-row//mat-cell[1]//span[contains(text(),'" + updatedDesignParamter
				+ "')]//..//..//mat-slide-toggle[@class='mat-slide-toggle mat-primary mat-checked']"))).click()
				.perform();
		waitForElementToDisappear(loader);

		element(By.xpath("//mat-row//mat-cell[1]//span[contains(text(),'" + updatedDesignParamter
				+ "')]//..//..//mat-slide-toggle[@class='mat-slide-toggle mat-primary']")).click();
		waitForElementToDisappear(loader);

	} else {
		element(By.xpath("//mat-row//mat-cell[1]//span[contains(text(),'" + updatedDesignParamter
				+ "')]//..//..//mat-slide-toggle[@class='mat-slide-toggle mat-primary']")).click();
		waitForElementToDisappear(loader);
	}

}
/*******************************************************************
* Description: Select SubSystem Param: NA Returns: void Status: Completed
********************************************************************/
public void SelectSubsystems(String susbsystemName) {

element(By.xpath("//a[contains(text(),'" + susbsystemName + "')]")).click();

}

/********************************************************************
 * Description:Verify Configuration page Param: NA Returns: void Status:
 * Completed
 *
 * @param
 ********************************************************************/
public boolean verifyConfigPage(String ExpConfigURL) {
	String ActualConfigURL = getDriver().getCurrentUrl();
	if (ActualConfigURL.equals(ExpConfigURL))
		return true;
	else
		return false;
}





}