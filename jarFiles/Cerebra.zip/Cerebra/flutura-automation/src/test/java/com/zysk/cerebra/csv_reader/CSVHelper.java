package com.zysk.cerebra.csv_reader;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

public class CSVHelper {
	
	//private static String baseCsvFilePath = "src/test/resources/dataSources/";
	private static String path = "src/test/resources/dataSources/cerebraData.csv";
	private static HashMap<String,String> data;
	
   
   public static void loadCSV(String target) {

	   data = new HashMap<String, String>();
	   String line;
	   String [] split;

	   target = path;
	   
	   try (BufferedReader br = new BufferedReader(new FileReader(target))) {

	   System.out.println("Reading from " + target);
	   while ((line = br.readLine()) != null) {
	   split = line.split(",");
	   String key = split[0];
	   String value = split[1];

	   if (System.getProperty(key) != null) {
	   value = System.getProperty(key);
	   System.out.println("Overriding key '" + key + "' with value '" + value + "'");
	   }

	   data.put(key,value);
	   }

	   } catch (IOException e) {
	   System.out.println("\n***** ERROR: CSV not found. *****\n");
	   }

	   }

   public static String getKey(String key) {

	   if (data == null) loadCSV(path);

	   if (data.get(key) == null) return "ERROR: Key not found";

	   return data.get(key);

	   }
	
	public static String getLoginEmail()
	{
		System.out.println("Fetched login email");
		return getKey("loginEmail");
	}
	
	public static String getLoginPassword()
	{
		System.out.println("Fetched pw");
		return getKey("loginPassword");
	}
	

   public static String getDesignParameterTab()
	{
		return getKey("designParameterTab");
	}
	
	public static String getMeasurementTab()
	{
		return getKey("measurementTab");
	}
	
	public static String getAlarmTab()
	{
		return getKey("alarmTab");
	}
	
	public static String getTripTab()
	{
		return getKey("tripTab");
	}
	
	public static String getFaultsTab()
	{
		return getKey("faultTab");
	}
	
	public static String getFunctionStatesTab()
	{
		return getKey("functionStatesTab");
	}
	
	public static String getCalibrationTab()
	{
		return getKey("calibrationTab");
	}
	
	public static String getStaticPath()
	{
		return getKey("staticFilePath");
	}
	
	public static String getBaseUrl()
	{
		return getKey("baseUrl");
	}
	
	public static String getCDUrl()
	{
		return getKey("configurationURL");
	}
}