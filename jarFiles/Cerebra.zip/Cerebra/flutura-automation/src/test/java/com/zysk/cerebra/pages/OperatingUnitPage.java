package com.zysk.cerebra.pages;

import com.zysk.cerebra.commonPages.CommonFunctions;
import com.zysk.cerebra.csv_reader.CSVHelper;

import cucumber.api.java.en.When;

import java.util.List;

import org.fluentlenium.core.wait.FluentWait;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.WebDriver;

public class OperatingUnitPage extends CommonFunctions{

	/***********************Page element identifiers******************************/
	private By operatingUnit = By.xpath("//a[contains(text(),'Operating Unit')]");
	private By customerList = By.xpath("//div[@class='row']//a");
	private By searchfield = By.xpath("//span[@class='search-bar']");
	private By addNew = By.xpath("//span[contains(text(),'Add New')]");
	private By ouName = By.xpath("//input[@formcontrolname='name']");
	private By ouNumber = By.xpath("//input[@formcontrolname='serial_no']");
	private By deploymentDate = By.xpath("//input[@formcontrolname='deployment_date']");
	private By manufacturedDate = By.xpath("//input[@formcontrolname='manufacture_date']");
	private By selectGateway = By.xpath("//div[@class='mat-select-value']");
	private By add = By.xpath("//button[@type='submit']//span[contains(text(),'Add')]");
	private By model = By.xpath("//mat-select[@formcontrolname='child_id']");
	private By gateway = By.xpath("//mat-select[@formcontrolname='gateway_id']");
	private By countField = By.xpath("//input[@formcontrolname='count']");
	private By updateButton = By.xpath("//button[contains(text(),'Yes, update it!')]");
	private By operatingUnitTab = By.xpath("//button//span[contains(text(),'Operating Units')]");
	private By deleteConfirmation = By.xpath("//button[contains(text(),'Yes, delete it!')]");
	private By parameterNameField = By.xpath("//input[@id='name']");
	private By parameterDropdown = By.xpath("//mat-select[@id='parameter']");
	private By selectUnitDropdown = By.xpath("//span[contains(text(),'Select Unit')]");
	private By metricDropdown = By.xpath("//mat-select[@aria-label='Select Metric']");
	private By parameterNameEditField = By.xpath("//input[@placeholder='Enter Name']");
	private By severityField = By.xpath("//mat-select[@aria-label='Select Severity']");
	private By relatedMeasurementField = By.xpath("//mat-select[@aria-label='Select Related Measurement']");
	private By recommendation = By.xpath("//textarea");
	private By valueField =By.xpath("//input[@placeholder='Enter Value']");
	private By submitButton = By.xpath("//button[@type='submit']");
	private By expandIcon = By.xpath("//mat-icon[contains(text(),'chevron_right')]");
	private By addButton = By.xpath("//button//span[text()=' Add ']");
	private By dialogBox = By.xpath("//div[@role='dialog']");

	
	
	/********************************************************************
	* Description: Select Operating Unit
	* Param: NA
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void selectOperatingUnit()
	{
		element(operatingUnit).click();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verify customer page
	* Param: expUrl
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public boolean verifyCustomerPage(String expUrl)
	{
		String actUrl = getDriver().getCurrentUrl();
		System.out.println("1"+actUrl.contains(expUrl));
		System.out.println("2"+element(customerList).isCurrentlyVisible());
		System.out.println("3"+element(searchfield).isCurrentlyVisible());
		if (actUrl.contains(expUrl) && 
				element(customerList).isCurrentlyVisible() &&
				element(searchfield).isCurrentlyVisible())
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Select customer
	* Param: customer
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void selectCustomer(String customer)
	{
		element(By.xpath("//a[text()='"+customer+"']")).click();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verify Model list
	* Param: modelUrl
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyModelList(String modelUrl)
	{
		String actUrl = getDriver().getCurrentUrl();
		System.out.println("4"+actUrl.contains(modelUrl));
		System.out.println("5"+element(searchfield).isCurrentlyVisible());
		System.out.println("6"+element(By.xpath("//ngx-masonry//div[@class='masonry-item dx-test-group mt-3 ng-star-inserted']")).isCurrentlyVisible());
		if(actUrl.contains(modelUrl) &&
				element(searchfield).isCurrentlyVisible() &&
				element(By.xpath("//ngx-masonry//div[@class='masonry-item dx-test-group mt-3 ng-star-inserted']")).isCurrentlyVisible())
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Select Model to add operating Unit
	* Param: Model
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void selectModelToAddOperatingUnit(String Model)
	{
		element(By.xpath("//div[text()='"+Model+"']")).click();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Add Operating Unit
	* Param: operatingUnitName,operatingUnitNumber,date,gateway
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void addOperatingUnit(String operatingUnitName,String operatingUnitNumber,String date,String gateway)
	{
	    element(addNew).click();	
	    waitForElementToDisappear(loader);
	    element(ouName).sendKeys(operatingUnitName);
	    element(ouNumber).sendKeys(operatingUnitNumber);
	    element(manufacturedDate).sendKeys(date);
	    element(selectGateway).click();
	    waitSeconds(2);
	    List<WebElement> l1 = getDriver().findElements(By.xpath("//div//mat-option//span"));
	    int s1 = l1.size();
	    for(int i=1;i<s1;i++)
	    {
	    	if(l1.get(i).getText().contains(gateway))
	    	{
	    		l1.get(i).click();
	    	}
	    		
	    }
	    element(add).click();
	    waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verify the added operating unit
	* Param: operatingUnitName,operatingUnitNumber,date,gateway
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyOperatingUnit(String OUName)
	{
		if(element(By.xpath("//a[contains(text(),'"+OUName+"')]")).isCurrentlyVisible())
			return true;
		else return false;
	}
	
//	/********************************************************************
//	* Description: Select the operating unit to add subsystem
//	* Param: operatingUnitName,operatingUnitNumber,date,gateway
//	* Returns: Boolean
//	* Status: Completed
//	********************************************************************/
//	public void selectOperatingUnitToAddSubsystem(String models)
//	{
//		element(By.xpath("//div[contains(text(),'"+models+"')]")).click();
//		waitForElementToDisappear(loader);
//	}
//	
	
	/********************************************************************
	* Description: Add subsystem for Operating unit
	* Param: parentUnit,childModel,count
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void addSubsystemForOperatinUnit(String parentUnit,String childModel,String count,String gatewaySelection)
	{
		while(element(expandIcon).isCurrentlyVisible()){
			
			element(expandIcon).click();
		}
		element(By.xpath("//a[contains(text(),'"+parentUnit+"')]/../../..//mat-icon[contains(text(),'add')]")).click();
		element(model).click();
		waitForElementToAppear(By.xpath("//mat-option//span"));
		List<WebElement> l1 = getDriver().findElements(By.xpath("//mat-option//span"));
		int s1 = l1.size();
		try {
		for(int i=0; i<=s1; i++)
		{
			if(l1.get(i).getText().contains(childModel))
			{
				l1.get(i).click();
				//getJavascriptExecutor().executeScript("document.querySelector('.mat-option-text').click();");
			}
		}
		}
		catch(Exception e)
		{
			System.out.println("Exception Handled");
		}
		waitForElementToAppear(By.xpath("//div[@class='mat-select-trigger']//span[contains(text(),'"+childModel+"')]"));
		waitSeconds(4);
		Actions act2 = new Actions(getDriver());
		act2.moveToElement(element(gateway)).click().build().perform();
		List<WebElement> l2 = getDriver().findElements(By.xpath("//mat-option//span"));
		int s2 = l2.size();
	    try {
		for(int i=0; i<=s2; i++)
		{
			if(l2.get(i).getText().trim().equals(gatewaySelection))
			{
				System.out.println("inside loop");
				waitSeconds(3);
				l2.get(i).click();
				break;
			}
		}
		}
		catch(StaleElementReferenceException e)
		{
			System.out.println("Exception Handled");
		}
		element(countField).sendKeys(count);
		element(By.xpath("//button[@type='button']//span[contains(text(),'Add')]")).click();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verify the added operating unit
	* Param: childModel
	* Returns: void
	* Status: Completed
	********************************************************************/
	public boolean verifyAddedOperatingUnit(String childModel)
	{
        while(element(expandIcon).isCurrentlyVisible()){
			
			element(expandIcon).click();
		}
		//element(By.xpath("//a[contains(text(),'"+parentUnit+"')]/../../../..//mat-icon[contains(text(),'chevron_right')]")).click();
		boolean result = false;
        if(element(By.xpath("//a[contains(text(),'"+childModel+"')]")).isCurrentlyVisible())
		{
			List<WebElement> l1 = getDriver().findElements(By.xpath("//a[contains(text(),'"+childModel+"')]"));
			int s1= l1.size();
			System.out.println(s1);
			if(s1>=1)
			{
		result = true;
			}
			else result = false;
		}
        System.out.println(result);
		return result;
	}
	
	/********************************************************************
	* Description: Reassign customer
	* Param: operatingUnit,customer
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void reassignOperatingUnitToAnotherCustomer(String operatingUnit,String customer)
	{
		element(By.xpath("//a[contains(text(),'"+operatingUnit+"')]/..//span//span[contains(text(),'Re-Assign Customer')]")).click();
		waitForElementToDisappear(loader);
		waitSeconds(2);
		Actions act1 = new Actions(getDriver());
		act1.moveToElement(element(By.xpath("//p[contains(text(),'"+customer+"')]/../..//div[@class='mat-radio-outer-circle']"))).click().perform();
		//element(By.xpath("//p[contains(text(),'"+customer+"')]")).click();
//		element(updateButton).click();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verify the operating unit for the reassigned customer
	* Param: operatingUnit,customer,Model
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyReassignedOperatingUnit(String customer,String Model,String operatingUnit)
	{
		element(By.xpath("//span[contains(text(),'Customers')]")).click();
		waitForElementToDisappear(loader);
		element(By.xpath("//a[contains(text(),'"+customer+"')]")).click();
		selectModelToAddOperatingUnit(Model);
		if (element(By.xpath("//a[contains(text(),'"+operatingUnit+"')]")).isCurrentlyVisible())
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Disable the operating unit
	* Param: operatingUnit
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void disableOperatingUnit(String operatingUnit)
	{
        while(element(expandIcon).isCurrentlyVisible()){
			
			element(expandIcon).click();
		}
       // Actions act3 = new Actions(getDriver());
        if (element(By.xpath("//a[contains(text(),'"+operatingUnit+"')]/..//span[contains(text(),'Disable')]")).isCurrentlyVisible()){
        	element(By.xpath("//a[contains(text(),'"+operatingUnit+"')]/..//span[contains(text(),'Disable')]")).click();
        	element(updateButton).click();
        	waitForElementToDisappear(loader);
        }
        else {
        	if(element(By.xpath("//a[contains(text(),'"+operatingUnit+"')]/..//mat-icon[@class='toggle-icon mat-icon toggle-enable material-icons']")).isCurrentlyVisible()) {
        	element(By.xpath("//a[contains(text(),'"+operatingUnit+"')]/..//mat-icon[@class='toggle-icon mat-icon toggle-enable material-icons']")).click();
        	element(updateButton).click();
        	waitForElementToDisappear(loader);
        	}
        }
        
        
        //
        //String s = (String) getJavascriptExecutor().executeScript("return document.querySelector('.mat-input-element').value");
        
	}
	
	/********************************************************************
	* Description: Verify the disabled operating unit
	* Param: operatingUnit
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyDisabledOperatingUnit(String operatingUnit)
	{
		boolean result = false;
		boolean result1 = false;
		if (element(By.xpath("//a[contains(text(),'"+operatingUnit+"')]/..//mat-icon[@class='toggle-icon mat-icon toggle-disable material-icons']")).isCurrentlyVisible())
		{
			String actText = element(By.xpath("//a[contains(text(),'"+operatingUnit+"')]/..//mat-icon[@class='toggle-icon mat-icon toggle-disable material-icons']")).getText();
			String expText = "toggle_off";
			System.out.println("ActText"+actText);
			if(actText.equals(expText))
				result = true;
			System.out.println("Disable1"+result);
		}
		else 
			{
			if(element(By.xpath("//a[contains(text(),'"+operatingUnit+"')]/..//span[contains(text(),'Enable')]")).isCurrentlyVisible())
			{
				String actText1 = element(By.xpath("//a[contains(text(),'"+operatingUnit+"')]/..//span[contains(text(),'Enable')]")).getText();
				String expText1 = " Enable ";
				if(actText1.equals(expText1))
					result1 = true;
				System.out.println("Disable2"+result1);
			}
			}
		System.out.println(result==true || result1==true);
		if (result==true || result1==true)
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Enable the operating unit
	* Param: operatingUnit
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void enableOperatingUnit(String operatingUnit)
	{
        while(element(expandIcon).isCurrentlyVisible()){
			element(expandIcon).click();
		}
        if (element(By.xpath("//a[contains(text(),'"+operatingUnit+"')]/..//span[contains(text(),'Enable')]")).isCurrentlyVisible()){
        	element(By.xpath("//a[contains(text(),'"+operatingUnit+"')]/..//span[contains(text(),'Enable')]")).click();
        	element(updateButton).click();
        	waitForElementToDisappear(loader);
        }
        else {
        	if(element(By.xpath("//a[contains(text(),'"+operatingUnit+"')]/..//mat-icon[@class='toggle-icon mat-icon toggle-disable material-icons']")).isCurrentlyVisible()) {
        	element(By.xpath("//a[contains(text(),'"+operatingUnit+"')]/..//mat-icon[@class='toggle-icon mat-icon toggle-disable material-icons']")).click();
        	element(updateButton).click();
        	waitForElementToDisappear(loader);
        	}
        }
	}
	
	/********************************************************************
	* Description: Verify the enabled operating unit
	* Param: operatingUnit
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyEnabledOperatingUnit(String operatingUnit)
	{
		boolean result = false;
		boolean result1 = false;
		if (element(By.xpath("//a[contains(text(),'"+operatingUnit+"')]/..//mat-icon[@class='toggle-icon mat-icon toggle-enable material-icons']")).isCurrentlyVisible())
		{
			String actText = element(By.xpath("//a[contains(text(),'"+operatingUnit+"')]/..//mat-icon[@class='toggle-icon mat-icon toggle-enable material-icons']")).getText();
			String expText = "toggle_on";
			System.out.println("ActText"+actText);
			if(actText.equals(expText))
				result = true;
			System.out.println("Disable1"+result);
		}
		else 
			{
			if(element(By.xpath("//a[contains(text(),'"+operatingUnit+"')]/..//span[contains(text(),'Disable')]")).isCurrentlyVisible())
			{
				String actText1 = element(By.xpath("//a[contains(text(),'"+operatingUnit+"')]/..//span[contains(text(),'Disable')]")).getText();
				String expText1 = "Disable";
				if(actText1.equals(expText1))
					result1 = true;
				System.out.println("Disable2"+result1);
			}
			}
		System.out.println(result==true || result1==true);
		if (result==true || result1==true)
			return true;
		else return false;
	}

	/********************************************************************
	* Description: Update the operating unit
	* Param: updateOUName,updateOUNumber,manuDate,deployDate,updateGateway
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void updateOperatingUnit(String OUToEdit,String updateOUName,String updateOUNumber,String manuDate,String deployDate,String updateGateway)
	{
        while(element(expandIcon).isCurrentlyVisible()){
			
			element(expandIcon).click();
		}
        element(By.xpath("//a[contains(text(),'"+OUToEdit+"')]")).click();
        waitForElementToDisappear(loader);
		element(ouName).clear();
		element(ouName).sendKeys(updateOUName);
		element(ouNumber).clear();
		element(ouNumber).sendKeys(updateOUNumber);
		element(manufacturedDate).clear();
		element(manufacturedDate).sendKeys(manuDate);
		
		if(element(deploymentDate).getAttribute("value").isEmpty())
		{
		element(deploymentDate).sendKeys(deployDate);
		}else
		{
			element(deploymentDate).clear();
			element(deploymentDate).sendKeys(deployDate);
		}
			
		element(selectGateway).click();
		List<WebElement> l1 = getDriver().findElements(By.xpath("//mat-option//span"));
		int s1 = l1.size();
		for(int i=1 ;i<s1;i++)
		{
			if(l1.get(i).getText().contains(updateGateway))
			{
				l1.get(i).click();
			}
		}
		element(By.xpath("//button//span[contains(text(),'Update')]")).click();
        waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verify the updated operating unit
	* Param: updateOUName,updateOUNumber,manuDate,deployDate,updateGateway
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public boolean verifyUpdatedOperatingUnit(String updatedOUName)
	{
		element(operatingUnitTab).click();
		waitForElementToDisappear(loader);
        while(element(By.xpath("//mat-icon[contains(text(),'chevron_right')]")).isCurrentlyVisible()){
			
			element(By.xpath("//mat-icon[contains(text(),'chevron_right')]")).click();
		}
        if(element(By.xpath("//a[contains(text(),'"+updatedOUName+"')]")).isCurrentlyVisible())
        	return true;
        else return false;
	}
	
	/********************************************************************
	* Description: Select operating unit to verify details
	* Param: operatingUnit
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void selectOperatingUnitToViewTheDetails(String operatingUnit)
	{
        while(element(expandIcon).isCurrentlyVisible()){
			
			element(expandIcon).click();
		}
		element(By.xpath("//a[contains(text(),'"+operatingUnit+"')]")).click();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verify details
	* Param: operatingUnitName,operatingUnitNumber,manuDate
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public boolean verifyOperatingUnitDetailsPage(String operatingUnitName,String operatingUnitNumber,String manuDate)
	{
		System.out.println("name"+element(ouName).getAttribute("value"));
		System.out.println("number"+element(ouNumber).getAttribute("value"));
		System.out.println("manudate"+element(manufacturedDate).getAttribute("value"));
		System.out.println(element(By.xpath("//span[contains(text(),'Details')]")).isCurrentlyVisible());
		System.out.println(element(ouName).getAttribute("value").equals(operatingUnitName));
		System.out.println(element(ouNumber).getAttribute("value").equals(operatingUnitNumber));
		System.out.println(element(manufacturedDate).getAttribute("value").equals(manuDate));
		//System.out.println("deplodate"+element(deploymentDate).getAttribute("value"));
		if(element(By.xpath("//span[contains(text(),'Details')]")).isCurrentlyVisible() &&
				element(ouName).getAttribute("value").equals(operatingUnitName) &&
				element(ouNumber).getAttribute("value").equals(operatingUnitNumber) &&
				element(manufacturedDate).getAttribute("value").equals(manuDate))
			return true;
		else return false;
		
	}
	
	/********************************************************************
	* Description: Delete the operating Unit
	* Param: operatingUnit
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void deleteOperatingUnit(String operatingUnit)
	{
        while(element(expandIcon).isCurrentlyVisible()){
			
			element(expandIcon).click();
		}
        
        //if(element(By.xpath("//a[contains(text(),'"+operatingUnit+"')]/..//mat-icon[contains(text(),'delete')]")).isCurrentlyVisible())
        element(By.xpath("//a[contains(text(),'"+operatingUnit+"')]/..//mat-icon[contains(text(),'delete')]")).click();
        element(deleteConfirmation).click();
        waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Delete the operating Unit
	* Param: OperatingUnit
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public boolean verifyDeletedOperatingUnit(String operatingUnit)
	{
       while(element(expandIcon).isCurrentlyVisible()){
			element(expandIcon).click();
		}
       if(element(By.xpath("//a[contains(text(),'"+operatingUnit+"')]")).isCurrentlyVisible())
    	   return false;
       else return true;
	}
	
	/********************************************************************
	* Description: Select operating Unit to add parameter
	* Param: Operating Unit
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void selectOperatingUnitToAddOperatingUnit(String operatingUnit)
	{
		while(element(expandIcon).isCurrentlyVisible()){
			element(expandIcon).click();
		}
		element(By.xpath("//a[contains(text(),'"+operatingUnit+"')]")).click();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Add Measurement parameter
	* Param: tabName,measurementName,measurementParameter,metricOption,unit
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void addMeasurementParameter(String tabName,String measurementName,String measurementParameter,String metricOption,String unit,String prioritySelection)
	{
		element(By.xpath("//a[contains(text(),'"+tabName+"')]")).click();
		waitForElementToDisappear(loader);
		element(addNew).click();
		waitForElementToDisappear(loader);
		element(parameterNameField).sendKeys(measurementName);
		element(parameterDropdown).click();
		List<WebElement> l1 = getDriver().findElements(By.xpath("//div//mat-option//span"));
		int s1 = l1.size();
		for (int i=1;i<s1;i++)
		{
			if(l1.get(i).getText().contains(measurementParameter))
				l1.get(i).click();
		}
		waitSeconds(3);
		Actions act = new Actions(getDriver());
		
		act.moveToElement(element(metricDropdown)).click().build().perform();
		List<WebElement> l2 = getDriver().findElements(By.xpath("//div//mat-option//span"));
		int s2 = l2.size();
		for(int j=1;j<s2;j++)
		{
			if(l2.get(j).getText().contains(metricOption))
				l2.get(j).click();
		}
		waitSeconds(3);
		element(selectUnitDropdown).click();
		List<WebElement> l3 = getDriver().findElements(By.xpath("//div//mat-option//span"));
		int s3 = l3.size();
		for(int k=1;k<s3;k++)
		{
			if(l3.get(k).getText().contains(unit))
				l3.get(k).click();
		}
		
		if (prioritySelection.equals("yes")) {
			element(By.xpath("//div[@class='mat-checkbox-inner-container']")).click();
		}
		element(add).click();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verify Measurement parameter added
	* Param: tabName,measurementName,measurementParameter,metricOption,unit
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public boolean verifyMeasurementParameterAdded(String measurementName,String unit,String prioritySelection)
	{
		boolean result = false;
		if(prioritySelection.equals("yes")) 
		{
			String actcheckboxStatus = element(By.xpath("//span[contains(text(),'"+measurementName+"')]/../..//input[@name='priority_flag']")).getAttribute("aria-checked");
			String expcheckboxStatus = "true";
		if(element(By.xpath("//span[contains(text(),'"+measurementName+"')]")).isCurrentlyVisible() &&
				element(By.xpath("//span[contains(text(),'"+measurementName+"')]/../..//span[contains(text(),'"+unit+"')]")).isCurrentlyVisible() &&
				actcheckboxStatus.equals(expcheckboxStatus))
			result = true;
		else result = false;
		}
		else
		{
			String actcheckboxStatus = element(By.xpath("//span[contains(text(),'"+measurementName+"')]/../..//input[@name='priority_flag']")).getAttribute("aria-checked");
			String expcheckboxStatus = "false";
		if(element(By.xpath("//span[contains(text(),'"+measurementName+"')]")).isCurrentlyVisible() &&
				element(By.xpath("//span[contains(text(),'"+measurementName+"')]/../..//span[contains(text(),'"+unit+"')]")).isCurrentlyVisible() &&
				actcheckboxStatus.equals(expcheckboxStatus))
			result = true;
		else result = false;
			
		}
			return result;
	}
	
	/********************************************************************
	* Description: Add parameter for Alarm,Trips,Faults,FUnction states
	* Param: tabName,parameterName,parameterSelection
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void addParameter(String tabName,String parameterName, String parameterSelection)
	{
		element(By.xpath("//a[contains(text(),'"+tabName+"')]")).click();
		waitForElementToDisappear(loader);
		element(addNew).click();
		waitForElementToDisappear(loader);
		element(parameterNameField).sendKeys(parameterName);
		element(parameterDropdown).click();
		List<WebElement> l1 = getDriver().findElements(By.xpath("//div//mat-option//span"));
		int s1 = l1.size();
		for(int i=1;i<s1;i++)
		{
			if(l1.get(i).getText().equals(parameterSelection))
				l1.get(i).click();
		}
		element(add).click();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verify the parameter added
	* Param: tabName
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public boolean verifyParameterAdded(String parameterName)
	{
		if(element(By.xpath("//span[contains(text(),'"+parameterName+"')]")).isCurrentlyVisible())
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Add parameter for Calibration
	* Param: tabName,parameterName,parameterSelection
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void addParameterforCalibration(String tabName, String parameterName,String value,String parameterSelection,String metricSelection,String unit)
	{
		element(By.xpath("//a[contains(text(),'"+tabName+"')]")).click();
		waitForElementToDisappear(loader);
		element(addNew).click();
		waitForElementToDisappear(loader);
		element(parameterNameField).sendKeys(parameterName);
		element(By.xpath("//input[@id='value']")).sendKeys(value);
		element(parameterDropdown).click();
		List<WebElement> l1 = getDriver().findElements(By.xpath("//div//mat-option//span"));
		int s1 = l1.size();
		for(int i=1; i<s1;i++)
		{
			if(l1.get(i).getText().equals(parameterSelection))
				l1.get(i).click();
		}
		waitSeconds(3);
		element(metricDropdown).click();
		List<WebElement> l2 = getDriver().findElements(By.xpath("//div//mat-option//span"));
		int s2 = l2.size();
		for(int i=1; i<s2;i++)
		{
			if(l2.get(i).getText().equals(metricSelection))
				l2.get(i).click();
		}
		waitSeconds(3);
		element(selectUnitDropdown).click();
		List<WebElement> l3 = getDriver().findElements(By.xpath("//div//mat-option//span"));
		int s3 = l3.size();
		for(int i=1; i<s3;i++)
		{
			if(l3.get(i).getText().equals(unit))
				l3.get(i).click();
		}
		waitSeconds(3);
		Actions act = new Actions(getDriver());
		act.moveToElement(element(add)).click().build().perform();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Edit parameter for Measurement
	* Param: parameterName,editParameter,metricSelection,unitOfMeasurement,LCLvalue,UCLvalue,minRange,maxRange,tagId,aggregator
	* Returns: Void
	* Status: Completed
	********************************************************************/
	
	public void editParameterForMeasurement(String tabName,String parameterName,String editParameter,String metricSelection,String unitOfMeasurement,String LCLvalue,String UCLvalue,String minRange,String maxRange,String tagId,String aggregator,String priorityFlag,String visibilityFlag)
	{
		element(By.xpath("//a[contains(text(),'"+tabName+"')]")).click();
		waitForElementToDisappear(loader);
		element(By.xpath("//span[contains(text(),'"+parameterName+"')]/../..//mat-icon[@class='edit-icon mat-icon material-icons']")).click();
		element(parameterNameEditField).clear();
		element(parameterNameEditField).sendKeys(editParameter);
		element(By.xpath("(//mat-select[@aria-label='Select Unit of Measurement'])[1]")).click();
		List<WebElement> l1 = getDriver().findElements(By.xpath("//div//mat-option//span"));
		waitSeconds(2);
		int s1 = l1.size();
		try {
		for(int i=0; i<s1;i++)
		{
			if(l1.get(i).getText().equals(metricSelection)) l1.get(i).click();
			waitForElementToDisappear(loader);
		}
		}
		catch(Exception e)
		{
			System.out.println("Exception found");
		}
		waitSeconds(4);
		element(By.xpath("(//mat-select[@aria-label='Select Unit of Measurement']//div[@class='mat-select-value'])[2]")).click();
		List<WebElement> l2 = getDriver().findElements(By.xpath("//div//mat-option//span"));
		int s2 = l2.size();
		System.out.println("Size=="+s2);
		for(int i=0;i<s2;i++)
		{
			if(l2.get(i).getText().equals(unitOfMeasurement))
							l2.get(i).click();
		}
		waitSeconds(3);
		element(By.xpath("//input[@placeholder='Enter LCL']")).clear();
		element(By.xpath("//input[@placeholder='Enter LCL']")).sendKeys(LCLvalue);
		element(By.xpath("//input[@placeholder='Enter UCL']")).clear();
		element(By.xpath("//input[@placeholder='Enter UCL']")).sendKeys(UCLvalue);
		element(By.xpath("//input[@placeholder='Enter Signal Range(Min)']")).clear();
		element(By.xpath("//input[@placeholder='Enter Signal Range(Min)']")).sendKeys(minRange);
		element(By.xpath("//input[@placeholder='Enter Signal Range(Max)']")).clear();
		element(By.xpath("//input[@placeholder='Enter Signal Range(Max)']")).sendKeys(maxRange);
		element(By.xpath("//input[@placeholder='Enter TagId']")).clear();
		element(By.xpath("//input[@placeholder='Enter TagId']")).sendKeys(tagId);
		waitSeconds(5);
		String actStatus = element(By.xpath("//input[@placeholder='Enter Name']/../../../../../../..//input[@type='checkbox' and @name='priority_flag']")).getAttribute("aria-checked");
		System.out.println("Status1"+actStatus);
		if(actStatus.equals("false") && priorityFlag.equals("ON"))
		{
			Actions act = new Actions(getDriver());
			act.moveToElement(element(By.xpath("//input[@placeholder='Enter Name']/../../../../../../..//input[@type='checkbox' and @name='priority_flag']/.."))).click().build().perform();
			waitForElementToDisappear(loader);
		 // element(By.xpath("//input[@placeholder='Enter Name']/../../../../../../..//input[@type='checkbox' and @name='priority_flag']/..")).click();
		}
		else if(actStatus.equals("true") && priorityFlag.equals("OFF"))
		{
			System.out.println("Status1again"+actStatus);
			Actions act = new Actions(getDriver());
			act.moveToElement(element(By.xpath("//input[@placeholder='Enter Name']/../../../../../../..//input[@type='checkbox' and @name='priority_flag']/.."))).click().build().perform();
			waitForElementToDisappear(loader);
		}
		String actVisibilty = element(By.xpath("//input[@placeholder='Enter Name']/../../../../../../..//input[@type='checkbox' and @name='visible_flag']")).getAttribute("aria-checked");
		System.out.println("Status2"+actVisibilty);
		if(actVisibilty.equals("false") && visibilityFlag.equals("ON"))
		{
			Actions act = new Actions(getDriver());
			act.moveToElement(element(By.xpath("//input[@placeholder='Enter Name']/../../../../../../..//input[@type='checkbox' and @name='visible_flag']/.."))).click().build().perform();
			waitForElementToDisappear(loader);
		}
		else if(actVisibilty.equals("true") && visibilityFlag.equals("OFF"))
		{
			System.out.println("Status2again"+actVisibilty);
			Actions act = new Actions(getDriver());
			act.moveToElement(element(By.xpath("//input[@placeholder='Enter Name']/../../../../../../..//input[@type='checkbox' and @name='visible_flag']/.."))).click().build().perform();
			waitForElementToDisappear(loader);
		}
		element(By.xpath("//mat-select[@aria-label='Select Aggregator']//div[@class='mat-select-value']")).click();
		List<WebElement> l3 = getDriver().findElements(By.xpath("//div//mat-option//span"));
		int s3 = l3.size();
		for(int i=1;i<s3;i++)
		{
			if(l3.get(i).getText().equals(aggregator))
			{
				l3.get(i).click();
			}
		}
		waitSeconds(3);
		try {
		element(By.xpath("//mat-icon[contains(text(),'done')]")).click();
		}
		catch(Exception e)
		{
			System.out.println("Exception Found");
		}
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verify edited parameter for measurement
	* Param: parameterName,editParameter,metricSelection,unitOfMeasurement,LCLvalue,UCLvalue,minRange,maxRange,tagId,aggregator
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public boolean verifyEditedMeasurement(String updatedMeasurement,String unitOfMeasurement,String LCLvalue,String UCLvalue,String minRange,String maxRange,String tagId,String priorityFlag,String visibilityFlag)
	{
		boolean result1 = false;
		if(element(By.xpath("//span[contains(text(),'"+updatedMeasurement+"')]")).isCurrentlyVisible() &&
				element(By.xpath("//span[contains(text(),'"+unitOfMeasurement+"')]")).isCurrentlyVisible() &&
				element(By.xpath("//span[contains(text(),'"+LCLvalue+"')]")).isCurrentlyVisible() &&
				element(By.xpath("//span[contains(text(),'"+UCLvalue+"')]")).isCurrentlyVisible() &&
				element(By.xpath("//span[contains(text(),'"+minRange+"')]")).isCurrentlyVisible() &&
				element(By.xpath("//span[contains(text(),'"+maxRange+"')]")).isCurrentlyVisible() &&
				element(By. xpath("//span[contains(text(),'"+tagId+"')]")).isCurrentlyVisible())
		{
			result1 = true;
		}
		System.out.println("Element Status"+result1);
		boolean result2 = false	;
		String actStatus = element(By.xpath("//span[contains(text(),'"+updatedMeasurement+"')]/../..//input[@name='priority_flag']")).getAttribute("aria-checked");
		System.out.println("Actual ppriorty status"+actStatus);
		if (priorityFlag.equals("ON"))
		{
			if(actStatus.equals("true"))
			result2 = true;	
		}
		else if (priorityFlag.equals("OFF"))
		{
			if(actStatus.equals("false"))
			result2 = true;	
		}
		System.out.println("Element priority status"+result2);
		boolean result3 = false;
		String actVisibiltyStatus = element(By.xpath("//span[contains(text(),'"+updatedMeasurement+"')]/../..//input[@name='visible_flag']")).getAttribute("aria-checked");
		System.out.println("VisibilityStatus"+actVisibiltyStatus);
		if (visibilityFlag.equals("ON"))
		{
			if(actVisibiltyStatus.equals("true"))
				result3 = true;	
		}
		else if (visibilityFlag.equals("OFF"))
		{
			if(actVisibiltyStatus.equals("false"))
				result3 = true;	
		}
		System.out.println("Element visibility status"+result3);
		if(result1==true && result2==true && result3==true)
		return true;
		else return false;	
	}

	/********************************************************************
	* Description: Edit parameter for Alarms,Trips,Faults,FunctionStates
	* Param: tabName,parameterName,editParameter,severity,tagId,relatedMeasurement,recommendationMessage
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void editParameter(String tabName,String parameterName,String editParameterName,String severity,String tagId,String relatedMeasurement,String recommendationMessage,String value,String operatingUnit,String metricUnitSelection)
	{
//		getDriver().navigate().refresh();
//		waitForElementToDisappear(loader);
		element(By.xpath("//a[contains(text(),'"+tabName+"')]")).click();
		waitForElementToDisappear(loader);
		element(By.xpath("//span[contains(text(),'"+parameterName+"')]/../..//mat-icon[@class='edit-icon mat-icon material-icons']")).click();
		element(parameterNameEditField).clear();
		element(parameterNameEditField).sendKeys(editParameterName);
		waitSeconds(3);
		if(element(severityField).isCurrentlyVisible())
		{
		element(severityField).click();
		waitSeconds(2);
		List<WebElement> l1 = getDriver().findElements(By.xpath("//div//mat-option//span"));
		int s1= l1.size();
		for(int i=0;i<s1;i++)
		{
			if(l1.get(i).getText().equals(severity))
			{
				l1.get(i).click();
			}
		}
		}
		waitSeconds(3);
		element(By.xpath("//input[@placeholder='Enter Tag Id']")).clear();
		element(By.xpath("//input[@placeholder='Enter Tag Id']")).sendKeys(tagId);
		waitSeconds(3);
		try{
			element(relatedMeasurementField).click();
			List<WebElement> l2 = getDriver().findElements(By.xpath("//div//mat-option//span"));
			for(int j=0;j<l2.size();j++)
			{
				if(l2.get(j).getText().equals(relatedMeasurement)) l2.get(j).click();
			}
			}
		catch(Exception e)
		{
			System.out.println("Exception Found");
			element(relatedMeasurementField).click();
			List<WebElement> l2 = getDriver().findElements(By.xpath("//div//mat-option//span"));
			for(int k=0;k<l2.size();k++)
			{
				if(l2.get(k).getText().equals(relatedMeasurement)) l2.get(k).click();
			}
		}
		element(By.xpath("//html")).click();
		waitSeconds(3);
		if(element(recommendation).isCurrentlyVisible())
		{
		element(recommendation).clear();
		element(recommendation).sendKeys(recommendationMessage);
		}
		if(element(valueField).isCurrentlyVisible())
		{
			element(valueField).clear();
			element(valueField).sendKeys(value);
		}
		if(element(By.xpath("(//mat-select[@aria-label='Select UOMt'])[1]")).isCurrentlyVisible())
		{
			element(By.xpath("(//mat-select[@aria-label='Select UOMt'])[1]")).click();
			List<WebElement> l3 = getDriver().findElements(By.xpath("//div//mat-option//span"));
					int s3 = l3.size();
					for(int i=0;i<s3;i++)
					{
						if(l3.get(i).getText().equals(metricUnitSelection))
						{
						l3.get(i).click();
						}
					}
			waitSeconds(3);
		}
		if(element(By.xpath("(//mat-select[@aria-label='Select UOMt'])[2]")).isCurrentlyVisible())
		{
			element(By.xpath("(//mat-select[@aria-label='Select UOMt'])[2]")).click();
			List<WebElement> l4 = getDriver().findElements(By.xpath("//div//mat-option//span"));
					int s4 = l4.size();
					for(int i=0;i<s4;i++)
					{
						if(l4.get(i).getText().equals(operatingUnit))
						{
						l4.get(i).click();
						}
					}
			waitSeconds(3);
		}
		
		element(By.xpath("//button[@type='submit']//mat-icon[contains(text(),'done')]")).click();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verify edited parameter for Alarms,Trips,Faults
	* Param: tabName,parameterName,editParameter,severity,tagId,relatedMeasurement,recommendationMessage
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyEditedParameterAlarmsTripsFaults(String editParameterName,String severity,String tagId,String relatedMeasurement,String recommendationtext)
	{
		boolean result1 = false;
		if(element(By.xpath("//span[contains(text(),'"+editParameterName+"')]")).isCurrentlyVisible() &&
				element(By.xpath("//span[contains(text(),'"+relatedMeasurement+"')]")).isCurrentlyVisible() &&
				element(By.xpath("//span[contains(text(),'"+tagId+"')]")).isCurrentlyVisible())
		{
			result1 = true;
		}
		System.out.println("Status1111"+result1);
		boolean result2 = false;
		if(element(By.xpath("//button[contains(text(),'Severity')]")).isCurrentlyVisible())
		{
			if(element(By.xpath("//span[contains(text(),'"+editParameterName+"')]/../..//span[contains(text(),'"+severity+"')]")).isCurrentlyVisible())
				result2 = true;
		}
		System.out.println("Severity status"+result2);
		boolean result3 = false;
		if(element(By.xpath("//button[contains(text(),'Recommendation')]")).isCurrentlyVisible())
		{
			if(element(By.xpath("//span[contains(text(),'"+editParameterName+"')]/../..//span[contains(text(),'"+recommendationtext+"')]")).isCurrentlyVisible())
				result3 = true;
		}
		System.out.println("Recommendation status"+result3);
		if(result1==true && result2==true && result3==true)
			return true;
			else return false;
		
	}
	
	/********************************************************************
	* Description: Verify edited parameter for Function states
	* Param: editParameter,tagId,relatedMeasurement
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyEditedParameterForFucntionStates(String editParameterName,String tagId,String relatedMeasurement)
	{
		if(element(By.xpath("//span[contains(text(),'"+editParameterName+"')]")).isCurrentlyVisible() &&
				element(By.xpath("//span[contains(text(),'"+tagId+"')]")).isCurrentlyVisible() &&
				element(By.xpath("//span[contains(text(),'"+relatedMeasurement+"')]")).isCurrentlyVisible())
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Verify edited parameter for Calibration
	* Param: editParameterName,tagId,relatedMeasurement,unitofMeasurement
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyEditedParameterForCalibration(String editParameterName,String value,String unitofMeasurement,String tagId,String relatedMeasurement)
	{
		if(element(By.xpath("//span[contains(text(),'"+editParameterName+"')]")).isCurrentlyVisible() &&
				element(By.xpath("//span[contains(text(),'"+editParameterName+"')]/../..//span[contains(text(),'"+value+"')]")).isCurrentlyVisible() &&
				element(By.xpath("//span[contains(text(),'"+editParameterName+"')]/../..//span[contains(text(),'"+unitofMeasurement+"')]")).isCurrentlyVisible() &&
				element(By.xpath("//span[contains(text(),'"+editParameterName+"')]/../..//span[contains(text(),'"+tagId+"')]")).isCurrentlyVisible()&&
				element(By.xpath("//span[contains(text(),'"+editParameterName+"')]/../..//span[contains(text(),'"+relatedMeasurement+"')]")).isCurrentlyVisible())
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Disable/Enable the parameter
	* Param: tabName,parameterName
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void  disableEnableParameter(String tabName,String parameterName)
	{
		element(By.xpath("//a[contains(text(),'"+tabName+"')]")).click();
		waitForElementToDisappear(loader);
		element(By.xpath("//span[contains(text(),'"+parameterName+"')]/../..//div[@class='mat-slide-toggle-bar mat-slide-toggle-bar-no-side-margin']")).click();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Disable the parameter
	* Param: parameterName
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyDisabledParamter(String parameterName)
	{
		String actClass = element(By.xpath("//span[contains(text(),'"+parameterName+"')]/../..//mat-slide-toggle[@class='mat-slide-toggle mat-primary']")).getAttribute("class");
		String expClass = "mat-slide-toggle mat-primary";
		if(actClass.equals(expClass))
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Enable the parameter
	* Param: parameterName
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyEnabledParamter(String parameterName)
	{
		String actClass = element(By.xpath("//span[contains(text(),'"+parameterName+"')]/../..//mat-slide-toggle[@class='mat-slide-toggle mat-primary mat-checked']")).getAttribute("class");
		String expClass = "mat-slide-toggle mat-primary mat-checked";
		if(actClass.equals(expClass))
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Delete the parameter
	* Param: tabName,parameterName
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void deleteParameter(String tabName,String parameterName )
	{
		element(By.xpath("//a[contains(text(),'"+tabName+"')]")).click();
		waitForElementToDisappear(loader);
		element(By.xpath("//span[contains(text(),'"+parameterName+"')]/../..//mat-icon[contains(text(),'delete')]")).click();
		element(deleteConfirmation).click();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verify the deleted parameter
	* Param: tabName,parameterName
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public boolean verifyDeletedParameter(String parameterName)
	{
		waitSeconds(3);
		if(!element(By.xpath("//span[contains(text(),'"+parameterName+"')]")).isCurrentlyVisible())
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Click on sync tab
	* Param: NA
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void clickOnSync()
	{
		element(By.xpath("//a[contains(text(),'Sync')]")).click();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Sync all the unsynced parameters
	* Param: NA
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void syncAllParameters()
	{
		while(element(By.xpath("//i[contains(text(),'sync')]")).isCurrentlyVisible())
		{
			element(By.xpath("//i[contains(text(),'sync')]")).click();
			waitForElementToDisappear(loader);
		}
	}
	
	/********************************************************************
	* Description: Verify all the parameters are synced
	* Param: NA
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public boolean verifySyncedParameters()
	{
		if(!element(By.xpath("//span[contains(text(),'Sync all')]")).isCurrentlyVisible() &&
				!element(By.xpath("//i[@class='material-icons custom-sync-icon' and @mattooltip='sync']")).isCurrentlyVisible())
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Verify error message while adding duplicate operating unit
	* Param: operatingUnitName
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyErrorMessageWhileAddingDuplicateOperatingUnit(String operatingUnitName)
	{
		String actErrMsg = element(By.xpath("//simple-snack-bar[@class='mat-simple-snackbar ng-star-inserted']//span")).getText();
		String expErrMsg = "Operating Unit with this name '"+operatingUnitName+"' already exists. Please provide a different name";
		String actUrl = getDriver().getCurrentUrl();
		String expUrl = "configuration#/operating-unit/models/operating-units/add";
		if(actErrMsg.equalsIgnoreCase(expErrMsg) && actUrl.equals(CSVHelper.getBaseUrl()+expUrl))
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Verify error message while adding duplicate operating unit
	* Param: parameterName
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyErrorMessageForDuplicateParameterInMeasurementParameter(String parameterName)
	{
		String actErrMsg = element(By.xpath("//simple-snack-bar[@class='mat-simple-snackbar ng-star-inserted']//span")).getText();
		String expErrMsg = "'"+parameterName+"' already exists. Please provide a different name";
		List<WebElement> paraList = getDriver().findElements(By.xpath("//mat-row//mat-cell//span[contains(text(),'"+parameterName+"')]"));
		if(actErrMsg.equalsIgnoreCase(expErrMsg) && paraList.size()==1)
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Verify error message while adding duplicate operating unit
	* Param: parameterName
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyErrorMessageForDuplicateParameterInAlarmParameter(String parameterName)
	{
		String actErrMsg = element(By.xpath("//simple-snack-bar[@class='mat-simple-snackbar ng-star-inserted']//span")).getText();
		String expErrMsg = "'"+parameterName+"' - Alarm already exists. Please provide a different name";
		List<WebElement> paraList = getDriver().findElements(By.xpath("//mat-row//mat-cell//span[contains(text(),'"+parameterName+"')]"));
		if(actErrMsg.equalsIgnoreCase(expErrMsg) && paraList.size()==1)
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Verify error message while adding duplicate operating unit
	* Param: parameterName
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyErrorMessageForDuplicateParameterInTripParameter(String parameterName)
	{
		String actErrMsg = element(By.xpath("//simple-snack-bar[@class='mat-simple-snackbar ng-star-inserted']//span")).getText();
		String expErrMsg = "'"+parameterName+"' - Trip already exists. Please provide a different name";
		List<WebElement> paraList = getDriver().findElements(By.xpath("//mat-row//mat-cell//span[contains(text(),'"+parameterName+"')]"));
		if(actErrMsg.equalsIgnoreCase(expErrMsg) && paraList.size()==1)
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Verify error message while adding duplicate operating unit
	* Param: parameterName
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyErrorMessageForDuplicateParameterInFaultParameter(String parameterName)
	{
		String actErrMsg = element(By.xpath("//simple-snack-bar[@class='mat-simple-snackbar ng-star-inserted']//span")).getText();
		String expErrMsg = "'"+parameterName+"' - Fault already exists. Please provide a different name";
		List<WebElement> paraList = getDriver().findElements(By.xpath("//mat-row//mat-cell//span[contains(text(),'"+parameterName+"')]"));
		if(actErrMsg.equalsIgnoreCase(expErrMsg) && paraList.size()==1)
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Verify error message while adding duplicate operating unit
	* Param: parameterName
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyErrorMessageForDuplicateParameterInFunctionStatesParameter(String parameterName)
	{
		String actErrMsg = element(By.xpath("//simple-snack-bar[@class='mat-simple-snackbar ng-star-inserted']//span")).getText();
		String expErrMsg = "'"+parameterName+"' - Function State already exists. Please provide a different name";
		List<WebElement> paraList = getDriver().findElements(By.xpath("//mat-row//mat-cell//span[contains(text(),'"+parameterName+"')]"));
		if(actErrMsg.equalsIgnoreCase(expErrMsg) && paraList.size()==1)
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Verify error message while adding duplicate operating unit
	* Param: parameterName
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyErrorMessageForDuplicateParameterInCalibrationParameter(String parameterName)
	{
		String actErrMsg = element(By.xpath("//simple-snack-bar[@class='mat-simple-snackbar ng-star-inserted']//span")).getText();
		String expErrMsg = "'"+parameterName+"' - Calibration already exists. Please provide a different name";
		System.out.println("1"+"Error message"+actErrMsg);
		System.out.println("2"+actErrMsg.equalsIgnoreCase(expErrMsg));
		List<WebElement> paraList = getDriver().findElements(By.xpath("//mat-row//mat-cell//span[contains(text(),'"+parameterName+"')]"));
		if(actErrMsg.equalsIgnoreCase(expErrMsg) && paraList.size()==1)
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Verify error message while adding duplicate operating unit
	* Param: parameterName
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyErrorMessageForDuplicateParameterInMeasurementParameterWhileUpdating(String parameterName)
	{
		String actErrMsg = element(By.xpath("//simple-snack-bar[@class='mat-simple-snackbar ng-star-inserted']//span")).getText();
		String expErrMsg = "The measurement with name '"+parameterName+"' already exists. Please provide a different name";
		List<WebElement> paraList = getDriver().findElements(By.xpath("//mat-row//mat-cell//span[contains(text(),'"+parameterName+"')]"));
		if(actErrMsg.equalsIgnoreCase(expErrMsg) && paraList.size()==1)
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Verify error message while adding duplicate operating unit
	* Param: parameterName
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyErrorMessageForDuplicateParameterInAlarmParameterWhileUpdating(String parameterName)
	{
		String actErrMsg = element(By.xpath("//simple-snack-bar[@class='mat-simple-snackbar ng-star-inserted']//span")).getText();
		String expErrMsg = "'"+parameterName+"'- Alarm already exists.Please provide a different name";
//		System.out.println("act"+actErrMsg);
//		System.out.println("exp"+expErrMsg);
//		System.out.println(actErrMsg.equalsIgnoreCase(expErrMsg));
		List<WebElement> paraList = getDriver().findElements(By.xpath("//mat-row//mat-cell//span[contains(text(),'"+parameterName+"')]"));
//		System.out.println(paraList.size());
		waitSeconds(2);
		if(actErrMsg.equalsIgnoreCase(expErrMsg) && paraList.size()==1)
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Edit the parameter with duplicate
	* Param: parameterName
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public void editParameterWithDuplicate(String tabName,String parameterName,String editParameterName)
	{
			element(By.xpath("//a[contains(text(),'"+tabName+"')]")).click();
			waitForElementToDisappear(loader);
			element(By.xpath("//span[contains(text(),'"+parameterName+"')]/../..//mat-icon[@class='edit-icon mat-icon material-icons']")).click();
			element(parameterNameEditField).clear();
			element(parameterNameEditField).sendKeys(editParameterName);
			waitSeconds(3);
			element(By.xpath("//button[@type='submit']//mat-icon[contains(text(),'done')]")).click();
			waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verify error message while adding duplicate operating unit for trip
	* Param: parameterName
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyErrorMessageForDuplicateParameterInTripParameterWhileUpdating(String parameterName)
	{
		String actErrMsg = element(By.xpath("//simple-snack-bar[@class='mat-simple-snackbar ng-star-inserted']//span")).getText();
		String expErrMsg = "'"+parameterName+"'- Trip already exists.Please provide a different name";
//		System.out.println("act"+actErrMsg);
//		System.out.println("exp"+expErrMsg);
//		System.out.println(actErrMsg.equalsIgnoreCase(expErrMsg));
		List<WebElement> paraList = getDriver().findElements(By.xpath("//mat-row//mat-cell//span[contains(text(),'"+parameterName+"')]"));
//		System.out.println(paraList.size());
		waitSeconds(2);
		if(actErrMsg.equalsIgnoreCase(expErrMsg) && paraList.size()==1)
			return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Verify error message while adding duplicate operating unit for function states
	* Param: parameterName
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyErrorMessageForDuplicateParameterInFunctionStatesParameterWhileUpdating(String parameterName)
	{
		String actErrMsg = element(By.xpath("//simple-snack-bar[@class='mat-simple-snackbar ng-star-inserted']//span")).getText();
		String expErrMsg = "'"+parameterName+"' already exists.  Please provide a different name";
		System.out.println("act"+actErrMsg);
		System.out.println("exp"+expErrMsg);
		System.out.println(actErrMsg.equalsIgnoreCase(expErrMsg));
		List<WebElement> paraList = getDriver().findElements(By.xpath("//mat-row//mat-cell//span[contains(text(),'"+parameterName+"')]"));
		System.out.println(paraList.size());
		waitSeconds(2);
		if(actErrMsg.equalsIgnoreCase(expErrMsg) && paraList.size()==1)
			return true;
		else return false;
	}
	
	

	/********************************************************************
	* Description: Update the visibility and priority 
	* Param: parameterName,priorityFlag,visibilityFlag
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public void updateVisibilityAndPriorityForParameter(String tabname,String parameterName,String priorityFlag,String visibilityFlag)
	{
		if(tabname.equals("Design Parameters")) {
		}
		else {
			element(By.xpath("//a[text()='"+tabname+"']")).click();
			waitForElementToDisappear(loader);
		}
		String actPriorityStatus = element(By.xpath("//span[contains(text(),'"+parameterName+"')]/../..//input[@type='checkbox' and @name='priority_flag']")).getAttribute("aria-checked");
		System.out.println("Status1"+actPriorityStatus);
		if(actPriorityStatus.equals("false") && priorityFlag.equals("ON"))
		{
			Actions act = new Actions(getDriver());
			act.moveToElement(element(By.xpath("//span[contains(text(),'"+parameterName+"')]/../..//input[@type='checkbox' and @name='priority_flag']/.."))).click().build().perform();
			waitForElementToDisappear(loader);
		 // element(By.xpath("//input[@placeholder='Enter Name']/../../../../../../..//input[@type='checkbox' and @name='priority_flag']/..")).click();
		}
		else if(actPriorityStatus.equals("true") && priorityFlag.equals("OFF"))
		{
			System.out.println("Status1again"+actPriorityStatus);
			Actions act = new Actions(getDriver());
			act.moveToElement(element(By.xpath("//span[contains(text(),'"+parameterName+"')]/../..//input[@type='checkbox' and @name='priority_flag']/.."))).click().build().perform();
			waitForElementToDisappear(loader);
		}
		String actVisibilty = element(By.xpath("//span[contains(text(),'"+parameterName+"')]/../..//input[@type='checkbox' and @name='visible_flag']")).getAttribute("aria-checked");
		System.out.println("Status2"+actVisibilty);
		if(actVisibilty.equals("false") && visibilityFlag.equals("ON"))
		{
			Actions act = new Actions(getDriver());
			act.moveToElement(element(By.xpath("//span[contains(text(),'"+parameterName+"')]/../..//input[@type='checkbox' and @name='visible_flag']/.."))).click().build().perform();
			waitForElementToDisappear(loader);
		}
		else if(actVisibilty.equals("true") && visibilityFlag.equals("OFF"))
		{
			System.out.println("Status2again"+actVisibilty);
			Actions act = new Actions(getDriver());
			act.moveToElement(element(By.xpath("//span[contains(text(),'"+parameterName+"')]/../..//input[@type='checkbox' and @name='visible_flag']/.."))).click().build().perform();
			waitForElementToDisappear(loader);
		}
	}
	
	
	/********************************************************************
	* Description: Verify the priority and visibility flag status
	* Param: parameterName,priorityFlag,visibilityFlag
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyUpdatedVisibilityAndPriorityFlag(String parameterName,String priorityFlag,String visibilityFlag)
	{
		String actPriorityStatus = element(By.xpath("//span[contains(text(),'"+parameterName+"')]/../..//input[@type='checkbox' and @name='priority_flag']")).getAttribute("aria-checked");
		System.out.println("Actual ppriorty status"+actPriorityStatus);
		boolean result1=false;
		if (priorityFlag.equals("ON"))
		{
			if(actPriorityStatus.equals("true"))
			result1 = true;	
		}
		else if (priorityFlag.equals("OFF"))
		{
			if(actPriorityStatus.equals("false"))
			result1 = true;	
		}
		System.out.println("Element priority status"+result1);
		boolean result2 = false;
		String actVisibiltyStatus = element(By.xpath("//span[contains(text(),'"+parameterName+"')]/../..//input[@type='checkbox' and @name='visible_flag']")).getAttribute("aria-checked");
		System.out.println("VisibilityStatus"+actVisibiltyStatus);
		if (visibilityFlag.equals("ON"))
		{
			if(actVisibiltyStatus.equals("true"))
				result2 = true;	
		}
		else if (visibilityFlag.equals("OFF"))
		{
			if(actVisibiltyStatus.equals("false"))
				result2 = true;	
		}
		System.out.println("Element visibility status"+result2);
		if(result1==true && result2==true && result2==true)
		return true;
		else return false;	
	}
	
	/********************************************************************
	* Description: Edit the parameter with blank
	* Param: tabname,parameterName
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void editParameterWithBlank(String tabname,String parameterName)
	{
		element(By.xpath("//a[contains(text(),'"+tabname+"')]")).click();
		waitForElementToDisappear(loader);
		element(By.xpath("//span[contains(text(),'"+parameterName+"')]/../..//mat-icon[@class='edit-icon mat-icon material-icons']")).click();
		element(parameterNameEditField).clear();
	}
	
	
	/********************************************************************
	* Description: Verify submit button getting disabled
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifySubmitButtonGettingDisabled()
	{
		return (!element(submitButton).isEnabled());
	}

	/********************************************************************
	* Description: Check the priority and visibility checkboxes if its unchecked
	* Param: tabname,parameterName
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void updateTheVisibilityAndPriorityFlag(String tabname, String priorityFlag, String MeasurementParameter, String visibilityFlag)
	{
		element(By.xpath("//a[contains(text(),'"+tabname+"')]")).click();
		waitForElementToDisappear(loader);
		String actStatus = element(By.xpath("//span[contains(text(),'"+MeasurementParameter+"')]/../..//input[@name='priority_flag']")).getAttribute("aria-checked");
		System.out.println("Status1"+actStatus);
		
		if(actStatus.equals("false") && priorityFlag.equals("ON"))
		{
			Actions act = new Actions(getDriver());
			act.moveToElement(element(By.xpath("//span[contains(text(),'"+MeasurementParameter+"')]/../..//input[@name='priority_flag']/.."))).click().build().perform();
			waitForElementToDisappear(loader);
		 // element(By.xpath("//input[@placeholder='Enter Name']/../../../../../../..//input[@type='checkbox' and @name='priority_flag']/..")).click();
		}
		else if(actStatus.equals("true") && priorityFlag.equals("OFF"))
		{
			System.out.println("Status1again"+actStatus);
			Actions act = new Actions(getDriver());
			act.moveToElement(element(By.xpath("//span[contains(text(),'"+MeasurementParameter+"')]/../..//input[@name='priority_flag']/.."))).click().build().perform();
			waitForElementToDisappear(loader);
		}
		String actVisibilty = element(By.xpath("//span[contains(text(),'"+MeasurementParameter+"')]/../..//input[@name='visible_flag']")).getAttribute("aria-checked");
		System.out.println("Status2"+actVisibilty);
		if(actVisibilty.equals("false") && visibilityFlag.equals("ON"))
		{
			Actions act = new Actions(getDriver());
			act.moveToElement(element(By.xpath("//span[contains(text(),'"+MeasurementParameter+"')]/../..//input[@name='visible_flag']/.."))).click().build().perform();
			waitForElementToDisappear(loader);
		}
		else if(actVisibilty.equals("true") && visibilityFlag.equals("OFF"))
		{
			System.out.println("Status2again"+actVisibilty);
			Actions act = new Actions(getDriver());
			act.moveToElement(element(By.xpath("//input[@placeholder='Enter Name']/../../../../../../..//input[@type='checkbox' and @name='visible_flag']/.."))).click().build().perform();
			waitForElementToDisappear(loader);
		}
		
	}
	
	/********************************************************************
	* Description: Verify priority and Visiblity Check boxes are selecting
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/

	public boolean verifyCheckBoxesAreSelecting(String MeasurementParameter) {
		
		
		String actStatus = element(By.xpath("//span[contains(text(),'"+MeasurementParameter+"')]/../..//input[@name='priority_flag']")).getAttribute("aria-checked");
		System.out.println("Status1"+actStatus);
		String actVisibilty = element(By.xpath("//span[contains(text(),'"+MeasurementParameter+"')]/../..//input[@name='visible_flag']")).getAttribute("aria-checked");
		System.out.println("Status2"+actVisibilty);
		if(actStatus.equals("true")&&actVisibilty.equals("true"))
			return true;
		else
		return false;
		
		
	}
	
	/********************************************************************
	* Description: Add subsystem to the disabled OU
	* Param: OUName,modelName,gateWay,count
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void addSubsystemToADisabledOU(String OUName,String modelName,String gateWay,String count)
	{
		while(element(expandIcon).isCurrentlyVisible())
		{
			element(expandIcon).click();
		}
		if(element(By.xpath("//a[contains(text(),'"+OUName+"')]/../../../..//mat-icon[contains(text(),'toggle_on')]")).isCurrentlyVisible())
		{
			element(By.xpath("//a[contains(text(),'"+OUName+"')]/../../../..//mat-icon[contains(text(),'toggle_on')]")).click();
			waitForElementToDisappear(loader);
			while(element(expandIcon).isCurrentlyVisible())
			{
				element(expandIcon).click();
			}
		}
		
		else if(element(By.xpath("//a[contains(text(),'"+OUName+"')]/../../../..//span[contains(text(),' Disable ')]")).isCurrentlyVisible())
		{
			element(By.xpath("//a[contains(text(),'"+OUName+"')]/../../../..//span[contains(text(),' Disable ')]")).click();
			waitForElementToDisappear(loader);
			while(element(expandIcon).isCurrentlyVisible())
			{
				element(expandIcon).click();
			}
		}
		
		element(By.xpath("//a[contains(text(),'"+OUName+"')]/../../../..//mat-icon[contains(text(),'add')]")).click();
		waitForElementToDisappear(loader);
		element(model).click();
		List<WebElement> modelList = getDriver().findElements(By.xpath("//mat-option//span"));
		for(int i=0;i<modelList.size();i++)
		{
			if(modelList.get(i).getText().equals(modelName))
			{
				modelList.get(i).click();
				break;
			}	
		}
		Actions act = new Actions(getDriver());
		act.moveToElement(element(gateway)).click().perform();
		List<WebElement> gatewayList = getDriver().findElements(By.xpath("//mat-option//span"));
		for(int i=0;i<gatewayList.size();i++)
		{
			if(gatewayList.get(i).getText().equals(gateWay))
			{
				gatewayList.get(i).click();
				break;
			}	
		}
		element(countField).sendKeys(count);
		act.moveToElement(element(addButton)).click().perform();
		waitForElementToDisappear(loader);
	}
	
	
	/********************************************************************
	* Description: Verify error message while adding subsystem for disabled OU
	* Param: OUName,modelName,gateWay,count
	* Returns: void
	* Status: Completed
	********************************************************************/
	public boolean verifyErrorMessageWhileAddingSubsystemForDisabledOU()
	{
		if(element(dialogBox).isCurrentlyVisible())
			return true;
		else return false;
	}
}

