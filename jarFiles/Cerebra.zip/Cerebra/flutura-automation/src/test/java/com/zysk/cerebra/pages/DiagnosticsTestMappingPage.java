package com.zysk.cerebra.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.zysk.cerebra.commonPages.CommonFunctions;

public class DiagnosticsTestMappingPage extends CommonFunctions {

		
	
	private By DiagnosticTestMappingLink = By.xpath("//div[contains(text(),' Diagnostics Workbench ')]//..//..//..//a[contains(text(),' Diagnostic Tests Mapping ')]");
	private By customerPageSearchbar = By.xpath("//input[@placeholder='Search..']");
	private By diagnosticTestPageSearchbar = By.xpath("//input[@placeholder='Search Tests..']");
	private By searchBar = By.xpath("//input[@type='text']");
	private By customerlist = By.xpath("//div[@class='row']/div");
	private By equipmentlist = By.xpath("//a[@class='header-text']");
	private By diagnosticTestlist = By.xpath("//div[@class='title header-text']"); 
	private By operatingunitlist = By.xpath("//a[@class='header-text']");
	private By submitbutton = By.xpath("//button[@mattooltip='Submit']");
	
	/********************************************************************
	* Description: Visit diagnosticsTestMapping page by clicking on diagnosticsTestMapping link
	* Param: NA
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void clickdiagnosticsTestMapping() 
	{
		element(DiagnosticTestMappingLink).click();
		waitForElementToDisappear(loader);
		
	}

	/********************************************************************
	* Description: verify Diagnostics Test Mapping customer page
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean diagnosticsTestMappingCustomerPage(String diagnosticsTestMappingCustomerPageURL)
	{
		if(element(customerPageSearchbar).isCurrentlyVisible() &&
 				getDriver().getCurrentUrl().equals(diagnosticsTestMappingCustomerPageURL)) return true;
 		else return false;
	}

	/********************************************************************
	* Description: click on Any customer card
	* Param: NA
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void clickCustomer(String customerName)
	{
		element(By.xpath("//a[text()='"+customerName+"']")).click();
		waitForElementToDisappear(loader);
	}

	/********************************************************************
	* Description: verify Diagnostics Test Mapping Equipments page
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean diagnosticsTestMappingEquipmentsPage(String diagnosticsTestMappingEquipmentsPageURL)
	{
		if(element(customerPageSearchbar).isCurrentlyVisible() &&
 				getDriver().getCurrentUrl().equals(diagnosticsTestMappingEquipmentsPageURL)) return true;
 		else return false;
	}

	/********************************************************************
	* Description: click on Any Equipment card
	* Param: NA
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void clickEquipmentCard(String equipmentName)
	{
		element(By.xpath("//a[text()='"+equipmentName+"']")).click();
		waitForElementToDisappear(loader);
	}

	/********************************************************************
	* Description: verify Diagnostics Test Mapping Diagnostic page
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean diagnosticsTestMappingDiagnosticsPage(String diagnosticsTestMappingDiagnosticPageURL) 
	{
		if(element(diagnosticTestPageSearchbar).isCurrentlyVisible() &&
 				getDriver().getCurrentUrl().equals(diagnosticsTestMappingDiagnosticPageURL)) return true;
 		else return false;
	}

	/********************************************************************
	* Description: click on Any DiagnosticTests card
	* Param: NA
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void clickDiagnosticTestsCard(String diagnosticTestsName) 
	{
	element(By.xpath("//div[text()='"+diagnosticTestsName+"']")).click();
	waitForElementToDisappear(loader);
	}

	/********************************************************************
	* Description: verify Diagnostics Test Mapping Opeartingunit page
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean diagnosticsTestMappingOperatingUnitPage(String operatingUnitPageURL)
	{
		if(element(customerPageSearchbar).isCurrentlyVisible() &&
 				getDriver().getCurrentUrl().equals(operatingUnitPageURL)) return true;
 		else return false;
	}

	/********************************************************************
	* Description: click on Any Operating Units card
	* Param: NA
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void clickoperatingUnitCard(String operatingUnitName)
	{
		element(By.xpath("//a[text()='"+operatingUnitName+"']")).click();
		waitForElementToDisappear(loader);
	}

	/********************************************************************
	* Description: verify Diagnostics Test Mapping Test coverage page
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean diagnosticsTestMappingtestCoveragePage(String testCoveragePageURL)
	{
		if(getDriver().getCurrentUrl().equals(testCoveragePageURL)) return true;
 		else return false;
	}

	/********************************************************************
	* Description: Enter valid data in DiagnosticsTestMapping search field
	* Param: NA
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void searchValidCustomer(String validCustomerName)
	{
		element(searchBar).sendKeys(validCustomerName);
	}

	/********************************************************************
	* Description: verify list of customers in DiagnosticsTestMapping Customerpage
	* Param: NA
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public boolean verifyValidCustomer() 
	{
		List<WebElement> c = getDriver().findElements(customerlist);
		int size = c.size();
		if(size>0) return true;
		else return false;
	}

	/********************************************************************
	* Description: Enter Invalid data in DiagnosticsTestMapping search field
	* Param: NA
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void searchInValidCustomer(String invalidCustomerName)
	{
		element(searchBar).sendKeys(invalidCustomerName);
	}

	/********************************************************************
	* Description: Verify empty list of customers in DiagnosticsTestMapping Customerpage
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyInValidCustomer() 
	{
		List<WebElement> c = getDriver().findElements(customerlist);
		int size = c.size();
		if(size==0) return true;
		else return false;
	}

	/********************************************************************
	* Description:Enter valid data in DiagnosticsTestMapping Equipment search field
	* Param: NA
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void searchValidEquipment(String validEquipmentName) 
	{
		element(searchBar).sendKeys(validEquipmentName);
	}

	/********************************************************************
	* Description: Verify list of customers in DiagnosticsTestMapping Equipmentpage
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyValidEquipment() 
	{
		List<WebElement> c = getDriver().findElements(equipmentlist);
		int size = c.size();
		if(size>0) return true;
		else return false;
	}

	/********************************************************************
	* Description:Enter Invalid data in DiagnosticsTestMapping Equipment search field
	* Param: NA
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void searchInValidEquipment(String invalidEquipmentName)
	{
		element(searchBar).sendKeys(invalidEquipmentName);
		
	}

	/********************************************************************
	* Description: Verify empty list of Equipment in DiagnosticsTestMapping Equipmentpage
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyInValidEquipment() 
	{
		List<WebElement> c = getDriver().findElements(equipmentlist);
		int size = c.size();
		if(size==0) return true;
		else return false;
	}

	
	/********************************************************************
	* Description: Enter valid data in DiagnosticsTestMapping DiagnosticsTest search field
	* Param: NA
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void searchValidDiagnosticsTest(String validDiagnosticsTestName) 
	{
		element(searchBar).sendKeys(validDiagnosticsTestName);
	}

	/********************************************************************
	* Description: verify list of items in DiagnosticsTestMapping DiagnosticsTestpage
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyValidDiagnosticsTest() 
	{
		List<WebElement> c = getDriver().findElements(diagnosticTestlist);
		int size = c.size();
		if(size>0) return true;
		else return false;
	}

	/********************************************************************
	* Description: Enter Invalid data in DiagnosticsTestMapping DiagnosticsTest search field
	* Param: NA
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void searchInValidDiagnosticsTest(String invalidDiagnosticsTestName)
	{
		element(searchBar).sendKeys(invalidDiagnosticsTestName);
	}

	/********************************************************************
	* Description: verify empty list of items in DiagnosticsTestMapping DiagnosticsTestpage
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyInValidDiagnosticsTest() 
	{
		List<WebElement> c = getDriver().findElements(diagnosticTestlist);
		int size = c.size();
		if(size==0) return true;
		else return false;
	}

	/********************************************************************
	* Description: Enter valid data in DiagnosticsTestMapping Operatingunit search field
	* Param: NA
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void searchValidOperatingunit(String validOperatingunitName)
	{
		element(searchBar).sendKeys(validOperatingunitName);
	}

	/********************************************************************
	* Description: verify list of items in DiagnosticsTestMapping Operatingunitpage
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyValidOperatingunit()
	{
		List<WebElement> c = getDriver().findElements(operatingunitlist);
		int size = c.size();
		if(size>0) return true;
		else return false;
	}

	/********************************************************************
	* Description: Enter Invalid data in DiagnosticsTestMapping Operatingunit search field
	* Param: NA
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void searchInValidOperatingunit(String invalidOperatingunitName) 
	{
		element(searchBar).sendKeys(invalidOperatingunitName);
	}

	/********************************************************************
	* Description: verify empty list of items in DiagnosticsTestMapping Operatingunitpage
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyInValidOperatingunit()
	{
		List<WebElement> c = getDriver().findElements(operatingunitlist);
		int size = c.size();
		if(size==0) return true;
		else return false;
	}
	
	/********************************************************************
	* Description: enable disable the toggle bar in Testcoverage page
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public void enableDisableToggleinTestcoveragePage(String testCoveragematcardName)
	{
		element(By.xpath("//mat-card//span[text()='"+testCoveragematcardName+"']/..//span[@class='mat-button-wrapper']")).click();
		element(submitbutton).click();
		waitForElementToDisappear(loader);
	}
	/********************************************************************
	* Description: verify the toggle bar is disabled
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyDisableToggleinTestcoveragePage(String testCoveragematcardName)
	{
		if(element(By.xpath("//mat-card//span[text()='"+testCoveragematcardName+"']/..//span[@class='mat-button-wrapper']//mat-icon[text()=' toggle_off ']")).isCurrentlyVisible())
		return true;
		else
		return false;
	}
	/********************************************************************
	* Description: verify the toggle bar is enabled
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyEnableToggleinTestcoveragePage(String testCoveragematcardName)
	{
		if(element(By.xpath("//mat-card//span[text()='"+testCoveragematcardName+"']/..//span[@class='mat-button-wrapper']//mat-icon[text()=' toggle_on ']")).isCurrentlyVisible())
			return true;
			else
			return false;
	}

}