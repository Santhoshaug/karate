package com.zysk.cerebra.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

import com.zysk.cerebra.commonPages.CommonFunctions;
import com.zysk.cerebra.csv_reader.CSVHelper;
import com.zysk.cerebra.csv_reader.EquipmentStructureCSVReader;
import com.zysk.cerebra.csv_reader.OperatingUnitCSVReader;

import net.serenitybdd.core.pages.PageObject;

public class AccessControlPage extends CommonFunctions{
	
	/***********************Page element identifiers******************************/
	
	private By accessControl = By.xpath("//mat-card-header//div[contains(text(),' Security & Notification ')]/..//..//..//a[contains(text(),'Access Control')]");
	private By customersTab = By.xpath("//span[@class='mat-button-wrapper' and contains(text(),'Customers')]");
	private By machineUnitTab = By.xpath("//a[text()='Machine Unit']");
	private By assetsTab = By.xpath("//a[text()='Assets']");
	//private By srcLocator = By.xpath("//span[text()='"+machineUnit+"']");
	private By destLocator = By.xpath("(//mat-card[@class='custom-container shadow mat-card']//mat-card-content)[2]"); 
	
	private static String userGroupName = "TestGroup";
	private static String demoUserGroup = "DemoUser Group";
	private By demoUserGroupLocator = By.xpath("//span[contains(text(),'"+demoUserGroup+"')]");
	private By userGroup = By.xpath("//span[contains(text(),'"+userGroupName+"')]");
	//private By machineUnitAssigned = By.xpath("//span[contains(text(),'"+machineUnit+"')]");
	//private By machineUnitVerification = By.xpath("//mat-card-title[text()='Assigned Machine Unit']/../../..//span[contains(text(),'"+machineUnit+"')]");
	private By loader2 = By.xpath("//img[@id='splashScreenImage']");
	
	
	private static String accessControlUrl = "https://cerebra.flutura.com/configuration#/user-access";
	
	 
	 /********************************************************************
		* Description: Visit Access level page by clicking on Access level link
		* Param: NA
		* Returns: Void
		* Status: Completed
		********************************************************************/
		public void clickAccessControl()
		{
		element(accessControl).click();
		waitForElementToDisappear(loader);
		}
	
	/********************************************************************
	* Description: Select demo customer
	* Param: Customername
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void selectDemoCustomer(String customerName)
	{
		element(By.xpath("//a[contains(text(),'"+customerName+"')]")).click();
		waitForElementToAppear(By.xpath("//div[@class='row mx-0 ng-star-inserted']"));
		//getDriver().navigate().refresh();
	}
	
	/********************************************************************
	* Description: Select the user group for which you want to assign the
	              machine unit
	* Param: NA
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void selectUserGroup(String userGroup)
	{
	element(By.xpath("//span[contains(text(),'"+userGroup+"')]")).click();
	waitForElementToDisappear(loader);
	waitFor(2000);
	
	}
	
	/********************************************************************
	* Description: Select Machine Unit tab
	* Param: NA
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void clickMachineUnitTab()
	{
	element(machineUnitTab).click();
	waitForElementToDisappear(loader);
	// waitForElementToAppear(By.xpath("//div[@class='col-5 px-0 custom-drag-drop-card']"));
	}
	
	/********************************************************************
	 * Description: Assign machine unit to the user group Param: Machine name
	 * Returns: Void Status: Completed
	 ********************************************************************/
	public void assignMachineUnit() {
		if (element(By.xpath("//mat-card-title[text()=' Unassigned Machine Unit ']/../../..//span[contains(text(),'"
				+ EquipmentStructureCSVReader.getMachineUnitName() + "')]")).isCurrentlyVisible()) {
			Actions act = new Actions(getDriver());
			Action dragAndDrop = act
					.clickAndHold(element(
							By.xpath("//span[text()='" + EquipmentStructureCSVReader.getMachineUnitName() + "']")))
					.moveToElement(element(destLocator)).release(element(destLocator)).build();
			dragAndDrop.perform();
			waitForElementToDisappear(loader);
		}
	}
	
	/********************************************************************
	 * Description: Verify machine unit in the assigned list Param: Machine name
	 * Returns: Boolean Status: Completed
	 ********************************************************************/
	public boolean verifyMachineUnit() {
		if (element(By.xpath("//mat-card-title[text()='Assigned Machine Unit']/../../..//span[contains(text(),'"
				+ EquipmentStructureCSVReader.getMachineUnitName() + "')]")).isCurrentlyVisible())
			return true;
		else
				return false;
			
		
	}
	
	/********************************************************************
	 * Description: Verify machine unit in the list Param: NA Returns: Booelan
	 * Status: Completed
	 ********************************************************************/
	public boolean verifyMachineUnit(String machineUnit) {
		if (element(By.xpath("//a[contains(text(),'" + machineUnit + "')]")).isCurrentlyVisible())
			return true;
		else
			return false;
	}
	
	/********************************************************************
	* Description:Select asset tab
	* Param: 
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	
	public void clickAssetTab()
	{
		element(assetsTab).click();
		//waitSeconds(7);
		waitForElementToAppear(By.xpath("//div[@class='col-5 px-0 custom-drag-drop-card']"));
	}
	
	/********************************************************************
	* Description: Assign Asset to the user group
	* Param: asset name
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void assignAsset()
	{
		Actions act = new Actions(getDriver());
		Action dragAndDrop =
				act.clickAndHold(element(By.xpath("//span[text()='"+OperatingUnitCSVReader.getAssetNameToAssignInAccessControl()+"']")))
				.moveToElement(element(destLocator))
				.release(element(destLocator)).build();
				waitSeconds(10);
				dragAndDrop.perform();
				waitSeconds(7);
				waitForElementToDisappear(loader);
				
	}
	
	/********************************************************************
	* Description: Verify machine unit in the assigned list
	* Param: Machine name
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyAssets()
	{
		
		if(element(By.xpath("//mat-card-title[text()='Assigned Assets']/../../..//span[contains(text(),'"+OperatingUnitCSVReader.getAssetNameToAssignInAccessControl()+"')]")).isCurrentlyVisible()) 
		return true;
		else return false;
		
	}

	
	 /********************************************************************
	* Description: Verify Asset in end app
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/

	public void goTOEndApplication() {
	
	
		element(By.xpath("//app-sidebar//div[@mattooltip='Dashboard']")).click();
		waitForElementToDisappear(loader);
		element(By.xpath("//mat-card-header//div[contains(text(),' Monitoring Console ')]/..//..//..//a[contains(text(),' Monitoring Console ')]")).click();
		waitForElementToDisappear(loader2);
		waitForElementToDisappear(loader);
		waitFor(10);
	}


/********************************************************************
	* Description: Verify Asset in end app
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
public boolean verifyAssetInEndApp() {
	String asset = OperatingUnitCSVReader.getAssetNameToAssignInAccessControl();
	element(By.xpath("//label[contains(text(),' Asset ')]/..//span[@class='ng-arrow-wrapper']")).click();
	List<WebElement> l1 = getDriver().findElements(By.xpath("//div[@role='option']/..//input/..//label"));
	System.out.println("DropdownListcount"+l1.size());
	boolean result1 = false;
	for(int i=0;i<l1.size();i++)
		
	{
		if(l1.get(i).getText().equals(asset))
		
		 result1 = true;
		break;
	}
	if(result1==true)
	return true;
	else return false;
	}


/********************************************************************
* Description:
* Param:
* Returns:
* Status:
********************************************************************/
	public void SelectAndClickOnMachineUnit(String MachineUnit)
	{
	element(By.xpath("//a[contains(text(),'"+MachineUnit+"')]")).click();
	waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description:
	* Param:
	* Returns:
	* Status:
	********************************************************************/
	public boolean verifyMachineUnitDeleted(String MachineUNitName) {
	if(!element(By.xpath("//a[contains(text(),'"+MachineUNitName+"')]")).isCurrentlyVisible())
	return true;
	else
	return false;
	
	
	}
	
	/********************************************************************
	* Description: Verify machine unit in the list
	* Param: NA
	* Returns: Booelan
	* Status: Completed
	********************************************************************/
	public boolean verifyMachineUnits(String machineUnit)
	{
	if (element(By.xpath("//a[contains(text(),'"+machineUnit+"')]")).isCurrentlyVisible())
	return true;
	else return false;
	}
}
