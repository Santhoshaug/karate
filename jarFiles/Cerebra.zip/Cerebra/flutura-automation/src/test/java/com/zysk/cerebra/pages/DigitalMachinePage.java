package com.zysk.cerebra.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

import com.zysk.cerebra.commonPages.CommonFunctions;
import com.zysk.cerebra.csv_reader.CSVHelper;

public class DigitalMachinePage extends CommonFunctions{
	
	/***********************Page element identifiers******************************/
	
	private By digitalMachine =  By.xpath("//a[text()=' Digital Machine ']");
	private By pageContent = By.xpath("//ngx-masonry[@class='ng-star-inserted']");
	private By pageEquimentCategoryList = By.xpath("//div[@class='title']");
	private By pageTitle = By.xpath("//span[@class='page-header align-self-center ng-star-inserted' and contains(text(),' Equipments')]");
	private By searchBar = By.xpath("//input[@class='search-input ng-untouched ng-pristine ng-valid']");
	private By listOfModel = By.xpath("//mat-card//div//a");
	private By addButton = By.xpath("//button//span[contains(text(),' Add ')]");
	private By nameFieldEnable = By.xpath("//input[@name='category']");
	private By enterDigitalMachineName = By.xpath("//input[@placeholder='Enter ']");
	private By clickOnRightIcon = By.xpath("//mat-icon[contains(text(),'done')]");
	private By clickOnCloseIcon = By.xpath("//mat-icon[contains(text(),'close')]");
	private By successfulMessage = By.xpath("//simple-snack-bar//span");
	private By EditName = By.xpath("//input[@name='eleName']");
	private By deleteConfirmation = By.xpath("//button[text()='Yes, delete it!']");
	private By sendValuesToAddSubsystem = By.xpath("//input[@placeholder='Name of the SubSystem']");
	private By subSystemAddButton = By.xpath("//button[@mattooltip='Add']");
	private By subSystemCancelButton = By.xpath("//button[@mattooltip='Cancel']");
	private By operatingCharacteristics =By.xpath("//mat-expansion-panel-header");
	private By ocSaveButton = By.xpath("//button[@mattooltip='Save']");
	private By ocCheckBoxes = By.xpath("//div//input[@type='checkbox']");
	private By deletePopup = By.xpath("//button[text()='Yes, delete it!']");
	
	
	/********************************************************************
	* Description: Visit Digital Machine page by clicking on Digital machine link
	* Param: NA
	* Returns: Void
	* Status: Completed
	********************************************************************/
	


	public void clickOnDigitalMachine() {
		
			element(digitalMachine).click();
			waitForElementToDisappear(loader);
			
	}
	

	/********************************************************************
	* Description: Verify DigitalMachine page
	* Param: expUrl
	* Returns: Void
	* Status: Completed
	********************************************************************/
	
	
	public boolean verifyDigitalMachinePage(String expUrl)
	{
//		String actUrl = getDriver().getCurrentUrl();
		if (	element(pageTitle).isCurrentlyVisible() &&
				element(pageEquimentCategoryList).isCurrentlyVisible())
			return true;
		else return false;
	}

	/********************************************************************
	* Description: Select models
	* Param: EquipmentName
	* Returns: Void
	* Status: Completed
	********************************************************************/

	public void selectEquipment(String EquipmentName) {
		
		element(By.xpath("//mat-card//div[@class='desc desc-text'][contains(text(),'"+EquipmentName+"')]")).click();
		waitForElementToDisappear(loader);
		
	}
	
	/********************************************************************
	* Description: Verify models list on selecting Equipments
	* Param: expUrl,EquipmentName
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyModelPage(String expUrl, String EquipmentName) {
		String actUrl = getDriver().getCurrentUrl();
		if (actUrl.contains(expUrl)&& element(searchBar).isCurrentlyVisible())
			return true;
		else
			return false;
	}
	
	/********************************************************************
	* Description: Select the model
	* Param: modelFromCSV
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void selectTheModel(String modelFromCSV) {
		
		element(By.xpath("//mat-card//div//a[contains(text(),'"+modelFromCSV+"')]")).click();
		waitForElementToDisappear(loader);
	}
	

	/********************************************************************
	* Description: Verify model selected by navigate to Digital Machine page
	* Param: String expUrl
	* Returns: Void
	* Status: Completed
	********************************************************************/
		public boolean verifyModelSelectedInDigitalMachinePage(String expUrl) {
			String actUrl = getDriver().getCurrentUrl();
			if (actUrl.contains(expUrl)&&
					element(addButton).isCurrentlyVisible()&&
					element(By.xpath("//input[@placeholder='Search..']")).isCurrentlyVisible())

				return true;
			else return false;
			
	}

	/********************************************************************
	* Description: Add digital machine
	* Param: DMName
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void addDigitalMachine(String DMName) {
		if (!element(By.xpath("//a[contains(text(),'" + DMName + "')]")).isCurrentlyVisible()) {
			element(addButton).click();
//		element(nameFieldEnable).sendKeys(DMName);
			element(enterDigitalMachineName).sendKeys(DMName);
			element(clickOnRightIcon).click();
			waitForElementToDisappear(loader);
		}
	}

	/********************************************************************
	* Description: Verify models list on selecting Equipments
	* Param: DigitalmachineName
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public boolean verifyAddedDigitalMachine(String DigitalmachineName) {
//		String ExpMsg="New digital machine '"+DigitalmachineName+"' added";
//		String actMsg=element(successfulMessage).getText();
//		if((actMsg.equals(ExpMsg))&&element(By.xpath("//a[contains(text(),'"+DigitalmachineName+"')]")).isCurrentlyVisible())
			if(element(By.xpath("//a[contains(text(),'"+DigitalmachineName+"')]")).isCurrentlyVisible())
			return true;
			else 
			return false;
	}	
	/********************************************************************
	* Description: Edit digital machine
	* Param: UpdatedName,machineNameToEdit
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void editDigitalMachine(String existingDigitalMachineToEdit, String DigitalMachineToUpdate) {
		if(!element(By.xpath("//a[contains(text(),'"+DigitalMachineToUpdate+"')]")).isCurrentlyVisible()) {
		element(By.xpath("//mat-list-item//a[contains(text(),'"+existingDigitalMachineToEdit+"')]/../..//mat-icon[text()='edit']")).click();
		element(EditName).clear();
		element(EditName).sendKeys(DigitalMachineToUpdate);
		element(clickOnRightIcon).click();
		waitForElementToDisappear(loader);
	}}
	
	/********************************************************************
	* Description: Verify edited digital machine updated successfully
	* Param: UpdatedDigitalMachineName
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public boolean iCanSeeTheUpdatedDMName(String UpdatedDigitalMachineName) {		
//		String ExpMsg="Digital Machine updated";
//		String actMsg=element(successfulMessage).getText();
		if(element(By.xpath("//a[contains(text(),'"+UpdatedDigitalMachineName+"')]")).isCurrentlyVisible())
		return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Disable Digital Machine
	* Param: DigitalMachineToDisable
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void disableDigitalMachine(String DigitalMachineToDisable) {
		element(By.xpath("//mat-list-item//a[contains(text(),'"+DigitalMachineToDisable+"')]/../..//label[@class='mat-slide-toggle-label']")).click();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verifying Digital Machine disabled
	* Param: DigitalMachineToDisable
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public boolean digtalMachineDisabled(String DigitalMachineToDisable) {
		String ExpMsg="Digital Machine '"+DigitalMachineToDisable+"' disabled";
		String actMsg=element(successfulMessage).getText();
		System.out.println("result"+!(element(By.xpath("//mat-list-item//a[contains(text(),'"+DigitalMachineToDisable+"')]/../..//mat-icon[text()='edit']")).isCurrentlyVisible()));
		if((actMsg.equals(ExpMsg))&&!(element(By.xpath("//mat-list-item//a[contains(text(),'"+DigitalMachineToDisable+"')]/../..//mat-icon[text()='edit']")).isCurrentlyVisible()))
			return true;
			else 
			return false;
	}
	
	/********************************************************************
	* Description: Disable Digital Machine
	* Param: DigitalMachineToEnable
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void enableDigitalMachine(String DigitalMachineToEnable) {
		element(By.xpath("//mat-list-item//a[contains(text(),'"+DigitalMachineToEnable+"')]/../..//div[@class='mat-slide-toggle-bar mat-slide-toggle-bar-no-side-margin']")).click();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verifying Digital Machine disabled
	* Param: DigitalMachineToEnable
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public boolean digtalMachineEnabled(String DigitalMachineToEnable) {
		String ExpMsg="Digital Machine '"+DigitalMachineToEnable+"' enabled";
		String actMsg=element(successfulMessage).getText();
		System.out.println("result"+element(By.xpath("//mat-list-item//a[contains(text(),'"+DigitalMachineToEnable+"')]/../..//mat-icon[text()='edit']")).isCurrentlyVisible());
		if((actMsg.equals(ExpMsg)) && element(By.xpath("//mat-list-item//a[contains(text(),'"+DigitalMachineToEnable+"')]/../..//mat-icon[text()='edit']")).isCurrentlyVisible())
			return true;
			else 
			return false;
	}
	/********************************************************************
	* Description: Delete Digital Machine
	* Param: DigitalMachineToEnable
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void deleteDigitalMachine(String DigitalMachineToDelete) {
		element(By.xpath("//mat-list-item//a[contains(text(),'"+DigitalMachineToDelete+"')]/../..//mat-icon[text()='delete']")).click();
		element(deleteConfirmation).click();
		waitForElementToDisappear(loader);
		
	}
	
	/********************************************************************
	* Description: Verifying Digital Machine deleted
	* Param: 
	* Returns: 
	* Status: Completed
	********************************************************************/
	public boolean digtalMachineDeletedSuccessfully(String DigitalMachineToDelete) {
		String ExpMsg="Digital Machine '"+DigitalMachineToDelete+"' deleted";
		String actMsg=element(successfulMessage).getText();
		System.out.println("result"+element(By.xpath("//mat-list-item//a[contains(text(),'"+DigitalMachineToDelete+"')]/../..//mat-icon[text()='edit']")).isCurrentlyVisible());
		if((actMsg.equals(ExpMsg)) && !(element(By.xpath("//mat-list-item//a[contains(text(),'"+DigitalMachineToDelete+"')]/../..//mat-icon[text()='delete']")).isCurrentlyVisible()))
			return true;
			else 
			return false;
	}
	
	/********************************************************************
	* Description: 
	* Param: 
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void AddDMWithExistingName(String DigitalMachineToEditWithExistingName, String ExistingName) {
		element(By.xpath("//mat-list-item//a[contains(text(),'"+ExistingName+"')]/../..//label[@class='mat-slide-toggle-label']//../..//..//mat-icon[contains(text(),'edit')]")).click();
		element(EditName).clear();
		element(EditName).sendKeys(ExistingName);
		element(clickOnRightIcon).click();
		waitForElementToDisappear(loader);
		
	}
	
	/********************************************************************
	* Description: 
	* Param: 
	* Returns: 
	* Status: Completed
	********************************************************************/
	public boolean digitalMachineNotUpdated(String ExistingName) {
		List<WebElement> DMList = getDriver().findElements(By.xpath("//mat-list-item//a[contains(text(),'"+ExistingName+"')]"));
		if(DMList.size()==1)
			return true;
		else
		return false;
	}
	
	/********************************************************************
	* Description: 
	* Param: 
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void selectDigitalMachine(String ExistingName){
		element(By.xpath("//mat-list-item//a[contains(text(),'"+ExistingName+"')]")).click();
		waitForElementToDisappear(loader);		
	}
	
	/********************************************************************
	* Description: 
	* Param: 
	* Returns: 
	* Status: Completed
	********************************************************************/
	public boolean subSystemDisplayingAfterSelectDigitalMacine(String expUrl, String SubsystemName) {
		String actUrl = getDriver().getCurrentUrl();
		if (actUrl.contains(expUrl) && 
				element(addButton).isCurrentlyVisible() &&
				element(By.xpath("//div//span[contains(text(),'"+SubsystemName+"')]")).isCurrentlyVisible())
			return true;
		else return false;
	}
	
	
	/********************************************************************
	* Description: 
	* Param: 
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void addSubsystem(String subsystemName) {
		element(addButton).click();
		element(sendValuesToAddSubsystem).sendKeys(subsystemName);
		element(subSystemAddButton).click();
		waitForElementToDisappear(loader);
		
	}
	/********************************************************************
	* Description: 
	* Param: 
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public boolean subSystemAddedSuccessfully(String subsystemName) {	
		String actMsg=element(successfulMessage).getText();
		String ExpMsg = "New digital machine subsystem'"+subsystemName+"' added";
		if((actMsg.equals(ExpMsg)))
				return true;
		else
		return false;
	}
	
	/********************************************************************
	* Description: 
	* Param: 
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void selectSubsystem(String SsystemName) {
		element(By.xpath("//mat-card//a[text()='"+SsystemName+"']")).click();
		waitForElementToDisappear(loader);
//	while(element(operatingCharacteristics).isCurrentlyVisible()) {
//		element(By.xpath("//mat-expansion-panel-header[@aria-expanded='false']")).click();	
//	}
//	waitFor(10);
	}
	/********************************************************************
	* Description: 
	* Param: 
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public boolean displayOperatingCharacteristics(String expUrl) {
//		String actUrl = getDriver().getCurrentUrl();
//		System.out.println("url"+actUrl);
		System.out.println("save button" + element(ocSaveButton).isCurrentlyVisible());
		System.out.println("Searchbar" + element(searchBar).isCurrentlyVisible());
		if (element(ocSaveButton).isCurrentlyVisible() && element(searchBar).isCurrentlyVisible())
			return true;
		else
			return false;
	}
	
	/********************************************************************
	* Description: 
	* Param: 
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void selectOCCheckboxes() {
	
		List<WebElement>ele=getDriver().findElements(By.xpath("//mat-panel-title/p"));
		int count = ele.size();
	
		try {
		
		for(int i=1; i<=count;i++) {
			if(element(By.xpath("//mat-panel-title//p")).isCurrentlyVisible()) {
			element(By.xpath("//mat-expansion-panel-header[@aria-expanded='false']//mat-panel-title")).click();
			}
			
		}
	}
   catch (Exception e) {
				
			}
		
		List<WebElement>ele2=getDriver().findElements(By.xpath("//div//span//..//mat-checkbox"));
		System.out.println(ele2);
		try {
			
			for(int i=0; i<=ele2.size();i++) {
				if(element(By.xpath("//div//span//..//mat-checkbox//div[@class='mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin']//input[@aria-checked='false']")).isCurrentlyVisible()==true) 
				{				
					ele2.get(i).click();
//element(By.xpath("//mat-expansion-panel[1]//mat-panel-title//p//..//..//..//..//div[@class='mat-expansion-panel-content ng-trigger ng-trigger-bodyExpansion']//mat-list-item[1]//div[@class='d-flex justify-content-between align-item-center py-3']//mat-checkbox")).click();
				}
				
			}
		}
	   catch (Exception e) {
					
				}
		element(By.xpath("//span[contains(text(),'Save')]")).click();
		waitForElementToDisappear(loader);
		
		}
	
	/********************************************************************
	* Description: 
	* Param: 
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public boolean verifyMeasurementsMappedToSubsystem() {
		String actMsg = element(successfulMessage).getText();
		String exptMsg = "Measurement Mapped to Subsystem successfully";
		if(actMsg.equals(exptMsg))
			return true;
			else
		return false;
	}
	
	/********************************************************************
	* Description: 
	* Param: 
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void unSelectOperaticUnitCheckboxes() {
		List<WebElement>ele=getDriver().findElements(By.xpath("//mat-panel-title/p"));
		int count = ele.size();
	
		try {
		
		for(int i=1; i<=count;i++) {
			if(element(By.xpath("//mat-panel-title//p")).isCurrentlyVisible()) {
			element(By.xpath("//mat-expansion-panel-header[@aria-expanded='false']//mat-panel-title")).click();
			}
			
		}
	}
   catch (Exception e) {
				
			}
		
		List<WebElement>ele2=getDriver().findElements(By.xpath("//div//span//..//mat-checkbox"));
		System.out.println(ele2);
		try {
			
			for(int i=1; i<=ele2.size();i++) {
				if(element(By.xpath("//div//span//..//mat-checkbox//div[@class='mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin']//input[@aria-checked='true']")).isCurrentlyVisible()==true) 
				{				
					ele2.get(i).click();
				}
				
			}
		}
	   catch (Exception e) {
					
				}
		element(By.xpath("//span[contains(text(),'Save')]")).click();
		waitForElementToDisappear(loader);
	
	}
	
	/********************************************************************
	* Description: 
	* Param: 
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public boolean verifyMeasurementsMappedToSubsystemAfterUnselctOUCheckboxes() {
		String actMsg = element(successfulMessage).getText();
		String exptMsg = "Measurement Mapped to Subsystem successfully";
		if(actMsg.equals(exptMsg))
			return true;
			else
		return false;
		
//		String actMsg2 = element(successfulMessage).getText();
//		String exptMsg2 = "Please check the Required feild";
//		if(actMsg2.equals(exptMsg2))
//			return true;
//			else
//		return false;
	}
	
	/********************************************************************
	* Description: 
	* Param: 
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void addsubSystemToLevel(String subsystemName, String NewSubsystemToAdd) {
		element(By.xpath("//mat-card//a[contains(text(),'"+subsystemName+"')]//..//mat-icon[@mattooltip='Add']")).click();
		element(sendValuesToAddSubsystem).sendKeys(NewSubsystemToAdd);
		element(subSystemAddButton).click();
		waitForElementToDisappear(loader);
		
	}
	
	/********************************************************************
	* Description: 
	* Param: 
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public boolean subSystemAddedToLevel(String subsystemName) {
		String actMsg = element(successfulMessage).getText();
		String exptMsg = "New digital machine subsystem'"+subsystemName+"' added";
		if(actMsg.equals(exptMsg))
			return true;
			else
		return false;
	}
	
	/********************************************************************
	* Description: 
	* Param: 
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void deleteSubSystem(String subsystemName) {
		element(By.xpath("//mat-card//a[contains(text(),'"+subsystemName+"')]//..//mat-icon[text()=' delete']")).click();
		element(deletePopup).click();
		waitForElementToDisappear(loader);
		
	}
	
	/********************************************************************
	* Description: 
	* Param: 
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public boolean subSystemDeletedInLevel(String subsystemName) {
		String actMsg = element(successfulMessage).getText();
		String exptMsg = "Digital Machine Subsystem'"+subsystemName+"' deleted";
		if(actMsg.equals(exptMsg))
			return true;
			else
		return false;
	}
	
	/********************************************************************
	* Description: 
	* Param: 
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void searchForOperatingCharateristics(String NameToSearch) {
		List<WebElement>ele=getDriver().findElements(By.xpath("//mat-panel-title/p"));
		int count = ele.size();
	
		try {
		
		for(int i=1; i<=count;i++) {
			if(element(By.xpath("//mat-panel-title//p")).isCurrentlyVisible()) {
			element(By.xpath("//mat-expansion-panel-header[@aria-expanded='false']//mat-panel-title")).click();
			}
			
		}
	}
		 catch (Exception e) {
				
			}
		
		element(By.xpath("//input[@placeholder='Search..']")).sendKeys(NameToSearch);
		
		
	}
	
	/********************************************************************
	* Description: 
	* Param: 
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public boolean operatingCharacteristicsSearched(String NameToSearch) {
		
		if(element(By.xpath("//div[@class='mat-list-item-content']//span[contains(text(),'"+NameToSearch+"')]")).isCurrentlyVisible())
			return true;
		else
			return false;
	}
	
	/********************************************************************
	* Description: 
	* Param: 
	* Returns: Void
	* Status: Completed
	********************************************************************/

	public boolean operatingCharacteristicsSearchedForInvalidData(String NameToSearch) {
		if(!(element(By.xpath("//div[@class='mat-list-item-content']//span[contains(text(),'"+NameToSearch+"')]"))).isCurrentlyVisible())
			return true;
		else
			return false;
	}
	/********************************************************************
	* Description: 
	* Param: 
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void addDuplicateSubsystemName(String subsystemName, String subsystemNameToduplicateName) {
		element(By.xpath("//mat-card//a[contains(text(),'"+subsystemName+"')]//..//mat-icon[@mattooltip='Add']")).click();
		element(sendValuesToAddSubsystem).sendKeys(subsystemNameToduplicateName);
		element(subSystemAddButton).click();
		waitForElementToDisappear(loader);
		
	}
	
	/********************************************************************
	* Description: 
	* Param: 
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public boolean duplicateSubSystemAdded(String subsystemName) {
		String actMsg=element(successfulMessage).getText();
		String ExpMsg = "New digital machine subsystem'"+subsystemName+"' added";
		if((actMsg.equals(ExpMsg)))
				return true;
		else
		return false;
	}
	
	/********************************************************************
	* Description: 
	* Param: 
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void addValueToSubsystemTextField(String subsystemName,String subsystemNameToVerifyCancelButton) {
		
		element(By.xpath("//mat-card//a[contains(text(),'"+subsystemName+"')]//..//mat-icon[@mattooltip='Add']")).click();
		element(sendValuesToAddSubsystem).sendKeys(subsystemNameToVerifyCancelButton);
		element(subSystemCancelButton).click();
		
	}
	
	
	/********************************************************************
	* Description: 
	* Param: 
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public boolean subSystemNotAdded() {			
	if(!(element(successfulMessage)).isCurrentlyVisible())
		return true;
		else
	return false;
	}
	
	/********************************************************************
	    * Description: select Digital Machine
	    * Param:
	    * Returns: void
	    * Status: Completed
	    ********************************************************************/
	public void clickDigitalMachine()
	{
	element(By.xpath("//a[contains(text(),' Digital Machine ')]")).click();

	}
	/********************************************************************
	    * Description: search by entering valid data in search text field
	    * Param:
	    * Returns: void
	    * Status: Completed
	    ********************************************************************/
	public void searchByValidData(String DataToSearch)
	{
	element(By.xpath("//input[@placeholder='Search Equipments...']")).sendKeys(DataToSearch);
	}

	/********************************************************************
	    * Description: Verify list of machinename displayed
	    * Param:
	    * Returns: boolean
	    * Status: Completed
	    ********************************************************************/
	public boolean VerifySearchByValidData()
	{
	List<WebElement> machineList = getDriver().findElements(By.xpath("//div//mat-card"));
	int size = machineList.size();
	if(size>0) return true;
	else return false;
	}

	/********************************************************************
	    * Description: search by entering invalid data in search text field
	    * Param:
	    * Returns: void
	    * Status: Completed
	    ********************************************************************/
	public void searchByInvalidData(String DataToSearch)
	{
		element(By.xpath("//input[@placeholder='Search Equipments...']")).sendKeys(DataToSearch);

	}

	/********************************************************************
	    * Description: Verify list of machinename not displayed
	    * Param:
	    * Returns: boolean
	    * Status: Completed
	    ********************************************************************/
	    public boolean VerifySearchByInValidData()
	    {
	    List<WebElement> machineList = getDriver().findElements(By.xpath("//div//mat-card"));
	int size = machineList.size();
	if(size>0) return true;
	else return false;
	}
	   
	    /********************************************************************
	    * Description: click on equipment
	    * Param:
	    * Returns: void
	    * Status: Completed
	    ********************************************************************/
	public void clickOnEquipment()
	{
	element(By.xpath("//div[@class='dx-test-item ng-star-inserted']//div[normalize-space(text())='Engine']")).click();
	waitForElementToDisappear(loader);
	}

	/********************************************************************
	    * Description:search by entering valid data in search text field in the models page
	    * Param:
	    * Returns: void
	    * Status: Completed
	    ********************************************************************/
	public void searchByValidDataForModels(String ValidDataToSearchModel)
	{
	element(By.xpath("//input[@placeholder='Search..']")).sendKeys(ValidDataToSearchModel);

	}

	/********************************************************************
	    * Description: Verify list of models displayed in the models page
	    * Param:
	    * Returns: boolean
	    * Status: Completed
	    ********************************************************************/

	public boolean VerifySearchByValidDataForModels()
	{
	List<WebElement> machineList = getDriver().findElements(By.xpath("//div//mat-card"));
	int size = machineList.size();
	if(size>0) return true;
	else return false;

	}

	/********************************************************************
	    * Description:search by entering invalid data in search text field in the models page
	    * Param:
	    * Returns: void
	    * Status: Completed
	    ********************************************************************/
	public void searchByInValidDataForModels(String InValidDataToSearchModel)
	{
		element(By.xpath("//input[@placeholder='Search..']")).sendKeys(InValidDataToSearchModel);

	}

	/********************************************************************
	    * Description: Verify list of models displayed in the models page
	    * Param:
	    * Returns: boolean
	    * Status: Completed
	    ********************************************************************/
	public boolean VerifySearchByInValidDataForModels()
	{
	List<WebElement> machineList = getDriver().findElements(By.xpath("//div//mat-card"));
	int size = machineList.size();
	if(size>0) return true;
	else return false;
	}

	/********************************************************************
	    * Description:click on any Model
	    * Param:
	    * Returns: void
	    * Status: Completed
	    ********************************************************************/
	public void clickOnModel()
	{
	element(By.xpath("//a[text()='Test']")).click();
	waitForElementToDisappear(loader);
	}

	/********************************************************************
	    * Description: search by entering valid data in search text field in digital machine sub page
	    * Param:
	    * Returns: void
	    * Status: Completed
	    ********************************************************************/
	public void searchByValidDataForDigitalMachineSubPage(String ValidDigitalMachineNameToSearchInDigitalMachineTab)
	{
	element(By.xpath("//input[@placeholder='Search..']")).sendKeys(ValidDigitalMachineNameToSearchInDigitalMachineTab);

	}

	/********************************************************************
	    * Description:Verify list of digital machines displayed in the digital machine sub page
	    * Param:
	    * Returns: boolean
	    * Status: Completed
	    ********************************************************************/
	public boolean VerifySearchByValidDataForDigitalMachineSubPage()
	{
	List<WebElement> machineList = getDriver().findElements(By.xpath("//a[@class='mat-line ng-star-inserted']"));
	int size = machineList.size();
	if(size>0) return true;
	else return false;
	}

	/********************************************************************
	    * Description: search by entering Invalid data in search text field in digital machine sub page
	    * Param:
	    * Returns: void
	    * Status: Completed
	    ********************************************************************/
	public void searchByInvalidDataForDigitalMachineSubPage(String InValidDigitalMachineNameToSearchInDigitalMachineTab)
	{
		element(By.xpath("//input[@placeholder='Search..']")).sendKeys(InValidDigitalMachineNameToSearchInDigitalMachineTab);

	}

	/********************************************************************
	    * Description: Verify list of digital machines not displayed in the digital machine sub page
	    * Param:
	    * Returns: boolean
	    * Status: Completed
	    ********************************************************************/
	public boolean VerifySearchByInValidDataForDigitalMachineSubPage()
	{
	List<WebElement> machineList = getDriver().findElements(By.xpath("//a[@class='mat-line ng-star-inserted']"));
	int size = machineList.size();
	if(size>0) return true;
	else return false;
	}

	/********************************************************************
    * Description: add data to text field and click on close icon
    * Param:
    * Returns: 
    * Status: Completed
    ********************************************************************/

	public void passValueToTextareafieldAndClickOnCloseIcon(String DMName) {
		element(addButton).click();
		element(nameFieldEnable).sendKeys(DMName);
		element(clickOnCloseIcon).click();
		
	}

	/********************************************************************
    * Description: add data to text field and click on close icon
    * Param:
    * Returns: 
    * Status: Completed
    ********************************************************************/

	public boolean checkCloseIconInSubsystemPageORDigitalMachinePage() {
		if(!(element(successfulMessage)).isCurrentlyVisible())
			return true;
		else
			return false;
	}	
	
}
