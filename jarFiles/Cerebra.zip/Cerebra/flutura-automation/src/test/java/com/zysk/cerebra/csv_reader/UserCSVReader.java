package com.zysk.cerebra.csv_reader;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

public class UserCSVReader {

	private static String path = "src/test/resources/dataSources/userData.csv";
	private static HashMap<String,String> data;
	
   
   public static void loadCSV(String target) {

	   data = new HashMap<String, String>();
	   String line;
	   String [] split;

	   target = path;
	   
	   try (BufferedReader br = new BufferedReader(new FileReader(target))) {

	   System.out.println("Reading from " + target);
	   while ((line = br.readLine()) != null) {
	   split = line.split(",");
	   String key = split[0];
	   String value = split[1];

	   if (System.getProperty(key) != null) {
	   value = System.getProperty(key);
	   System.out.println("Overriding key '" + key + "' with value '" + value + "'");
	   }

	   data.put(key,value);
	   }

	   } catch (IOException e) {
	   System.out.println("\n***** ERROR: CSV not found. *****\n");
	   }

	   }

   public static String getKey(String key) {

	   if (data == null) loadCSV(path);

	   if (data.get(key) == null) return "ERROR: Key not found";

	   return data.get(key);

	   }
   
   public static String getUserFirstNameToAdd() {
	   return getKey("UserFirstNameToAdd");
   }
   
   public static String getUserLasttNameToAdd() {
	   return getKey("UserLasttNameToAdd");
   }
   
   public static String getUserPhoneNumberToAdd() {
	   return getKey("UserPhoneNumberToAdd");
   }
   
   public static String getUserEmailIdToAdd() {
	   return getKey("UserEmailIdToAdd");
   }
   
   public static String getDomainToAdd() {
	   return getKey("DomainToAdd");
   }
   
   public static String getPasswordToAdd() {
	   return getKey("PasswordToAdd");
   }
   
   public static String getConfirmToAdd() {
	   return getKey("ConfirmToAdd");
   }
   
   public static String getCustomerToSelect() {
	   return getKey("CustomerToSelect");
   }
   
   public static String getCustomerToDisable() {
	   return getKey("selectCustomerToDisableUser");
   }
   
   public static String getUserToDisable() {
	   return getKey("DisableUser");
   }
   
   public static String getCustomerToEnable() {
	   return getKey("selectCustomerToEnableUser");
   }
   
   public static String getUserToEnable() {
	   return getKey("EableUser");
   }
   
   public static String getUser() {
	   return getKey("UserToVerify");
   }
   
   public static String getCustomerAndEditDeatils() {
	   return getKey("selectCustomerToEditUser");
   }
   
   public static String getUserToEdit() {
	   return getKey("selectUserToEdit");
   }
   
   public static String getUserName() {
	   return getKey("EditUserFirstName");
   }
   
   public static String getLastName() {
	   return getKey("EditUserLastName");
   }
   
   public static String getMobileNumber() {
	   return getKey("MobileNumberr");
   }
   
   public static String getEmailID() {
	   return getKey("EditUserEmailId");
   }
   
   public static String getNewPassword() {
	   return getKey("EditNewPass");
   }
   
   public static String getConfirmPassword() {
	   return getKey("EditConfirmPass");
   }
   
   public static String getDomain() {
	   return getKey("selectDomain");
   }
   
	public static String getUpdatedUserName()
	{
	    return getKey("updatedupdatedUserNameName");	
	}
	
	public static String getCustomerToDeleteUser()
   {
	   return getKey("selectCustomerToDeleteTheUser");
   }

   public static String getUserToDelete()
   {
	   return getKey("selectTheUserToDelete");
   }
   
   public static String getVerifyUserDelete()
   {
	   return getKey("selectTheUserToDelete");
   }
   
   public static String getUserr()
   {
	   return getKey("selectUser");
   }
	   
	public static String getdisableToggleBar()
	{
		return getKey("disableSuccesfull");
	}
	
	public static String getEnableToggleBar()
	{
		return getKey("enableSuccesfull");
	}
	
	public static String getselectGroup()
	{
		return getKey("selectGroup");
	}
	
	public static String getselectUserFromDropdown()
	{
		return getKey("selectUserFromDropdown");
	}
	
	public static String getVerifyUserInList()
	{
		return getKey("groupByUserList");
	}
	
	public static String getselectGroupp()
	{
		
		return getKey("selectgroup");
	}
	
	public static String getFname()
	{
		
		return getKey("invalidFirstName");
	}
	
	public static String getLname() {
		return getKey("invalidLastName");
	}
	
	public static String getUserNameToClickOnPermissionsLink() {
		return getKey("UserNameToClickOnPermissionsLink");
	
	}
	
	public static String getGroupNameToPermissionsTab() {
		return getKey("GroupNameToClickOnViewIcon");
	
	}
	
	public static String getGroupNameToSelectGroup() {
		return getKey("GroupNameToSelectGroup");
	}
	
	public static String getGroupNameToSelectCheckBox() {
		return getKey("GroupNameToSelectCheckBox");
	}
	
	public static String getPermissionTabUrl() {
		return getKey("PermissionTabUrl");
	}
	
	public static String getEmailIdToVerify() {
		return getKey("EmailIdForVerification");
	}
	
	public static String getNewPasswordToVerify() {
		return getKey("NewPasswordForVerification");
	}

	public static String getConfirmPasswordToVerify() {
		return getKey("ConfirmPasswordForVerification");
	}
	
	public static String getAccessControlURLToVerifyNavigationFromPermissionTab() {
		return getKey("AccessControlURLToVerifyNavigationFromPermissionTab");
	}
	
	public static String getUserNameToSelectCheckBox() {
		return getKey("UserNameToSelectCheckBox");
	}
	
	public static String getUserNameToUnSelectCheckBox() {
		return getKey("UserNameToUnSelectCheckBox");
	}
	
	public static String getGroupNameToSelect() {
		return getKey("GrouprNameToUnSelectCheckBox");
	}
	
	public static String getGroupNameToUnSelect() {
		return getKey("GroupNameToUnSelectCheckBox");
	}
	
	public static String getUserNameToSelectFromList() {
		return getKey("UserNameToSelectFromList");
	}
	
	public static String getGroupnameInUserDetailsTabToSelect() {
		return getKey("GroupnameInUserDetailsTabToSelect");
		
	}
	
	public static String getGroupnameInUserDetailsTabToUnselect() {
		return getKey("GroupnameInUserDetailsTabToUnselect");
		
	}
	
	public static String getUserNameToSelectInUserDetailsTab() {
		return getKey("UserNameToSelectInUserDetailsTab");
	}
	
	public static String getUserNameToUnSelectInUserDetailsTab() {
		return getKey("UserNameToUnSelectInUserDetailsTab");
	}

	public static String getUserToDeleteFormuserList() {
		return getKey("UserToDelete");
	}
	
}
