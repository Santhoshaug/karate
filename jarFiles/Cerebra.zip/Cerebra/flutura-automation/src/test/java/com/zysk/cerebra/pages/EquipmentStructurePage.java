package com.zysk.cerebra.pages;

import java.awt.Robot;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.lang.reflect.InvocationTargetException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
//import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Point;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
//import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.server.handler.FindChildElements;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.zysk.cerebra.commonPages.CommonFunctions;
import com.zysk.cerebra.csv_reader.CSVHelper;
import com.zysk.cerebra.csv_reader.EquipmentStructureCSVReader;
//import org.openqa.selenium.remote.internal.JsonToWebElementConverter;
//import org.openqa.selenium.interactions.touch.TouchActions;

//import com.gargoylesoftware.htmlunit.javascript.host.event.InputEvent;

public class EquipmentStructurePage extends CommonFunctions {

	// private JsonToWebElementConverter converter;

	/***********************
	 * Page element identifiers
	 ******************************/
	private By clickOnEquipmentTab = By.xpath(
			"//div[contains(text(),\" Digital Twin Workbench\")]//..//..//..//a[contains(text(),\" Equipment Structure\")]");
//	private By clickOnEquipmentTab = By.xpath("//div[contains(text(),'Digital Twin Workbench')]//..//..//..//a[contains(text(),'Machine Unit')]");
	private By digitalTwinTile = By.xpath("//div[contains(text(),'Digital Twin Workbench')]");
	private By accessControl = By.xpath("//a[contains(text(),'Access Control')]");
	private By equipmentStructure = By.xpath("//a[text()=' Equipment Structure ']");
	private By addNew = By.xpath("//span[text()=' Add New ']");
	private By search = By.xpath("//span[@class='search-bar']");
	private By equipmentList = By.xpath("//div[@class='row']");
//	private By machineUnitTab = By.xpath("//button[@class='header-text mat-button router-active-custom']//span[contains(text()='Machine Units')]");
	private By machineUnitTab = By.xpath("//section//a[contains(text(),'Machine Unit')]");
	private By machineUnitName = By.xpath("//input[@name='name']");
	private By machineUnitDescription = By.xpath("//input[@name='description']");
	private By selectCategory = By.xpath("//span[text()='Select Select Category']");
	private By categoryDropdown = By.xpath("//div/mat-option/span");
	private By selectType = By.xpath("//div[@class='mat-select-value']//span[text()='Select Select Type']");
	private By fileUpload = By.xpath("//input[@id='files']");
	private By addMU = By.xpath("//div/button//span[text()=' Add ']");
	private By type = By.xpath("//mat-select[@id='type']//span[contains(text(),'Select Select Type')]");
	private By typeDropdown = By.xpath("//div/mat-option/span");
	private By configDashboard = By.xpath("//div[@class='text-center side-menu py-3 align-self-center home-icon']");
	private By edit = By.xpath("//a[contains(text(),'Test Machine')]/../../..//span[contains(text(),'Edit')]");
	private By editField = By.xpath("//input[@id='equipment_name']");
	private By update = By.xpath("//span[contains(text(),'Update')]");
	private By categories = By.xpath("//span[contains(text(),'Add Categories')]");
	private By categoryField = By.xpath("//input[@name='category']");
	private By saveCategory = By.xpath("//button[@type='submit']//mat-icon[contains(text(),'done')]");
	private By categoryList = By.xpath("//form[@class='ng-untouched ng-pristine ng-valid ng-star-inserted']//mat-list-item//a[@class='mat-line ng-star-inserted']");
	private By searchfield = By.xpath("(//input[@type='text'])[2]");
	private By listOfMachine = By.xpath("//div[@class='row']/div");

	private static String equipmentStructreUrl = "https://cerebra.flutura.com/configuration#/equipment-structure";
	public static String machineUnit = "Test Machine";
	private static String machineUnitDesc = "Test Description";
	private static String category = "Fleet";
	private static String assetType = "Equipment";
	private By machineUnitAdded = By.xpath("//a[contains(text(),'" + machineUnit + "')]");
	private static String editMachineUnitName = "Test Machine Edited";
	private By editedMachineUnit = By.xpath("//a[contains(text(),'" + editMachineUnitName + "')]");
	// private static String newCategory = "Test Category";
	// private By toggleCategory =
	// By.xpath("//a[contains(text(),'"+newCategory+"')]/../..//div[@class='mat-slide-toggle-bar
	// mat-slide-toggle-bar-no-side-margin']");
	// private By editCategory =
	// By.xpath("//a[contains(text(),'"+newCategory+"')]/../..//mat-icon[contains(text(),'edit')]");
	private By editCategoryField = By.xpath("//input[@name='eleName']");
	private static String editCategoryName = "Test Category Edited";
	private By delete = By.xpath("//button[contains(text(),'Yes, delete it!')]");
	private By toggleMachine = By.xpath("//div[@class='mat-slide-toggle-bar mat-slide-toggle-bar-no-side-margin']");
	private By disabledMsg = By.xpath("//p[@class='text-muted py-2 ng-star-inserted']");
	private By addButton = By.xpath("//mat-icon[contains(text(),'add')]");
	private By searchSubsystem = By.xpath("//input[@type='text' and @placeholder='Search SubSystem']");
	private By machineList = By.xpath("//div[@role='listbox']//mat-option//span");
	private By addSubsystem = By.xpath("//button[@type='button']//span[contains(.,'Add')]");
	private By designParamter = By.xpath("//a[text()='Design Parameters']");
	private By measurements = By.xpath("//a[text()='Measurements']");
	private By alarms = By.xpath("//a[text()='Alarms']");
	private By trips = By.xpath("//a[text()='Trips']");
	private By faults = By.xpath("//a[text()='Faults']");
	private By functionStates = By.xpath("//a[text()='Function States']");
	private By calibration = By.xpath("//a[text()='Calibration']");
	private By nameParameter = By.xpath("//input[@name='name']");
	private By parameterDropdown = By.xpath("//span[contains(text(),'Select parameter')]");
	private By parameterListLocator = By.xpath("//div[@class='cdk-overlay-pane']//span");
	private By parameterList = By.xpath("//mat-row[@class='mat-row ng-star-inserted']");
	private By editParameterField = By.xpath("//span[@class='w-100 px-1 align-self-center ng-star-inserted']//input");
	private By editParameterDropdown = By.xpath("//div[@class='mat-select-value']");
	private By moreOptions = By.xpath("//button[@type='button' and @class='mat-icon-button']");
	private By add = By.xpath("//button[@type='submit']");
	private By addNewParameter = By.xpath(
			"//div[@class='mat-drawer-inner-container']//div[@class='px-1']//button[@class='module-add-btn mr-4 mat-raised-button ng-star-inserted']//span[text()=' Add ']");
	private By newParameterTextField = By.xpath("//input[@name='category']");
	private By parameterTypelocator = By.xpath("//mat-list-item//a[@class='mat-line ng-star-inserted']");
	private By close = By.xpath("//a[@role='button']//mat-icon[text()=' close ']");
	private By addType = By
			.xpath("//button[@class='module-add-btn mr-4 mat-raised-button ng-star-inserted']//span[text()=' Add ']");
	private By parameterListed = By.xpath(
			"//mat-row[@class='mat-row ng-star-inserted']//mat-cell[@class='plain-title-text mat-cell cdk-column-name mat-column-name ng-star-inserted']//span[@class='ng-star-inserted']");
	private By typeWindow = By.xpath("//div[@class='mat-drawer-inner-container']");
	private By editParameterType = By.xpath("//input[@name='eleName']");
	private By EquipmentPageSearchBar = By.xpath("//span[1]//input[@placeholder='Search..']");
	private By MachineUNIT_Tab = By.xpath("//button//span[contains(text(),' Machine Units ')]");

	private By destLocator = By.xpath("(//mat-card[@class='custom-container shadow mat-card']//mat-card-content)[2]");

	/********************************************************************
	 * Description: Visit equipment structure page by clicking on Equipment
	 * structure link Param: NA Returns: Void Status: Completed
	 ********************************************************************/
	public void clickEquipmentStructure() {
		element(clickOnEquipmentTab).click();
		waitForElementToDisappear(loader);
	}

	/********************************************************************
	 * Description: Verify equipment structure page Param: NA Returns: Boolean
	 * Status: Completed
	 ********************************************************************/
	public boolean verifyEquipmentStructure(String equipmentStructreUrl) {
		waitForElementToDisappear(loader);
		if (getDriver().getCurrentUrl().equals(equipmentStructreUrl) && element(addNew).isCurrentlyVisible()
				&& element(search).isCurrentlyVisible() && element(equipmentList).isCurrentlyVisible())
			return true;
		else
			return false;
	}

	/********************************************************************
	 * Description: Click on Add New Button Param: Returns: Void Status: Completed
	 ********************************************************************/
	public void clickOnAddNewButton() {
		element(addNew).click();
		waitForElementToDisappear(loader);
	}

	/********************************************************************
	 * Description: Add new Category Param: Returns: Void Status: Completed
	 ********************************************************************/
	public void addCategory(String categoryName) {
			if (!element(By.xpath("//div[@class='mat-list-text']//a[contains(text(),'"+categoryName+"')]"))
					.isCurrentlyVisible()) {
				element(categories).click();
				element(categoryField).sendKeys(categoryName);
				element(saveCategory).click();
				waitForElementToDisappear(loader);
			}
		}

	/********************************************************************
	 * Description: Verify newly added category in the list Param: Category Returns:
	 * Boolean Status: Completed
	 ********************************************************************/
	public boolean verifyCategoriesAdded(String categoryName) {
		List<WebElement> categList = getDriver().findElements(categoryList);
		int s3 = categList.size();
		boolean result = false;
		for (int i = 0; i < s3; i++) {
			if (categList.get(i).getText().contains(categoryName))
				result = true;
			// else result = false;
		}
		return result;
	}

	/********************************************************************
	 * Description: Verify newly added category in the category dropdown Param:
	 * Category Returns: Boolean Status: Completed
	 ********************************************************************/
	public boolean verifyCategoryInTheDropdown(String categoryName) {
		element(selectCategory).click();
		List<WebElement> categoryList = getDriver().findElements(categoryDropdown);
		int s1 = categoryList.size();
		boolean result1 = false;
		for (int i = 0; i < s1; i++) {
			if (categoryList.get(i).getText().contains(categoryName))
				result1 = true;
		}
		return result1;
	}

	/********************************************************************
	 * Description: Edit the category Param: Category,newCategory Returns: Void
	 * Status: Completed
	 ********************************************************************/
	public void editCategory(String existingCategoryName, String updateCategoryName) {
		getDriver().navigate().refresh();
		waitForElementToDisappear(loader);
		
		if(element(By.xpath("//div[@class='mat-list-text']//a[contains(text(),'"+existingCategoryName+"')]")).isCurrentlyVisible() && 
				!element(By.xpath("//div[@class='mat-list-text']//a[contains(text(),'"+updateCategoryName+"')]")).isCurrentlyVisible())
		{
		element(By.xpath("//div[@class='mat-list-text']//a[contains(text(),'"+existingCategoryName+"')]//..//..//mat-icon[contains(text(),'edit')]"))
				.click();
		element(editCategoryField).clear();
		element(editCategoryField).sendKeys(updateCategoryName);
		element(saveCategory).click();
		waitForElementToDisappear(loader);
		}
	}

	/********************************************************************
	 * Description: Disable added category Param: Category Returns: Void Status:
	 * Completed
	 ********************************************************************/
	public void disableCategories(String categoryName) {
		getDriver().navigate().refresh();
		waitForElementToDisappear(loader);
		if ((element(By.xpath("//a[contains(text(),'" + categoryName + "')]/../..//mat-icon[contains(text(),'edit')]")))
				.isCurrentlyVisible()) {
			element(By.xpath("//a[contains(text(),'" + EquipmentStructureCSVReader.getCategoryNameToEditAndUpdate()
					+ "')]//..//..//mat-icon//..//..//..//button[@mattooltip='Edit']//..//..//div[@class='mat-slide-toggle-thumb']"))
							.click();
			waitForElementToDisappear(loader);
		}
	}

	/********************************************************************
	 * Description: Verify disable category in the list Param: Category Returns:
	 * Boolean Status: Completed
	 ********************************************************************/
	public boolean verifyDisabledCategoryInList(String categoryName) {
		if (!(element(
				By.xpath("//a[contains(text(),'" + categoryName + "')]/../..//mat-icon[contains(text(),'edit')]")))
						.isCurrentlyVisible())
			return true;
		else
			return false;
	}

	/********************************************************************
	 * Description: Verify disable category in the dropdown Param: Category Returns:
	 * Boolean Status: Completed
	 ********************************************************************/
	public boolean verifyEnabledCategory(String categoryName) {
		element(selectCategory).click();
		boolean result1 = false;
		List<WebElement> categoryList = getDriver().findElements(categoryDropdown);
		int s1 = categoryList.size();
		for (int i = 0; i < s1; i++) {
			if (categoryList.get(i).getText().equals(categoryName))
				result1 = true;
			// else result1 = false;
		}
		System.out.println(result1);
		return result1;
	}

	/********************************************************************
	 * Description: Verify Enable category in the dropdown Param: Category Returns:
	 * Boolean Status: Completed
	 ********************************************************************/
	public void enableCategory() {
		if (!(element(By.xpath("//a[contains(text(),'" + EquipmentStructureCSVReader.getCategoryNameToEditAndUpdate()
				+ "')]/../..//mat-icon[contains(text(),'edit')]"))).isCurrentlyVisible()) {
			element(By.xpath("//a[contains(text(),'" + EquipmentStructureCSVReader.getCategoryNameToEditAndUpdate()
					+ "')]//..//..//div[@class='mat-slide-toggle-thumb']")).click();
			waitForElementToDisappear(loader);
		}
	}

	/********************************************************************
	 * Description: Verify Enable category in the dropdown Param: Category Returns:
	 * Boolean Status: Completed
	 ********************************************************************/
	public boolean verifyCategoryEnabled(String categoryName) {
		if (element(By.xpath("//a[contains(text(),'" + categoryName + "')]/../..//mat-icon[contains(text(),'edit')]"))
				.isCurrentlyVisible())
			return true;
		else
			return false;
	}

	/********************************************************************
	 * Description: Delete the category Param: Category Returns: Void Status:
	 * Completed
	 ********************************************************************/
	public void deleteCategory(String categoryUpdatedName, String categoryName) {

		List<WebElement> categoryList = getDriver().findElements(By.xpath("//div[@class='mat-list-text']//a"));
		try{
		for (int i = 0; i<=categoryList.size(); i++) {
			if (categoryList.get(i).getText().equals(categoryUpdatedName)) {
				Actions actions2 = new Actions(getDriver());
				actions2.moveToElement(element(
						By.xpath("//div[@class='mat-list-text']//a[contains(text(),'"+categoryUpdatedName+"')]//..//..//mat-icon[contains(text(),'delete')]")))
						.click().perform();

				waitSeconds(2);
				element(delete).click();
				waitForElementToDisappear(loader);
			}
		}}
		
		catch (Exception e){
			//code to handle exception e
		}
	
		List<WebElement> categoryList2 = getDriver().findElements(By.xpath("//div[@class='mat-list-text']//a"));
		try{
		for (int j = 0; j<=categoryList2.size(); j++) {
			if (categoryList2.get(j).getText().equals(categoryName)) {
				Actions actions2 = new Actions(getDriver());
				actions2.moveToElement(
						element(By.xpath("//div[@class='mat-list-text']//a[contains(text(),'"+categoryName+"')]//..//..//mat-icon[contains(text(),'delete')]")))
						.click().perform();
				waitSeconds(2);
				element(delete).click();
				waitForElementToDisappear(loader);

			}
		}
		}
		catch (Exception e){
			//code to handle exception e
		}
         

	}

	/********************************************************************
	 * Description: Verify deleted category in the category dropdown Param: Category
	 * Returns: Void Status: Completed
	 ********************************************************************/
	public boolean verifyDeletedCategory(String categoryName) {
		element(selectCategory).click();
		List<WebElement> categoryList = getDriver().findElements(categoryDropdown);
		int s1 = categoryList.size();
		boolean result1 = false;
		for (int i = 0; i < s1; i++) {
			if (categoryList.get(i).getText().equals(categoryName))
				result1 = true;
			// else result1 = false;
		}
		System.out.println(result1);
		return result1;
	}

	/********************************************************************
	 * Description: Verify deleted category in the list Param: Category Returns:
	 * Boolean Status: Completed
	 ********************************************************************/
	public boolean verifyDeletedCategoryInList() {
		if (element(By.xpath("//a[contains(text(),'" + EquipmentStructureCSVReader.getCategoryNameToEditAndUpdate()
				+ "')]/../..//mat-icon[contains(text(),'edit')]")).isCurrentlyVisible())
			return true;
		else
			return false;
	}

	/********************************************************************
	 * Description: Fill all the details and add the machine unit Param: NA Returns:
	 * Void Status: Completed
	 ********************************************************************/
	public void addMachineUnit(String machineName, String machineCategory, String machineDescription, String assetType,
			String pathOfImage) {
		if (!element(By.xpath("//a[contains(text(),'" + machineName + "')]")).isCurrentlyVisible()) {
			element(addNew).click();
			waitForElementToDisappear(loader);

			if (!element(By.xpath("//div[@class='mat-list-text']//a[contains(text(),'"+machineCategory+"')]"))
					.isCurrentlyVisible()) {
				element(categories).click();
				element(categoryField).sendKeys(machineCategory);
				element(saveCategory).click();
				waitForElementToDisappear(loader);
			}
			element(machineUnitName).sendKeys(machineName);
			element(machineUnitDescription).sendKeys(machineDescription);
			element(selectCategory).click();
			List<WebElement> categoryList = getDriver().findElements(categoryDropdown);
			int s1 = categoryList.size();
			try {
				for (int i = 0; i < s1; i++) {
					if (categoryList.get(i).getText().equals(machineCategory)) {
						categoryList.get(i).click();
					}
				}
			} catch (StaleElementReferenceException e) {
				System.out.println("Exception handled");
			}
			element(type).click();

			List<WebElement> typeList = getDriver().findElements(typeDropdown);
			int s2 = typeList.size();
			for (int i = 1; i < s2; i++) {
				if (typeList.get(i).getText().equals(assetType)) {
					typeList.get(i).click();
				}
			}
			element(fileUpload).sendKeys(pathOfImage);
			element(addMU).click();
			waitForElementToDisappear(loader);
		}
	}

	/********************************************************************
	 * Description: Completed
	 ********************************************************************/
	public boolean verifyEquipmentORMachineUnitadded(String MachineUnitName) {
		if (element(By.xpath("//a[contains(text(),'" + MachineUnitName + "')]")).isCurrentlyVisible())
			return true;
		else
			return false;
	}

	/********************************************************************
	 * Description: Select Configuration Dashboard Param: NA Returns: Void Status:
	 * Completed
	 ********************************************************************/
	public void selectConfigurationDashboard() {

		element(By.xpath("//div[@mattooltip='Dashboard']//i")).click();
		waitForElementToDisappear(loader);
	}


	/********************************************************************
	 * Description: Edit the machine Unit Param: NA Returns: Void Status: Completed
	 ********************************************************************/
	public void editMachineUnit(String existingMachineUnit, String updateMachineUnit) {
		if (element(By.xpath("//mat-card//a[contains(text(),'" + existingMachineUnit + "')]")).isCurrentlyVisible()
				&& !element(By.xpath("//mat-card//a[contains(text(),'" + updateMachineUnit + "')]"))
						.isCurrentlyVisible()) {
			element(By.xpath(
					"//a[contains(text(),'" + existingMachineUnit + "')]/../../..//span[contains(text(),'Edit')]"))
							.click();
			element(editField).clear();
			element(editField).sendKeys(updateMachineUnit);
			element(update).click();
			waitForElementToDisappear(loader);
//		waitForElementToAppear(addNew);

		}
	}

	/********************************************************************
	 * Description: Verify Machine Unit after editing Param: NA Returns: Boolean
	 * Status: Completed
	 ********************************************************************/
	public boolean verifyEditedMachineUnit(String editmachineunit) {
		if (element(By.xpath("//a[contains(text(),'" + editmachineunit + "')]")).isCurrentlyVisible())
			return true;
		else
			return false;
	}

	/********************************************************************
	 * Description: Disable the machine unit Param: Machine unit Returns: Void
	 * Status: Completed
	 ********************************************************************/
	public void disableMachineUnitInList(String machineUnitToDisable) {
		if (element(By.xpath(
				"//a[contains(text(),'" + machineUnitToDisable + "')]/../../..//span[contains(text(),'Disable')]"))
						.isCurrentlyVisible()) {
			element(By.xpath(
					"//a[contains(text(),'" + machineUnitToDisable + "')]/../../..//span[contains(text(),'Disable')]"))
							.click();
			waitForElementToDisappear(loader);
		}
	}

	/********************************************************************
	 * Description: Verify the machine unit disabled Param: Machineunit Returns:
	 * Boolean Status: Completed
	 ********************************************************************/
	public boolean verifyMachineUnitDisabled(String machineUnitName) {

		if (element(
				By.xpath("//a[contains(text(),'" + machineUnitName + "')]/../../..//span[contains(text(),'Enable')]"))
						.isCurrentlyVisible())
			return true;
		else
			return false;
	}

	/********************************************************************
	 * Description: Enable the machine unit Param: Machineunit Returns: Void Status:
	 * Completed
	 ********************************************************************/
	public void enableMachineUnit(String machineUnit) {
		if (element(By.xpath("//a[contains(text(),'" + machineUnit + "')]/../../..//span[contains(text(),'Enable')]"))
				.isCurrentlyVisible())
			element(By.xpath("//a[contains(text(),'" + machineUnit + "')]/../../..//span[contains(text(),'Enable')]"))
					.click();
		waitForElementToDisappear(loader);
	}

	/********************************************************************
	 * Description: Verify the machine unit disabled Param: Machineunit Returns:
	 * Boolean Status: Completed
	 ********************************************************************/
	public boolean verifyMachineUnitEnabled(String machineUnitName) {

		if (element(
				By.xpath("//a[contains(text(),'" + machineUnitName + "')]/../../..//span[contains(text(),'Disable')]"))
						.isCurrentlyVisible())
			return true;
		else
			return false;
	}

	/********************************************************************
	 * Description: Select the machine unit Param: Machineunit Returns: VOid Status:
	 * Completed
	 ********************************************************************/
	public void selectMachineUnit(String machineUnitName) {
		element(By.xpath("//a[contains(text(),'" + machineUnitName + "')]")).click();
		waitForElementToDisappear(loader);

	}

	/********************************************************************
	 * Description:Disable the machine unit Param: NA Returns: void Status:
	 * Completed
	 ********************************************************************/
	public void disableMachineUnitInSubsystem(String MachineUnitName) {
		if(element(By.xpath("//mat-card//div//span[contains(text(), 'Subsystems - "+MachineUnitName+" ')]//..//div//a//span[contains(text(),'Enabled')]")).isCurrentlyVisible())
		{
			element(toggleMachine).click();
			waitForElementToDisappear(loader);
		}
	}

	/********************************************************************
	 * Description:Disable the machine unit Param: NA Returns: void Status:
	 * Completed
	 ********************************************************************/
	public void EnableMachineUnitInSubsystem(String MachineUnitName) {
		if(element(By.xpath("//mat-card//div//span[contains(text(), 'Subsystems - "+MachineUnitName+" ')]//..//div//a//span[contains(text(),'Disabled')]")).isCurrentlyVisible())
		{
			element(toggleMachine).click();
			waitForElementToDisappear(loader);
		}
	}

	/********************************************************************
	 * Description: Verify machine unit gets disabled Param: NA Returns: Boolean
	 * Status: Completed
	 ********************************************************************/
	public boolean verifyMachineUnitDisabledInSubsystem(String MachineUnitName) {
		if(element(By.xpath("//mat-card//div//span[contains(text(), 'Subsystems - "+MachineUnitName+" ')]//..//div//a//span[contains(text(),'Disabled')]")).isCurrentlyVisible())
			return true;
		else
			return false;
	}

	/********************************************************************
	 * Description: Verify machine unit gets enabled Param: Machineunit Returns:
	 * Boolean Status: Completed
	 ********************************************************************/
	public boolean verifyEnabledMachineUnitInSubunit(String MachineUnitName) {
		if(element(By.xpath("//mat-card//div//span[contains(text(), 'Subsystems - "+MachineUnitName+" ')]//..//div//a//span[contains(text(),'Enabled')]")).isCurrentlyVisible())
			return true;
		else
			return false;
	}

	/********************************************************************
	 * Description: Param: Returns: Status:
	 ********************************************************************/
	public void searchOREquipmentORMachineUnit(String EquipmentORMachineUnit) {
		element(EquipmentPageSearchBar).sendKeys(EquipmentORMachineUnit);
	}

	/********************************************************************
	 * Description: Param: Returns: Status:
	 ********************************************************************/
	public void deleteMachineUnit(String UpdatedMachineUNitName,String MachineUNitName) {
		
		if(element(By.xpath("//a[contains(text(),'" + UpdatedMachineUNitName + "')]//..//../..//span[contains(text(),'Delete')]")).isCurrentlyVisible()) {
			element(By.xpath("//a[contains(text(),'" + UpdatedMachineUNitName + "')]//..//../..//span[contains(text(),'Delete')]"))
			.click();
			element(By.xpath("//button[contains(text(),'Yes, delete it!')]")).click();
			waitForElementToDisappear(loader);
		}
		
		if(element(By.xpath("//a[contains(text(),'" + MachineUNitName + "')]//..//../..//span[contains(text(),'Delete')]")).isCurrentlyVisible()) {
			element(By.xpath("//a[contains(text(),'" + MachineUNitName + "')]//..//../..//span[contains(text(),'Delete')]"))
			.click();
			element(By.xpath("//button[contains(text(),'Yes, delete it!')]")).click();
			waitForElementToDisappear(loader);
		}		
		
	}

	/********************************************************************
	 * Description: Param: Returns: Status:
	 ********************************************************************/
	public void SelectAndClickOnMachineUnit(String MachineUnit) {
		if(element(By.xpath("//a[contains(text(),'" + MachineUnit + "')]")).isCurrentlyVisible()) {
		element(By.xpath("//a[contains(text(),' "+MachineUnit+" ')]")).click();
		waitForElementToDisappear(loader);
		}
	}
	/********************************************************************
	 * Description: Param: Returns: Status:
	 ********************************************************************/
	public boolean verifyMachineUnitDeleted(String MachineUNitName) {
		if (!element(By.xpath("//a[contains(text(),'" + MachineUNitName + "')]")).isCurrentlyVisible())
			return true;
		else
			return false;

	}

	/********************************************************************
	 * Description: Param: Returns: Status:
	 ********************************************************************/
	public void deleteMachineUnitInSubsystem(String machineUnitInsubsystemToDelete) {
		
		if (element(By.xpath("//a[contains(text(),'" + machineUnit + "')]/../../..//span[contains(text(),'Enable')]"))
				.isCurrentlyVisible())
		{
			element(By.xpath("//a[contains(text(),'" + machineUnit + "')]/../../..//span[contains(text(),'Enable')]"))
					.click();
		waitForElementToDisappear(loader);
		
		}
		
		element(By.xpath("//span[contains(text(),' Subsystems - " + machineUnitInsubsystemToDelete
				+ " ')]//..//a//span[contains(text(),'Delete')]")).click();
		element(By.xpath("//button[contains(text(),'Yes, delete it!')]")).click();
		waitForElementToDisappear(loader);
	}

	/********************************************************************
	 * Description: Param: Returns: Status:
	 ********************************************************************/
	public boolean verifyMachineUnitDeletedInSubsystemLevel(String DeletedMachineUnitName) {

		if (element(By.xpath("//a[contains(text(),'" + DeletedMachineUnitName + "')]")).isCurrentlyVisible())
			return true;
		else
			return false;

	}

	/********************************************************************
	 * Description: Param: Returns: Status:
	 ********************************************************************/
	public void addMachineUnitInSubsystemLevel() {
		element(By.xpath("//mat-icon[@mattooltip='Add']")).click();
		element(By.xpath("//input[@placeholder='Search SubSystem']")).click();
		if (element(By.xpath("//mat-option//span")).isCurrentlyVisible()) {
			element(By.xpath("//mat-option[1]//span")).click();
		}
		element(By.xpath("//button[2]//span[contains(text(),'Add')]")).click();
		waitForElementToDisappear(loader);
	}

	/********************************************************************
	 * Description: Param: Returns: Status:
	 ********************************************************************/
	public boolean verifyMachineUnitInSubstemAdded() {
		List<WebElement> Count = getDriver().findElements(By.xpath("//mat-card"));
		int SubsytemList = Count.size();
		if (SubsytemList >= 3)
			return true;
		else
			return false;
	}

	/********************************************************************
	 * Description: Machine unit can be added as subsystem by drag and drop Param:
	 * Source Machineunit,Destination machineunit Returns: Boolean Status: Completed
	 * 
	 * @throws InterruptedException
	 ********************************************************************/
	public void dragAndDropSubsystem(String MachineUnitName) throws InterruptedException {
//       if(element(By.xpath("//div[1][@draggable='true']")).isCurrentlyVisible()){
//    	   Actions act = new Actions(getDriver());
//   		Action dragAndDrop =
//   				act.clickAndHold(element(By.xpath("//div[@class='align-self-center ml-2 textoverFlow']")))
//   				.moveToElement(element(By.xpath("//mat-tree-node[1]//mat-card")))
//   				.release(element(By.xpath("//mat-tree-node[1]//mat-card"))).build();
//   				dragAndDrop.perform();
//   				waitForElementToDisappear(loader);

		WebElement source = getDriver().findElement(By.xpath(
				"//div[@class='example-list cdk-drop-list']//div[@class='example-box ng-star-inserted'][1]//span[@class='textoverFlow']"));
		WebElement target = getDriver().findElement(By.xpath("//a[contains(text(),'" + MachineUnitName + "')]"));
		// dragAndDrop() method for dragging the element from source to //destination
		Actions a = new Actions(getDriver());
		a.dragAndDrop(source, target).build().perform();
		getDriver().quit();
	}

	/********************************************************************
	 * Description: Add parameters Param: NA Returns: Boolean Status: Completed
	 ********************************************************************/
	public void addMachineUnitInSubsystem(String EquipmaentName) {
		element(By.xpath("//mat-card//a[contains(text(),'" + EquipmaentName + "')]")).click();
		waitForElementToDisappear(loader);
	}

	/********************************************************************
	 * Description: Add parameters Param: NA Returns: Boolean Status: Completed
	 ********************************************************************/
	public void addDesignParameter(String tabname, String name, String editparameter) {
		getDriver().navigate().refresh();
		element(By.xpath("//a[text()='" + tabname + "']")).click();
		waitForElementToDisappear(loader);

		if (!element(By.xpath("//mat-row//mat-cell//span[contains(text(),'" + name + "')]")).isCurrentlyVisible()) {
			element(addNew).click();
			waitSeconds(2);
			element(nameParameter).sendKeys(name);
			element(By.xpath("//div[@class='mat-select-arrow']")).click();
			element(By.xpath("//mat-option[2]//span")).click();
			element(addMU).click();
			waitForElementToDisappear(loader);
		}

	}

	/********************************************************************
	 * Description: Edit design paramaters Param: Paramatername ,tabname, Parameter
	 * Returns: Boolean Status: Completed
	 ********************************************************************/
	public void editDesignParameter(String addedparameter, String editparameter) {
		waitForElementToDisappear(loader);
		if (element(By.xpath("//mat-row//mat-cell//span[contains(text(),'" + addedparameter + "')]")).isCurrentlyVisible() && 
				!element(By.xpath("//mat-row//mat-cell//span[contains(text(),'" + editparameter + "')]")).isCurrentlyVisible())	
		{
			element(By.xpath("//span[contains(text(),'" + addedparameter
					+ "')]/../..//button[@class='mat-icon-button ng-star-inserted']")).click();
		element(editParameterField).clear();
		element(editParameterField).sendKeys(editparameter);
		waitSeconds(3);
//			element(editParameterDropdown).click();
//			waitSeconds(2);
		element(By.xpath("//div[@class='mat-select-arrow']")).click();
		element(By.xpath("//mat-option[3]//span")).click();
		waitSeconds(2);
		element(saveCategory).click();
		waitForElementToDisappear(loader);
		}
	}

	/********************************************************************
	 * Description: Disable the parameter added Param: New Parameter name Returns:
	 * Void Status: Completed
	 ********************************************************************/
	public void disableOREnableParameter(String editparameter) {

	if(	element(By.xpath("//mat-row//mat-cell//span[contains(text(),'" + editparameter + "')]")).isCurrentlyVisible()) {
		element(By.xpath(
				"//span[contains(text(),'" + editparameter + "')]/../..//span[@class='slider-align ng-star-inserted']"))
						.click();
		// element(By.xpath("//span[contains(text(),'"+parameter+"')]"));
		// waitSeconds(8);
		waitForElementToDisappear(loader);
		}
	}

	/********************************************************************
	 * Description: Delete the added parameter Param: New Parameter name Returns:
	 * Void Status: Completed
	 ********************************************************************/
	public void deleteAddedParameter(String parameter, String tabname) {
		if (tabname.equals("Design Parameters")) {
		} 
		else  {
			element(By.xpath("//a[text()='" + tabname + "']")).click();
			waitForElementToDisappear(loader);
			// waitSeconds(5);
		}
		if(	element(By.xpath("//mat-row//mat-cell//span[contains(text(),'" + parameter + "')]")).isCurrentlyVisible()){
		element(By.xpath("//span[contains(text(),'" + parameter + "')]/../../mat-cell//mat-icon[text()=' delete ']"))
				.click();
		element(delete).click();
		waitForElementToDisappear(loader);
		}
	}

	/********************************************************************
	 * Description: Param: Returns: Status:
	 ********************************************************************/
	public void addParametrUnit(String tabname,String ParameterName) {
		if(element(By.xpath("//a//mat-icon[contains(text(),'close')]")).isCurrentlyVisible())
		{
			element(By.xpath("//a//mat-icon[contains(text(),'close')]")).click();
		}
		element(By.xpath("//a[text()='" + tabname + "']")).click();
		waitForElementToDisappear(loader);
		element(addNew).click();
		waitFor(200);
		element(By.xpath("//button//span[@class='mat-button-wrapper']//mat-icon[contains(text(),'more_vert')]")).click();
		waitForElementToDisappear(loader);
		if(!element(By.xpath("//mat-list-item//div[@class='mat-list-text']//a[contains(text(),'"+ParameterName+"')]")).isCurrentlyVisible()) {
		element(By.xpath("//button[@mattooltip='Add']")).click();
		element(By.xpath("//input[@placeholder='Enter ']")).sendKeys(ParameterName);
		element(By.xpath("//span//mat-icon[contains(text(),'done')]")).click();
		waitForElementToDisappear(loader);
		}
	}

	/********************************************************************
	 * Description: Param: Returns: Status:
	 ********************************************************************/
	public void editParametrUnit(String ParameterName, String editParameter) {
		if(element(By.xpath("//mat-list-item//a[contains(text(),'"+ParameterName+"')]")).isCurrentlyVisible() && 
				!element(By.xpath("//mat-list-item//a[contains(text(),'"+editParameter+"')]")).isCurrentlyVisible())
		{
		element(By.xpath("//a[contains(text(),'"+ParameterName+"')]//..//..//span//mat-icon[contains(text(),'edit')]")).click();
		element(By.xpath("//input[@name='eleName']")).clear();
		element(By.xpath("//input[@name='eleName']")).sendKeys(editParameter);
		element(By.xpath("//span//mat-icon[contains(text(),'done')]")).click();
		waitForElementToDisappear(loader);
		}
	}

	/********************************************************************
	 * Description: Disable the parameter added Param: New Parameter name Returns:
	 * Void Status: Completed
	 ********************************************************************/
	public void disableOREnableParameterInDesignParametersType(String ParameterName) {
		element(By.xpath("//a[contains(text(),'" + ParameterName + "')]//..//..//div[@class='mat-slide-toggle-thumb']"))
				.click();
		waitForElementToDisappear(loader);
	}

	/********************************************************************
	 * Description: Param: Returns: Void Status: Completed
	 ********************************************************************/

	public boolean verifyDesignParameterAdded(String Parametername) {
		if(element(By.xpath("//mat-cell//span[contains(text(),'"+Parametername+"')]")).isCurrentlyVisible())
			return true;
		else
			return false;

	}

	/********************************************************************
	 * Description: Param: Returns: Void Status: Completed
	 ********************************************************************/

	public boolean verifyDesignParameterEdited(String EditedParametername) {
		if(element(By.xpath("//mat-cell//span[contains(text(),'"+EditedParametername+"')]")).isCurrentlyVisible())
			return true;
		else
			return false;

	}

	/********************************************************************
	 * Description: Param: Returns: Void Status: Completed
	 ********************************************************************/

	public boolean verifyDesignParameterEnabled(String Parametername) {
		String SuccessfulMsg = element(By.xpath("//simple-snack-bar//span")).getText();
		String ExpSuccessfulMsg = "Design parameter '" + Parametername + "' disabled";
		if (SuccessfulMsg.equals(ExpSuccessfulMsg)
				&& element(By.xpath("//mat-row//mat-cell//span[contains(text(),'" + Parametername + "')]"))
						.isCurrentlyVisible())
			return true;
		else
			return false;

	}

	/********************************************************************
	 * Description: Verify parameter disabled Param: New Parameter name Returns:
	 * Void Status: Completed
	 ********************************************************************/
	public boolean verifyDisabledParameter(String parameter) {
		String actclassName = element(By.xpath("//span[contains(text(),'" + parameter
				+ "')]/../..//span[@class='slider-align ng-star-inserted']//mat-slide-toggle")).getAttribute("class");
		String expclassName = "mat-slide-toggle mat-primary cdk-focused cdk-mouse-focused";
		if (actclassName.contains(expclassName))
			return true;
		else
			return false;
	}

	/********************************************************************
	 * Description: Verify parameter enabled Param: New Parameter name Returns: Void
	 * Status: Completed
	 ********************************************************************/
	public boolean verifyEnabledParameter(String parameter) {
		String actclassName = element(By.xpath("//span[contains(text(),'" + parameter
				+ "')]/../..//span[@class='slider-align ng-star-inserted']//mat-slide-toggle")).getAttribute("class");
		String expclassName = "mat-slide-toggle mat-primary cdk-focused cdk-mouse-focused mat-checked";
		if (actclassName.contains(expclassName))
			return true;
		else
			return false;
	}

	/********************************************************************
	 * Description: Param: Returns: Void Status: Completed
	 ********************************************************************/

	public void deleteParameter(String ParameterName) {
		if (element(By.xpath("//mat-cell//span[contains(text(),'" + ParameterName + "')]")).isCurrentlyVisible())
			element(By
					.xpath("//span[contains(text(),'" + ParameterName + "')]//..//..//mat-icon[@mattooltip='Delete']"))
							.click();
		element(delete).click();
		waitForElementToDisappear(loader);
	}

	/********************************************************************
	 * Description: Param: Returns: Void Status: Completed
	 ********************************************************************/

	public boolean verifyDesignParameterDeleted(String Parametername) {
		String SuccessfulMsg = element(By.xpath("//simple-snack-bar//span")).getText();
		String ExpSuccessfulMsg = "Design parameter '" + Parametername + "' deleted";
		if (SuccessfulMsg.equals(ExpSuccessfulMsg)
				&& !element(By.xpath("//mat-row//mat-cell//span[contains(text(),'" + Parametername + "')]"))
						.isCurrentlyVisible())
			return true;
		else
			return false;

	}

	/********************************************************************
	 * Description: Param: Returns: Void Status: Completed
	 ********************************************************************/
	public boolean enableParameters(String ParameterName) {
		String actMsg = element(By.xpath("//simple-snack-bar//span")).getText();
		String expMsg = "Design parameter '" + ParameterName + "' enabled";
		if (actMsg.equals(expMsg))
			return true;
		else
			return false;
	}

	/********************************************************************
	 * Description: Param: Returns: Void Status: Completed
	 ********************************************************************/
	public boolean disableParameters(String ParameterName) {
		String actMsg = element(By.xpath("//simple-snack-bar//span")).getText();
		String expMsg = "Design parameter '" + ParameterName + "' disabled";
		if (actMsg.equals(expMsg))
			return true;
		else
			return false;
	}

	/********************************************************************
	 * Description: Param: Returns: Void Status: Completed
	 ********************************************************************/
	public boolean verifyParameterUnitAdded(String ParameterUnit) {
		if(element(By.xpath("//mat-list-item//div[@class='mat-list-text']//a[contains(text(),'"+ParameterUnit+"')]")).isCurrentlyVisible())
			return true;
		else
			return false;
		
		
	}

	/********************************************************************
	 * Description: Param: Returns: Void Status: Completed
	 ********************************************************************/
	public boolean verifyParameterUnitEdited(String editParameter) {
		if(element(By.xpath("//mat-list-item//a[contains(text(),'"+editParameter+"')]")).isCurrentlyVisible()) 
			return true;
		else
			return false;
	}
	
	
	/********************************************************************
	 * Description: Param: Returns: Void Status: Completed
	 ********************************************************************/
	public void disableParameterUnit(String editParameter) {
		if(element(By.xpath("//div[@class='mat-list-text']//a[contains(text(),'"+editParameter+"')]")).isCurrentlyVisible()) {
			if(element(By.xpath("//div[@class='mat-list-text']//a[contains(text(),'"+editParameter+"')]//..//..//mat-icon[contains(text(),'edit')]")).isCurrentlyVisible())
		element(By.xpath("//div[@class='mat-list-text']//a[contains(text(),'"+editParameter+"')]//..//..//div[@class='mat-slide-toggle-thumb']")).click();
		waitForElementToDisappear(loader);
		}
	}

	/********************************************************************
	 * Description: Param: Returns: Void Status: Completed
	 ********************************************************************/
	public boolean verifyParameterUnitDisabled(String editParameter) {
		if(!element(By.xpath("//div[@class='mat-list-text']//a[contains(text(),'"+editParameter+"')]//..//..//mat-icon[contains(text(),'edit')]")).isCurrentlyVisible())
			return true;
		else
			return false;
		
	}

	/********************************************************************
	 * Description: Param: Returns: Void Status: Completed
	 ********************************************************************/
	public void enableParameterUnit(String editParameter) {
		if(element(By.xpath("//div[@class='mat-list-text']//a[contains(text(),'"+editParameter+"')]")).isCurrentlyVisible()) {
			if(!element(By.xpath("//div[@class='mat-list-text']//a[contains(text(),'"+editParameter+"')]//..//..//mat-icon[contains(text(),'edit')]")).isCurrentlyVisible())
		element(By.xpath("//div[@class='mat-list-text']//a[contains(text(),'"+editParameter+"')]//..//..//div[@class='mat-slide-toggle-thumb']")).click();
		waitForElementToDisappear(loader);
		
		}
	}

	/********************************************************************
	 * Description: Param: Returns: Void Status: Completed
	 ********************************************************************/
	public boolean verifyParameterUnitEnabled(String editParameter) {
		if(element(By.xpath("//div[@class='mat-list-text']//a[contains(text(),'"+editParameter+"')]//..//..//mat-icon[contains(text(),'edit')]")).isCurrentlyVisible())
			return true;
		else
			return false;
	}

	/********************************************************************
	 * Description: Param: Returns: Void Status: Completed
	 ********************************************************************/
	public void ClickOnAddNewAndMenuButton(String tabname) {
		element(By.xpath("//a[text()='" + tabname + "']")).click();
		waitForElementToDisappear(loader);
		element(addNew).click();
		waitFor(200);
		element(By.xpath("//button//span[@class='mat-button-wrapper']//mat-icon[contains(text(),'more_vert')]")).click();
		waitForElementToDisappear(loader);
		
	}
	/********************************************************************
	 * Description: Param: Returns: Void Status: Completed
	 ********************************************************************/
	public void deleteParameterUnit(String editParameter,String ParameterUnit) {
		if(element(By.xpath("//div[@class='mat-list-text']//a[contains(text(),'"+editParameter+"')]")).isCurrentlyVisible())
				{
					element(By.xpath("//div[@class='mat-list-text']//a[contains(text(),'"+editParameter+"')]//..//..//mat-icon[contains(text(),'delete')]")).click();
					element(By.xpath("//div[@class='swal2-actions']//button[contains(text(),'Yes, delete it!')]")).click();
					waitForElementToDisappear(loader);	
				}
				
		if(element(By.xpath("//div[@class='mat-list-text']//a[contains(text(),'"+ParameterUnit+"')]")).isCurrentlyVisible())
		{
			element(By.xpath("//div[@class='mat-list-text']//a[contains(text(),'"+ParameterUnit+"')]//..//..//mat-icon[contains(text(),'delete')]")).click();
			element(By.xpath("//div[@class='swal2-actions']//button[contains(text(),'Yes, delete it!')]")).click();
			waitForElementToDisappear(loader);	
		}
	}

	/********************************************************************
	 * Description: Param: Returns: Void Status: Completed
	 ********************************************************************/
		public boolean verifyParameterUnitDeleted(String editParameter, String ParameterUnit) {
			if(!element(By.xpath("//div[@class='mat-list-text']//a[contains(text(),'"+editParameter+"')]")).isCurrentlyVisible() && 
					!element(By.xpath("//div[@class='mat-list-text']//a[contains(text(),'"+ParameterUnit+"')]")).isCurrentlyVisible()) {
				return true;
			}
			return false;
		}

	
		
//	/********************************************************************
//	 * Description: Param: Returns: Void Status: Completed
//	 ********************************************************************/
//		public void parameterUnitAddButton() {
//			element(By.xpath("//button//span[contains(text(),'Add New')]")).click();
//			element(By.xpath("//span//mat-icon[contains(text(),'more_vert')]")).click();
//			
//		}
//		
//	/********************************************************************
//	 * Description: Param: Returns: Void Status: Completed
//	 ********************************************************************/
//			public void parameterUnitAddButton() {
//				element(By.xpath("//button//span[contains(text(),'Add New')]")).click();
//			}
}
