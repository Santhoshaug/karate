package com.zysk.cerebra.steps;

import com.zysk.cerebra.csv_reader.CSVHelper;
import com.zysk.cerebra.csv_reader.DigitalMachineCSVReader;
import com.zysk.cerebra.csv_reader.EquipmentStructureCSVReader;
import com.zysk.cerebra.csv_reader.UserCSVReader;
import com.zysk.cerebra.pages.UsersPage;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertTrue;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.steps.ScenarioSteps;

public class UsersSteps extends ScenarioSteps{
	
	UsersPage userPage;
	
	/********************************************************************
	* Description: Click on customer link
	* Status: Completed
	********************************************************************/
	@When("^I click on User Link$")
	public void whenIClickOnUserLink()
	{
		userPage.clickUser();
	}
	
	/********************************************************************
	* Description: Customer list will be visible
	* Status: Completed
	********************************************************************/
	@Then("^I can see the list of customers$")
	public void thenICanSeeTheListOfCustomers()
	{
		assertTrue("Customer List Not showing",userPage.verifyUserPage());
	}
	
	/********************************************************************
	* Description: Select the customer
	* Status: Completed
	********************************************************************/
	@When("^I select customer created$")
	public void whenISelectCustomerCreated()
	{
		String customerName = UserCSVReader.getCustomerToSelect();
		userPage.selectCustomer(customerName);
	}
	
	/********************************************************************
	* Description: On selecting customer created, user list will be displayed
	* Status: Completed
	********************************************************************/
	@Then("^I can see user list page$")
	public void thenICanSeeUserListPage()
	{
		assertTrue("User Lists are not displaying",userPage.verifyUserList());
	}
	
	/********************************************************************
	* Description: Add new user
	* Status: Completed
	********************************************************************/
	@When("^I add new user with all the details$")
	public void whenIAddNewUserWithAllTheDetails()
	{
		String UserfirstName = UserCSVReader.getUserFirstNameToAdd();
		String UserlastName = UserCSVReader.getUserLasttNameToAdd();
		String PhoneNumber = UserCSVReader.getUserPhoneNumberToAdd();
		String UseEmailID = UserCSVReader.getUserEmailIdToAdd();
		String DomainName = UserCSVReader.getDomainToAdd();
		String UserPassword = UserCSVReader.getPasswordToAdd();
		String UserConfirmPassword = UserCSVReader.getConfirmToAdd();
		userPage.addNewUser(UserfirstName, UserlastName, PhoneNumber, UseEmailID, DomainName, UserPassword, UserConfirmPassword);
	}
	
	/********************************************************************
	* Description: Added user must be displayed on the list
	* Status: Completed
	********************************************************************/
	@Then("^I can see user getting added$")
	public void thenICanSeeUserGettingAdded()
	{
		String UserFirstname = UserCSVReader.getUserFirstNameToAdd();
		String UserLastName =  UserCSVReader.getUserLasttNameToAdd();
		assertTrue("New User Not added",userPage.verifyUserAdded(UserFirstname,UserLastName));
	}
	
	/********************************************************************
	* Description: Verify search field by entering valid data
	* Status: Completed
	********************************************************************/
    @When("^I enter valid data \"(.*)\" in search field$")
    public void whenIEnterValidDataInSearchField(String validInput)
    {
    	userPage.verifySearchfield(validInput);
    }
    
    /********************************************************************
	* Description: On entering valid data list of users based on entered data
	               should be displayed
	* Status: Completed
	********************************************************************/
    @Then("^List of users should be displayed based on added data$")
    public void thenListOfUsersShouldBeDisplayedBasedOnAddedData()
    {
    	assertTrue("List is not searched",userPage.verifySearchFieldForValidInputs());
    }
    
    /********************************************************************
   	* Description: Verify search field by entering invalid data
   	* Status: Completed
   	********************************************************************/
    @When("^I enter invalid data \"(.*)\" in search field$")
    public void whenIEnterInvalidDataInSearchField(String invalidData)
    {
    	userPage.verifySearchfieldWithInvalidData(invalidData);
    }
    
    /********************************************************************
	* Description: On entering invalid data no data will be displayed
	* Status: Completed
	********************************************************************/
    @Then("^No data will be displayed$")
    public void thenNoDataWillBeDisplayed()
    {
    	assertTrue("data is displaying for Invalid Input",userPage.verifySearchFieldForInValidInputs());
    }
    
	/********************************************************************
	* Description: Select the Customer
	* Status: Completed
	********************************************************************/ 
   
    @And("^I select the customer to disable the user$")
    public void iSelectTheCustomerToDisableTheUser() 
    {
    	String selectCustomer=UserCSVReader.getCustomerToDisable();
    	userPage.clickCustomer(selectCustomer);
    }
    
	/********************************************************************
	* Description: Disable the User
	* Status: Completed
	********************************************************************/ 

    @And("^I disable the User$")
    public void  iDisableTheUser()
    {	
		String DisableUser = UserCSVReader.getUserToDisable();
		userPage.disableUser(DisableUser);
    }
    
    /********************************************************************
	* Description: Verify User is getting disabled
	* Status: Completed
	********************************************************************/ 
   
    @Then("^I can see User is getting disabled$")
    public void iCanSeeUserIsGettingDisable() 
    {  	
      String User=UserCSVReader.getUserToDisable();
     assertTrue("fail",userPage.verifyUserIsgettingDisabled(User));
    }
    
    /********************************************************************
	* Description: Select the Customer to enable
	* Status: Completed
	********************************************************************/ 
   
    @And("^I select the customer to Enable the user$")
    public void iSelectTheCustomerToEnableTheUser() {

    	String selectCustomerToDisable=UserCSVReader.getCustomerToEnable();
    	userPage.clickCustomerToEnable(selectCustomerToDisable);
	
	}
    
	/********************************************************************
	* Description: Enable the User
	* Status: Completed
	********************************************************************/ 

    @And("^I enable the User$")
    public void iEnableTheUser() {
    	
    	String EnableUser = UserCSVReader.getUserToEnable();
		userPage.enableDisabledUser(EnableUser );

    }
    
    /********************************************************************
	* Description: Verify User is getting Enabled
	* Status: Completed
	********************************************************************/ 

    @Then("^I can see User is getting enabled$")
    public void iCanSeeUserIsGettingEnabled() 
    {  	
    	String User=UserCSVReader.getUserToEnable();
     assertTrue("Fail",userPage.verifyUserIsgettingEnabled(User));
    }
    
    
    /********************************************************************
   	* Description: select customer to edit user
   	* Status: Completed
   	********************************************************************/ 
    
    @And("^I select customer to edit the user$")
    public void i_select_customer_to_edit_the_user() {
       String selectCustomerToEditUser = UserCSVReader.getCustomerAndEditDeatils();
	userPage.CustSelect(selectCustomerToEditUser );
    }
    
    /********************************************************************
   	* Description: select user and edit the details
   	* Status: Completed
   	********************************************************************/ 
    
    @And("^I edit the user$")
    public void i_edit_the_user() {
        String EditUser = UserCSVReader.getUserToEdit();
		String userFirstName = UserCSVReader.getUserName();
		String userLastName= UserCSVReader.getLastName();
		String userMobileNumber = UserCSVReader.getMobileNumber();
//		Integer number = Integer.valueOf(userMobileNumber);
		String userEmailId = UserCSVReader.getEmailID();
		String userNewPassword = UserCSVReader.getNewPassword();
		String userConfirmPassword = UserCSVReader.getConfirmPassword();
		String domain = UserCSVReader.getDomain();
		userPage.editUser(EditUser, userFirstName ,userLastName,userMobileNumber,userEmailId,userNewPassword,userConfirmPassword,domain);
	
    }
    
    /********************************************************************
   	* Description: Verifying user details updating
   	* Status: Completed
   	********************************************************************/ 
    
//    @Then("^I can see User details getting updated$")
//    public void i_can_see_user_details_getting_updated() 
//    {
//    		String editUserName = UserCSVReader.getUserName()+' '+UserCSVReader.getLastName();
//    		assertTrue("User details are not edited and updated",userPage.verifyUserDetailsAreUpdating(editUserName));
//    }
//    
    /********************************************************************
   	* Description: Go to users page
   	* Status: Completed
   	********************************************************************/ 
    @And("^I go to users details page$")
    public void i_go_to_users_details_page() {
    	String ClickOnUserName = UserCSVReader.getUser();
		userPage.gotouserPageToViewUpdateDetails(ClickOnUserName);
       
    }
    
    /********************************************************************
   	* Description: Check for email and domin 
   	* Status: Completed
   	********************************************************************/ 
    @Then("^I can see user updated user email and Domain$")
    public void i_can_see_user_updated_user_email_and_domain() {
      String editedMail = UserCSVReader.getEmailID();
	 String EditedDomain = UserCSVReader.getDomain();
	assertTrue("Fail",userPage.verifyUserDetailsAreUpdating(editedMail, EditedDomain));
    }
    
    /********************************************************************
     * Description: Click on customer
     * Status:
     ********************************************************************/
      @And("^I select customer to delete the user$")
      public void andISelectCustomerToDeleteTheUser()
      {
      String selectCustomer=UserCSVReader.getCustomerToDeleteUser();
      userPage.clickCustomer(selectCustomer);
      }
     
     
      /********************************************************************
     * Description: Delete the user
     * Status:
     ********************************************************************/
      @And("^I delete the user$")
      public void andIDeleteTheUser()
      {
      String deleteUser=UserCSVReader.getUserToDelete();
      userPage.deleteUser(deleteUser);
      }
      /********************************************************************
     * Description: Verify user got deleted
     * Status:
     ********************************************************************/
      @Then("^I can see the deleted user is not present in the list$")
      public void thenISeeUserGotDeleted()
      {
      String  verifyDeleteUser= UserCSVReader.getVerifyUserDelete();
      assertTrue("User is still displayed in the hirerarchy",userPage.verifyUserAfterDeleting(verifyDeleteUser));
      }
      /********************************************************************
     * Description: Select the customer
     * Status:
     ********************************************************************/
      @And("^I select the customer to disable and enable user$")
      public void andISelectTheCustomerToDisableAndEnableUser()
      {
      String selectCustomer=UserCSVReader.getCustomerToDeleteUser();
      userPage.clickCustomer(selectCustomer);
      }
      /********************************************************************
     * Description:  select the user
     * Status:
     ********************************************************************/
      @And("^I select the user to disable and enable user$")
      public void andiSelectTheUserToDisableAndEnableUser()
      {
      String selectUser= UserCSVReader.getUser();
      userPage.selectUser(selectUser);
      }
     
      /********************************************************************
     * Description:  To disable the user
     * Status:
     ********************************************************************/
      @And("^I click on disable to disable user$")
      public void andiClickOnDisableToDisableUser()
      {
      userPage.disableUser();
      }
     
      /********************************************************************
     * Description:  To verify user got disabled
     * Status:
     ********************************************************************/
      @Then("^I can see the user got disabled$")
      public void theniCanSeeTheUserGotDisabled()
      {
      String verifyUserDisable= UserCSVReader.getdisableToggleBar();
      assertTrue("Error message is not proper or the user is not disabled ",userPage.verifyUserDisabled(verifyUserDisable));
      }
      /********************************************************************
     * Description:  To enable the user
     * Status:
     ********************************************************************/
      @And("^I click on enable to enable user$")
      public void andi_Click_On_Enable_To_Enable_User()
      {
      userPage.enableUser();
      }
     
      /********************************************************************
     * Description:  To verify user got enabled
     * Status:
     ********************************************************************/
      @Then("^I can see the user got enabled$")
      public void theni_Can_See_The_User_Got_Enabled()
      {
      String verifyUserEnable= UserCSVReader.getEnableToggleBar();
      assertTrue("Error message is not proper or User is not enabled",userPage.verifyUserEnabled(verifyUserEnable));
      }
     
      /********************************************************************
     * Description:  To go to calibration dashboard
     * Status:
     ********************************************************************/
      @And("^I go to dashboard$")
      public void andIGoToDashboard()
      {
      userPage.moveToDashboard();
      }
     
      /********************************************************************
     * Description:  select usergroup
     * Status:
     ********************************************************************/
      @And("^I select the usergroup link$")
      public void andISelectTheUsergroupLink()
      {
      userPage.selectUserGroup();
      }
     
      /********************************************************************
     * Description:  To select the customer
     * Status:
     ********************************************************************/
      @And("^I select the customer to add the user$")
      public void andISelectTheCustomerToAddTheUser()
      {
      String selectCustomer=UserCSVReader.getCustomerToDeleteUser();
      userPage.clickCustomer(selectCustomer);
      }
     
      /********************************************************************
     * Description: selecting the group
     * Status:
     ********************************************************************/
      @And("^I select the group to add the user$")
      public void iselectthegrouptoaddtheuser()
      {
      String selectGroup= UserCSVReader.getselectGroup();
      userPage.selectGroupAddUser(selectGroup);
      }
     
      /********************************************************************
     * Description: add user from the dropdown
     * Status:
     ********************************************************************/
      @And("^I add the user from the dropdown$")
      public void andiAddTheUserFromTheDropdown()
      {
      String selectUserFromDropdown= UserCSVReader.getselectUserFromDropdown();
      userPage.addUserFromDropdown(selectUserFromDropdown);
      }
     
      /********************************************************************
     * Description: verify user got addead in list
     * Status:
     ********************************************************************/
      @Then("^I can see user got addead in the list$")
      public void theni_Can_See_User_Got_Addead_In_The_List()
      {
      String selectUserFromDropdown= UserCSVReader.getselectUserFromDropdown();
      String UserInList= UserCSVReader.getVerifyUserInList();
      assertTrue("User is not enabled",userPage.verifyUserInList(UserInList,selectUserFromDropdown));
      }
      
      /********************************************************************
       * Description:  I click on permission for the user
       * Status:
       ********************************************************************/
       @And("^I click on permission for the user$")
        public void i_click_on_permission_for_the_user()
        {
           String selectUser= UserCSVReader.getUser();
           userPage.clickPermission(selectUser);
        }
          
   /********************************************************************
  * Description: I select any one group in permission link
  * Status:
  ********************************************************************/
   
   @And("^I select any one group in permission link$")
   public void i_select_any_one_group_in_permission_link()
   {
   String selectGroup= UserCSVReader.getselectGroupp();
   userPage.clickGroupInPermission(selectGroup);
   }
           
           
   /********************************************************************
    * Description:
    * Status:
    ********************************************************************/
           
   @And("^I click on Add New button in User list page$")
   public void i_click_on_add_new_button_in_user_list_page(){
	  userPage.addButton();
       
   }
   
   /********************************************************************
    * Description: 
    * Status:
    ********************************************************************/

   @And("^I enter the invalid first name$")
   public void i_enter_the_invalid_first_name()  {
   
   String firstName= UserCSVReader.getFname();
   userPage.enterInvalidFirstName(firstName);
    
   }
   
   /********************************************************************
    * Description: 
    * Status:
    ********************************************************************/
   
   @Then("^I verify error message is showing$")
   public void i_verify_error_message_is_showing() {
	   assertTrue("First name text field is accepting invalid name",userPage.firstNameerrorMessage());
      
   }
   
   /********************************************************************
    * Description: 
    * Status:
    ********************************************************************/
   
   @And("^I click on Permissions link$")
   public void i_click_on_permissions_link() {
	   String UserName= UserCSVReader.getUserNameToClickOnPermissionsLink();
	   userPage.clickOnPermissionLink(UserName);
	   
       
   }
   /********************************************************************
    * Description: 
    * Status:
    ********************************************************************/
   
   @Then("^I verify Permissions screen is displaying$")
   public void i_verify_permissions_screen_is_displaying()  {
	   String expUrl = CSVHelper.getBaseUrl()+ UserCSVReader.getPermissionTabUrl();
	   assertTrue("Permissions tab not displaying",userPage.verifyPermissionLinkTab(expUrl));
       
   }
   
   /********************************************************************
    * Description: 
    * Status:
    ********************************************************************/
   

   @And("^I click on View icon$")
   public void i_click_on_view_icon() {
	   String userGroupNameToClickOnViewIcon= UserCSVReader.getGroupNameToPermissionsTab();
	   userPage.permissionsLinkViewIcon(userGroupNameToClickOnViewIcon);
       
   }
   
   /********************************************************************
    * Description: 
    * Status:
    ********************************************************************/ 
   
   @And("^I click on Edit icon$")
   public void i_click_on_edit_icon() {
	   String userGroupNameToClickOnEditIcon= UserCSVReader.getGroupNameToPermissionsTab();
	   userPage.permissionsLinkEditIcon(userGroupNameToClickOnEditIcon);
      
   }
   
   /********************************************************************
    * Description: 
    * Status:
    ********************************************************************/ 
   
   @And("^I select the Group$")
   public void i_select_the_group()  {
	   String GroupNameToSelectGroup = UserCSVReader.getGroupNameToSelectGroup();
	   userPage.selectGroupNewInPermissionsTab(GroupNameToSelectGroup);
   }
   
   /********************************************************************
    * Description:
    * Status:
    ********************************************************************/ 

   @And("^I select the Group checkbox$")
   public void i_select_the_group_checkbox()  {
	   
	String GroupNameToSelectCheckBox = UserCSVReader.getGroupNameToSelectCheckBox();
	userPage.selectCheckboxOfGroup(GroupNameToSelectCheckBox );
   }
   
   /********************************************************************
    * Description:
    * Status:
    ********************************************************************/ 
   
   @And("^I click on Edit button in Permission Tab$")
   public void i_click_on_edit_button_in_permission_tab()  {
       userPage.clickOnPermissionTabEditButton();
   }
   
   /********************************************************************
    * Description:
    * Status:
    ********************************************************************/ 
   
   @And("^I enter the invalid Last name$")
   public void i_enter_the_invalid_last_name()  {
	   String LastName= UserCSVReader.getLname();
	   userPage.enterInvalidLastName(LastName);
  
   }
   
   /********************************************************************
    * Description:
    * Status:
    ********************************************************************/ 

   @And("^I enter the invalid New password to password text field$")
   public void i_enter_the_invalid_New_password_to_password_text_field()  {
	   String NewPassword= UserCSVReader.getNewPasswordToVerify();
	   userPage.enterInvalidNewPassword(NewPassword);

   }
   
   /********************************************************************
    * Description:
    * Status:
    ********************************************************************/ 

   @And("^I enter the invalid Confirm password to Confirmpassword text field$")
   public void i_enter_the_invalid_Confirm_password_to_Confirmpassword_text_field()  {
	   String ConfirmPassword= UserCSVReader.getConfirmPasswordToVerify();
	   userPage.enterInvalidConfirmPassword(ConfirmPassword);

   }
   
   /********************************************************************
    * Description:
    * Status:
    ********************************************************************/ 
   @Then("^I verify error message is showing for Last name text field$")
   public void i_verify_error_message_is_showing_for_last_name_text_field() {
	   assertTrue("Last name text field is accepting invalid name",userPage.LastNameErrorMessage());
      
   }

   /********************************************************************
    * Description:
    * Status:
    ********************************************************************/ 
   @And("^I enter the invalid EmailId$")
   public void i_enter_the_invalid_email()  {
	   String EmailId= UserCSVReader.getEmailIdToVerify();
	   userPage.enterInvalidEmailID(EmailId);
      
   }
   /********************************************************************
    * Description:
    * Status:
    ********************************************************************/ 
   @Then("^I Verify Edit button is displaying$")
   public void i_verify_edit_button_is_displaying() {
	   assertTrue("Edit button is not displaying",userPage.editButtonInPermissionTabIsdisplaying());
       
   }

   /********************************************************************
    * Description:
    * Status:
    ********************************************************************/ 
   @Then("^I verify AccessControl page is Displaying$")
   public void i_verify_accesscontrol_page_is_displaying()  {
	   String expUrl = CSVHelper.getBaseUrl() + UserCSVReader.getAccessControlURLToVerifyNavigationFromPermissionTab();
	assertTrue("Access control page is not displaying",userPage.accessControlPageIsDiaplaying(expUrl));
      
   }
   
   /********************************************************************
    * Description:
    * Status:
    ********************************************************************/ 
   @Then("^I verify Email id text field showing error message$")
   public void i_verify_email_id_text_field_showing_error_message()  {
	   assertTrue("EmailId text field is accepting invalid emailId format",userPage.EmailIdVerification());
      
   }
   /********************************************************************
    * Description:
    * Status:
    ********************************************************************/ 
   @Then("^I verify error message is showing for New Password field$")
   public void i_verify_error_message_is_showing_for_password_field()  {
	   assertTrue("New password field not satisfies all the rules",userPage.NewPasswordfieldVerification());
    
   }

   /********************************************************************
    * Description:
    * Status:
    ********************************************************************/ 
   
   @Then("^I verify error message is showing for Confirm Password field$")
   public void i_verify_error_message_is_showing_for_Confirm_password_field()  {
	   assertTrue("Confirm password field not satsfies all the rules",userPage.ConfirmPasswordVerification());
   }


   /********************************************************************
    * Description:
    * Status:
    ********************************************************************/ 
   @Then("^I verify group selected in permission tab$$")
   public void i_verify_group_selected_in_permission_tab()  {
	   assertTrue("Group is not selected in permission tab",userPage.editButtonInPermissionTabIsdisplaying());
   }
   
   /********************************************************************
    * Description:
    * Status:
    ********************************************************************/ 
   @Then("^I verify group is selected$")
   public void i_verify_group_is_selected()  {
   String UserNameToSelectGroup = UserCSVReader.getUserNameToSelectCheckBox();
   String GroupNameToSelect = UserCSVReader.getGroupNameToSelect();
   assertTrue("Group is not selected in permission tab",userPage.verifyGroupSelectedSuccessfulMessage(UserNameToSelectGroup,GroupNameToSelect));
   }
   
   /********************************************************************
    * Description:
    * Status:
    ********************************************************************/ 
   @Then("^I verify group is Unselected$")
   public void i_verify_group_is_Unselected()  {
   String UserNameToUnselectGroup = UserCSVReader.getUserNameToUnSelectCheckBox();
   String GroupNameToUnselect = UserCSVReader.getGroupNameToUnSelect();
	assertTrue("Group is not unselected in permission tab",userPage.verifyGroupUnSelectedSuccessfulMessage(UserNameToUnselectGroup,GroupNameToUnselect));
   }
   
   /********************************************************************
    * Description:
    * Status:
    ********************************************************************/ 
   @And("^I Select the User$")
   public void i_select_the_user()  {
	String UserName = UserCSVReader.getUserNameToSelectFromList();
	userPage.selectUserFromList(UserName );
      
   }

   /********************************************************************
    * Description:
    * Status:
    ********************************************************************/ 
   
   @And("^I select the Group in user details page$")
   public void i_select_the_group_in_user_details_page()  {
	   String GroupName = UserCSVReader.getGroupnameInUserDetailsTabToSelect();
	userPage.selectUserGroupInUserDetailsTab(GroupName);
      
   }
    
   /********************************************************************
    * Description:
    * Status:
    ********************************************************************/ 
   @Then("^I verify group is Selected in userdetails page$")
   public void i_verify_group_is_selected_in_userdetails_page()  {
	String UserNameToSelectGroup = UserCSVReader.getUserNameToSelectInUserDetailsTab();
	String GroupNameToSelect = UserCSVReader.getGroupnameInUserDetailsTabToSelect();
	assertTrue("Group not selected",userPage.verifyGroupSelectedSuccessfulMessageInUserDetailsTab(UserNameToSelectGroup,GroupNameToSelect));
      
   }
   
   /********************************************************************
    * Description:
    * Status:
    ********************************************************************/ 
   @Then("^I verify group is UnSelected in Userdetails page$")
   public void i_verify_group_is_unselected_in_userdetails_page() {
	String UserNameToUnselectGroup = UserCSVReader.getUserNameToUnSelectInUserDetailsTab();
	String GroupNameToUnselect = UserCSVReader.getGroupnameInUserDetailsTabToUnselect();
	assertTrue("Group is not unselected",userPage.verifyGroupUnSelectedSuccessfulMessageInUserDetailsTab(UserNameToUnselectGroup,GroupNameToUnselect));
      
   }

   

}
