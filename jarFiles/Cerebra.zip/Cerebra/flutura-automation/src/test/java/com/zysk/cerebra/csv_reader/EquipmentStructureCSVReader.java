package com.zysk.cerebra.csv_reader;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

import com.zysk.cerebra.commonPages.CommonFunctions;

public class EquipmentStructureCSVReader extends CommonFunctions {

	
	public static String target = "src/test/resources/dataSources/equipmentStructure.csv";
	private static HashMap<String,String> data;

	 public static void loadCSV() {

		   data = new HashMap<String, String>();
		   String line;
		   String [] split;
		   
		   try (BufferedReader br = new BufferedReader(new FileReader(target))) {

		   System.out.println("Reading from " + target);
		   while ((line = br.readLine()) != null) {
		   split = line.split(",");
		   String key = split[0];
		   String value = split[1];

		   if (System.getProperty(key) != null) {
		   value = System.getProperty(key);
		   System.out.println("Overriding key '" + key + "' with value '" + value + "'");
		   }

		   data.put(key,value);
		   }

		   } catch (IOException e) {
		   System.out.println("\n***** ERROR: CSV not found. *****\n");
		   }

		   }

	   public static String getKey(String key) {

		   if (data == null) loadCSV();

		   if (data.get(key) == null) return "ERROR: Key not found";

		   return data.get(key);

		   }
	
	public static String getEquipmentStructureUrl()
	{
		return getKey("equipmentStructreUrl");
	}
	
	public static String getCategoryName() {
		return getKey("CategoryName");	
	}
	
	public static String getCategoryNameToEditAndUpdate() {
		return getKey("CategoryNameToEditAndUpdate");
	}
	public static String getMachineUnitName()
	{
		return getKey("MachineUnitNameToAdd");
	}
	
	public static String getMachineUnitDescription()
	{
		return getKey("MachineUnitDescription");
	}
	
	public static String getMachineUnitAssetType()
	{
		return getKey("MachineUnitAssetType");
	}
	
	public static String gePathOfImageForMachineUnit()
	{
		return getKey("PathOfImageForMachineUnit");
	}
	
	public static String getCustomerNameForCustomerSelection()
	{
		return getKey("CustomerNameForCustomerSelection");
	}
	
	public static String getUserGroup() {
		return getKey("Usergroup");
	}
	
	public static String getEditAndUpdatedMachineUnitName() {
		return getKey("EditAndUpdatedMachineUnitName");
	}
	
	public static String getDesignParameterName() {
		return getKey("DesignParameterName");	
	}
	
	public static String getUpdatedDesignParameterName() {
		return getKey("UpdatedDesignParameterName");
	}

	public static String getDesignParameterUnit() {
		return getKey("DesignParameterUnit");
	}

	public static String getUpdatedDesignParameterUnit() {
		return getKey("UpdatedDesignParameterUnit");
	}
	
	}
