package com.zysk.cerebra.steps;

import com.zysk.cerebra.csv_reader.DiagnosticWorkBenchCSVReader;
import static org.junit.Assert.assertTrue;

import com.zysk.cerebra.csv_reader.CSVHelper;
import com.zysk.cerebra.pages.DiagnosticWorkBenchPage;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class DiagnosticWorkBenchSteps  {

	DiagnosticWorkBenchPage diagnosticWorkBench;
	
	/********************************************************************
	* Description: Click on Diagnostic link
	* Status: Completed
	********************************************************************/
	@And("^I click on Diagnostics Link$")
    public void i_click_on_diagnostics_link() {
     diagnosticWorkBench.DiagnosticLink();
    }
	
	/********************************************************************
	* Description: Verify user navigated to Diagnostic page
	* Status: Completed
	********************************************************************/
	@Then("^I am on Diagnostic page$")
    public void i_am_on_diagnostic_page()  {
        String exptUrl = CSVHelper.getBaseUrl()+DiagnosticWorkBenchCSVReader.getDiagnosticUrl();
		diagnosticWorkBench.VerifyDiagnosticPage(exptUrl );
    }
	
	/********************************************************************
	* Description: Search for valid equipments or category in Diagnostic page
	* Status: Completed
	********************************************************************/
	@And("^I Search for Equipments with valid Name$")
    public void i_search_for_equipments_with_valid_name()  {
        String ValidData = DiagnosticWorkBenchCSVReader.getDiagnosticEquipmentName();
		diagnosticWorkBench.SearchBarValidData(ValidData);
    }
	
	/********************************************************************
	* Description: Search related equipments / category lists are displaying
	* Status: Completed
	********************************************************************/
	 @Then("^I can see the Search releated Equipments List$")
	 public void i_can_see_the_search_releated_equipments_list()  {
		 assertTrue("Equipments/CategoryLists are not displaying",diagnosticWorkBench.VerifySearchBarValidData());
	    }

	/********************************************************************
	* Description: Search for Invalid equipments or category in Diagnostic page
	* Status: Completed
	********************************************************************/
    @And("^I Search for Equipments with invalid Name$")
    public void i_search_for_equipments_with_invalid_name()  {
    	String InValidData = DiagnosticWorkBenchCSVReader.getInValidDataForSearchBar();
		diagnosticWorkBench.SearchBarInValidData(InValidData);
    }
    
    /********************************************************************
	* Description: Search related equipments / category lists are not displaying
	* Status: Completed
	********************************************************************/

    @Then("^I can see the Search releated Equipments List is not displaying$")
    public void i_can_see_the_search_releated_equipments_list_is_not_displaying()  {
    	assertTrue("Eqipment/CategoryLists are displaying for Invalid Data",diagnosticWorkBench.VerifySearchBarInValidData());
    }
    
    /********************************************************************
	* Description: 
	* Status: Completed
	********************************************************************/
    @And("^I select the Equipments$")
    public void i_select_the_equipments() {
        String EquipmentName = DiagnosticWorkBenchCSVReader.getDiagnosticEquipmentName();
		diagnosticWorkBench.SelectEquipmentInDiagnostic(EquipmentName);
    }
    
    /********************************************************************
	* Description: 
	* Status: Completed
	********************************************************************/
    @Then("^I can see the list of Models are displaying$")
    public void i_can_see_the_list_of_models_are_displaying() {
        String exptUrl = CSVHelper.getBaseUrl()+DiagnosticWorkBenchCSVReader.getDiagnosticModelUrl();
		String EquipmentName = DiagnosticWorkBenchCSVReader.getDiagnosticEquipmentName();
		assertTrue("Model Tab is not displaying",diagnosticWorkBench.VerifyEquipmentSelectedAndModelsTabDisplaying(exptUrl,EquipmentName));
    }
    /********************************************************************
	* Description: 
	* Status: Completed
	********************************************************************/
    @And("^I select the Models$")
    public void i_select_the_models(){
        String ModelName = DiagnosticWorkBenchCSVReader.getDiagnosticModelName();
		diagnosticWorkBench.DiagnosticSelctModel(ModelName );
    }
    /********************************************************************
	* Description: 
	* Status: Completed
	********************************************************************/
    @Then("^I see Diagnostics Test Tab is displaying$")
    public void i_see_diagnostics_test_tab_is_displaying() {
        String exptUrl = CSVHelper.getBaseUrl() + DiagnosticWorkBenchCSVReader.getDiagnosticTestTabUrl();
		diagnosticWorkBench.VerifyModelIsSelectedAndDiagnosticTestsTabTabDisplaying(exptUrl );
    }
    /********************************************************************
	* Description: 
	* Status: Completed
	********************************************************************/
    @And("^I Search for model with valid name$")
    public void i_search_for_model_with_valid_name(){
    	String ValidData = DiagnosticWorkBenchCSVReader.getDiagnosticModelName();
        diagnosticWorkBench.SearchBarValidModelData(ValidData);
    }
    
    /********************************************************************
	* Description: 
	* Status: Completed
	********************************************************************/
    @Then("^I can see on search the model list are displaying$")
    public void i_can_see_on_search_the_model_list_are_displaying(){
    	assertTrue("Model List is not displaying",diagnosticWorkBench.VerifySearchBarValidModelData());
    }

    /********************************************************************
	* Description: 
	* Status: Completed
	********************************************************************/
    @And("^I search for model with invalid name$")
    public void i_search_for_model_with_invalid_name(){
    	
    	String InValidData = DiagnosticWorkBenchCSVReader.getInValidModelSearchData();
		diagnosticWorkBench.SearchBarInValidModelData(InValidData);
    }
    
    /********************************************************************
	* Description: 
	* Status: Completed
	********************************************************************/
    @Then("^I can see on search the Models lists are not displaying$")
    public void i_can_see_on_search_the_models_lists_are_not_displaying(){
    	
    	assertTrue("Model List is displaying for Invalid data",diagnosticWorkBench.VerifySearchBarInValidModelData());
    }
    
    /********************************************************************
	* Description: 
	* Status: Completed
	********************************************************************/
    @And("^I search for the diagnostics tests with valid name$")
    public void i_search_for_the_diagnostics_tests_with_valid_name(){
    	String ValidData = DiagnosticWorkBenchCSVReader.getTestName();
        diagnosticWorkBench.SearchBarValidDiagnosticTestData(ValidData);
    }
    
    /********************************************************************
	* Description: 
	* Status: Completed
	********************************************************************/
    
    @Then("^I can see search related diagnostics list is displaying$")
    public void i_can_see_search_related_diagnostics_list_is_displaying(){
    	assertTrue("Diagnostics tests list is not displaying",diagnosticWorkBench.VerifySearchBarValidDiagnosticTestData());
    }

    /********************************************************************
	* Description: 
	* Status: Completed
	********************************************************************/
    @And("^I search for the diagnostics tests with invalid name$")
    public void i_search_for_the_diagnostics_tests_with_invalid_name(){
    	String InValidData = DiagnosticWorkBenchCSVReader.getDiagnosticTestsInvalidData();
		diagnosticWorkBench.SearchBarInValidDiagnosticTestData(InValidData);
    }
    
    /********************************************************************
	* Description: 
	* Status: Completed
	********************************************************************/
    @Then("^I can see search related diagnostics list is not displaying$")
    public void i_can_see_search_related_diagnostics_list_is_not_displaying(){
    	assertTrue("Diagnostic tests List is displaying for Invalid data",diagnosticWorkBench.VerifySearchBarInValidDiagnosticTestData());
    }

    /********************************************************************
	* Description: 
	* Status: Completed
	********************************************************************/
    
    @And("^I go to Diagnostic Tests Tab$")
    public void i_go_to_diagnostic_tests_tab()  {
    String EquipmentName = DiagnosticWorkBenchCSVReader.getDiagnosticEquipmentName();
	String ModelName = DiagnosticWorkBenchCSVReader.getDiagnosticModelName();
	diagnosticWorkBench.dianosticTestTab(EquipmentName,ModelName);
    }
    
    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    @And("^I click on radio buttons$")
    public void i_click_on_radio_buttons() {
    	diagnosticWorkBench.clickOnRadioButtons();
        
    }
    
    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    @Then("^I verify radio buttons are working$")
    public void i_verify_radio_buttons_are_working() {
       assertTrue("radio buttons are not clickable",diagnosticWorkBench.verifyRadioButtons());
    }
    
    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    
    @And("^I click on Add Package button in Diagnostic Tests Tab$")
    public void i_click_on_add_package_button_in_diagnostic_tests_tab()  {
       diagnosticWorkBench.clickOnAddPackageButton();
    }
    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    @Then("^I can see Test package card is displaying$")
    public void i_can_see_test_package_card_is_displaying() {
       assertTrue("On click to Add package button Card is not displaying",diagnosticWorkBench.VerifyAddPackageButton());
    }

    /********************************************************************
	* Description: 
	* Status: Completed
	********************************************************************/
    @And("^I add the Test package$")
    public void i_add_the_test_package() {
        String PackageName = DiagnosticWorkBenchCSVReader.getPackageNameTOAdd();
		diagnosticWorkBench.addTestPackage(PackageName);
    }
 
    /********************************************************************
	* Description: 
	* Status: Completed
	********************************************************************/
    @Then("^I can see added TestPackage$")
    public void i_can_see_added_testpackage() {
    	  String PackageName = DiagnosticWorkBenchCSVReader.getPackageNameTOAdd();
        assertTrue("TestPackage Is not added",diagnosticWorkBench.VerifyTestPackageAdded(PackageName));
    }

    /********************************************************************
	* Description: 
	* Status: Completed
	********************************************************************/
    @And("^I add the duplicate Test package$")
    public void i_add_the_duplicate_test_package(){
    	String PackageName = DiagnosticWorkBenchCSVReader.getPackageNameTOAdd();
		diagnosticWorkBench.addDuplicatePackage(PackageName);
    }
    
    /********************************************************************
	* Description: 
	* Status: Completed
	********************************************************************/
    @Then("^I can see duplicate TestPackage not added$")
    public void i_can_see_duplicate_testpackage_not_added(){
       String PackageName = DiagnosticWorkBenchCSVReader.getPackageNameTOAdd();
	assertTrue("Duplicate testpackage is adding",diagnosticWorkBench.VerifyduplicateTestPackage(PackageName));
    }
    
    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    @And("^I add the Symptom Type$")
    public void i_add_the_symptom_type(){
    	String SymptomTypeName = DiagnosticWorkBenchCSVReader.getSymptomTypeNameTOAdd();
 		diagnosticWorkBench.SymptomType(SymptomTypeName);
    }

    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    @Then("^I can see added Symptom Type$")
    public void i_can_see_added_symptom_type(){
    	String SymptomTypeName = DiagnosticWorkBenchCSVReader.getSymptomTypeNameTOAdd();
        assertTrue("SymptomType Is not added",diagnosticWorkBench.VerifySymptomTypeAdded(SymptomTypeName));   
    }
    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    @And("^I add the duplicate Symptom Type$")
    public void i_add_the_duplicate_symptom_type(){
    	String SymptomTypeName = DiagnosticWorkBenchCSVReader.getSymptomTypeNameTOAdd();
		diagnosticWorkBench.addDuplicateSymptomType(SymptomTypeName); 
    }
    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    @Then("^I can see duplicate Symptom Type not added$")
    public void i_can_see_duplicate_symptom_type_not_added(){
    	 String SymptomTypeName = DiagnosticWorkBenchCSVReader.getSymptomTypeNameTOAdd();
    		assertTrue("Duplicate SymptomTypeName is adding",diagnosticWorkBench.VerifyduplicateSymptomType(SymptomTypeName)); 
    }
    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    @And("^I add the Engine Type$")
    public void i_add_the_engine_type(){
    	 String EngineTypeName = DiagnosticWorkBenchCSVReader.getEngineTypeTOAdd();
 		diagnosticWorkBench.addEngineType(EngineTypeName); 
    }
    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    @Then("^I can see added Engine Type$")
    public void i_can_see_added_engine_type(){
    	 String EngineTypeName = DiagnosticWorkBenchCSVReader.getEngineTypeTOAdd();
        assertTrue("TestPackage Is not added",diagnosticWorkBench.VerifyEngineTypeAdded(EngineTypeName));  
    }
    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    @And("^I add the duplicate Engine Type$")
    public void i_add_the_duplicate_engine_type(){
    	 String EngineTypeName = DiagnosticWorkBenchCSVReader.getEngineTypeTOAdd();
		diagnosticWorkBench.addDuplicateEngineType(EngineTypeName);  
    }
    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    @Then("^I can see duplicate Engine Type not added$")
    public void i_can_see_duplicate_engine_type_not_added(){
    	 String EngineTypeName = DiagnosticWorkBenchCSVReader.getEngineTypeTOAdd();
    	assertTrue("Duplicate Engine Type is adding",diagnosticWorkBench.VerifyduplicateEngineType(EngineTypeName));   
    }
    
    /********************************************************************
	* Description: 
	* Status: Completed
	********************************************************************/

    @And("^I click on Add button in Diagnostic Tests Tab$")
    public void i_click_on_add_button_in_diagnostic_tests_tab()  {
       diagnosticWorkBench.ClickOnDiagnosticAddTestButton();
    }
    
    /********************************************************************
	* Description: 
	* Status: Completed
	********************************************************************/
    @Then("^I verify Add test tab is displaying$")
    public void i_verify_add_test_tab_is_displaying()  {
      String exptUrl = CSVHelper.getBaseUrl()+DiagnosticWorkBenchCSVReader.getAddTestTabUrl();
	assertTrue("Add test tab is not displaying",diagnosticWorkBench.verifyAddTestTab(exptUrl ));
    }

    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    @And("^I add data to all the Test details add fields and click on Next button$")
    public void i_add_data_to_all_the_test_deatails_add_fields_and_click_on_next_button()  {
        String Testname = DiagnosticWorkBenchCSVReader.getTestName();
		String TestDescription = DiagnosticWorkBenchCSVReader.getTestDescription();
		String SymptomName = DiagnosticWorkBenchCSVReader.getSymptomName();
		String EngineTypeName = DiagnosticWorkBenchCSVReader.getEngineTypeName();
		String diagnosticTestSeverityName = DiagnosticWorkBenchCSVReader.getdiagnosticTestSeverityName();
		String diagnosticTestPackagName = DiagnosticWorkBenchCSVReader.getdiagnosticTestPackagName();	
		String NotificationTag = DiagnosticWorkBenchCSVReader.getNotificationTag();
		String NotificationMessage = DiagnosticWorkBenchCSVReader.getNotificationMessage();
		String RecomendationDescription = DiagnosticWorkBenchCSVReader.getRecomendationDescription();
		diagnosticWorkBench.addAllTheTestDetails(Testname,TestDescription,SymptomName,EngineTypeName,diagnosticTestSeverityName,diagnosticTestPackagName,NotificationTag,NotificationMessage,RecomendationDescription );
    }

    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    @And("^I add the valid rule and Click on Add rule button$")
    public void i_add_the_valid_rule_and_click_on_add_rule_button()  {
    	String RuleValue = DiagnosticWorkBenchCSVReader.getRuleValue();
        diagnosticWorkBench.AddValidRuleType(RuleValue);
    }
    
    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    @Then("^I see rule is created$")
    public void i_see_rule_is_created()  {
    	String TestName = DiagnosticWorkBenchCSVReader.getTestName();
    	  String ModelName = DiagnosticWorkBenchCSVReader.getDiagnosticModelName();
        assertTrue("Rule is not added",diagnosticWorkBench.verifyRuleIsAdded(TestName,ModelName));
    }
    
    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    @And("^I add the Invalid rule and Click on Add rule button$")
    public void i_add_the_invalid_rule_and_click_on_add_rule_button()  {
        diagnosticWorkBench.AddInvalidRule();
    }
    
    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    @Then("^I see rule is not created$")
    public void i_see_rule_is_not_created()  {
    	 assertTrue("Invalid Rule is showing as valid",diagnosticWorkBench.verifyRuleIsInValid());
    }
    
    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    @And("^I add data to all the second type add fields and click on Next button$")
    public void i_add_data_to_all_the_second_type_add_fields_and_click_on_next_button() {
    	String Testname = DiagnosticWorkBenchCSVReader.getTestNameToAddRuleType2();
		String TestDescription = DiagnosticWorkBenchCSVReader.getTestDescription();
		String SymptomName = DiagnosticWorkBenchCSVReader.getSymptomNameToAddRuleType2();
		String EngineTypeName = DiagnosticWorkBenchCSVReader.getEngineTypeNameToAddRuleType2();
		String diagnosticTestSeverityName = DiagnosticWorkBenchCSVReader.getdiagnosticTestSeverityNameToAddRuleType2();
		String diagnosticTestPackagName = DiagnosticWorkBenchCSVReader.getdiagnosticTestPackagNameToAddRuleType2();	
		String NotificationTag = DiagnosticWorkBenchCSVReader.getNotificationTag();
		String NotificationMessage = DiagnosticWorkBenchCSVReader.getNotificationMessage();
		String RecomendationDescription = DiagnosticWorkBenchCSVReader.getRecomendationDescription();
		diagnosticWorkBench.addDetailsToAllTheFieldsToAddSecondTypeRule(Testname,TestDescription,SymptomName,EngineTypeName,diagnosticTestSeverityName,diagnosticTestPackagName,NotificationTag,NotificationMessage,RecomendationDescription);
    	
    }
    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    @And("^I add the second valid rule and Click on Save button$")
    public void i_add_the_second_valid_rule_and_click_on_save_button() {
      String AnalysisType = DiagnosticWorkBenchCSVReader.getAnalysisType();
	String AlgorithmType =  DiagnosticWorkBenchCSVReader.getAlgorithmType();
	diagnosticWorkBench.AddSecondTypeRule(AnalysisType,AlgorithmType );
    }
    
    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    @Then("^I can see Added rule in Diagnostic test tab$")
    public void i_can_see_added_rule_in_diagnostic_test_tab() {
    	assertTrue(" Rule is not added",diagnosticWorkBench.verifyRuleType2IsAdded());
    }
    
    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    @And("^I Select the Test Name$")
    public void i_select_the_test_name(){
    	String TestName = DiagnosticWorkBenchCSVReader.getTestName();
        diagnosticWorkBench.selectTestName(TestName);
    }

    
    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    @And("^I Edit the Rule$")
    public void i_edit_the_rule(){
    	String RuleValue = DiagnosticWorkBenchCSVReader.getRuleValue();
        diagnosticWorkBench.EditTheDiagnosticRule(RuleValue);
    }
    
    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    @Then("^I see Rule is Edited$")
    public void i_see_rule_is_edited(){
    	String TestName = DiagnosticWorkBenchCSVReader.getTestName();
       assertTrue("Rule is not edited",diagnosticWorkBench.verifyRuleIsEdited(TestName));
    }
    
    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    @And("^I Select the second type Test package Name$")
    public void i_select_the_second_type_test_package_name()  {
        String TestName = DiagnosticWorkBenchCSVReader.getTestNameToAddRuleType2();;
		diagnosticWorkBench.selectSecondTypeTestName(TestName);
    }
    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    @And("^I Edit the second type Rule$")
    public void i_edit_the_second_type_rule()  {
    	String AnalysisType = DiagnosticWorkBenchCSVReader.getAnalysisTypeToEdit();
		String AlgorithmType = DiagnosticWorkBenchCSVReader.getAlgorithmTypeToEdit();
		diagnosticWorkBench.editTheSecondRuleType(AnalysisType,AlgorithmType);
    }
    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    @Then("^I see second type Rule is Edited$")
    public void i_see_second_type_rule_is_edited()  {
    	String TestName = DiagnosticWorkBenchCSVReader.getTestNameToAddRuleType2();
    	 assertTrue("Second type Rule is not edited",diagnosticWorkBench.verifySecondRuleTypeEdited(TestName));
    }
    
    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    @And("^I Edit the Rule without changes$")
    public void i_edit_the_rule_without_changes()  {
    	String RuleValue = DiagnosticWorkBenchCSVReader.getRuleValue();
        diagnosticWorkBench.EditTheDiagnosticRule(RuleValue);
    }

    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    @Then("^I see Rule is not Edited showing error message$")
    public void i_see_rule_is_not_edited_showing_error_message()  {
    	String TestName = DiagnosticWorkBenchCSVReader.getTestName();
    	 assertTrue("Rule is edited even edited with same rule without changes",diagnosticWorkBench.verifyRuleIsNotEditedOnEditWithSameRule(TestName));
    }
    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    @And("^I Edit the second type Rule without changes$")
    public void i_edit_the_second_type_rule_without_changes()  {
    	String AnalysisType = DiagnosticWorkBenchCSVReader.getAnalysisTypeToEdit();
		String AlgorithmType = DiagnosticWorkBenchCSVReader.getAlgorithmTypeToEdit();
		diagnosticWorkBench.editTheSecondRuleType(AnalysisType,AlgorithmType);  
    }
    
    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    @Then("^I see second type Rule is not Edited showing error message$")
    public void i_see_second_type_rule_is_not_edited_showing_error_message()  {
    	String TestName = DiagnosticWorkBenchCSVReader.getTestNameToAddRuleType2();
    	assertTrue("Second type Rule is edited even edited with same rule without changes",diagnosticWorkBench.verifySecondTypeRuleIsNotEditedOnEditWithSameRule(TestName));   
    }

    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    @And("^I disable the testName$")
    public void i_disable_the_testname() {
       diagnosticWorkBench.disableTheTestPackage();
    }
    
    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    @Then("^I can see TestName Disabled$")
    public void i_can_see_testname_disabled() {
    	String TestName = DiagnosticWorkBenchCSVReader.getTestName();
		assertTrue("Test Package not disabled",diagnosticWorkBench.verifyTestPackageDisabled(TestName));
    }
    
    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    @And("^I enable the testName$")
    public void i_enable_the_testname() {
       diagnosticWorkBench.enableTheTestpackage();
    }

    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    @Then("^I can see TestName Enabled$")
    public void i_can_see_testname_enabled() {
    	String TestName = DiagnosticWorkBenchCSVReader.getTestName();
       assertTrue("Test Package not enabled",diagnosticWorkBench.verifyTestPackageEnabled(TestName));
    }
    
    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/

    @And("^I edit the test Package details$")
    public void i_edit_the_test_package_details() {
    	String Testname = DiagnosticWorkBenchCSVReader.getTestNameToEdit();
    	String TestDescription = DiagnosticWorkBenchCSVReader.getTestDescriptionToEdit();
		String SymptomName = DiagnosticWorkBenchCSVReader.getSymptomNameToEditAndAddRule();
		String EngineTypeName = DiagnosticWorkBenchCSVReader.getEngineTypeNameToEditAndAddRule();
		String diagnosticTestSeverityName = DiagnosticWorkBenchCSVReader.getdiagnosticTestSeverityNameToEditAndAddRule();
		String diagnosticTestPackagName = DiagnosticWorkBenchCSVReader.getdiagnosticTestPackagNameToEditAndAddRule();	
		String NotificationTag = DiagnosticWorkBenchCSVReader.getNotificationTagToEditAndAddRule();
		String NotificationMessage = DiagnosticWorkBenchCSVReader.getNotificationMessageToEditAndAddRule();
		String RecomendationDescription = DiagnosticWorkBenchCSVReader.getRecomendationDescriptionToEditAndAddRule();
		diagnosticWorkBench.editTheTestPackageDetails(Testname,TestDescription,SymptomName,EngineTypeName,diagnosticTestSeverityName,diagnosticTestPackagName,NotificationTag,NotificationMessage,RecomendationDescription);
		
    }

    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    @Then("^I can see test package details edited$")
    public void i_can_see_test_package_details_edited() {
    	String TestNameToEdit = DiagnosticWorkBenchCSVReader.getTestNameToEdit();
    	assertTrue("Test Package not disabled",diagnosticWorkBench.verifyTestPackageDetailsEdited(TestNameToEdit));
    }
    
    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    @And("^I delete the testName$")
    public void i_delete_the_testname() {
    	diagnosticWorkBench.DeleteTheTestPackage();
    }
    
    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    @Then("^I can see TestName deleted$")
    public void i_can_see_testname_deleted() {
    	String TestName = DiagnosticWorkBenchCSVReader.getTestNameToEdit();
    	assertTrue("Test Package is not deleted",diagnosticWorkBench.verifyTestPackageDeleted(TestName));
    }

    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    @And("^I delete the second type testName$")
    public void i_delete_the_second_type_testname() {
    	diagnosticWorkBench.deleteTheSecondTypeTestPackage();
    }
    
    /********************************************************************
   	* Description: 
   	* Status: Completed
   	********************************************************************/
    @Then("^I can see Second Type TestName deleted$")
    public void i_can_see_second_type_testname_deleted() {
    	String TestName = DiagnosticWorkBenchCSVReader.getTestNameToAddRuleType2();
    	assertTrue("Second type Test Package not deleted",diagnosticWorkBench.verifySecondTypeTestPackageDeleted(TestName));  
    }
    
    
   
}
