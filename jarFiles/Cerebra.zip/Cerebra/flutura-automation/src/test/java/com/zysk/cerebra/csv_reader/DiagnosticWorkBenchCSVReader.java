package com.zysk.cerebra.csv_reader;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

public class DiagnosticWorkBenchCSVReader {


	private static String path = "src/test/resources/dataSources/DiagnosticWorkbenchData.csv";
	private static HashMap<String,String> data;
	
   
   public static void loadCSV(String target) {

	   data = new HashMap<String, String>();
	   String line;
	   String [] split;

	   target = path;
	   
	   try (BufferedReader br = new BufferedReader(new FileReader(target))) {

	   System.out.println("Reading from " + target);
	   while ((line = br.readLine()) != null) {
	   split = line.split(",");
	   String key = split[0];
	   String value = split[1];

	   if (System.getProperty(key) != null) {
	   value = System.getProperty(key);
	   System.out.println("Overriding key '" + key + "' with value '" + value + "'");
	   }

	   data.put(key,value);
	   }

	   } catch (IOException e) {
	   System.out.println("\n***** ERROR: CSV not found. *****\n");
	   }

	   }

   public static String getKey(String key) {

	   if (data == null) loadCSV(path);

	   if (data.get(key) == null) return "ERROR: Key not found";

	   return data.get(key);
   }	   
	   


	public static String getDiagnosticUrl() {
		return getKey("DiagnosticURL");
	}
	
	public static String getValidDataForSearchBar() {
		return getKey("ValidEquipmentNameORCategoryToSearch");
	}
	
	public static String getInValidDataForSearchBar() {
		return getKey("InvalidDataToSearchbarAndVerify");
	}
	
	public static String getDiagnosticModelUrl() {
		return getKey("DiagnosticModelURL");
	}
	
	public static String getDiagnosticEquipmentName() {
		return getKey("DiagnosticEquipmentNameToSelect");
	}
	public static String getDiagnosticModelName() {
		return getKey("DiagnosticModelName");
	}
	
	public static String getDiagnosticTestTabUrl() {
		return getKey("DiagnosticTestTabUrl");
	}
	
	public static String getValidModelSearchData() {
		return getKey("ValidModelSearchData");
	}
	
	public static String getInValidModelSearchData() {
		return getKey("InvalidDataToSearchbarAndVerify");
	}
	
	public static String getDiagnosticTestsValidData() {
		return getKey("DiagnosticTestsValidData");
	}
	
	public static String getDiagnosticTestsInvalidData() {
		return getKey("InvalidDataToSearchbarAndVerify");
	}
	
	public static String getAddTestTabUrl() {
		return getKey("AddtestUrl");
	}
	
	public static String getTestName() {
		return getKey("TestNameToAdd");
	}

	public static String getTestDescription() {
		return getKey("TestDescriptionToadd");
	}

	public static String getSymptomName() {
		return getKey("SymptomNameToSelectFromDropDown");
	}

	public static String getEngineTypeName() {
		return getKey("EngineTypeNameToSelectFromDropDown");
	}

	public static String getdiagnosticTestSeverityName() {
		return getKey("diagnosticTestSeverityNameToSelectFromDropDown");
	}

	public static String getdiagnosticTestPackagName() {
		return getKey("diagnosticTestPackagNameToSelectFromDropDown");
	}

	public static String getPackageNameTOAdd() {
		return getKey("PackageNameTOAdd");
	}

	public static String getSymptomTypeNameTOAdd() {
		return getKey("SymptomTypeNameTOAdd");
	}

	public static String getEngineTypeTOAdd() {
		return getKey("EngineTypeTOAdd");
	}

	public static String getNotificationTag() {
		return getKey("NotificationTag");
	}

	public static String getNotificationMessage() {
		return getKey("NotificationMessage");
	}

	public static String getRecomendationDescription() {
		return getKey("RecomendationDescription");
	}
	
	public static String getRuleValue() {
		return getKey("RuleToAddValue");
	}

	public static String getTestNameToAddRuleType2() {
		return getKey("TestNameToAddRuleType2");
	}

	public static String getSymptomNameToAddRuleType2() {
		return getKey("SecondSymptomNameToSelectFromDropDown");
	}

	public static String getEngineTypeNameToAddRuleType2() {
		return getKey("SecondEngineTypeNameToSelectFromDropDown");
	}

	public static String getdiagnosticTestSeverityNameToAddRuleType2() {
		return getKey("SeconddiagnosticTestSeverityNameToSelectFromDropDown");
	}

	public static String getdiagnosticTestPackagNameToAddRuleType2() {
		return getKey("SeconddiagnosticTestPackagNameToSelectFromDropDown");
	}
	
	public static String getAnalysisType() {
		return getKey("AnalysisType");
		}

	public static String getAlgorithmType() {
		return getKey("AlgorithmType");
	}

	public static String getAnalysisTypeToEdit() {
		return getKey("AnalysisTypeToEdit");
	}
	
	public static String getAlgorithmTypeToEdit() {
		return getKey("AlgorithmTypeToEdit");
	}

	public static String getTestNameToEdit() {
		return getKey("TestNameToEdit");
	}

	public static String getTestDescriptionToEdit() {
		return getKey("TestDescriptionToEdit");
	}

	public static String getSymptomNameToEditAndAddRule() {
		return getKey("SymptomNameToEditAndAddRule");
	}

	public static String getEngineTypeNameToEditAndAddRule() {
		return getKey("EngineTypeNameToEditAndAddRule");
	}

	public static String getdiagnosticTestSeverityNameToEditAndAddRule() {
		return getKey("");
	}

	public static String getdiagnosticTestPackagNameToEditAndAddRule() {
		return getKey("diagnosticTestPackagNameToEditAndAddRule");
	}

	public static String getNotificationTagToEditAndAddRule() {
		return getKey("NotificationTagToEditAndAddRule");
	}

	public static String getNotificationMessageToEditAndAddRule() {
		return getKey("NotificationMessageToEditAndAddRule");
	}

	public static String getRecomendationDescriptionToEditAndAddRule() {
		return getKey("RecomendationDescriptionToEditAndAddRule");
	}

	
}