package com.zysk.cerebra.csv_reader;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

public class OperatingUnitCSVReader {

		public static String target = "src/test/resources/dataSources/operatingUnit.csv";
		private static HashMap<String,String> data;

		 public static void loadCSV() {

			   data = new HashMap<String, String>();
			   String line;
			   String [] split;
			   
			   try (BufferedReader br = new BufferedReader(new FileReader(target))) {

			   System.out.println("Reading from " + target);
			   while ((line = br.readLine()) != null) {
			   split = line.split(",");
			   String key = split[0];
			   String value = split[1];

			   if (System.getProperty(key) != null) {
			   value = System.getProperty(key);
			   System.out.println("Overriding key '" + key + "' with value '" + value + "'");
			   }

			   data.put(key,value);
			   }

			   } catch (IOException e) {
			   System.out.println("\n***** ERROR: CSV not found. *****\n");
			   }

			   }

		   public static String getKey(String key) {

			   if (data == null) loadCSV();

			   if (data.get(key) == null) return "ERROR: Key not found";

			   return data.get(key);

			   }
		   
		   public static String getOUUrl()
		   {
			   return getKey("operatingUnitUrl");
		   }
		   
		   public static String getCustomer()
		   {
			   return getKey("selectCustomer");
		   }
		   
		   public static String getModelsUrl()
		   {
			   return getKey("modelUrl");
		   }
		   
		   public static String getCustomerforOperatingUnit()
		   {
			   return getKey("selectCustomerToAddOperatingUnit");
		   }
		   
		   public static String getModelToAddOperatingUnit()
		   {
			   return getKey("selectModelToAddOperatingUnit");
		   }
		   
		   public static String getOUNameToAddOperatingUnit()
		   {
			   return getKey("OUName");
		   }
		   
		   public static String getOUNumberToAddOperatingUnit()
		   {
			   return getKey("OUNumber");
		   }
		   
		   public static String getManufacturedDateForOperatingUnit()
		   {
			   return getKey("manufacturedDate");
		   }
		   
		   public static String getGatewayForOperatingUnit()
		   {
			   return getKey("selectGatewayForOU");
		   }
		   
		   public static String getCustomerToAddSubsystem()
		   {
			   return getKey("selectCustomerToAddSubsystemToOperatingUnit");
		   }
		   
		   public static String getModelToAddSubsystem()
		   {
			   return getKey("selectModelToAddSubsytemToOperatingUnit");
		   }
		   
		   public static String getOperatingUnitToAddSubsystem()
		   {
			   return getKey("operatingUnitToAddSubsystem");
		   }
		   
		   public static String getModelToAddAsSubsystem()
		   {
			   return getKey("selectModelToAddAsSubssytem");
		   }
		   
		   public static String getGatewayToAddAsSubsystem()
		   {
			   return getKey("selectGateway");
		   }
		   
		   public static String getCountOfSubsystem()
		   {
			   return getKey("countofSubsystem");
		   }
		   
		   public static String getCustomerToReassignOperatingUnitToAnotherCustomer()
		   {
			   return getKey("selectCustomerToReassignOperatingUnitToAnotherCustomer");
		   }
		   
		   public static String getModelToReassignOperatingUnitToAnotherCustomer()
		   {
			   return getKey("selectModelToReassignOperatingUnitToAnotherCustomer");
		   }

		   public static String getOperatingUnitToReassign()
		   {
			   return getKey("selectOperatingUnitToReassign");
		   }
		   
		   public static String getcustomerToWhichOperatingUnitIsReassigned()
		   {
			   return getKey("customerToWhichOperatingUnitIsReassigned");
		   }
		   
		   public static String getCustomerToAddSubsystemWithCountMoreThan1()
		   {
			   return getKey("selectCustomerToAddSubsystemToOperatingUnitWithCount>1");
		   }
		   
		   public static String getModelToAddSubsystemWithCountMoreThan1()
		   {
			   return getKey("selectModelToAddSubsystemToOperatingUnitWithCount>1");
		   }
		   
		   public static String getOperatingUnitToAddSubsystemWithCountMoreThan1()
		   {
			   return getKey("operatingUnitToAddSubsystemWithCount>1");
		   }
		   
		   public static String getModelToAddAsSubsystemWithCountMoreThan1()
		   {
			   return getKey("selectModelToAddAsSubssytemWithCount>1");
		   }
		   
		   public static String getGatewayToAddSubsystemWithCountMoreThan1()
		   {
			   return getKey("selectGatewayToAddSubystemWithCount>1");
		   }
		   
		   public static String getCountOfSubsystemToAddSubsystemWithCountMoreThan1()
		   {
			   return getKey("countofSubsystem>1");
		   }
		   
		   public static String getCustomerToUpdateOperatingUnit()
		   {
			   return getKey("selectCustomerToEditOperatingUnit");
		   }
		   
		   public static String getModelToUpdateOperatingUnit()
		   {
			   return getKey("selectModelToEditOperatingUnit");
		   }
		   
		   public static String getOperatingUnitToEdit()
		   {
			   return getKey("selectOperatingUnitToEdit");
		   }
		   
		   public static String getUpdatedOpertingUnitName()
		   {
			   return getKey("OUNameEdit");
		   }
		   
		   public static String getUpdatedOpertingUnitNumber()
		   {
			   return getKey("OUNumberEdit");
		   }
		   
		   public static String getManufacturedDatetOUpdateOperatingUnit()
		   {
			   return getKey("updateManufacturedDate");
		   }
		   
		   public static String getDeploymentDatetoUpdateOperatingUnit()
		   {
			   return getKey("deploymentDate");
		   }
		   
		   public static String getGatewayToUpdate()
		   {
			   return getKey("updateGateway");
		   }
	
		   public static String getCustomerToVerifyOperatingUnitDetails()
		   {
			   return getKey("selectCustomerToVerifyOperatingUnitDetails");
		   }
		   
		   public static String getModelToVerifyOperatingUnitDetails()
		   {
			   return getKey("selectModelToVerifyOperatingUnitDetails");
		   }
		   
		   public static String getOperatingUnitToVerifyOperatingUnitDetails()
		   {
			   return getKey("selectOperatingUnitToViewOperatingDetails");
		   }
		   
		   public static String getCustomerToDisableEnableOperatingUnit()
		   {
			   return getKey("selectCustomerToDisableEnableOperatingUnitDetails");
		   }
		   
		   public static String getModelToDisableEnableOperatingUnit()
		   {
			   return getKey("selectModelToDisableEnableOperatingUnitDetails");
		   }
		   
		   public static String getOperatingUnitToDisableEnableOperatingUnit()
		   {
			   return getKey("selectOperatingUnitToDisableEnable");
		   }
		   
		   public static String getCustomerToDeleteOperatingUnit()
		   {
			   return getKey("selectCustomerToDeleteOperatingUnit");
		   }
		   
		   public static String getModelToDeleteOperatingUnit()
		   {
			   return getKey("selectModelToDeleteOperatingUnit");
		   }
		   
		   public static String getOperatingUnitToDelete()
		   {
			   return getKey("selectOperatingUnitToDelete");
		   }
		   
		   public static String getCustomerToAddParameterForOperatingUnit()
		   {
			   return getKey("selectCustomerToAddParameterToOperatingUnit");
		   }
		   
		   public static String getModelToAddParameterForOperatingUnit()
		   {
			   return getKey("selectModelToAddParameterToOperatingUnit");
		   }
		   
		   public static String getOperatingUnitToAddParameter()
		   {
			   return getKey("selectOperatingUnitToAddParaemeter");
		   }
		   
		   public static String getMeasurementName()
		   {
			   return getKey("measurementName");
		   }
		   
		   public static String getMeasurementParameter()
		   {
			   return getKey("measurementParameter");
		   }
		   
		   public static String getMetricOptionForMeasurement()
		   {
			   return getKey("metricOptionForMeasurement");
		   }
		   
		   public static String getUnitOfMeasurement()
		   {
			   return getKey("unitForMeasurement");
		   }
		   
		   public static String getPriorityofMeasurement()
		   {
			   return getKey("prioritySelectionForMeasurement(yes/no)");
		   }
		   
		   public static String getAlarmName()
		   {
			   return getKey("alarmName");
		   }
		   
		   public static String getAlarmParameter()
		   {
			   return getKey("alarmParameter");
		   }
		   
		   public static String getTripName()
		   {
			   return getKey("tripName");
		   }
		   
		   public static String getTripParameter()
		   {
			   return getKey("tripParameter");
		   }
		   
		   public static String getFaultName()
		   {
			   return getKey("faultName");
		   }
		   
		   public static String getFaultParameter()
		   {
			   return getKey("faultParameter");
		   }
		   
		   public static String getFSName()
		   {
			   return getKey("fsName");
		   }
		   
		   public static String getFSParameter()
		   {
			   return getKey("fsParameter");
		   }
		   
		   public static String getCalibrationName()
		   {
			   return getKey("calibrationName");
		   }
		   
		   public static String getCalibrationParameter()
		   {
			   return getKey("calibrationParameter");
		   }
		   
		   public static String getMetricOptionForCalibration()
		   {
			   return getKey("metricOptionForCalibration");
		   }
		   
		   public static String getUnitOfCalibration()
		   {
			   return getKey("unitForCalibration");
		   }
		   
		   public static String getCalibrationValue()
		   {
			   return getKey("calibrationValue");
		   }
		   
		   public static String getCustomerToEditParameterForOperatingUnit()
		   {
			   return getKey("selectCustomerToEditParameterToOperatingUnit");
		   }
		   
		   public static String getModelToEditParameterForOperatingUnit()
		   {
			   return getKey("selectModelToEditParameterToOperatingUnit");
		   }
		   
		   public static String getOperatingUnitToEditParameter()
		   {
			   return getKey("selectOperatingUnitToEditParaemeter");
		   }
		   
		   public static String getParameterNameToEdit()
		   {
			   return getKey("parameterNameToEditForMeasurement");
		   }
		   
		   public static String getUpdatedParameterName()
		   {
			   return getKey("updateParameterNameForMeasurement");
		   }
		   
		   public static String getMetricSelection()
		   {
			   return getKey("metricSelectionToEditForMeasurement");
		   }
		   
		   public static String getUnitOfMeasurementToEdit()
		   {
			   return getKey("unitOfMeasurement");
		   }
		   
		   public static String getLCLValue()
		   {
			   return getKey("lclValue");
		   }
		   
		   public static String getUCLValue()
		   {
			   return getKey("uclValue");
		   }
		   
		   public static String getMinimumSignalRange()
		   {
			   return getKey("minSignalRange");
		   }
		   
		   public static String getMaximumSignalRange()
		   {
			   return getKey("maxSignalRange");
		   }
		   
		   public static String getTagId()
		   {
			   return getKey("tagID");
		   }
		   
		   public static String getPriorityFlag()
		   {
			   return getKey("priority(ON/OFF)");
		   }
		   
		   public static String getVisibilityFlag()
		   {
			   return getKey("visibility(ON/OFF)");
		   }
		   
		   public static String getAggregatorSelection()
		   {
			   return getKey("aggregatorSelection");
		   }
		   
		   public static String getAlarmNameToEdit()
		   {
			   return getKey("alarmNameToEditAlarm");
		   }
		   
		   public static String getUpdatedAlarmName()
		   {
			   return getKey("updateParameterNameForAlarm");
		   }
		   
		   public static String getSeverityForAlarm()
		   {
			   return getKey("severityForAlarm");
		   }
		   
		   public static String gettagIdForAlarm()
		   {
			   return getKey("tagIdForAlarm");
		   }
		   
		   public static String getrelatedMeasurementForAlarm()
		   {
			   return getKey("relatedMeasurementForAlarm");
		   }
		   
		   public static String getrecommendedMessageForAlarm()
		   {
			   return getKey("recommendationMessageForAlarm");
		   }
		   
		   public static String getTripNameToEdit()
		   {
			   return getKey("tripNameToEdit");
		   }
		   
		   public static String getUpdatedTripName()
		   {
			   return getKey("updateParameterNameForTrip");
		   }
		   
		   public static String getSeverityForTrip()
		   {
			   return getKey("severityForTrip");
		   }
		   
		   public static String gettagIdForTrip()
		   {
			   return getKey("tagIdForTrip");
		   }
		   
		   public static String getrelatedMeasurementForTrip()
		   {
			   return getKey("relatedMeasurementForTrip");
		   }
		   
		   public static String getrecommendedMessageForTrip()
		   {
			   return getKey("recommendationMessageForTrip");
		   }
		   
		   public static String getFaultNameToEdit()
		   {
			   return getKey("faultNameToEdit");
		   }
		   
		   public static String getUpdatedFaultName()
		   {
			   return getKey("updateParameterNameForFault");
		   }
		   
		   public static String getSeverityForFault()
		   {
			   return getKey("severityForFault");
		   }
		   
		   public static String gettagIdForFault()
		   {
			   return getKey("tagIdForFault");
		   }
		   
		   public static String getrelatedMeasurementForFault()
		   {
			   return getKey("relatedMeasurementForFault");
		   }
		   
		   public static String getrecommendedMessageForFault()
		   {
			   return getKey("recommendationMessageForFault");
		   }
		   
		   public static String getFSNameToEdit()
		   {
			   return getKey("FSNameToEdit");
		   }
		   
		   public static String getUpdatedFSName()
		   {
			   return getKey("updateParameterNameForFS");
		   }
		   
		   public static String gettagIdForFS()
		   {
			   return getKey("tagIdForFS");
		   }
		   
		   public static String getrelatedMeasurementForFS()
		   {
			   return getKey("relatedMeasurementForFS");
		   }
		   
		   public static String getCalibrationNameToEdit()
		   {
			   return getKey("CalibrationNameToEdit");
		   }
		   
		   public static String getUpdatedCalibrationName()
		   {
			   return getKey("updateParameterNameForCalibration");
		   }
		   
		   public static String getMetricUntiForCalibration()
		   {
			   return getKey("metricUnitSelectionForCalibration");
		   }
		   
		   public static String getUpdatedUnitOfCalibration()
		   {
			   return getKey("unitForCalibraTion");
		   }
		   
		   public static String getTagIdForCalibration()
		   {
			   return getKey("tagIdForCalibration");
		   }
		   
		   public static String getRelatedMeasurementForCalibration()
		   {
			   return getKey("relatedMeasurementForCalibration");
		   }
		   
		   public static String getValueToUpdateCalibration()
		   {
			   return getKey("valueToUpdateForCalibration");
		   }
		   
		   public static String getCustomerToDisableEnableParameterForOperatingUnit()
		   {
			   return getKey("selectCustomerToDisableEnableParameterToOperatingUnit");
		   }
		   
		   public static String getModelToDisableEnableParameterForOperatingUnit()
		   {
			   return getKey("selectModelToDisableEnableParameterToOperatingUnit");
		   }
		   
		   public static String getOperatingUnitToDisableEnableParameter()
		   {
			   return getKey("selectOperatingUnitToDisableEnableParaemeter");
		   }
		   
		   public static String getMeasurementParameterToDisableEnable()
		   {
			   return getKey("measurementParameterToDisableEnable");
		   }
		   
		   public static String getAlarmParameterToDisableEnable()
		   {
			   return getKey("alarmParameterToDisablEnable");
		   }
		   
		   public static String getTripParameterToDisableEnable()
		   {
			   return getKey("tripParameterToDisableEnable");
		   }
		   
		   public static String getFaultParameterToDisableEnable()
		   {
			   return getKey("faultParameterToDisableEnable");
		   }
		   
		   public static String getFSParameterToDisableEnable()
		   {
			   return getKey("fsParameterToDisableEnable");
		   }
		   
		   public static String getCalibrationParameterToDisableEnable()
		   {
			   return getKey("calibrationToDisableEnable");
		   }
		   
		   public static String getCustomerToDeleteParameterForOperatingUnit()
		   {
			   return getKey("selectCustomerToDeleteParameterToOperatingUnit");
		   }
		   
		   public static String getModelToDeleteParameterForOperatingUnit()
		   {
			   return getKey("selectModelToDeleteParameterToOperatingUnit");
		   }
		   
		   public static String getOperatingUnitToDeleteParameter()
		   {
			   return getKey("selectOperatingUnitToDeleteParaemeter");
		   } 
		   
		   public static String getMeasurementParameterToDelete()
		   {
			   return getKey("measurementParameterToDelete");
		   }
		   
		   public static String getAlarmParameterToDelete()
		   {
			   return getKey("alarmParameterToDelete");
		   }
		   
		   public static String getTripParameterToDelete()
		   {
			   return getKey("tripParameterToDelete");
		   }
		   
		   public static String getFaultParameterToDelete()
		   {
			   return getKey("faultToDelete");
		   }
		   
		   public static String getFSParameterToDelete()
		   {
			   return getKey("fsToDelete");
		   }
		   
		   public static String getCalibrationParameterToDelete()
		   {
			   return getKey("calibrationToDelete");
		   }
		   
		   public static String getCustomerToSyncParameterForOperatingUnit()
		   {
			   return getKey("selectCustomerToSyncParameterToOperatingUnit");
		   }
		   
		   public static String getModelToSyncParameterForOperatingUnit()
		   {
			   return getKey("selectModelToSyncParameterToOperatingUnit");
		   }
		   
		   public static String getOperatingUnitToSyncParameter()
		   {
			   return getKey("selectOperatingUnitToSyncParaemeter");
		   } 
		   
			public static String getAssetNameToAssignInAccessControl()
			{
				return getKey("assetNameToAssignInAccessControl");
			}
		   
		   public static String getCustomerToAddOperatingUnitWithAnExistingName()
		   {
			   return getKey("selectCustomerToVerifyDuplicateParameterForOU");
		   }
		   
		   public static String getModelToAddOperatingUnitWithAnExistingName()
		   {
			   return getKey("selectModelToVerifyDuplicateParameterForOU");
		   }
		   
		   public static String getOperatingUnitNameToVerifyDuplicate()
		   {
			   return getKey("selectOperatingUnitToVerifyDuplicateParameterForOU");
		   }
		   
		   public static String getOperatingUnitNumberToVerifyDuplicate()
		   {
			   return getKey("operatingUnitNumberToVerifyDuplicate");
		   }
		   
		   public static String getOperatingUnitDateToVerifyDuplicate()
		   {
			   return getKey("operatingUnitDateToVerifyDuplicate");
		   }
		   
		   public static String getOperatingUnitGatewayToVerifyDuplicate()
		   {
			   return getKey("operatingUnitGatewayToVerifyDuplicate");
		   }
		   
		   public static String getCustomerToVerifyDuplicateParameterForOU()
		   {
			   return getKey("selectCustomerToVerifyDuplicateParameterForOU");
		   }
		   
		   public static String getModelToVerifyDuplicateParameterForOU()
		   {
			   return getKey("selectModelToVerifyDuplicateParameterForOU");
		   }
		   
		   public static String getOUToVerifyDuplicateParameterForOU()
		   {
			   return getKey("selectOperatingUnitToVerifyDuplicateParameterForOU");
		   }
		   
		   public static String getMeasurementNameToVerifyDuplicateParameterForOU()
		   {
			   return getKey("measurementNameToVerifyDuplicateParameter");
		   }
		   
		   public static String getMeasurementParameterToVerifyDuplicateParameterForOU()
		   {
			   return getKey("measurementParameterToVerifyDuplicateParameter");
		   }
		   
		   public static String getMetricOptionToVerifyDuplicateParameterForOU()
		   {
			   return getKey("metricOptionForMeasurementToVerifyDuplicateParameter");
		   }
		   
		   public static String getUnitForMeasurementToVerifyDuplicateParameterForOU()
		   {
			   return getKey("unitForMeasurementToVerifyDuplicateParameter");
		   }
		   
		   public static String getPrioritySelectionForMeasurementToVerifyDuplicateParameterForOU()
		   {
			   return getKey("prioritySelectionForMeasurementToVerifyDuplicateParameter(ON/OFF)");
		   }
		   
		   public static String getAlarmParameterNameToVerifyDuplicateParameterForOU()
		   {
			   return getKey("parameterNameForAlarmToVerifyDuplicate");
		   }
		   
		   public static String getAlarmParameterToVerifyDuplicateParameterForOU()
		   {
			   return getKey("alarmParameterToVerifyDuplicate");
		   }
		   
		   public static String getTripParameterNameToVerifyDuplicateParameterForOU()
		   {
			   return getKey("parameterNameForTripToVerifyDuplicate");
		   }
		   
		   public static String getTripParameterToVerifyDuplicateParameterForOU()
		   {
			   return getKey("tripParameterToVerifyDuplicate");
		   }
		   
		   public static String getFaultParameterNameToVerifyDuplicateParameterForOU()
		   {
			   return getKey("parameterNameForFaultToVerifyDuplicate");
		   }
		   
		   public static String getFaultParameterToVerifyDuplicateParameterForOU()
		   {
			   return getKey("faultParameterToVerifyDuplicate");
		   }
		   
		   public static String getFunctionStatesParameterNameToVerifyDuplicateParameterForOU()
		   {
			   return getKey("parameterNameForFunctionStatesToVerifyDuplicate");
		   }
		   
		   public static String getFunctionStatesParameterToVerifyDuplicateParameterForOU()
		   {
			   return getKey("functionStatesParameterToVerifyDuplicate");
		   }
		   
		   public static String getCalibrationParameterNameToVerifyDuplicateParameterForOU()
		   {
			   return getKey("parameterNameForCalibrationToVerifyDuplicate");
		   }
		   
		   public static String getCalibrationValueToVerifyDuplicateParameterForOU()
		   {
			   return getKey("calibrationValueToVerifyDuplicate");
		   }
		   
		   public static String getCalibrationParameterToVerifyDuplicateParameterForOU()
		   {
			   return getKey("calibrationParameterToVerifyDuplicate");
		   }
		   
		   public static String getMetricSelectionToVerifyDuplicateParameterForOU()
		   {
			   return getKey("metricSelectionForCalibrationToVerifyDuplicate");
		   }
		   
		   public static String getUnitSelectionToVerifyDuplicateParameterForOU()
		   {
			   return getKey("unitSelectionForCalibrationToVerifyDuplicate");
		   }
		   
		   public static String getCustomerToVerifyDuplicateParameterForOUWhileEditing()
		   {
			   return getKey("selectCustomerToUpdateParameterWithDuplicateToOperatingUnit");
		   }
		   
		   public static String getModelToVerifyDuplicateParameterForOUWhileEditing()
		   {
			   return getKey("selectModelToUpdateParameterWithDuplicateToOperatingUnit");
		   }
		   
		   public static String getOUToVerifyDuplicateParameterForOUWhileEditing()
		   {
			   return getKey("selectOperatingUnitToUpdateParameterWithDuplicate");
		   }
		   
		   public static String getMeausrementNameToVerifyDuplicateParameterForOUWhileEditing()
		   {
			   return getKey("measurementParameterToEditToVerifyDuplicate");
		   }
		   
		   public static String getUpdatedMeausrementNameToVerifyDuplicateParameterForOUWhileEditing()
		   {
			   return getKey("updatedMeasurementNameToVerifyDuplicateWhileEditing");
		   }
		   
		   public static String getMetricSelectionForMeasurementToVerifyDuplicateParameterForOUWhileEditing()
		   {
			   return getKey("metricSelectionToVerifyDuplicateWhileEditing");
		   }

		   public static String getUnitForMeasurementToVerifyDuplicateParameterForOUWhileEditing()
		   {
			   return getKey("unitForMeasurementToVerifyDuplicateWhileEditing");
		   }
		   
		   public static String getlclValueForMeasurementToVerifyDuplicateParameterForOUWhileEditing()
		   {
			   return getKey("lclValueForMeasurementToVerifyDuplicateWhileEditing");
		   }
		   
		   public static String getuclValueForMeasurementToVerifyDuplicateParameterForOUWhileEditing()
		   {
			   return getKey("uclValueForMeasurementToVerifyDuplicateWhileEditing");
		   }
		   
		   public static String getminRangeForMeasurementToVerifyDuplicateParameterForOUWhileEditing()
		   {
			   return getKey("minRangeForMeasurementToVerifyDuplicateWhileEditing");
		   }
		   
		   public static String getMaxRangeForMeasurementToVerifyDuplicateParameterForOUWhileEditing()
		   {
			   return getKey("maxRangeForMeasurementToVerifyDuplicateWhileEditing");
		   }
		   
		   public static String getTagIdForMeasurementToVerifyDuplicateParameterForOUWhileEditing()
		   {
			   return getKey("tagIdForMeasurementToVerifyDuplicateWhileEditing");
		   }
		   
		   public static String getAggregatorForMeasurementToVerifyDuplicateParameterForOUWhileEditing()
		   {
			   return getKey("aggregatorForMeasurementToVerifyDuplicateWhileEditing");
		   }
		   
		   public static String getPriorityFlagForMeasurementToVerifyDuplicateParameterForOUWhileEditing()
		   {
			   return getKey("priorityFlagForMeasurementToVerifyDuplicateWhileEditing(ON/OFF)");
		   }
		   
		   public static String getVisibilityFlagForMeasurementToVerifyDuplicateParameterForOUWhileEditing()
		   {
			   return getKey("visibilityFlagForMeasurementToVerifyDuplicateWhileEditing(ON/OFF)");
		   }
		   
		   public static String getAlarmNameToEditToVerifyDuplicateParameterForOUWhileEditing()
		   {
			   return getKey("getAlarmNameToEditToVerifyDuplicate");
		   }
		   
		   public static String getUpdatedAlarmNameToVerifyDuplicateParameterForOUWhileEditing()
		   {
			   return getKey("getUpdatedAlarmNameToVerifyDuplicate");
		   }
		   
		   public static String getTripNameToEditToVerifyDuplicateParameterForOUWhileEditing()
		   {
			   return getKey("getTripNameToEditToVerifyDuplicate");
		   }
		   
		   public static String getUpdatedTripNameToVerifyDuplicateParameterForOUWhileEditing()
		   {
			   return getKey("getUpdatedTripNameToVerifyDuplicate");
		   }
		   
		   public static String getFaultNameToEditToVerifyDuplicateParameterForOUWhileEditing()
		   {
			   return getKey("getFaultNameToEditToVerifyDuplicate");
		   }
		   
		   public static String getUpdatedFaultNameToVerifyDuplicateParameterForOUWhileEditing()
		   {
			   return getKey("getUpdatedFaultNameToVerifyDuplicate");
		   }
		   
		   public static String getFunctionStatesNameToEditToVerifyDuplicateParameterForOUWhileEditing()
		   {
			   return getKey("getFunctionStatesNameToEditToVerifyDuplicate");
		   }
		   
		   public static String getUpdatedFunctionStatesNameToVerifyDuplicateParameterForOUWhileEditing()
		   {
			   return getKey("getUpdatedFaultNameToVerifyDuplicate");
		   }
		   
		   public static String getCalibrationNameToEditToVerifyDuplicateParameterForOUWhileEditing()
		   {
			   return getKey("getCalibrationNameToEditToVerifyDuplicate");
		   }
		   
		   public static String getUpdatedCalibrationNameToVerifyDuplicateParameterForOUWhileEditing()
		   {
			   return getKey("getUpdatedFaultNameToVerifyDuplicate");
		   }
		   
		   public static String getCustomerToUpdateVisibilityAndPriorityFlagForParameter()
		   {
			   return getKey("selectCustomerToUpdateVisibilityAndPriorityFlagForParameter");
		   }
		   
		   public static String getModelToUpdateVisibilityAndPriorityFlagForParameter()
		   {
			   return getKey("selectModelToUpdateVisibilityAndPriorityFlagForParameter");
		   }
		   
		   public static String getOperatingUnitToUpdateVisibilityAndPriorityFlagForParameter()
		   {
			   return getKey("selectOperatingUnitToUpdateVisibilityAndPriorityFlagForParameter");
		   }
		   
		   public static String getMeasurementParameterToUpdateVisibilityAndPriorityFlag()
		   {
			   return getKey("measurementParameterToUpdateVisibilityAndPriorityFlag");
		   }
		   
		   public static String getPriorityFlagToUpdateMeasurement()
		   {
			   return getKey("priorityFlagStatusForMeasurementParameter(ON/OFF)");
		   }
		   
		   public static String getVisibilityFlagToUpdateMeasurement()
		   {
			   return getKey("visibiltyFlagStatusForMeasurementParameter(ON/OFF)");
		   }
		   
		   public static String getCustomerToEditTheParameterWithBlank()
		   {
			   return getKey("selectCustomerToEditTheParemeterWithBlank");
		   }
		   
		   public static String getModelToEditTheParameterWithBlank()
		   {
			   return getKey("selectModelToEditTheParemeterWithBlank");
		   }
		   
		   public static String getOperatingUnitToEditTheParameterWithBlank()
		   {
			   return getKey("selectOperatingUnitToEditTheParemeterWithBlank");
		   }
		   
		   public static String getMeasurementParameterToVerifyBlank()
		   {
			   return getKey("measurementParameterToVerifyBlankParameter");
		   }
		   
		   public static String getAlarmParameterToVerifyBlank()
		   {
			   return getKey("alarmParameterToVerifyBlankParameter");
		   }
		   
		   public static String getTripParameterToVerifyBlank()
		   {
			   return getKey("tripParameterToVerifyBlankParameter");
		   }
		   
		   public static String getFaultParameterToVerifyBlank()
		   {
			   return getKey("faultParameterToVerifyBlankParameter");
		   }
		   
		   public static String getFunctionStatesParameterToVerifyBlank()
		   {
			   return getKey("functionStatesParameterToVerifyBlankParameter");
		   }
		   
		   public static String getCalibrationParameterToVerifyBlank()
		   {
			   return getKey("calibrationParameterToVerifyBlankParameter");
		   }
		   
		  public static String getMeasurementNameForPriorityAndVisibilityCheck()
		  {
			  return getKey("measurementNameForPriorityAndVisibilityCheck");
		  }
		   
		   public static String getCustomerToAddSubsystemForDisabledOU()
		   {
			   return getKey("selectCustomerToAddSystemForDisabledOU");
		   }
		   
		   public static String getModelToAddSubsystemForDisabledOU()
		   {
			   return getKey("selectModelToAddSystemForDisabledOU");
		   }
		   
		   public static String getOperatingUnitToAddSubsystemForDisabledOU()
		   {
			   return getKey("selectOperatingUnitToAddSystemForDisabledOU");
		   }
		   
		   public static String getmodelNameToAddSubsystemForDisabledOU()
		   {
			   return getKey("modelNameToAddSystemForDisabledOU");
		   }
		   
		   public static String getgatewayToAddSubsystemForDisabledOU()
		   {
			   return getKey("gatewayToAddSystemForDisabledOU");
		   }
		   
		   public static String getCountToAddSubsystemForDisabledOU()
		   {
			   return getKey("countToAddSystemForDisabledOU");
		   }
}