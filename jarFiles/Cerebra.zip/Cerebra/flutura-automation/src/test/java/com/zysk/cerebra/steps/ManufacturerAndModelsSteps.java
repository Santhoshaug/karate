package com.zysk.cerebra.steps;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import org.openqa.selenium.By;

import com.zysk.cerebra.csv_reader.CSVHelper;
import com.zysk.cerebra.csv_reader.EquipmentStructureCSVReader;
import com.zysk.cerebra.csv_reader.ManufacturerAndModelCSVReader;
import com.zysk.cerebra.pages.ManufacturerAndModelsPages;

import au.com.bytecode.opencsv.CSVReader;

import static org.assertj.core.api.Assertions.assertThat;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ManufacturerAndModelsSteps {
	ManufacturerAndModelsPages manufacturerModelPage;
	
	/********************************************************************
   	* Description: Select the manufacturer and models
   	* Status: Completed
   	********************************************************************/
	@When("^I select manufacturer and models$")
	public void whenISelectManufacturerAndModels()
	{
		manufacturerModelPage.selectManufacturerAndModels();
	}	
	
	/********************************************************************
   	* Description: Verify Category page on selecting manufacturer and models
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the category list$")
	public void thenICanSeeTheCategoryList()
	{
		assertTrue("Categories page is not loaded with all elements",manufacturerModelPage.verifyCategoryPage());
	}
	
	/********************************************************************
   	* Description: Select the machine unit
   	* Status: Completed
   	********************************************************************/
	@When("^I select Machineunit$")
	public void whenISelectMachineunitToAddManufacturer()
	{
		String machineunit = EquipmentStructureCSVReader.getEditAndUpdatedMachineUnitName();
		manufacturerModelPage.selectMachineunit(machineunit);
	}
	
	/********************************************************************
   	* Description: Add new manufacturer
   	* Status: Completed
   	********************************************************************/
	@When("^I add new Manufacturer to the machine unit$")
	public void whenIAddNewManufacturerToTheMachineUnit()
	{
		String newManufacturerName = ManufacturerAndModelCSVReader.getnewManufaturerNameToAdd();
		String code = ManufacturerAndModelCSVReader.getmanufacturerCode();
		manufacturerModelPage.addManufacturer(newManufacturerName,code);
	}
	
	/********************************************************************
   	* Description: Verify added manufacturer
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the manufacturer gets listed$")
	public void thenICanSeeTheManufacturerGetsListed()
	{
		String newManufacturerName = ManufacturerAndModelCSVReader.getnewManufaturerNameToAdd();
		assertTrue("Added manufacturer is not displayed in the list",manufacturerModelPage.verifyAddedManufacturerNameInTheList(newManufacturerName));
	}
	
	/********************************************************************
   	* Description: Disable the manufacturer
   	* Status: Completed
   	********************************************************************/
	@When("^I disable the manufacturer$")
	public void whenIDisableTheManufacturer()
	{
		String manufacturerName = ManufacturerAndModelCSVReader.getnewManufaturerNameToAdd();
		manufacturerModelPage.disableManufacturer(manufacturerName);
	}
	
	/********************************************************************
   	* Description: Verify Manufacturer gets disabled
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the manufacturer gets disabled$")
	public void thenICanSeeTheManufacturerGetsDisabled()
	{
		String manufacturerName = ManufacturerAndModelCSVReader.getnewManufaturerNameToAdd();
		assertTrue("Manufacturer is already disabled",manufacturerModelPage.verifyManufactureDisabled(manufacturerName));
	}

	/********************************************************************
   	* Description: Enable the manufacturer
   	* Status: Completed
   	********************************************************************/
	@When("^I enable the manufacturer$")
	public void whenIEnableTheManufacturer()
	{
		String manufacturerName = ManufacturerAndModelCSVReader.getnewManufaturerNameToAdd();
		manufacturerModelPage.enableManufacturer(manufacturerName);
	}
	
	/********************************************************************
   	* Description: Verify Manufacturer gets enabled
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the manufacturer gets enabled$")
	public void thenICanSeeTheManufacturerGetsEnabled()
	{
		String manufacturerName = ManufacturerAndModelCSVReader.getnewManufaturerNameToAdd();
		assertFalse("Manufacturer is already enabled",manufacturerModelPage.verifyManufacturerEnabled(manufacturerName));
	}
	
	/********************************************************************
   	* Description: Delete the manufacturer
   	* Status: Completed
   	********************************************************************/
	@When("^I delete the manufacturer$")
	public void whenIDeleteTheManufacturer()
	{
		String manufacturerName = ManufacturerAndModelCSVReader.getnewManufaturerNameToAdd();
		manufacturerModelPage.deleteManufacturer(manufacturerName);
	}
	
	/********************************************************************
   	* Description: Verify manufacturer should get deleted 
   	* Status: Completed
   	********************************************************************/
	@Then("^I can see the manufacturer gets deleted$")
	public void thenICanSeeTheManufacturerGetsDeleted()
	{
		String manufacturerName = ManufacturerAndModelCSVReader.getnewManufaturerNameToAdd();
		assertTrue("Delted Manufacturer name is displayed in the list",manufacturerModelPage.verifyManufacturerDeleted(manufacturerName));
	}
	
	/********************************************************************
   	* Description: Select the manufacturer
   	* Status: Completed
   	********************************************************************/
	@When("^I select the Manufacturer$")
	public void whenISelectTheManufacturer()
	{
		String manufacturerName = ManufacturerAndModelCSVReader.getnewManufaturerNameToAdd();
		manufacturerModelPage.selectManufacturer(manufacturerName);
	}
	
	/********************************************************************
   	* Description: Select the manufacturer
   	* Status: Completed
   	*******************************************************************/
	  @And("^I select the Model from the manufacture page$")
	    public void i_select_the_model_from_the_manufacture_page()  {
	      String model = ManufacturerAndModelCSVReader.getUpdatedModelName();
		  manufacturerModelPage.selectModel(model);
	    }
	  
	 /********************************************************************
	    * Description: Add models to the manufacturer
	    * Status: Completed
	    ********************************************************************/
	@When("^I add models to the manufacturer$")
	public void whenIAddModelsToTheManufacturer()
	{
	String modelNameValue = ManufacturerAndModelCSVReader.getModelName();
	String modelCodeValue = ManufacturerAndModelCSVReader.getModelCode();
	String filepath = ManufacturerAndModelCSVReader.getModelImage();
	manufacturerModelPage.addModelName(modelNameValue,modelCodeValue,filepath);
	}

	/********************************************************************
	    * Description: Verify the model added
	    * Status: Completed
	    ********************************************************************/
	@Then("^I can see the models should get added$")
	public void thenICanSeeTheModelsShouldGetAdded()
	{
	String modelName = ManufacturerAndModelCSVReader.getModelName();
	assertTrue("Model is not displayed in the list",manufacturerModelPage.verifyModelsAdded(modelName));
	}

	/********************************************************************
	    * Description: Disable the models
	    * Status: Completed
	    ********************************************************************/
	@When("^I disable the added models$")
	public void whenIDisableTheAddedModels()
	{
	String disableModel = ManufacturerAndModelCSVReader.getUpdatedModelName();
	manufacturerModelPage.disableTheModel(disableModel);
	}

	/********************************************************************
	    * Description: Verify model get disabled
	    * Status: Completed
	    ********************************************************************/
	@Then("^I can see the models gets disabled$")
	public void thenICanSeeTheModelsGetsDisabled()
	{
	String disableModel = ManufacturerAndModelCSVReader.getUpdatedModelName();
	assertTrue("Edit button is visible",manufacturerModelPage.verifyModelDisabled(disableModel));
	}

	/********************************************************************
	    * Description: Enable the disabled models
	    * Status: Completed
	    ********************************************************************/
	@When("^I enable the disabled models$")
	public void whenIEnableTheDisabledModels()
	{
	String modelName = ManufacturerAndModelCSVReader.getUpdatedModelName();
	manufacturerModelPage.enableTheModel(modelName);
	}

	/********************************************************************
	    * Description: Verify model get enabled
	    * Status: Completed
	    ********************************************************************/
	@Then("^I can see the models gets enabled$")
	public void thenICanSeeTheModelsGetsEnabled()
	{
	String modelName = ManufacturerAndModelCSVReader.getUpdatedModelName();
	assertTrue("Edit button is not visible",manufacturerModelPage.verifyModelEnabled(modelName));
	}

	/********************************************************************
	    * Description: Edit the model
	    * Status: Completed
	    ********************************************************************/
	@When("^I edit the model$")
	public void whenIEditTheModel()
	{
	String modelToEdit = ManufacturerAndModelCSVReader.getModelName();
	String updateModelName = ManufacturerAndModelCSVReader.getUpdatedModelName();
	String updateModelCode = ManufacturerAndModelCSVReader.getUpdatedModelCode();
	String updateFilepath = ManufacturerAndModelCSVReader.getModelImage();
	manufacturerModelPage.editModel(modelToEdit,updateModelName,updateModelCode,updateFilepath);
	}

	/********************************************************************
	    * Description: Verify the edited model
	    * Status: Completed
	    ********************************************************************/
	@Then("^I can see the models gets edited$")
	public void thenICanSeeTheModelsGetsEdited()
	{
	String updateModelName = ManufacturerAndModelCSVReader.getUpdatedModelName();
	assertTrue("Updated model is not visible in the list",manufacturerModelPage.verifyUpdateModel(updateModelName));
	}

	/********************************************************************
	    * Description: Delete the models
	    * Status: Completed
	    ********************************************************************/
	@When("^I delete the model$")
	public void whenIDeleteModels()
	{
	String modelName = ManufacturerAndModelCSVReader.getModelName();
	String editedModelName = ManufacturerAndModelCSVReader.getUpdatedModelName();
	manufacturerModelPage.deleteModel(modelName,editedModelName);
	}

	/********************************************************************
	    * Description: Verify deleted model
	    * Status: Completed
	    ********************************************************************/
	@Then("^I can see the models gets deleted$")
	public void thenModelGetsDeleted()
	{
	String modelName = ManufacturerAndModelCSVReader.getUpdatedModelName();
	assertFalse("Deleted Model is visible in the list",manufacturerModelPage.verifyModelsAdded(modelName));
	}
	
	/********************************************************************
	* Description: 
	* Status: Completed
	********************************************************************/

	  @And("^I select the Updated Model$")
	    public void i_select_the_updated_model()  {
		  String updateModelName = ManufacturerAndModelCSVReader.getUpdatedModelName();
	       manufacturerModelPage.selectTheUpdatedModel(updateModelName);
	    }

  /********************************************************************
    * Description: 
    * Status: Completed
    ********************************************************************/
	    @And("^I add the Subsystems in subsystem page$")
	    public void i_add_the_subsystems_in_subsystem_page()  {
	       String MachineUnitName = EquipmentStructureCSVReader.getEditAndUpdatedMachineUnitName();
		String ModelName = ManufacturerAndModelCSVReader.getUpdatedModelName();
		manufacturerModelPage.addSubsystemInSubsystemPage(MachineUnitName,ModelName);
	    }

	    /********************************************************************
	   	* Description: Verify Configurations Page
	   	* Status: 
	   	********************************************************************/
		 @Then("^I Verify configurations page$")
		    public void i_verify_configurations_page() {  
		  String ExpConfigURL = ManufacturerAndModelCSVReader.getExpConfigURL();
		  assertFalse("Configurations page Url is not opened",manufacturerModelPage.verifyConfigPage(ExpConfigURL));
		
		 }
			 /********************************************************************
			   	* Description: Enter name and value to fields
			   	* Status: 
			   	********************************************************************/
		    @And("^I Select SubSystems$")
		    public void i_select_subsystems()
		    {
		    	String SusbsystemName = ManufacturerAndModelCSVReader.getUpdatedModelName();
		    	manufacturerModelPage.SelectSubsystems(SusbsystemName);
		    	
		    }
		
		    /********************************************************************
		   	* Description: I add design parameter
		   	* Status: 
		   	********************************************************************/
		    @And("^I add Design Parameter in Configurations$")
		    public void i_add_design_parameter_in_configurations() {
		    	 
		    String DesignParameterName = ManufacturerAndModelCSVReader.getDesignParameterName();
		   	String Value = ManufacturerAndModelCSVReader.getValue();
		   	String MetricUnitSystem = ManufacturerAndModelCSVReader.getModelName();
			 String USUnitSystem = ManufacturerAndModelCSVReader.getModelName();
			 String Number = ManufacturerAndModelCSVReader.getModelCode(); 
			 String Unitname =  ManufacturerAndModelCSVReader.getModelName();
			 manufacturerModelPage.AddDesignParamter(DesignParameterName, Value,MetricUnitSystem,USUnitSystem,Number,Unitname);
		    	
		    }
		    
		    /********************************************************************
			 * Description: I Verify Added Design parameter
			 * *******************************************************************/
			
			  @Then("^I Can see added Design paramter$")
			    public void i_can_see_added_design_paramter() {
				  
				  String DesignParameterName = ManufacturerAndModelCSVReader.getDesignParameterName();
				  assertTrue("Design Parameter is not added",manufacturerModelPage.verifyaddedDesignParameter(DesignParameterName));
			  }
		

			/********************************************************************
			 * Description: I add design parameter Status:
			 ********************************************************************/
			@And("^I edit Design Parameter$")
			public void i_edit_design_parameter() {
	        
		    String DesignParameterName = ManufacturerAndModelCSVReader.getDesignParameterName();
			String UpdatedDesignParamter = ManufacturerAndModelCSVReader.getUpdatedDesignParameterName();
			String UpdatedValue = ManufacturerAndModelCSVReader.getUpdatedModelCode();
			manufacturerModelPage.EditDesignParameter(UpdatedDesignParamter,UpdatedValue,DesignParameterName);	
				
			}
			  /********************************************************************
				 * Description: I Verify Added edited Design parameter
				 * *******************************************************************/
				
			  @Then("^I can see the edited Design Parameter$")
			    public void i_can_see_the_edited_design_parameter() {
				  
				  String UpdatedDesignParamter = ManufacturerAndModelCSVReader.getUpdatedModelName();
				  assertTrue("Edited Design parameter is not present",manufacturerModelPage.verifyEditedDesignParameter(UpdatedDesignParamter));
			  }
			  
			  /********************************************************************
				 * Description: I Verify Added edited Design parameter
				 * *******************************************************************/
			  @And("^I disable the Design Parameter in Configuration page$")
			    public void i_disable_the_design_parameter_in_configuration_page()  {
				  String UpdatedDesignParamter = ManufacturerAndModelCSVReader.getUpdatedDesignParameterName();
			       manufacturerModelPage.disableDesignParameter(UpdatedDesignParamter);
			    }
			  
			  /********************************************************************
				 * Description: I Verify Added edited Design parameter
				 * *******************************************************************/
			  @Then("^I verfiy Design Parameter Disabled in Configuration page$")
			    public void i_verfiy_design_parameter_disabled_in_configuration_page()  {
				  String UpdatedDesignParamter = ManufacturerAndModelCSVReader.getUpdatedDesignParameterName();
				 assertTrue("Manufacture model not disabled",manufacturerModelPage.verifyDesignParameterDisabled(UpdatedDesignParamter));
			    }
			  
			  /********************************************************************
				 * Description: I Verify Added edited Design parameter
				 * *******************************************************************/
			    @And("^I Enable the  Design Parameter in Configuration page$")
			    public void i_enable_the_design_parameter_in_configuration_page()  {
			    	  String UpdatedDesignParamter = ManufacturerAndModelCSVReader.getUpdatedDesignParameterName();
//				       manufacturerModelPage.enableDesignParameter(UpdatedDesignParamter);
			    }
			    
			    /********************************************************************
				 * Description: I Verify Added edited Design parameter
				 * *******************************************************************/

			    @Then("^I verfiy Design Parameter Enabled in Configuration page$")
			    public void i_verfiy_design_parameter_enabled_in_configuration_page()  {
			       
			    }
			  /********************************************************************
				 * Description: I Select Measurements
				 * *******************************************************************/
			  @And("^I select Measurements$")
			    public void i_select_measurements() {
				  
				  manufacturerModelPage.SelectMeasurements();
			  }
			  
			  /********************************************************************
				 * Description: I Add New Measurements in Configuration
				 * *******************************************************************/
			  @And("^I add Measurments in configuration$")
			    public void i_add_measurments_in_configuration() {
				  
					String DesignParameterName = ManufacturerAndModelCSVReader.getDesignParameterName();
					String MetricUnitSystem = ManufacturerAndModelCSVReader.getModelName();
					String USUnitSystem = ManufacturerAndModelCSVReader.getModelName();
					String Number = ManufacturerAndModelCSVReader.getModelCode();
					manufacturerModelPage.AddMeasurements(DesignParameterName,MetricUnitSystem,USUnitSystem,Number);

			  }
			  

			  /********************************************************************
				 * Description: I Add New Measurements in Configuration
				 * *******************************************************************/
			  @Then("^I can see added measurements$")
			    public void i_can_see_added_measurements() {
				  String DesignParameterName = ManufacturerAndModelCSVReader.getDesignParameterName();
				  assertFalse("Design Parameter is not added",manufacturerModelPage.verifyMeasurements(DesignParameterName));
				  
			  }
			  /********************************************************************
				 * Description: I edit New Measurements in Configuration
				 * *******************************************************************/
			  @And("^I edit Measurements$")
			    public void i_edit_enable_and_disable_measurements() 
			    {
				  String DesignParameterName = ManufacturerAndModelCSVReader.getDesignParameterName();
					String UpdatedDesignParamter = ManufacturerAndModelCSVReader.getUpdatedDesignParameterName();
					String UpdatedValue = ManufacturerAndModelCSVReader.getUpdatedModelCode();
					manufacturerModelPage.EditEnableDisableMeasurements(UpdatedDesignParamter,UpdatedValue,DesignParameterName);	
						
			    }
			  /********************************************************************
				 * Verify Edited Design parameter
				 * *******************************************************************/
			  
			  @Then("^I verify Edited Measurements$")
			    public void i_verify_edited_measurements() {
				  
				  String UpdatedDesignParameterName = ManufacturerAndModelCSVReader.getUpdatedDesignParameterName();
				  assertTrue("Edited Measurement is not added",manufacturerModelPage.verifyEditedMeasurements(UpdatedDesignParameterName));
	   		  } 
		
			  /********************************************************************
				 * Verify Edited Measurement is present
				 * *******************************************************************/
			  @And("^I disable and Enable Measurements$")
				public void i_disable_and_enable_measurements() {

					String DesignParameterName = ManufacturerAndModelCSVReader.getDesignParameterName();
					String UpdatedDesignParamter = ManufacturerAndModelCSVReader.getUpdatedDesignParameterName();
					String UpdatedValue = ManufacturerAndModelCSVReader.getUpdatedModelCode();
					manufacturerModelPage.EnableDisableMeasurements(UpdatedDesignParamter, UpdatedValue,
							DesignParameterName);

				}
			  /********************************************************************
				 * Select Alarms
				 * *******************************************************************/
			   @And("^I select Alarms$")
			    public void i_select_alarms() {
					  manufacturerModelPage.SelectAlarms();
			   }
			   /********************************************************************
				 * Add New Alarms
				 * *******************************************************************/
			   @And("^I add new Alarms$")
			    public void i_add_new_alarms() {
				   String DesignParameterName = ManufacturerAndModelCSVReader.getDesignParameterName();
					manufacturerModelPage.AddAlarms(DesignParameterName); 
				   
			   }
			   
			   
			   /********************************************************************
				 * Verify Added New Alarm
				 *********************************************************************/
			   @Then("^I can see added New Alarm$")
			    public void i_can_see_added_new_alarm() {
				   
				   String DesignParameterName = ManufacturerAndModelCSVReader.getDesignParameterName();
				 assertFalse("Design Parameter is not added",manufacturerModelPage.verifyNewAlarm(DesignParameterName));  
			   }
			   
			   
			   /********************************************************************
				 * Edit added Alarms
				**********************************************************************/
			   @And("^I edit the added Alarm$")
			    public void i_edit_the_added_alarm() {
				   String DesignParameterName = ManufacturerAndModelCSVReader.getDesignParameterName();
					String UpdatedDesignParamter = ManufacturerAndModelCSVReader.getUpdatedDesignParameterName();
					String UpdatedValue = ManufacturerAndModelCSVReader.getUpdatedModelCode();
					manufacturerModelPage.EditAlarms(UpdatedDesignParamter,UpdatedValue,DesignParameterName); 
				   
				   
			   }
		
			   /********************************************************************
						 * Verify edited alarm
			    **********************************************************************/
			   @Then("^I see Edited Alarm$")
			    public void i_see_edited_alarm() {
				   String UpdatedDesignParameter = ManufacturerAndModelCSVReader.getUpdatedDesignParameterName();
				  assertFalse("Edited Measurement is not added",manufacturerModelPage.verifyEditedAlarm(UpdatedDesignParameter)); 	   
			   }
		
			   /********************************************************************
			    * Verify edited alarm
	            **********************************************************************/
				@And("^I enable disable alarm$")
				public void i_enable_disable_alarm() {

					String DesignParameterName = ManufacturerAndModelCSVReader.getDesignParameterName();
					String UpdatedDesignParamter = ManufacturerAndModelCSVReader.getUpdatedDesignParameterName();
					String UpdatedValue = ManufacturerAndModelCSVReader.getUpdatedModelCode();
					manufacturerModelPage.EnableDisableAlarms(UpdatedDesignParamter, UpdatedValue, DesignParameterName);
				}	
		
				 /********************************************************************
				    *Select Trips
		            **********************************************************************/
			    @And("^I select Trips$")
			    public void i_select_trips() {
					  manufacturerModelPage.SelectTrips();
			    }
			    /********************************************************************
				    * Add new trips
		            **********************************************************************/
				@And("^I add new Trips$")
				public void i_add_new_trips() {
					String DesignParameterName = ManufacturerAndModelCSVReader.getDesignParameterName();
					manufacturerModelPage.AddAlarms(DesignParameterName);
				}
			    
			    
			    /********************************************************************
				    * verify added new trips
		         **********************************************************************/
				@Then("^I can see added New Trips$")
				public void i_can_see_added_new_trips() {
					String DesignParameterName = ManufacturerAndModelCSVReader.getDesignParameterName();
					assertFalse("Design Parameter is not added", manufacturerModelPage.verifyNewAlarm(DesignParameterName));
				}
			    
			    /********************************************************************
				    * Edit added trips
		            **********************************************************************/
			    @And("^I edit the added Trips$")
				public void i_edit_the_added_trips() {

					String DesignParameterName = ManufacturerAndModelCSVReader.getDesignParameterName();
					String UpdatedDesignParamter = ManufacturerAndModelCSVReader.getUpdatedDesignParameterName();
					String UpdatedValue = ManufacturerAndModelCSVReader.getUpdatedModelCode();
					manufacturerModelPage.EditAlarms(UpdatedDesignParamter, UpdatedValue, DesignParameterName);
				}
			    
			    /********************************************************************
				    * Verify edited trips
		            **********************************************************************/
				@Then("^I see Edited Trips$")
				public void i_see_edited_trips() {
					String UpdatedDesignParameter = ManufacturerAndModelCSVReader.getUpdatedDesignParameterName();
					assertFalse("Edited Measurement is not added",
							manufacturerModelPage.verifyEditedAlarm(UpdatedDesignParameter));
				}
			    
			   
			    /********************************************************************
				    * Enable Disable trips
		            **********************************************************************/
				@And("^I enable disable Trips$")
				public void i_enable_disable_trips() {
					String DesignParameterName = ManufacturerAndModelCSVReader.getDesignParameterName();
					String UpdatedDesignParamter = ManufacturerAndModelCSVReader.getUpdatedDesignParameterName();
					String UpdatedValue = ManufacturerAndModelCSVReader.getUpdatedModelCode();
					manufacturerModelPage.EnableDisableAlarms(UpdatedDesignParamter, UpdatedValue, DesignParameterName);
				}
		
		
				 /********************************************************************
				    *Select failure mode
		            **********************************************************************/
				 @And("^I select Failure Mode$")
				    public void i_select_failure_mode() {
					  manufacturerModelPage.SelectFailureMode();
			    }
			    /********************************************************************
				    * Add new failure mode
		            **********************************************************************/
				  @And("^I add new Failure Mode$")
				    public void i_add_new_failure_mode() {
					String DesignParameterName = ManufacturerAndModelCSVReader.getDesignParameterName();
					manufacturerModelPage.AddAlarms(DesignParameterName);
				}
			    
			    
			    /********************************************************************
				    * verify added new failure mode
		         **********************************************************************/
				  @Then("^I can see added New Failure mode$")
				    public void i_can_see_added_new_failure_mode() {
					String DesignParameterName = ManufacturerAndModelCSVReader.getDesignParameterName();
					assertFalse("Design Parameter is not added", manufacturerModelPage.verifyNewAlarm(DesignParameterName));
				}
			    
			    /********************************************************************
				    * Edit added failure mode
		            **********************************************************************/
				   @And("^I edit the added Failure mode$")
				    public void i_edit_the_added_failure_mode() {

					String DesignParameterName = ManufacturerAndModelCSVReader.getDesignParameterName();
					String UpdatedDesignParamter = ManufacturerAndModelCSVReader.getUpdatedDesignParameterName();
					String UpdatedValue = ManufacturerAndModelCSVReader.getUpdatedModelCode();
					manufacturerModelPage.EditAlarms(UpdatedDesignParamter, UpdatedValue, DesignParameterName);
				}
			    
			    /********************************************************************
				    * Verify edited failure mode
		            **********************************************************************/
				   @Then("^I see Edited Failure Mode$")
				    public void i_see_edited_failure_mode() {
					String UpdatedDesignParameter = ManufacturerAndModelCSVReader.getUpdatedDesignParameterName();
					assertFalse("Edited Measurement is not added",
							manufacturerModelPage.verifyEditedAlarm(UpdatedDesignParameter));
				}
			    
			   
			    /********************************************************************
				    * Enable Disable failure mode
		            **********************************************************************/
				   @And("^I enable disable Failure Mode$")
				    public void i_enable_disable_failure_mode() {
					String DesignParameterName = ManufacturerAndModelCSVReader.getDesignParameterName();
					String UpdatedDesignParamter = ManufacturerAndModelCSVReader.getUpdatedDesignParameterName();
					String UpdatedValue = ManufacturerAndModelCSVReader.getUpdatedModelCode();
					manufacturerModelPage.EnableDisableAlarms(UpdatedDesignParamter, UpdatedValue, DesignParameterName);
				}
		
				   /********************************************************************
				    *Select Function States
		            **********************************************************************/
				   @And("^I select Function States$")
				    public void i_select_function_states() {
					  manufacturerModelPage.SelectFuncitonStates();
			    }
			    /********************************************************************
				    * Add new Function States
		            **********************************************************************/
				   @And("^I add new Function States$")
				    public void i_add_new_function_states() {
					String DesignParameterName = ManufacturerAndModelCSVReader.getDesignParameterName();
					manufacturerModelPage.AddFunctionStates(DesignParameterName);
				}
			    
			    
			    /********************************************************************
				    * verify added new Function States
		         **********************************************************************/
				   @Then("^I can see added New Function States$")
				    public void i_can_see_added_new_function_states() {
					String DesignParameterName = ManufacturerAndModelCSVReader.getDesignParameterName();
					assertFalse("Design Parameter is not added", manufacturerModelPage.verifyFunctionStates(DesignParameterName));
				}
			    
			    /********************************************************************
				    * Edit added Function States
		            **********************************************************************/
				  @And("^I edit the added Function States$")
				    public void i_edit_the_added_function_states() {

					String DesignParameterName = ManufacturerAndModelCSVReader.getDesignParameterName();
					String UpdatedDesignParamter = ManufacturerAndModelCSVReader.getUpdatedDesignParameterName();
					String UpdatedValue = ManufacturerAndModelCSVReader.getUpdatedModelCode();
					manufacturerModelPage.EditFunctionStates(UpdatedDesignParamter, UpdatedValue, DesignParameterName);
				}
			    
			    /********************************************************************
				    * Verify edited Function States
		            **********************************************************************/
				  @Then("^I see Edited Function States$")
				    public void i_see_edited_function_states()  {
					String UpdatedDesignParameter = ManufacturerAndModelCSVReader.getUpdatedDesignParameterName();
					assertFalse("Edited Measurement is not added",
							manufacturerModelPage.verifyEditedFunctionStates(UpdatedDesignParameter));
				}
			    
			   
			    /********************************************************************
				    * Enable Disable Function States
		            **********************************************************************/
				    @And("^I enable disable Function States$")
				    public void i_enable_disable_function_states() {
					String DesignParameterName = ManufacturerAndModelCSVReader.getDesignParameterName();
					String UpdatedDesignParamter = ManufacturerAndModelCSVReader.getUpdatedDesignParameterName();
					String UpdatedValue = ManufacturerAndModelCSVReader.getUpdatedModelCode();
					manufacturerModelPage.EnableDisableFunctionStates(UpdatedDesignParamter, UpdatedValue, DesignParameterName);
				}
				    
				    /********************************************************************
					    * Select Calibrations
			            **********************************************************************/
					@And("^I select Calibration$")
					public void i_select_calibration() {
						manufacturerModelPage.SelectCalibrations();
					}
				    
				    /********************************************************************
					    * Add new Calibration
			            **********************************************************************/
					@And("^I add new Calibration$")
					public void i_add_new_calibration() {
						String DesignParameterName = ManufacturerAndModelCSVReader.getDesignParameterName();
						String Value = ManufacturerAndModelCSVReader.getValue();
						String MetricUnitSystem = ManufacturerAndModelCSVReader.getModelName();
						String USUnitSystem = ManufacturerAndModelCSVReader.getModelName();
						String Number = ManufacturerAndModelCSVReader.getModelCode();
						String Unitname = ManufacturerAndModelCSVReader.getModelName();
						manufacturerModelPage.AddCalibration(DesignParameterName, Value, MetricUnitSystem, USUnitSystem,
								Number, Unitname);
					}
					
					
					/********************************************************************
					    * Add new Calibration
			            **********************************************************************/
					   @Then("^I can see added New Calibration$")
					    public void i_can_see_added_new_calibration() {
						   String DesignParameterName = ManufacturerAndModelCSVReader.getDesignParameterName();
							assertFalse("Design Parameter is not added", manufacturerModelPage.verifyCalibration(DesignParameterName));
					   }
					   
					   /********************************************************************
					    * Add edit Calibration
			            **********************************************************************/
					   @And("^I edit the added Calibration$")
					    public void i_edit_the_added_calibration() {
						   String DesignParameterName = ManufacturerAndModelCSVReader.getDesignParameterName();
							String UpdatedDesignParamter = ManufacturerAndModelCSVReader.getUpdatedDesignParameterName();
							String UpdatedValue = ManufacturerAndModelCSVReader.getUpdatedModelCode();
							manufacturerModelPage.EditCalibration(UpdatedDesignParamter,UpdatedValue,DesignParameterName);	
								
					   }
					   /********************************************************************
					    * I see edited Calibration
			            **********************************************************************/
					   @Then("^I see Edited Calibration$")
					    public void i_see_edited_calibration() {
						   String UpdatedDesignParameter = ManufacturerAndModelCSVReader.getUpdatedDesignParameterName();
							assertFalse("Edited Measurement is not added",
									manufacturerModelPage.verifyEditedCalibration(UpdatedDesignParameter));  
						   
					   }
					   /********************************************************************
					    * Enable and Disable Calibrations
			            **********************************************************************/
					   @And("^I enable disable Calibration$")
					    public void i_enable_disable_calibration() {
			
								String DesignParameterName = ManufacturerAndModelCSVReader.getDesignParameterName();
								String UpdatedDesignParamter = ManufacturerAndModelCSVReader.getUpdatedDesignParameterName();
								manufacturerModelPage.EnableDisableCalibrations(UpdatedDesignParamter, DesignParameterName);
					   }
						   
					   
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
//    /********************************************************************
//    * Description: 
//    * Status: Completed
//    ********************************************************************/
//	    @And("^I Select SubSystems$")
//	    public void i_select_subsystems()  {
//	       
//	    }
//
//	
//	/********************************************************************
//	    * Description: 
//	    * Status: Completed
//	    ********************************************************************/
//	 @And("^I Click on models$")
//	   public void i_click_on_models() {
//	 String modelName = ManufacturerAndModelCSVReader.getModelName();
//	 manufacturerModelPage.ClickOnModel(modelName);
//	 }
//	/********************************************************************
//	    * Description: Verify Configurations Page
//	    * Status:
//	    ********************************************************************/
//	@Then("^I Verify configurations page$")
//	   public void i_verify_configurations_page() {
//	 
//	 String ExpConfigURL = ManufacturerAndModelCSVReader.getExpConfigURL();
//	 assertFalse("Configurations page Url is not opened",manufacturerModelPage.verifyConfigPage(ExpConfigURL));
//	 }
//	/********************************************************************
//	  * Description: Enter name and value to fields
//	  * Status:
//	  ********************************************************************/
//	   @And("^I Select SubSystems$")
//	   public void i_select_subsystems()
//	   {
//	    String SusbsystemName = ManufacturerAndModelCSVReader.getUpdatedModelName();
//	    manufacturerModelPage.SelectSubsystems(SusbsystemName);
//	   
//	   }
//
//	   /********************************************************************
//	  * Description: I add design parameter
//	  * Status:
//	  ********************************************************************/
//	   @And("^I add Design Parameter in Configurations$")
//	   public void i_add_design_parameter_in_configurations() {
//	   
//	   String DesignParameterName = ManufacturerAndModelCSVReader.getDesignParameterName();
//	  String Value = ManufacturerAndModelCSVReader.getValue();
//	  String MetricUnitSystem = ManufacturerAndModelCSVReader.getModelName();
//	String USUnitSystem = ManufacturerAndModelCSVReader.getModelName();
//	String Number = ManufacturerAndModelCSVReader.getModelCode();
//	String Unitname =  ManufacturerAndModelCSVReader.getModelName();
//	manufacturerModelPage.AddDesignParamter(DesignParameterName, Value,MetricUnitSystem,USUnitSystem,Number,Unitname);
//	   
//	   }
//
//	/********************************************************************
//	* Description: I add design parameter Status:
//	********************************************************************/
//	@And("^I edit enable disable Design Parameter$")
//	public void i_edit_enable_disable_design_parameter() {
//	       
//	   String DesignParameterName = ManufacturerAndModelCSVReader.getDesignParameterName();
//	String UpdatedDesignParamter = ManufacturerAndModelCSVReader.getUpdatedDesignParameterName();
//	String UpdatedValue = ManufacturerAndModelCSVReader.getUpdatedModelCode();
//	manufacturerModelPage.EditEnableDisable(UpdatedDesignParamter,UpdatedValue,DesignParameterName);
//
//	}
//	/********************************************************************
//	* Description: I Verify Added Design parameter
//	* *******************************************************************/
//
//	 @Then("^I Can see added Design paramter$")
//	   public void i_can_see_added_design_paramter() {
//	 
//	 String DesignParameterName = ManufacturerAndModelCSVReader.getDesignParameterName();
//	 assertFalse("Design Parameter is not added",manufacturerModelPage.verifyaddedDesignParameter(DesignParameterName));
//	 }
//
//	 /********************************************************************
//	* Description: I Verify Added edited Design parameter
//	* *******************************************************************/
//
//	 @Then("^I can see the edited Design Parameter$")
//	   public void i_can_see_the_edited_design_parameter() {
//	 
//	 String UpdatedDesignParamter = ManufacturerAndModelCSVReader.getUpdatedModelName();
//	 String updatedValue = ManufacturerAndModelCSVReader.();
//	String updatedUnit = ManufacturerAndModelCSVReader.;
//	assertTrue("Edited Design parameter is not present",manufacturerModelPage.verifyEditedDesignParameter(UpdatedDesignParamter,updatedValue,updatedUnit));
//	 }
}