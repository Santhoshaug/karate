package com.zysk.cerebra.pages;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.zysk.cerebra.commonPages.CommonFunctions;
import com.zysk.cerebra.csv_reader.DigitalMachineCSVReader;
//import com.zysk.cerebra.commonPages.CommonFunctions;
import com.zysk.cerebra.pages.LoginPage;

import net.serenitybdd.core.pages.PageObject;

public class UsersPage extends CommonFunctions{
	
	private static final boolean False = false;
	/***********************Page element identifiers******************************/
	
	private By Users = By.xpath("//a[text()=' User ']");
	private By customerList = By.xpath("//div[@class='row']");
	private By searchBar = By.xpath("//input[@placeholder='Search..']");
	private By userList = By.xpath("//div[@class='row']");
	private By addNewButton = By.xpath("//span[text()=' Add New ']");
	private By search = By.xpath("//span[@class='search-bar']");
	private By firstNameField = By.xpath("//input[@id='firstName']");
	private By lastNameField = By.xpath("//input[@id='lastName']");
	private By phNumber = By.xpath("//div[@class='phone-input']");
	private By MobileNum = By.xpath("//int-phone-prefix[@placeholder='Enter Mobile Number']");
	private By email = By.xpath("//input[@id='email']");
	private By password = By.xpath("//input[@id='newPassword']");
	private By confirmPassword = By.xpath("//input[@id='confirmPassword']");
	private By addButton = By.xpath("//button[@type='submit']");
	private By searchUser = By.xpath("//input[@type='text']");
	private By listOfUser = By.xpath("//div[@class='row']/div");
	private By successfulORErrorMessage = By.xpath("//snack-bar-container//simple-snack-bar//span");
	
	private By EditfirstNameField = By.xpath("//input[@name='firstName']");
	private By EditLastNameField = By.xpath("//input[@name='lastName']");
	private By EditMobileNumber = By.xpath("//input[@class='form-control ng-pristine ng-valid ng-touched']");
	
	private By EditEmailID = By.xpath("//input[@name='email']");
	private By EditNewPassword = By.xpath("//div//input[@name='newPassword']");
	private By EditConfirmPassword = By.xpath("//div//input[@name='confirmPassword']");
	private By UdateDetails = By.xpath("//button//span[text()=' Update ']");
	private By ChangeDomain = By.xpath("//mat-select[@role='listbox']");
//	private By DisableUser = By.xpath("//div//mat-card-actions//span[@class=\"icon-text disable\"]");
	private By VerifyUserDisable = By.xpath("//app-card-ud//mat-card//app-ribbon-bar//div[@class=\"corner-ribbon align-items-center left font-smaller\"]");
	private By userListLocator = By.xpath("//span[@class='mat-option-text']");
	
	private By AddUserSuccessfulMessage = By.xpath("//snack-bar-container//simple-snack-bar");
	
	private By userGroup = By.xpath("//a[contains(text(),' User Group ')]");
	private By AccessLevelTab = By.xpath("//button//span[contains(text(),' Access levels ')]");
	private By DomainDropdownList = By.xpath("//mat-option//span");
	private By popUpYesButton = By.xpath("//button[contains(text(),'Yes, delete it!')]");
	
	
	private static String firstName = "Test";
	private static String lastName = "User";
	private By userCreated = By.xpath("//div[@class='row']//a[@class='header-text text-truncate' and contains(text(),'"+firstName+" "+lastName+"')]");
	private By PermissionTabTitle = By.xpath("//div[@class='page-header align-self-center my-2 textoverFlow' and contains(text(),' Permissions')]");
	private By DomaindropdownIcon = By.xpath("//div[@class='mat-select-arrow']");
	
	//private By userCreated = By.xpath("//div[@class='row']//a[contains(text()='"+firstName+" "+lastName+"')]");
	
	private static String userPageUrl = "https://cerebra.flutura.com/configuration#/users";
	private static String userListUrl = "https://cerebra.flutura.com/configuration#/users/list";
	
	String userFirstName = "EditUserFirstName";
	String userLastName = "EditUserLastName";
	String userMobileNumber = "EditUserMobileNumber";
	String userEmailId = "EditUserEmailId";
	
	
	/********************************************************************
	* Description: Visit user page by clicking on user link
	* Param: NA
	* Returns: Void
	* Status: Completed
	********************************************************************/
	public void clickUser()
	{
		element(Users).click();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verify user page
	* Param: NA
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyUserPage()
	{
		if(element(customerList).isCurrentlyVisible() &&
				element(searchBar).isCurrentlyVisible())
				 return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Select customer
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void selectCustomer(String customerName) 
	{
		element(By.xpath("//a[contains(text(),'"+customerName+"')]")).click();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verify user list after selecting customer
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public boolean verifyUserList()
	{
		if (element(userList).isCurrentlyVisible() &&
				element(addNewButton).isCurrentlyVisible()) 
				 return true;
		else return false;	
	}
	
	/********************************************************************
	* Description: Add new user by filling all the details
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void addNewUser(String UserfirstName,String UserlastName,String PhoneNumber,String UseEmailID,String DomainName,String UserPassword,String UserConfirmPassword)
	{
		element(addNewButton).click();
		element(firstNameField).sendKeys(UserfirstName);
		element(lastNameField).sendKeys(UserlastName);
//		element(MobileNum).clear();
//		element(MobileNum).sendKeys(PhoneNumber);
		element(email).clear();
		element(email).sendKeys(UseEmailID);
		element(DomaindropdownIcon).click();
		element(By.xpath("//div//mat-option//span[contains(text(),'"+DomainName+"')]")).click();
//		List<WebElement> domainList = getDriver().findElements(DomainDropdownList);
//		int size = domainList.size();
//		for(int i=1;i<domainList.size();i++) {
//			if(domainList.get(i).getText().contains("'"+DomainName+"'"))
//	    element(By.xpath("//mat-option//span[contains(text(),'"+DomainName+"')]")).click();
//		}
		element(password).clear();
		element(password).sendKeys(UserPassword);
		element(confirmPassword).sendKeys(UserConfirmPassword);
		element(addButton).click();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verify newly added user
	* Param: NA
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyUserAdded(String UserFirstname,String UserLastName) {
		if(element(By.xpath("//a[contains(text(),'"+UserFirstname+" "+UserLastName+"')]")).isCurrentlyVisible())
		return true;
		else
			return false;
	}
	
	/********************************************************************
	* Description: Verify search field by entering valid data
	* Param: Valid Input
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void verifySearchfield(String validInput)
	{
		element(searchUser).sendKeys(validInput);
	}
	
	/********************************************************************
	* Description: List of user will be displayed based on entered data 
	* Param: NA
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifySearchFieldForValidInputs()
	{
		List<WebElement> userList = getDriver().findElements(listOfUser);
		int size = userList.size();
		if(size>0) return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Verify search field by entering invalid data
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void verifySearchfieldWithInvalidData(String invalidData)
	{
		element(searchUser).sendKeys(invalidData);
	}
	
	/********************************************************************
	* Description: No List of user will be displayed based on entered data 
	* Param: NA
	* Returns: Boolean
	* Status: Completed
	********************************************************************/
	public boolean verifySearchFieldForInValidInputs()
	{
		List<WebElement> userList = getDriver().findElements(listOfUser);
		int size = userList.size();
		if(size==0) return true;
		else return false;
	}
	/********************************************************************
	* Description: Select the GTT customer
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void clickCustomer(String selectCustomer) {
	
		element(By.xpath("//a[text()='"+selectCustomer+"']")).click();
		waitForElementToDisappear(loader);
		
	}
	
	/********************************************************************
	* Description: Disable the User
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void disableUser(String DisableUser)
	{
		element(By.xpath("//a[contains(text(),'"+DisableUser+"')]/../../..//span[contains(text(),'Disable')]")).click();
		waitForElementToDisappear(loader);
	}
	/********************************************************************
	* Description: Verify user is getting disabled
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	
	public boolean verifyUserIsgettingDisabled(String User)
	{
		if (element(By.xpath("//a[contains(text(),'"+User+"')]/../../..//span[contains(text(),'Enable')]")).isCurrentlyVisible()) 
		return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Select the GTT customer to enable user
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	
	public void clickCustomerToEnable(String selectCustomerToDisable)
	{
	
		element(By.xpath("//a[text()='"+selectCustomerToDisable+"']")).click();
		waitForElementToDisappear(loader);
		
	}
	
	/********************************************************************
	* Description: Disable the User
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void enableDisabledUser(String EnableUser)
	{
		element(By.xpath("//a[contains(text(),'"+EnableUser+"')]/../../..//span[contains(text(),'Enable')]")).click();
		waitForElementToDisappear(loader);
		//waitSeconds(7);
	}
	/********************************************************************
	* Description: Verify user is getting disabled
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	
	public boolean verifyUserIsgettingEnabled(String User)
	{
		waitForElementToDisappear(loader);
		System.out.println("1"+element(By.xpath("//a[contains(text(),'"+User+"')]/../../..//span[contains(text(),' Disable ')]")).isCurrentlyVisible());
		if (element(By.xpath("//a[contains(text(),'"+User+"')]/../../..//span[contains(text(),' Disable ')]")).isCurrentlyVisible()) 
//		element(By.xpath("//a[contains(text(),'\"+User+\"')]/../../..//span[contains(text(),'Enable')]")).isCurrentlyVisible()) 
////		if(element(By.xpath("//a[contains(text(),'"+User+"')]/../../..//span[contains(text(),'Edit')]")).isCurrentlyVisible()) 
		return true;
		else return false;
	}
	
	/********************************************************************
	* Description: Verify selecting customer to edit user details
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void CustSelect(String selectCustomerToEditUser) {
		element(By.xpath("//a[text()='"+selectCustomerToEditUser+"']")).click();
		waitForElementToDisappear(loader);
		
		}
	
	/********************************************************************
	* Description: Verify user is able to edit details
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	
	public void editUser(String EditUser,String userFirstName,String userLastName,String userMobileNumber,
			String userEmailId,String userNewPassword,String userConfirmPassword,String domain)
	{
		element(By.xpath("//a[contains(text(),'"+EditUser+"')]/../../..//span[contains(text(),'Edit')]")).click();
		waitForElementToDisappear(loader);
		element(EditfirstNameField).clear();
		element(EditfirstNameField).sendKeys(userFirstName);
		element(EditLastNameField).clear();
		element(EditLastNameField).sendKeys(userLastName);
//		element(EditMobileNumber).click();
//		element(EditMobileNumber).clear();
//		element(EditMobileNumber).sendKeys(number);
		element(EditEmailID).clear();
		element(EditEmailID).sendKeys(userEmailId);
		element(ChangeDomain).click();
		element(By.xpath("//div//mat-option//span[contains(text(),'"+domain+"')]")).click();
//		element(EditNewPassword).sendKeys(userNewPassword);
//		element(EditConfirmPassword).clear();
//		element(EditConfirmPassword).sendKeys(userConfirmPassword);
		element(UdateDetails).click();
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: Verify user details are updating
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/

//	public boolean verifyUserDetailsAreUpdating(String editUserName)
//	{
//		String expMessaeg  = element(By.xpath(""));
//		String actUserName = element(By.xpath("//a[contains(text(),'"+editUserName+"')]")).getText();
//		System.out.println("Edited name"+actUserName);
//		System.out.println("1"+element(By.xpath("//a[contains(text(),'"+editUserName+"')]")).isCurrentlyVisible() );
////		System.out.println("2"+actUserName.contains(expUserName));
////		if (element(By.xpath("//a[contains(text(),'"+editUserName+"')]")).isCurrentlyVisible() && actUserName.equalsIgnoreCase(expUserName))
////			return true;
////			else
////			return false;
//	}
//	
	/********************************************************************
	* Description: Verify user details are updating
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void gotouserPageToViewUpdateDetails(String ClickOnUserName) {
		element(By.xpath("//a[contains(text(),'"+ClickOnUserName+"')]")).click();
	}
	
	/********************************************************************
	* Description: Verify user details are updating
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/

	public boolean verifyUserDetailsAreUpdating(String editedMail,String EditedDomain)
	{
		String expEmail = editedMail;
		String expDomain = EditedDomain;
		String actUserEmail = element(EditEmailID).getText();
		String actUDomain = element(EditEmailID).getText();
		System.out.println("1"+actUserEmail);
		System.out.println("2"+actUDomain);
		
		if (expEmail.equals(editedMail)&&expDomain.equals(EditedDomain))
			return true;
			else
			return false;
		
	}
	
	/********************************************************************
	* Description: Search for customer
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void searchCustomer()
	{
	element(searchUser).sendKeys("user");

	}

	/********************************************************************
	* Description: Click on customer
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void clickCustomerr(String selectCustomer)
	{
	element(By.xpath("//a[text()='"+selectCustomer+"']")).click();
	waitForElementToDisappear(loader);
	}

	/********************************************************************
	* Description: To delete user
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void deleteUser(String deleteUser)
	{
	element(By.xpath("//a[contains(text(),'"+deleteUser+"')]/..//mat-icon[@mattooltip='Delete']")).click();
	element(popUpYesButton).click();
	waitForElementToDisappear(loader);

	}

	/********************************************************************
	* Description: verify user got deleted
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyUserAfterDeleting(String verifyDeleteUser)
	{
	if (!element(By.xpath("//a[contains(text(),'"+verifyDeleteUser+"')]")).isCurrentlyVisible())
	return true;
	else return false;
	}

	/********************************************************************
	* Description: select the user
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void selectUser(String selectUser)
	{
	element(By.xpath("//a[contains(text(),'"+selectUser+"')]")).click();
	waitForElementToDisappear(loader);
	}

	/********************************************************************
	* Description: disable the user
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void disableUser()
	{
	element(By.xpath("//div[@class='mat-slide-toggle-bar mat-slide-toggle-bar-no-side-margin']")).click();
	waitForElementToDisappear(loader);
	}

	/********************************************************************
	* Description: verify user is disabled
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	     public boolean verifyUserDisabled(String verifyUserDisable )
	{
	    String actelementStatus = element(By.xpath("//*[@class='mat-simple-snackbar ng-star-inserted']")).getText();
	System.out.println(actelementStatus);
	String expelementStatus = "User '"+verifyUserDisable+"' disabled successfully";
	System.out.println("1"+element(By.xpath("//span[contains(text(),'Disabled')]")).isCurrentlyVisible());
	System.out.println("2"+element(By.xpath("//mat-slide-toggle[@class='mat-slide-toggle mat-primary ng-valid ng-dirty ng-touched']")).isCurrentlyVisible());
	System.out.println("3"+actelementStatus.equals(expelementStatus));
	if (element(By.xpath("//span[contains(text(),'Disabled')]")).isCurrentlyVisible() &&
	actelementStatus.equals(expelementStatus)) 
	return true;
	else return false;
	}

	/********************************************************************
	* Description: enable the user
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void enableUser()
	{
	element(By.xpath("//div[@class='mat-slide-toggle-bar mat-slide-toggle-bar-no-side-margin']")).click();
	waitForElementToDisappear(loader);

	}

	/********************************************************************
	* Description: verify user is enabled
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyUserEnabled(String verifyUserEnable)
	{
	String actelementStatus = element(By.xpath("//*[@class='mat-simple-snackbar ng-star-inserted']")).getText();
	System.out.println(actelementStatus);
	String expelementStatus = "User '"+verifyUserEnable+"' enabled successfully";
	if (element(By.xpath("//span[contains(text(),'Enabled')]")).isCurrentlyVisible() &&
	actelementStatus.equals(expelementStatus)) 
	return true;
	else return false;
	}

	/********************************************************************
	* Description: move to dashboard
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void moveToDashboard()
	{
	getDriver().navigate().back();
	waitForElementToDisappear(loader);
	}

	/********************************************************************
	* Description: select user group link
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void selectUserGroup()
	{
	element(userGroup).click();
	waitForElementToDisappear(loader);
	}

	/********************************************************************
	* Description: selecting group
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void selectGroupAddUser(String selectGroup)
	{
	element(By.xpath("//span[text()='"+selectGroup+"']")).click();
	waitForElementToDisappear(loader);
	}

	/********************************************************************
	* Description: add user from dropdown
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void addUserFromDropdown(String selectUserFromDropdown)
	{
	element(By.xpath("//span[contains(text(),' Add User ')]")).click();
	element(By.xpath("//div[@class='mat-form-field-infix']")).click();
	List<WebElement> userList = getDriver().findElements(userListLocator);
	int s= userList.size();

	for(int i=1; i<s;i++)
	{
	if(userList.get(i).getText().equals(selectUserFromDropdown))
	{
	userList.get(i).click();
	break;
	    }
	}

	element(By.xpath("//span[text()=' Add ']")).click();
	waitForElementToDisappear(loader);
	     }

	/********************************************************************
	* Description: verify user got addead in list
	* Param: NA
	* Returns: boolean
	* Status: Completed
	********************************************************************/
	public boolean verifyUserInList(String UserInList,String selectUserFromDropdown)
	{
	boolean result1= false;
	if(element(By.xpath("//span[contains(text(),'"+UserInList+"')]")).isCurrentlyVisible())
	result1 = true;

	element(By.xpath("//span[contains(text(),' Add User ')]")).click();
	element(By.xpath("//div[@class='mat-form-field-infix']")).click();
	List<WebElement> userList = getDriver().findElements(userListLocator);
	int s= userList.size();
	boolean result2 = false;
	for(int i=1; i<s;i++)
	{
	if(userList.get(i).getText().equals(selectUserFromDropdown))
	result2 = true;

	}
	if(result1==true && result2==false)
	        return true;
	        else return false;

	}
	
	/********************************************************************
	* Description: click on permission for the user
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void clickPermission(String selectUser)
	{
	element(By.xpath("//a[contains(text(),'"+selectUser+"')]/../../..//span[contains(text(),' Permissions ')]")).click();
	waitForElementToDisappear(loader);
	}

	/********************************************************************
	* Description: I select any one group in permission link
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void clickGroupInPermission(String selectGroup)
	{

//		WebElement scanEle =new WebDriverWait(getDriver(), 20).until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()='Admin']/..//input[@aria-checked='true']")));
//		Actions action =new Actions(getDriver());
//		action.moveToElement(scanEle).click();
		
		By disableElement = By.xpath("//a[text()='Admin']/..//input[@aria-checked='true']");
		Actions act = new Actions(getDriver());
		act.moveToElement(element(disableElement)).click().perform();
//	element(By.xpath("//a[text()='Admin']/..//input[@aria-checked='true']")).click();
//		try {
//		element(By.xpath("//a[text()='General']/../mat-checkbox/label/div[@class='mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin')]")).click();
//	waitForElementToDisappear(loader);
//		}
//		catch (Exception e) {
//			
//		}
	}
	
	/********************************************************************
	* Description: click on permission for the user
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void enterInvalidFirstName(String firstName)
	{
		element(firstNameField).sendKeys(firstName);
		element(lastNameField).click();
	
	}
	
	/********************************************************************
	* Description: click on permission for the user
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public boolean firstNameerrorMessage()
	
	{
	String actelementStatus = element(By.xpath("//input[@name='firstName']//..//..//..//mat-error//span")).getText();
	System.out.println(actelementStatus);
	String expelementStatus = "First Name is invalid";
	if(actelementStatus.equals(expelementStatus))
	return true;
	else return false;
	
	}
	
	/********************************************************************
	* Description: click on permission for the user
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	
	public void addButton()
	{
		element(addNewButton).click();
	}	
	
	/********************************************************************
	* Description: click on permission for the user
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void clickOnPermissionLink(String UserName)
	{
		element(By.xpath("//mat-card/div//a[contains(text(),' "+UserName+ "')]//..//..//..//span[contains(text(),'Permissions')]")).click();		
	}	
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	  public boolean verifyPermissionLinkTab(String expUrl)
	{
		  String actUrl = getDriver().getCurrentUrl();
			if (actUrl.contains(expUrl) && 
					element(PermissionTabTitle).isCurrentlyVisible())
				return true;
			else return false;
		
			
	}	
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void permissionsLinkViewIcon(String userGroupNameToClickOnViewIcon)
	{
		element(By.xpath("//mat-list-item//a[contains(text(),'"+userGroupNameToClickOnViewIcon+"')]/../..//span//mat-icon[contains(text(),' remove_red_eye ')]")).click();	
	}	
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void permissionsLinkEditIcon(String userGroupNameToClickOnEditIcon)
	{
		Actions act =  new Actions(getDriver());
		act.moveToElement(getDriver().findElement(By.xpath("//mat-list-item//a[contains(text(),'"+userGroupNameToClickOnEditIcon+"')]/../..//span//mat-icon[contains(text(),' edit ')]"))).click().perform();
		waitFor(100);
		waitForElementToDisappear(loader);
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void selectGroupNewInPermissionsTab(String GroupNameToSelectGroup) {
		element(By.xpath("//mat-list-item//a[contains(text(),'"+GroupNameToSelectGroup+"')]")).click();
		waitForElementToDisappear(loader);
		
		
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void selectCheckboxOfGroup(String GroupNameToSelectCheckBox) {
		element(By.xpath("//mat-list-item//a[contains(text(),'"+GroupNameToSelectCheckBox+"')]/..//mat-checkbox")).click();
		waitForElementToDisappear(loader);
	}
		
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void clickOnPermissionTabEditButton() {
		element(By.xpath("//button//span[contains(text(),'Edit')]")).click();
		waitForElementToDisappear(loader);
	
	}
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
	public void enterInvalidLastName(String LastName) {
	
		element(lastNameField).sendKeys(LastName);
		element(email).click();
	}
	
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
    public boolean LastNameErrorMessage()
	{
	String actelementStatus = element(By.xpath("//input[@name='lastName']//..//..//..//mat-error//span")).getText();
	System.out.println(actelementStatus);
	String expelementStatus = "Last Name is invalid";
	if(actelementStatus.equals(expelementStatus))
	return true;
	else return false;
	
	}
	
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
    public void enterInvalidEmailID(String EmailId) {
    	
		element(email).sendKeys(EmailId);
		element(password).click();
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
  public boolean EmailIdVerification()
	
	{
	String actelementStatus = element(By.xpath("//input[@name='email']//..//..//..//mat-error//span")).getText();
	System.out.println(actelementStatus);
	String expelementStatus = "Email is invalid";
	if(actelementStatus.equals(expelementStatus))
	return true;
	else return false;
	
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
   public void enterInvalidNewPassword(String NewPassword) {
  	
		element(password).sendKeys(NewPassword);
		element(confirmPassword).click();
	}
	
	/********************************************************************
	* Description: 
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
   public boolean NewPasswordfieldVerification()
	
  	{
  	String actelementStatus = element(By.xpath("//input[@name='newPassword']//..//..//..//mat-error//span")).getText();
  	System.out.println(actelementStatus);
  	String expelementStatus = "Password should be minimum 10 characters and should contain (lowercase letters, capital letters, numbers, special characters).";
  	if(actelementStatus.equals(expelementStatus))
  	return true;
  	else return false;
  	
  	}
   
   /********************************************************************
	* Description: 
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
   public void enterInvalidConfirmPassword(String ConfirmPassword) {
   	
		element(confirmPassword).sendKeys(ConfirmPassword);
		element(password).click();
	}
   
   /********************************************************************
	* Description: 
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
   public boolean ConfirmPasswordVerification()
	
  	{
  	String actelementStatus = element(By.xpath("//input[@name='confirmPassword']//..//..//..//mat-error//span")).getText();
  	System.out.println(actelementStatus);
  	String expelementStatus = "Password does not match the confirm password. Password should contain (lowercase letters, capital letters, numbers, special characters).";
  	if(actelementStatus.equals(expelementStatus))
  	return true;
  	else return false;
  	
  	}
   
   /********************************************************************
	* Description: 
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
  public boolean editButtonInPermissionTabIsdisplaying()
	
 	{
	  if(element(By.xpath("//button//span[contains(text(),'Edit')]")).isCurrentlyEnabled())
	  return true;
	  else
	  return false;
 	}
  
  /********************************************************************
	* Description: 
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
  public boolean accessControlPageIsDiaplaying(String expUrl)
	
	{
	  String actUrl = getDriver().getCurrentUrl();
		if (actUrl.contains(expUrl) && 
				element(AccessLevelTab).isCurrentlyVisible())
			return true;
		else return false; 
	
	}
  

/********************************************************************
	* Description: 
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
public boolean verifyGroupSelectedSuccessfulMessage(String UserNameToSelectGroup, String GroupNameToSelect)
	
	{
	
	String actelementStatus = element(By.xpath("//simple-snack-bar//span")).getText();
  	System.out.println(actelementStatus);
  	String expelementStatus = "User '"+UserNameToSelectGroup+"' added to group '"+GroupNameToSelect+"'";
  	if(actelementStatus.equals(expelementStatus))
  	return true;
  	else return false;
	
	}

/********************************************************************
* Description: 
* Param: NA
* Returns: void
* Status: Completed
********************************************************************/
public boolean verifyGroupUnSelectedSuccessfulMessage(String UserNameToUnselectGroup, String GroupNameToUnselect)

{

String actelementStatus = element(By.xpath("//simple-snack-bar//span")).getText();
	System.out.println(actelementStatus);
	String expelementStatus = "User '"+UserNameToUnselectGroup+"' removed from the group '"+GroupNameToUnselect+"'";
	if(actelementStatus.equals(expelementStatus))
	return true;
	else return false;

}

/********************************************************************
	* Description: 
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
  public void selectUserFromList(String UserName){
	  element(By.xpath("//mat-card//a[contains(text(),'"+UserName+"')]")).click();
	  waitForElementToDisappear(loader);
  }
  
  /********************************************************************
	* Description: 
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
  public void selectUserGroupInUserDetailsTab(String GroupName){
	  element(By.xpath("//mat-checkbox//span[contains(text(),'"+GroupName+"')]")).click();
	  waitForElementToDisappear(loader);
  }
 
  /********************************************************************
 	* Description: 
 	* Param: NA
 	* Returns: void
 	* Status: Completed
 	********************************************************************/
  public boolean verifyGroupSelectedSuccessfulMessageInUserDetailsTab(String UserNameToSelectGroup, String GroupNameToSelect)
	
	{
	
	String actelementStatus = element(By.xpath("//simple-snack-bar//span")).getText();
	System.out.println(actelementStatus);
	String expelementStatus = "User '"+UserNameToSelectGroup+"' added to group '"+GroupNameToSelect+"'";
	if(actelementStatus.equals(expelementStatus))
	return true;
	else return false;
	
	}
  
  /********************************************************************
	* Description: 
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
public void unselectUserGroupInUserDetailsTab(String GroupName){
	  element(By.xpath("//mat-checkbox//span[contains(text(),'"+GroupName+"')]")).click();
	  waitForElementToDisappear(loader);
}

/********************************************************************
	* Description: 
	* Param: NA
	* Returns: void
	* Status: Completed
	********************************************************************/
public boolean verifyGroupUnSelectedSuccessfulMessageInUserDetailsTab(String UserNameToUnselectGroup, String GroupNameToUnselect)
	
	{
	
	String actelementStatus = element(By.xpath("//simple-snack-bar//span")).getText();
	System.out.println(actelementStatus);
	String expelementStatus = "User '"+UserNameToUnselectGroup+"' removed from the group '"+GroupNameToUnselect+"'";
	if(actelementStatus.equals(expelementStatus))
	return true;
	else return false;
	
	}


}
