package com.zysk.cerebra.csv_reader;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

public class ManufacturerAndModelCSVReader {

	public static String target = "src/test/resources/dataSources/manufacturerAndModels.csv";
	private static HashMap<String,String> data;

	 public static void loadCSV() {

		   data = new HashMap<String, String>();
		   String line;
		   String [] split;
		   
		   try (BufferedReader br = new BufferedReader(new FileReader(target))) {

		   System.out.println("Reading from " + target);
		   while ((line = br.readLine()) != null) {
		   split = line.split(",");
		   String key = split[0];
		   String value = split[1];

		   if (System.getProperty(key) != null) {
		   value = System.getProperty(key);
		   System.out.println("Overriding key '" + key + "' with value '" + value + "'");
		   }

		   data.put(key,value);
		   }

		   } catch (IOException e) {
		   System.out.println("\n***** ERROR: CSV not found. *****\n");
		   }

		   }

	   public static String getKey(String key) {

		   if (data == null) loadCSV();

		   if (data.get(key) == null) return "ERROR: Key not found";

		   return data.get(key);

		   }
	   
		
		public static String getnewManufaturerNameToAdd()
		{
			return getKey("newManufaturerNameToAdd");
		}
		
		public static String getmanufacturerCode()
		{
			return getKey("manufacturerCode");
		}
		
		public static String getManufacturerFromDropdown()
		{
			return getKey("selectManufacturerFromDropdown");
		}
		
		public static String getModelName()
		{
			return getKey("modelName");
		}
		
		public static String getModelCode()
		{
			return getKey("modelCode");
		}
		
		public static String getModelImage()
		{
			return getKey("modelImage");
		}
			
		public static String getUpdatedModelName()
		{
			return getKey("updateModelName");
		}
		
		public static String getUpdatedModelCode()
		{
			return getKey("updateModelCode");
		}
		
		public static String getUpdatedModelImagePath()
		{
			return getKey("updateModelImage");
		}
		
		
	
		
		/*****************************************************************************************************************/

		
		public static String getUpdatedDesignParameterName()
		{
			return getKey("UpdatedDesignParameterName");
		}

		public static String getDesignParameterName()
		{
			return getKey("DesignParameterName");
		}
		
		public static String getValue()
		{
			return getKey("Value");
		}
		
public static String getExpConfigURL() {
			
			return getKey("ExpConfigURL");
			}
		/*************************************************************************/
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		public static String getManufacturerToDisable()
		{
			return getKey("disableEnableManufacturer");
		}
		
		public static String getMachineUnitToDisableEnableManufacturer()
		{
			return getKey("selectMachineUnitToDisableEnableManufacturer");
		}
		
		public static String getManufacturerToEnable()
		{
			return getKey("disableEnableManufacturer");
		}
		
		public static String getMachineUnitToDeleteManufacturer()
		{
			return getKey("selectMachineUnitToDeleteManufacturer");
		}
		
		public static String getManufacturerToDelete()
		{
			return getKey("deleteManufacturer");
		}
		
		public static String getMachineUnitToAddModels()
		{
			return getKey("selectMachineUnitToAddModels");
		}
		
		public static String getManufacturerNameToAddModels()
		{
			return getKey("selectManufacturerNameToAddModels");
		}
		
		public static String getMachineUnitNameToDisableEnableModels()
		{
			return getKey("selectMachineUnitToDisableEnableModels");
		}
		
		public static String getManufacturerNameToDisableEnableModels()
		{
			return getKey("selectManufacturerNameToDisableEnableModels");
		}
		
		public static String getModelToDisableEnable()
		{
			return getKey("disableEnableModel");
		}
		
		public static String getMachineUnitNameToDeleteModels()
		{
			return getKey("selectMachineUnitToDeleteModel");
		}
		
		public static String getManufacturerNameToDeleteModels()
		{
			return getKey("selectManufacturerNameToDeleteModel");
		}
		
		public static String getModelToDelete()
		{
			return getKey("deleteModel");
		}
		
	   
	   public static String getMachineUnitNameToUpdateModels()
		{
			return getKey("selectMachineUnitToEditModel");
		}
		
		public static String getManufacturerNameToUpdateModels()
		{
			return getKey("selectManufacturerNameToEditModel");
		}
		
		public static String getModelNameToUpdate()
		{
			return getKey("modelToEdit");
		}
		
	
		
		public static String getMachineUnitToAddSubsystemToModel()
		{
			return getKey("selectMachineUnitToAddsubsystemToModel");
		}
		
		public static String getManufacturerToAddSubsystemToModel()
		{
			return getKey("selectManufacturerToAddsubsystemToModel");
		}
		
		public static String getModelToAddSubsystem()
		{
			return getKey("selectModelToAddsubsystem");
		}
	    
		public static String getSelectBattery()
		{
			return getKey("selectBattery");
		}
		
		public static String getSelectEngine()
		{
			return getKey("selectEngineToAddSubSystem");
		}
		
		public static String getselectAirIntakeSystem()
		{
			return getKey("selectAirIntakeSystem");
		}
		
		public static String getMachineUnitToAddMoreThan1subsystem()
		{
			return getKey("selectMachineUnitToAddMoreThan1subsystem");
		}
		
		public static String getManufacturerToAddMoreThan1Subsystem()
		{
			return getKey("selectManufacturerToAddMoreThan1subsystemToModel");
		}
		
		public static String getModelToAddMoreThan1Subsystem()
		{
			return getKey("selectModelToAddsubsystemMoreThan1");
		}
		
		public static String getEquipmentToAddSubsystem()
		{
			return getKey("selectequipmentToAddSubsystem");
		}
		
		public static String getEngine()
		{
			return getKey("selectEngine");
		}
		
		public static String getEngineModel()
		{
			return getKey("selectEngineModel");
		}
		
		public static String getCountOfSubsystem()
		{
			return getKey("countofModel");
		}
		
		public static String getMachineUnitToDisableEnablesubsystem()
		{
			return getKey("selectMachineUnitToDisableEnablesubsystem");
		}
		
		public static String getManufacturerToDisableEnablesubsystem()
		{
			return getKey("selectManufacturerToDisableEnablesubsystem");
		}
		
		public static String getModelToDisableEnablesubsystem()
		{
			return getKey("selectModelToDisableEnablesubsystem");
		}
		
		public static String getSubsystemToDisableEnable()
		{
			return getKey("enableDisableSubsystem");
		}
	   
	   public static String getMachineUnitToDeletesubsystem()
		{
			return getKey("selectMachineUnitToDeletesubsystem");
		}
		
		public static String getManufacturerToDeletesubsystem()
		{
			return getKey("selectManufacturerToDeletesubsystem");
		}
		
		public static String getModelToDeletesubsystem()
		{
			return getKey("selectModelToDeletesubsystem");
		}
		
		public static String getSubsystemToDelete()
		{
			return getKey("deleteSubsystem");
		}
		
		public static String getMachineUnitToViewConfigurationForSubsystem()
		{
			return getKey("selectMachineUnitToViewConfiguration");
		}
		
		public static String getManfacturerToViewConfigurationForSubsystem()
		{
			return getKey("selectManufacturerToViewConfiguration");
		}
		
		public static String getModelToViewConfigurationForSubsystem()
		{
			return getKey("selectModelToViewConfiguration");
		}
		
		public static String getSubsystemToViewConfiguration()
		{
			return getKey("selectSubsystemToViewConfiguration");
		}
		
		public static String getConfigurationUrl()
		{
			return getKey("configUrl");
		}
	   
	   public static String getMachineUnitToDisableEnableUnitForDesignParameter()
		{
			return getKey("selectMachineUnitToDisable/EnableUnitForDesignParameter");
		}
		
		public static String getManufacturerToDisableEnableUnitForDesignParameter()
		{
			return getKey("selectManufacturerToDisable/EnableUnitForDesignParameter");
		}
		
		public static String getModelToDisableEnableUnitForDesignParameter()
		{
			return getKey("selectModelToDisable/EnableUnitForDesignParameter");
		}
		
		public static String getSubsystemToDisableEnableUnitForDesignParameter()
		{
			return getKey("selectSubsystemToDisable/EnableUnitForDesignParameter");
		}
		
		public static String getdesignParameterToDisableEnableUnit()
		{
			return getKey("designParameterToDisable/EnableUnit");
		}
		
		public static String getdesignParameterUnitToDisableEnable()
		{
			return getKey("unitToDisable/EnableforDesignParameter");
		}
		
		public static String getdesignParameterMetricUnitToDisableEnable()
		{
			return getKey("metricunitToDisable/EnableforDesignParameter");
		}
		
		public static String getMachineUnitToDisableEnableUnitForMeasurement()
		{
			return getKey("selectMachineUnitToDisable/EnableUnitForMeasurement");
		}
		
		public static String getManufacturerToDisableEnableUnitForMeasurement()
		{
			return getKey("selectManufacturerToDisable/EnableUnitForMeasurement");
		}
		
		public static String getModelToDisableEnableUnitForMeasurement()
		{
			return getKey("selectModelToDisable/EnableUnitForMeasurement");
		}
		
		public static String getSubsystemToDisableEnableUnitForMeasurement()
		{
			return getKey("selectSubsystemToDisable/EnableUnitForMeasurement");
		}
		
		public static String getmeasurementToDisableEnableUnit()
		{
			return getKey("measurementToDisable/EnableUnit");
		}
		
		public static String getMeasurementUnitToDisableEnable()
		{
			return getKey("unitToDisable/EnableforMeasurement");
		}
		
		public static String getMeasurementMetricUnitToDisableEnable()
		{
			return getKey("metricunitToDisable/EnableforMeasurement");
		}
		
		public static String getMachineUnitToAddUnitForDesignParameter()
		{
			return getKey("selectMachineUnitToAddUnitForDesignParameter");
		}
		
		public static String getManufacturerToAddUnitForDesignParameter()
		{
			return getKey("selectManufacturerToAddUnitForDesignParameter");
		}
		
		public static String getModelToAddUnitForDesignParameter()
		{
			return getKey("selectModelToAddUnitForDesignParameter");
		}
		
		public static String getSubsystemToAddUnitForDesignParameter()
		{
			return getKey("selectSubsystemToAddUnitForDesignParameter");
		}
		
		public static String getDesignParameterToAddUnit()
		{
			return getKey("designParameterToAddUnit");
		}
		
		public static String getmetricUnitSystemNameToAddUnit()
		{
			return getKey("metricUnitSystemName");
		}
		
		public static String getUsUnitSystemNameToAddUnit()
		{
			return getKey("usUnitSystemName");
		}
		
		public static String getAdditive()
		{
			return getKey("additive");
		}
		
		public static String getSubtractive()
		{
			return getKey("subtractive");
		}
		
		public static String getMultiplicative()
		{
			return getKey("multiplicative");
		}
		
		public static String getDivision()
		{
			return getKey("division");
		}
		
		public static String getMachineUnitToAddUnitForMeasurement()
		{
			return getKey("selectMachineUnitToAddUnitForMeasurement");
		}
		
		public static String getManufacturerToAddUnitForMeasurement()
		{
			return getKey("selectManufacturerToAddUnitForMeasurement");
		}
		
		public static String getModelToAddUnitForMeasurement()
		{
			return getKey("selectModelToAddUnitForMeasurement");
		}
		
		public static String getSubsystemToAddUnitForMeasurement()
		{
			return getKey("selectSubsystemToAddUnitForMeasurement");
		}
		
		public static String getMeasurementToAddUnit()
		{
			return getKey("measurementToAddUnit");
		}
		
		public static String getmetricUnitSystemNameToAddUnitForMeasurment()
		{
			return getKey("metricUnitSystemNameForMeasurment");
		}
		
		public static String getUsUnitSystemNameToAddUnitForMeasurment()
		{
			return getKey("usUnitSystemNameForMeasurement");
		}
		
		public static String getAdditiveForMeasurment()
		{
			return getKey("additive-m");
		}
		
		public static String getSubtractiveForMeasurment()
		{
			return getKey("subtractive-m");
		}
		
		public static String getMultiplicativeForMeasurement()
		{
			return getKey("multiplicative-m");
		}
		
		public static String getDivisionForMeasurement()
		{
			return getKey("division-m");
		}
		
		public static String getMachineUnitToAddUnitForCalibration()
		{
			return getKey("selectMachineUnitToAddUnitForCalibration");
		}
		
		public static String getManufacturerToAddUnitForCalibration()
		{
			return getKey("selectManufacturerToAddUnitForCalibration");
		}
		
		public static String getModelToAddUnitForCalibration()
		{
			return getKey("selectModelToAddUnitForCalibration");
		}
		
		public static String getSubsystemToAddUnitForCalibration()
		{
			return getKey("selectSubsystemToAddUnitForCalibration");
		}
		
		public static String getCalibrationToAddUnit()
		{
			return getKey("calibrationToAddUnit");
		}
		
		public static String getmetricUnitSystemNameToAddUnitForCalibration()
		{
			return getKey("metricUnitSystemNameForCalibration");
		}
		
		public static String getUsUnitSystemNameToAddUnitForCalibration()
		{
			return getKey("usUnitSystemNameForCalibration");
		}
		
		public static String getAdditiveForCalibration()
		{
			return getKey("additive-c");
		}
		
		public static String getSubtractiveForCalibration()
		{
			return getKey("subtractive-c");
		}
		
		public static String getMultiplicativeForCalibration()
		{
			return getKey("multiplicative-c");
		}
		
		public static String getDivisionForCalibration()
		{
			return getKey("division-c");
		}
		
	   public static String getMachineUnitToDisableEnableUnitForCalibration()
		{
			return getKey("selectMachineUnitToDisable/EnableUnitForCalibration");
		}
		
		public static String getManufacturerToDisableEnableUnitForCalibration()
		{
			return getKey("selectManufacturerToDisable/EnableUnitForCalibration");
		}
		
		public static String getModelToDisableEnableUnitForCalibration()
		{
			return getKey("selectModelToDisable/EnableUnitForCalibration");
		}
		
		public static String getSubsystemToDisableEnableUnitForCalibration()
		{
			return getKey("selectSubsystemToDisable/EnableUnitForCalibration");
		}
		
		public static String getCalibrationToDisableEnableUnit()
		{
			return getKey("calibrationToDisable/EnableUnit");
		}
		
		public static String getCalibrationUnitToDisableEnable()
		{
			return getKey("unitToDisable/EnableforCalibration");
		}
		
		public static String getCalibrationMetricUnitToDisableEnable()
		{
			return getKey("metricunitToDisable/EnableforCalibration");
		}
	   
	   public static String getMachineUnitToDeleteUnitForDesignParameter()
		{
			return getKey("selectMachineUnitToDeleteUnitForDesignParameter");
		}
		
		public static String getManufacturerToDeleteUnitForDesignParameter()
		{
			return getKey("selectManufacturerToDeleteUnitForDesignParameter");
		}
		
		public static String getModelToDeleteUnitForDesignParameter()
		{
			return getKey("selectModelToDeleteUnitForDesignParameter");
		}
		
		public static String getSubsystemToDeleteUnitForDesignParameter()
		{
			return getKey("selectSubsystemToDeleteUnitForDesignParameter");
		}
		
		public static String getDesignParameterToDeleteUnit()
		{
			return getKey("designParameterToDeleteUnit");
		}
		
		public static String getDesignParameterUnitToDelete()
		{
			return getKey("unitToDeleteforDesignParameter");
		}
		
		public static String getDesignParameterMetricUnitToDelete()
		{
			return getKey("metricunitToDeleteforDesignParameter");
		}
	   
	   public static String getMachineUnitToDeleteUnitForMeasurement()
		{
			return getKey("selectMachineUnitToDeleteUnitForMeasurement");
		}
		
		public static String getManufacturerToDeleteUnitForMeasurement()
		{
			return getKey("selectManufacturerToDeleteUnitForMeasurement");
		}
		
		public static String getModelToDeleteUnitForMeasurement()
		{
			return getKey("selectModelToDeleteUnitForMeasurement");
		}
		
		public static String getSubsystemToDeleteUnitForMeasurement()
		{
			return getKey("selectSubsystemToDeleteUnitForMeasurement");
		}
		
		public static String getMeasurementToDeleteUnit()
		{
			return getKey("measurementToDeleteUnit");
		}
		
		public static String getMeasurementToDelete()
		{
			return getKey("unitToDeleteforMeasurement");
		}
		
		public static String getMeasurementMetricUnitToDelete()
		{
			return getKey("metricunitToDeleteforMeasurement");
		}
		
	   public static String getMachineUnitToDeleteUnitForCaibration()
		{
			return getKey("selectMachineUnitToDeleteUnitForCalibration");
		}
		
		public static String getManufacturerToDeleteUnitForCalibration()
		{
			return getKey("selectManufacturerToDeleteUnitForCalibration");
		}
		
		public static String getModelToDeleteUnitForCalibration()
		{
			return getKey("selectModelToDeleteUnitForCalibration");
		}
		
		public static String getSubsystemToDeleteUnitForCalibration()
		{
			return getKey("selectSubsystemToDeleteUnitForCalibration");
		}
		
		public static String getCalibrationToDeleteUnit()
		{
			return getKey("calibrationToDeleteUnit");
		}
		
		public static String getCalibrationToDelete()
		{
			return getKey("unitToDeleteforCalibration");
		}
		
		public static String getCalibrationMetricUnitToDelete()
		{
			return getKey("metricunitToDeleteforCalibration");
		}
		
	   
	   public static String getMachineUnitToAddParameter()
		{
			return getKey("selectMachineUnitToAddParameter");
		}
		
		public static String getManufacturerToAddParameter()
		{
			return getKey("selectManufacturerToAddParameter");
		}
		
		public static String getModelToAddParameter()
		{
			return getKey("selectModelToAddParameter");
		}
		
		public static String getSubsystemToAddParameter()
		{
			return getKey("selectSubsystemToAddParameter");
		}
		
		public static String getDPName()
		{
			return getKey("dpName");
		}
		
		public static String getDPValue()
		{
			return getKey("dpValue");
		}
		
		public static String getDesignParameter()
		{
			return getKey("designParameter");
		}
		
		public static String getsystemOfUnitForDesignParameter()
		{
			return getKey("systemOfUnitforDP");
		}
		
		public static String getDesignParameterUnit()
		{
			return getKey("dpUnit");
		}
		
		public static String getMeasurementNameForManufacturerAndModel()
		{
			return getKey("measurementName");
		}
		
		public static String getMeasurementParameter()
		{
			return getKey("measurement");
		}
		
		public static String getsystemOfUnitForMeasurement()
		{
			return getKey("systemOfUnitForMeasurement");
		}
		
		public static String getMeasurementUnit()
		{
			return getKey("measurementUnit");
		}
		
		public static String getCalibrationNameForManufacturerAndModel()
		{
			return getKey("calibrationNameToAdd");
		}
		
		public static String getCalibrationParameter()
		{
			return getKey("calibration");
		}
		
		public static String getsystemOfUnitForCalibration()
		{
			return getKey("systemOfUnitForCalibration");
		}
		
		public static String getCalibrationUnit()
		{
			return getKey("CalibrationUnit");
		}
		
		public static String getAlarmNameToAdd()
		{
			return getKey("alarmNameToAdd");
		}
		
		public static String getAlarmParameter()
		{
			return getKey("alarmParameter");
		}
		
		public static String getTripNameToAdd()
		{
			return getKey("tripNameToAdd");
		}
		
		public static String getTripParameter()
		{
			return getKey("tripParameter");
		}
		
		public static String getFaultNameToAdd()
		{
			return getKey("faultNameToAdd");
		}
		
		public static String getFaultParameter()
		{
			return getKey("faultParameter");
		}
		
		public static String getFunctionStatesToAdd()
		{
			return getKey("functionStatesNameToAdd");
		}
		
		public static String getFunctionStatesParameter()
		{
			return getKey("FSParameter");
		}
		
	   public static String getMachineUnitToDeleteParameter()
		{
			return getKey("selectMachineUnitToDeleteParameter");
		}
		
		public static String getManufacturerToDeleteParameter()
		{
			return getKey("selectManufacturerToDeleteParameter");
		}
		
		public static String getModelToDeleteParameter()
		{
			return getKey("selectModelToDeleteParameter");
		}
		
		public static String getSubsystemToDeleteParameter()
		{
			return getKey("selectSubsystemToDeleteParameter");
		}
		
		public static String getDesignParameterToDelete()
		{
			return getKey("deletedesignParamater");
		}
		
		public static String getMeasurementParameterToDelete()
		{
			return getKey("deleteMeasurement");
		}
		
		public static String getAlarmsToDelete()
		{
			return getKey("deleteAlarms");
		}
		
		public static String getTripsToDelete()
		{
			return getKey("deleteTrips");
		}
		
		public static String getFaultsToDelete()
		{
			return getKey("deleteFaults");
		}
		
		public static String getFunctionStatesToDelete()
		{
			return getKey("deleteFunctionStates");
		}
		
		public static String getCalibrationParameterToDelete()
		{
			return getKey("deleteCalibration");
		}
		
		public static String getMachineUnitToDisableEnableParameter()
		{
			return getKey("selectMachineUnitToDisable/EnableParameter");
		}
		
		public static String getManufacturerToDisableEnableParameter()
		{
			return getKey("selectManufacturerToDisable/EnableParameter");
		}
		
		public static String getModelToDisableEnableParameter()
		{
			return getKey("selectModelToDisable/EnableParameter");
		}
		
		public static String getSubsystemToDisableEnableParameter()
		{
			return getKey("selectSubsystemToDisable/EnableParameter");
		}
		
		public static String getDesignParameterToEnableDisable()
		{
			return getKey("enable/disabledesignParamater");
		}
		
		public static String getMeasurementToEnableDisable()
		{
			return getKey("enable/disableMeasurement");
		}
		
		public static String getAlarmsToEnableDisable()
		{
			return getKey("enable/disableAlarms");
		}
		
		public static String getTripsToEnableDisable()
		{
			return getKey("enable/disableTrips");
		}
		
		public static String getFaultsToEnableDisable()
		{
			return getKey("enable/disableFaults");
		}
		
		public static String getFunctionStatesToEnableDisable()
		{
			return getKey("enable/disableFunctionStates");
		}
		
		public static String getCalibrationToEnableDisable()
		{
			return getKey("enable/disableCalibration");
		}
	
	public static String getMachineUnitToViewGatewayConfiguration()
	{
		return getKey("selectMachineUnitToViewGatewayConfiguration");
	}
	
	public static String getManufacturerToViewGatewayConfiguration()
	{
		return getKey("selectManufacturerToViewGatewayConfiguration");
	}
	
	public static String getModelToViewGatewayConfiguration()
	{
		return getKey("selectModelToViewGatewayConfiguration");
	}
	
	public static String getSubsystemToViewGatewayConfiguration()
	{
		return getKey("selectSubsystemToViewGatewayConfiguration");
	}
	
	public static String getMachineUnitToAddTagsForParameter()
	{
		return getKey("selectMachineUnitToAddTagsForParameter");
	}
	
	public static String getManufacturerToAddTagsForParameter()
	{
		return getKey("selectManufacturerToAddTagsForParameter");
	}
	
	public static String getModelToAddTagsForParameter()
	{
		return getKey("selectModelToAddTagsForParameter");
	}
	
	public static String getSubsystemToAddTagsForParameter()
	{
		return getKey("selectSubsystemToAddTagsForParameter");
	}
	
	public static String getGateway()
	{
		return getKey("selectGateway");
	}
	
	public static String getmeasurementParameterNameToAddTag()
	{
		return getKey("measurementParameterNameToAddTag");
	}
	
	public static String getmeasurementTag()
	{
		return getKey("measurementTag");
	}
	
	public static String getalarmParameterNameToAddTag()
	{
		return getKey("alarmParameterNameToAddTag");
	}
	
	public static String getalarmTag()
	{
		return getKey("alarmTag");
	}
	
	public static String gettripParameterNameToAddTag()
	{
		return getKey("tripParameterNameToAddTag");
	}
	
	public static String gettripTag()
	{
		return getKey("tripTag");
	}
	
	public static String getfaultNameToAddTag()
	{
		return getKey("faultNameToAddTag");
	}
	
	public static String getfaultTag()
	{
		return getKey("faultTag");
	}
	
	public static String getfunctionStateToAddTag()
	{
		return getKey("functionStateToAddTag");
	}
	
	public static String getfunctionStateTag()
	{
		return getKey("functionStateTag");
	}
	
	public static String getcalibrationtToAddTag()
	{
		return getKey("calibrationtToAddTag");
	}
	
	public static String getcalibrationTag()
	{
		return getKey("calibrationTag");
	}
	
	
	public static String getMachineUnitToEditTagsForParameter()
	{
		return getKey("selectMachineUnitToEditTagsForParameter");
	}
	
	public static String getManufacturerToEditTagsForParameter()
	{
		return getKey("selectManufacturerToEditTagsForParameter");
	}
	
	public static String getModelToEditTagsForParameter()
	{
		return getKey("selectModelToEditTagsForParameter");
	}
	
	public static String getSubsystemToEditTagsForParameter()
	{
		return getKey("selectSubsystemToEditTagsForParameter");
	}
	public static String getmeasurementParameterNameToEditTag()
	{
		return getKey("measurementParameterNameToEditTag");
	}
	
	public static String getGatewayToEditTags()
	{
		return getKey("selectGatewayToEditTags");
	}
	
	public static String getmeasurementTagToUpdate()
	{
		return getKey("updateMeasurementTag");
	}
	
	public static String getalarmParameterNameToEditTag()
	{
		return getKey("alarmParameterNameToEditTag");
	}
	
	public static String getalarmTagToUpdate()
	{
		return getKey("updateAlarmTag");
	}
	
	public static String gettripParameterNameToEditTag()
	{
		return getKey("tripParameterNameToUpdateTag");
	}
	
	public static String gettripTagToUpdate()
	{
		return getKey("updateTripTag");
	}
	
	public static String getfaultNameToEditTag()
	{
		return getKey("faultNameToEditTag");
	}
	
	public static String getfaultTagToUpdate()
	{
		return getKey("updateFaultTag");
	}
	
	public static String getfunctionStateToEditTag()
	{
		return getKey("functionStateToEditTag");
	}
	
	public static String getfunctionStateTagToUpdate()
	{
		return getKey("updatefunctionStateTag");
	}
	
	public static String getcalibrationtToEditTag()
	{
		return getKey("calibrationtToEditTag");
	}
	
	public static String getcalibrationTagToUpdate()
	{
		return getKey("UpdatedcalibrationTag");
	}
	
	public static String getMachineUnitToEditParameter()
	{
		return getKey("selectMachineUnitToEditParameter");
	}
	
	public static String getManufacturerToEditParameter()
	{
		return getKey("selectManufacturerToEditParameter");
	}
	
	public static String getModelToEditParameter()
	{
		return getKey("selectModelToEditParameter");
	}
	
	public static String getSubsystemToEditParameter()
	{
		return getKey("selectSubsystemToEditParameter");
	}
	
	public static String getdesignParameterToEdit()
	{
		return getKey("designParameterToEdit");
	}
	
	public static String getUpdatedDesignParameter()
	{
		return getKey("designParameterUpdated");
	}
	
	public static String getUpdateddesignParameterValue()
	{
		return getKey("designParameterValue");
	}
	
	public static String getUpdateddesignParameterUnitType()
	{
		return getKey("designParameterUnitType");
	}
	
	public static String getUpdatedDesignParameterUnit()
	{
		return getKey("designParameterUnit");
	}
	
	public static String getmeasurementParameterToEdit()
	{
		return getKey("measurementNameToEdit");
	}
	
	public static String getUpdatedMeasurementParameter()
	{
		return getKey("updatedMeasurementParameter");
	}
	
	public static String getUpdatedMeasurementParameterUnitType()
	{
		return getKey("measurementParameterUnitType");
	}
	
	public static String getUpdatedMeasurementParameterUnit()
	{
		return getKey("measurementParameterUnit");
	}
	
	public static String getUpdatedMeasurementParameterLCLValue()
	{
		return getKey("measurementLCLValue");
	}
	
	public static String getUpdatedMeasurementParameterUCLValue()
	{
		return getKey("measurementUCLValue");
	}
	
	public static String getUpdatedMeasurementParameterMinSignalRange()
	{
		return getKey("measurmentMinSignalRange");
	}
	
	public static String getUpdatedMeasurementParameterMaxSignalRange()
	{
		return getKey("measurementMaxSignalRange");
	}
	
	public static String getUpdatedMeasurementParameterPriorityFlag()
	{
		return getKey("measurementPriorityFlag(ON/OFF)");
	}
	
	public static String getUpdatedMeasurementParameterVisibilityFlag()
	{
		return getKey("measurementVisibilityFlag(ON/OFF)");
	}
	
	public static String getUpdatedMeasurementParameterAggregator()
	{
		return getKey("measurementAggregator");
	}
	
	public static String getalarmParameterToEdit()
	{
		return getKey("alarmNameToedit");
	}
	
	public static String getUpdatedAlarmParameter()
	{
		return getKey("updatedAlarmName");
	}
	
	public static String getUpdatedAlarmSeverity()
	{
		return getKey("alarmSeverity");
	}
	
	public static String getUpdatedAlarmRelatedMeasurement()
	{
		return getKey("alarmRelatedMeasurement");
	}
	
	public static String getUpdatedAlarmRecommendationMessage()
	{
		return getKey("alarmRecommendationMessage");
	}
	
	public static String gettripParameterToEdit()
	{
		return getKey("tripNameToEdit");
	}
	
	public static String getUpdatedTripParameter()
	{
		return getKey("updatedTripName");
	}
	
	public static String getUpdatedTripSeverity()
	{
		return getKey("tripSeverity");
	}
	
	public static String getUpdatedTripRelatedMeasurement()
	{
		return getKey("tripRelatedMeasurement");
	}
	
	public static String getUpdatedTripRecommendationMessage()
	{
		return getKey("tripRecommendationMessage");
	}
	
	public static String getFaultParameterToEdit()
	{
		return getKey("faultNameToEdit");
	}
	
	public static String getUpdatedFaultParameter()
	{
		return getKey("updatedFaultName");
	}
	
	public static String getUpdatedFaultSeverity()
	{
		return getKey("faultSeverity");
	}
	
	public static String getUpdatedFaultRelatedMeasurement()
	{
		return getKey("faultRelatedMeasurement");
	}
	
	public static String getUpdatedFaultRecommendationMessage()
	{
		return getKey("faultRecommendationMessage");
	}
	
	public static String getFSParameterToEdit()
	{
		return getKey("functionStatesParameterToEdit");
	}
	
	public static String getUpdatedFSParameter()
	{
		return getKey("updatedFunctionStates");
	}
	
	public static String getUpdatedFSRelatedMeasurement()
	{
		return getKey("fsRelatedMeasurement");
	}
	
	public static String getCalibrationParameterToEdit()
	{
		return getKey("calibrationNameToEdit");
	}
	
	public static String getUpdatedCalibrationParameter()
	{
		return getKey("updatedCalibrationParameter");
	}
	
	public static String getUpdatedCalibrationParameterUnitType()
	{
		return getKey("calibrationUnitType");
	}
	
	public static String getUpdatedCalibrationParameterUnit()
	{
		return getKey("calibrationUnit");
	}
	
	public static String getUpdatedCalibrationParameterRelatedMeasurement()
	{
		return getKey("calibrationRelatedMeasurement");
	}
	
	public static String getMachineUnitToAddDuplicateManufacturer()
	{
		return getKey("selectMachineUnitToAddDuplicateManufacturer");
	}
	
	public static String getDuplicateManufacturer()
	{
		return getKey("duplicateManufacturerName");
	}
	
	public static String getMachineUnitToAddDuplicateModel()
	{
		return getKey("selectMachineUnitToAddDuplicateModel");
	}
	
	public static String getManufacturerToAddDuplicateModel()
	{
		return getKey("selectManufacturerToAddDuplicateModel");
	}
	
	public static String getDuplicateModel()
	{
		return getKey("duplicateModelName");
	}
	
	public static String getDuplicateModelCode()
	{
		return getKey("modelCodeForDuplicateModel");
	}
	
	public static String getDuplicateModelImage()
	{
		return getKey("modelImageForDuplicateModel");
	}
	
	public static String getMachineUnitToEditDuplicateModel()
	{
		return getKey("selectMachineUnitToEditDuplicateModel");
	}
	
	public static String getManufacturerToEditDuplicateModel()
	{
		return getKey("selectManufacturerToEditDuplicateModel");
	}
	
	public static String getModelNameToEdit()
	{
		return getKey("modelNameToEditWithDuplicateModel");
	}
	
	public static String getDuplicateModelName()
	{
		return getKey("duplicateModelNameWhileEditing");
	}
	
	public static String getDuplicateModelCodeToEdit()
	{
		return getKey("modelCodeForDuplicateModelWhileEditing");
	}
	
	public static String getDuplicateModelImageToEdit()
	{
		return getKey("modelImageForDuplicateModelWhileEditing");
	}
	
	public static String getMachineUnitToTestNegativeCount()
	{
		return getKey("selectMachineUnitToTestNegativeCountWhileAddingSubsystem");
	}
	
	public static String getManufacturerToTestNegativeCount()
	{
		return getKey("selectManufacturerToTestNegativeCountWhileAddingSubsystem");
	}
	
	public static String getModelNameToTestNegativeCount()
	{
		return getKey("selectModelToTestNegativeCountWhileAddingSubsystem");
	}
	
	public static String getNegativeCount()
	{
		return getKey("negativeCountWhileAddingSubsystem");
	}
	
	public static String getMachineUnitToVerifyDuplicateParameter()
	{
		return getKey("selectMachineUnitToAddDuplicateParameter");
	}
	
	public static String getManufacturerToVerifyDuplicateParameter()
	{
		return getKey("selectManufacturerToAddDuplicateParameter");
	}
	
	public static String getModelNameToVerifyDuplicateParameter()
	{
		return getKey("selectModelToAddDuplicateParameter");
	}
	
	public static String getSubsystemNameToverifyDuplicateParameter()
	{
		return getKey("selectSubsystemToAddDuplicateParameter");
	}
	
	public static String getDPNameToverifyDuplicateParameter()
	{
		return getKey("dpNameToVerifyDuplicate");
	}
	
	public static String getDPValueToverifyDuplicateParameter()
	{
		return getKey("dpValueToVerifyDuplicate");
	}
	
	public static String getDPParameterToVerifyDuplicateParameter()
	{
		return getKey("dpParameterSelectionToVerifyDuplicate");
	}
	
	public static String getDPSystemUnitToVerifyDuplicateParameter()
	{
		return getKey("dpSystemUnitToVerifyDuplicate");
	}
	
	public static String getDPUnitToVerifyDuplicateParameter()
	{
		return getKey("dpUnitToVerifyDuplicate");
	}
	
	public static String getMeasurementNameToVerifyDuplicateParameter()
	{
		return getKey("measurementNameToVerifyDuplicate");
	}
	
	public static String getMeasurementParameterToVerifyDuplicateParameter()
	{
		return getKey("measurementParameterToVerifyDuplicate");
	}
	
	public static String getMeasurementSystemUnitToVerifyDuplicateParameter()
	{
		return getKey("measurementSystemUnitToVerifyDuplicate");
	}
	
	public static String getMeasurementUnitToVerifyDuplicateParameter()
	{
		return getKey("measurementUnitToVerifyDuplicate");
	}
	
	public static String getAlarmNameToVerifyDuplicateParameter()
	{
		return getKey("alarmParameterNameToVerifyDuplicate");
	}
	
	public static String getAlarmParameterToVerifyDuplicateParameter()
	{
		return getKey("alarmParameterToVerifyDuplicate");
	}
	
	public static String getTripNameToVerifyDuplicateParameter()
	{
		return getKey("tripParameterNameToVerifyDuplicate");
	}
	
	public static String getTripParameterToVerifyDuplicateParameter()
	{
		return getKey("tripParameterToVerifyDuplicate");
	}
	
	public static String getFaultNameToVerifyDuplicateParameter()
	{
		return getKey("faultParameterNameToVerifyDuplicate");
	}
	
	public static String getFaultParameterToVerifyDuplicateParameter()
	{
		return getKey("faultParameterToVerifyDuplicate");
	}
	
	public static String getFunctionStatestNameToVerifyDuplicateParameter()
	{
		return getKey("functionstatesParameterNameToVerifyDuplicate");
	}
	
	public static String getFunctionStatesParameterToVerifyDuplicateParameter()
	{
		return getKey("functionstatesParameterNameToVerifyDuplicate");
	}
	
	public static String getCalibrationNameToVerifyDuplicateParameter()
	{
		return getKey("calibrationNameToVerifyDuplicate");
	}
	
	public static String getFCalibrationParameterToVerifyDuplicateParameter()
	{
		return getKey("calibrationParameterToVerifyDuplicate");
	}
	
	public static String getSystemUnitToVerifyDuplicateParameter()
	{
		return getKey("systemUnitToVerifyDuplicate");
	}
	
	public static String getUnitToVerifyDuplicateParameter()
	{
		return getKey("unitToVerifyDuplicate");
	}
	
	public static String getMachineUnitToVerifyDuplicateParameterWhileEditing()
	{
		return getKey("selectMachineUnitToEditDuplicateParameter");
	}
	
	public static String getManufacturerToVerifyDuplicateParameterWhileEditing()
	{
		return getKey("selectManufacturerToEditDuplicateParameter");
	}
	
	public static String getModelToVerifyDuplicateParameterWhileEditing()
	{
		return getKey("selectModelToEditDuplicateParameter");
	}
	
	public static String getSubsystemToVerifyDuplicateParameterWhileEditing()
	{
		return getKey("selectSubsystemToEditDuplicateParameter");
	}
	
	public static String getDPNameToEditToVerifyDuplicateParameterWhileEditing()
	{
		return getKey("designParameterNameToEditToVerifyduplicate");
	}
	
	public static String getUpdatedDPNameToVerifyDuplicateParameterWhileEditing()
	{
		return getKey("updatedDesignParameterNameToVerifyduplicate");
	}
	
	public static String getUpdatedDPValueToVerifyDuplicateParameterWhileEditing()
	{
		return getKey("updatedDesignParameterValueToVerifyDuplicate");
	}
	
	public static String getUpdatedDPUnitTypeToVerifyDuplicateParameterWhileEditing()
	{
		return getKey("updatedDPUnitTypeToVerifyDuplicate");
	}
	
	public static String getUpdatedDPUnitToVerifyDuplicateParameterWhileEditing()
	{
		return getKey("updatedDPUnitToVerifyDuplicate");
	}
	
	public static String getMeasurementParameterToeditToVerifyDuplicate()
	{
		return getKey("measurementParameterNameToEditToVerifyDuplicate");
	}
	
	public static String getMeasurementParameterNameToVerifyDuplicate()
	{
		return getKey("updateMeasurementParameterNameWithDuplicate");
	}
	
	public static String getMeasurementUnitTypeToVerifyDuplicate()
	{
		return getKey("updatedUnitTypeForMeasurementToVerifyDuplicate");
	}
	
	public static String getMeasurementUnitToVerifyDuplicate()
	{
		return getKey("updatedUnitToForMeasurementToVerifyDuplicate");
	}
	
	public static String getMeasurementLCLValueToVerifyDuplicate()
	{
		return getKey("updatedLCLValueForMeasurementToVerifyDuplicate");
	}
	
	public static String getMeasurementUCLValueToVerifyDuplicate()
	{
		return getKey("updatedUCLValueForMeasurementToVerifyDuplicate");
	}
	
	public static String getMeasurementMinRangeToVerifyDuplicate()
	{
		return getKey("updatedMinRangeValueForMeasurementToVerifyDuplicate");
	}
	
	public static String getMeasurementMaxRangeToVerifyDuplicate()
	{
		return getKey("updatedMaxRangeValueForMeasurementToVerifyDuplicate");
	}
	
	public static String getMeasurementPriorityFlagToVerifyDuplicate()
	{
		return getKey("updatedPriorityFlagForMeasurementToVerifyDuplicate(ON/OFF)");
	}
	
	public static String getMeasurementVisibilityFlagToVerifyDuplicate()
	{
		return getKey("updatedVisibilityFlagForMeasurementToVerifyDuplicate(ON/OFF)");
	}
	
	public static String getMeasurementAggregatorForMeasurementToVerifyDuplicate()
	{
		return getKey("updatedAggregatorForMeasurementToVerifyDuplicate");
	}
	
	public static String getAlarmNameToVerifyDuplicate()
	{
		return getKey("alarmParameterNameToEdit");
	}
	
	public static String getUpdatedAlarmParameterToVerifyDuplicate()
	{
		return getKey("updateAlarmParameterToVerifyDuplicate");
	}
	
	public static String getUpdatedAlarmSeverityToVerifyDuplicate()
	{
		return getKey("updateAlarmSeverityToVerifyDuplicate");
	}
	
	public static String getUpdatedAlarmRelatedMeasurementToVerifyDuplicate()
	{
		return getKey("updateRelatedMeasurementForAlarmToVerifyDuplicate");
	}
	
	public static String getUpdatedRecommendationMessageAlarmToVerifyDuplicate()
	{
		return getKey("updateRecommendationMessageForAlarmToVerifyDuplicate");
	}
	
	public static String getTripNameToVerifyDuplicate()
	{
		return getKey("tripParameterToEditToVerifyDuplicate");
	}
	
	public static String getUpdatedTripParameterToVerifyDuplicate()
	{
		return getKey("updateTripParameterToVerifyDuplicate");
	}
	
	public static String getUpdatedTripSeverityToVerifyDuplicate()
	{
		return getKey("updateTripSeverityToVerifyDuplicate");
	}
	
	public static String getUpdatedTripRelatedMeasurementToVerifyDuplicate()
	{
		return getKey("updateTripRelatedMeasurementToVerifyDuplicate");
	}
	
	public static String getUpdatedRecommendationMessageTripToVerifyDuplicate()
	{
		return getKey("updateRecommendationMessageForTripToVerifyDuplicate");
	}
	
	public static String getMachineUnitToVerifyErrorMessage()
	{
		return getKey("selectMachineUnitToVerifyErrorMessageOnClickingMoreOptionWithoutSelectingParameter");
	}
	
	public static String getManufacturerToVerifyErrorMessage()
	{
		return getKey("selectManufacturerToVerifyErrorMessageOnClickingMoreOptionWithoutSelectingParameter");
	}
	
	public static String getModelToVerifyErrorMessage()
	{
		return getKey("selectModelToVerifyErrorMessageOnClickingMoreOptionWithoutSelectingParameter");
	}
	
	public static String getSubsystemToVerifyErrorMessage()
	{
		return getKey("selectSubsystemToVerifyErrorMessageOnClickingMoreOptionWithoutSelectingParameter");
	}
	
	public static String getMachineUnitToEditUnitForParameter()
	{
		return getKey("selectMachineUnitToEditUnitForTheParameters");
	}
	
	public static String getManufacturerToEditUnitForParameter()
	{
		return getKey("selectManufacturerToEditUnitForTheParameters");
	}
	
	public static String getModelToEditUnitForParameter()
	{
		return getKey("selectModelToEditUnitForTheParameters");
	}
	
	public static String getSubsystemToEditUnitForParameter()
	{
		return getKey("selectSubsystemToEditUnitForTheParameters");
	}
	
	public static String getDesignParameterToEditDPUnit()
	{
		return getKey("designParameterToEditTheUnit");
	}
	
	public static String getUnitToEdit()
	{
		return getKey("unitToEdit");
	}
	
	public static String getAdditiveFactorforDPUnit()
	{
		return getKey("updateAdditiveValueForDPUnit");
	}
	
	public static String getSubtractiveFactorforDPUnit()
	{
		return getKey("updateSubtractiveValueForDPUnit");
	}
	
	public static String getMultipicativeFactorforDPUnit()
	{
		return getKey("updateMultiplicativeValueForDPUnit");
	}
	
	public static String getDivisionFactorforDPUnit()
	{
		return getKey("updateDivisionValueForDPUnit");
	}
	
	public static String getMeasurementParameterToEditMeasurementUnit()
	{
		return getKey("measurementParameterToEditTheUnit");
	}
	
	public static String getUnitToEditForMeasurementParameter()
	{
		return getKey("unitToEditForMeasurementParameter");
	}
	
	public static String getAdditiveFactorforMeasurementUnit()
	{
		return getKey("updateAdditiveValueForMeasurementUnit");
	}
	
	public static String getSubtractiveFactorforMeasurementUnit()
	{
		return getKey("updateSubtractiveValueForMeasurementUnit");
	}
	
	public static String getMultipicativeFactorforMeasurementUnit()
	{
		return getKey("updateMultiplicativeValueForMeasurementUnit");
	}
	
	public static String getDivisionFactorforMeasurementUnit()
	{
		return getKey("updateDivisionValueForMeasurementUnit");
	}
	
	public static String getCalibrationParameterToEditMeasurementUnit()
	{
		return getKey("calibrationParameterToEditTheUnit");
	}
	
	public static String getUnitToEditForCalibrationParameter()
	{
		return getKey("unitToEditForCalibrationParameter");
	}
	
	public static String getAdditiveFactorforCalibrationUnit()
	{
		return getKey("updateAdditiveValueForCalibrationUnit");
	}
	
	public static String getSubtractiveFactorforCalibrationUnit()
	{
		return getKey("updateSubtractiveValueForCalibrationUnit");
	}
	
	public static String getMultipicativeFactorforCalibrationUnit()
	{
		return getKey("updateMultiplicativeValueForCalibrationUnit");
	}
	
	public static String getDivisionFactorforCalibrationUnit()
	{
		return getKey("updateDivisionValueForCalibrationUnit");
	}
	
	public static String getMachineUnitToVerifyErrorMessageWhileUploadingFile()
	{
		return getKey("selectMachineUnitToVerifyErrorMessageWhileUploadingFile");
	}
	
	public static String getManufacturerToVerifyErrorMessageWhileUploadingFile()
	{
		return getKey("selectManufacturerToVerifyErrorMessageWhileUploadingFile");
	}
	
	public static String getModelNameToVerifyErrorMessageWhileUploadingFile()
	{
		return getKey("modelNameToVerifyErrorMessageWhileUploadingFile");
	}
	
	public static String getModelCodeToVerifyErrorMessageWhileUploadingFile()
	{
		return getKey("modelCodeToVerifyErrorMessageWhileUploadingFile");
	}
	
	public static String getFilePathToVerifyErrorMessageWhileUploadingFile()
	{
		return getKey("filePathToVerifyErrorMessageWhileUploadingFile");
	}
	
	public static String getMachineUnitToUpdateVisibilityAndPriorityFlag()
	{
		return getKey("selectMachineUnitToUpdateVisibilityAndPriorityFlag");
	}
	
	public static String getManufacturerToUpdateVisibilityAndPriorityFlag()
	{
		return getKey("selectManufacturerToUpdateVisibilityAndPriorityFlag");
	}
	
	public static String getModelNameToUpdateVisibilityAndPriorityFlag()
	{
		return getKey("selectModelToUpdateVisibilityAndPriorityFlag");
	}
	
	public static String getSubsystemToUpdateVisibilityAndPriorityFlag()
	{
		return getKey("selectSubsystemToUpdateVisibilityAndPriorityFlag");
	}
	
	public static String getMeasurementParameterToUpdateVisibilityAndPriorityFlag()
	{
		return getKey("measurementParameterToUpdateVisibilityAndPriority");
	}
	
	public static String getVisibilityFlagToUpdateVisibilityAndPriorityFlag()
	{
		return getKey("updateVisibilityFlag(ON/OFF)");
	}
	
	public static String getPriorityFlagToUpdateVisibilityAndPriorityFlag()
	{
		return getKey("updatePriorityFlag(ON/OFF)");
	}
	
	public static String getMachineUnitToUpdateParameterWithBlank()
	{
		return getKey("selectMachineUnitToUpdateTheParameterWithBlank");
	}
	
	public static String getManufacturerToUpdateParameterWithBlank()
	{
		return getKey("selectManufacturerToUpdateTheParameterWithBlank");
	}
	
	public static String getModelNameToUpdateParameterWithBlank()
	{
		return getKey("selectModelToUpdateTheParameterWithBlank");
	}
	
	public static String getSubsystemToUpdateParameterWithBlank()
	{
		return getKey("selectSubsystemToUpdateTheParameterWithBlank");
	}
	
	public static String getDPToUpdateParameterWithBlank()
	{
		return getKey("designParameterToUpdateWithBlank");
	}
	
	public static String getMeasurementToUpdateParameterWithBlank()
	{
		return getKey("measurementParameterToUpdateWithBlank");
	}
	
	public static String getAlarmToUpdateParameterWithBlank()
	{
		return getKey("alarmParameterToUpdateWithBlank");
	}
	
	public static String getTripToUpdateParameterWithBlank()
	{
		return getKey("tripParameterToUpdateWithBlank");
	}
	
	public static String getFaultToUpdateParameterWithBlank()
	{
		return getKey("faultParameterToUpdateWithBlank");
	}
	
	public static String getFunctionStatesToUpdateParameterWithBlank()
	{
		return getKey("functionStatesParameterToUpdateWithBlank");
	}
	
	public static String getCalibrationToUpdateParameterWithBlank()
	{
		return getKey("calibrationParameterToUpdateWithBlank");
	}
	
	public static String getMachineUnitToVerifySearchField()
	{
		return getKey("selectMachineUnitToVerifySearchFieldForParameter");
	}
	
	public static String getManufacturerToVerifySearchField()
	{
		return getKey("selectManufacturerToVerifySearchFieldForParameter");
	}
	
	public static String getModelNameToVerifySearchField()
	{
		return getKey("selectModelToVerifySearchFieldForParameter");
	}
	
	public static String getSubsystemToVerifySearchField()
	{
		return getKey("selectSubsystemToVerifySearchFieldForParameter");
	}
	
	public static String getValidInputToVerifySearchFieldForDP()
	{
		return getKey("validInputForDesignParameterToVerifySearchField");
	}
	
	public static String getInValidInputToVerifySearchFieldForDP()
	{
		return getKey("inValidInputForDesignParameterToVerifySearchField");
	}
	
	public static String getValidInputToVerifySearchFieldForMeasurement()
	{
		return getKey("validInputForMeasurementParameterToVerifySearchField");
	}
	
	public static String getinValidInputToVerifySearchFieldForMeasurement()
	{
		return getKey("inValidInputForMeasurementParameterToVerifySearchField");
	}
	
	public static String getValidInputToVerifySearchFieldForAlarm()
	{
		return getKey("validInputForAlarmParameterToVerifySearchField");
	}
	
	public static String getinValidInputToVerifySearchFieldForAlarm()
	{
		return getKey("inValidInputForAlarmParameterToVerifySearchField");
	}
	
	public static String getValidInputToVerifySearchFieldForTrip()
	{
		return getKey("validInputForTripParameterToVerifySearchField");
	}
	
	public static String getinValidInputToVerifySearchFieldForTrip()
	{
		return getKey("inValidInputForTripParameterToVerifySearchField");
	}
	
	public static String getValidInputToVerifySearchFieldForFault()
	{
		return getKey("validInputForFaultParameterToVerifySearchField");
	}
	
	public static String getinValidInputToVerifySearchFieldForFault()
	{
		return getKey("inValidInputForFaultParameterToVerifySearchField");
	}
	
	public static String getValidInputToVerifySearchFieldForFunctionStates()
	{
		return getKey("validInputForFunctionStatesParameterToVerifySearchField");
	}
	
	public static String getinValidInputToVerifySearchFieldForFunctionStates()
	{
		return getKey("inValidInputForFunctionStatesParameterToVerifySearchField");
	}
	
	public static String getValidInputToVerifySearchFieldForCalibration()
	{
		return getKey("validInputForCalibrationParameterToVerifySearchField");
	}
	
	public static String getinValidInputToVerifySearchFieldForCalibration()
	{
		return getKey("inValidInputForCalibrationParameterToVerifySearchField");
	}
	
	public static String getCalibrationNameToEditToVerifyDuplicate()
	{
		return getKey("calibrationParameterNameToEditToVerifyDuplicate");
	}
	
	public static String getUpdatedCalibrationParameterToEditToVerifyDuplicate()
	{
		return getKey("updateCalibrationParameterToVerifyDuplicate");
	}
	
	public static String getFunctionStatesNameToEditToVerifyDuplicate()
	{
		return getKey("functionStatesParameterNameToEditToVerifyDuplicate");
	}
	
	public static String getUpdatedFunctionStatesParameterToEditToVerifyDuplicate()
	{
		return getKey("updatefunctionStatesParameterToVerifyDuplicate");
	}
}