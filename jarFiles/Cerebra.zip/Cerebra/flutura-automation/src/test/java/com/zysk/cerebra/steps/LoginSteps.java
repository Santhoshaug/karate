package com.zysk.cerebra.steps;

import static org.assertj.core.api.Assertions.assertThat;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.zysk.cerebra.csv_reader.CSVHelper;
import com.zysk.cerebra.pages.LoginPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import net.thucydides.core.steps.ScenarioSteps;

public class LoginSteps extends ScenarioSteps {
	
	/******************************Page Objects**************************/
    LoginPage loginPage;
 
    /********************************************************************
	* Description: Visit Cerebra Application
	* Status: Completed
	********************************************************************/
	@Given("^I am on the Cerebra website$")
	public void givenIAmOnTheCerebraWebsite()
	{
        loginPage.open();
		
	}
	
	/********************************************************************
	* Description: Verify Login Page of Cerebra
	* Status: Completed
	********************************************************************/
	@Then("^I am on the Login Page$")
	public void thenIAmOnTheLoginPage() 
	{
		assertThat(loginPage.verifyLoginPage()).isTrue();
	}
	
	/********************************************************************
	* Description: Enter valid credentials and Login to the application
	* Status: Completed
	********************************************************************/
	@When("^I enter valid Email and Password on the login page$")
	public void whenIEnterValidEmailAndPasswordOnTheLoginPage()
	{
		loginPage.enterValidCredentials();
	}
	
	/********************************************************************
	* Description: Verify Homepage after Login
	* Status: Completed
	********************************************************************/
	@Then("^I am on the home page$")
	public void thenIAmOnTheHomePage()
	{
		assertThat(loginPage.verifyHomePage()).isTrue();
		assertThat(loginPage.veirfyAssetMonitorElements()).isTrue();
	}
	
	/************************************************************************
	* Description: Enter invalid credentials and try Login to the application
	* Status: Completed
	*************************************************************************/
	@When("^I enter invalid Email and Password on the login page$")
	public void whenIEnterInvalidEmailAndPasswordOnTheLoginpage() 
	{
		loginPage.enterInvalidCredentials();
	}
	
	/**********************************************************************
	* Description: Verify error message after entering invalid credentials
	* Status: Completed
	***********************************************************************/
	@Then("^I can see error message displayed$")
	public void thenICanSeeErrorMessageDisplayed() 
	{
	    assertThat(loginPage.verifyErrorMessage()).isTrue();
	}
}
