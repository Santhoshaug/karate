package com.zysk.cerebra.steps;

import static org.junit.Assert.assertTrue;

import com.zysk.cerebra.csv_reader.CSVHelper;
import com.zysk.cerebra.csv_reader.UserGroupCSVReader;
import com.zysk.cerebra.pages.UserGroupPage;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class UserGroupSteps {

	UserGroupPage usergroupPage;
	
	/********************************************************************
	* Description: Click on customer link
	* Status: Completed
	********************************************************************/
	@And("^I click on UserGroup link$")
	public void whenIClickOnUserLink()
	{
		usergroupPage.clickUserGroupLink();
		
	}
	
	/********************************************************************
	* Description: Customer list will be visible
	* Status: Completed
	********************************************************************/
	@Then("^I can see Customers Tab with Customers List$")
	public void thenICanSeeTheListOfCustomers()
	{
		assertTrue("Not clicked on Usergroup Link",usergroupPage.verifyUserPage());
	}
	
	/********************************************************************
	* Description: Verify search field by entering valid data 
	* Status: Completed
	********************************************************************/
	@When("^I enter valid data in Customer search text field$")
	public void whenIEnterValidDataInSearchTextField()
	{
		
		String DataToSearch = UserGroupCSVReader.getValidCustomerName();
		usergroupPage.verifySearchField(DataToSearch);
	}
	
	/********************************************************************
	* Description: On entering valid data list of customer will be displayed based on added input 
	* Status: Completed
	********************************************************************/
	@Then("^I can see list of customer related to searched data$")
	public void thenICanSeeListOfCustomerBasedOnEnteredData()
	{
		String CustomerName = UserGroupCSVReader.getValidCustomerName();
		assertTrue("Customer Not present/Search is not working",usergroupPage.verifySearchFieldForValidInputs(CustomerName));
	}
	
	/********************************************************************
	* Description: Verify search field by entering invalid data 
	* Status: Completed
	********************************************************************/
	@When("^I enter invalid data in Customer search text field$")
	public void IEnterInvalidDataInSearchTextField()
	{
		String DataToSearch = UserGroupCSVReader.getInValidCustomerName();
		usergroupPage.verifySearchField(DataToSearch);
	}
	
	/********************************************************************
	* Description: On entering invalid data no data will be displayed
	* Status: Completed
	********************************************************************/
	@Then("^I should not can see list of customer related to searched data$")
	public void thenNoDataDisplayed ()
	{
		String CustomerName = UserGroupCSVReader.getInValidCustomerName();
		assertTrue("Search bar not working",usergroupPage.verifySearchFieldForInValidInputs(CustomerName));
	}
	
	/*****************************************************************************
	* Description: On clicking on customer, customer details should be displayed
	* Status: Completed
	******************************************************************************/
	@When("^I click On UserGroup Customer$")
	public void ClickOnUserGroupCustomer()
	{
		String customerName = UserGroupCSVReader.getCustomerNameTOSelectAndVerify();
		usergroupPage.selectCustomer(customerName );
	}
	
	/*****************************************************************************
	* Description: On clicking on customer, customer details should be displayed
	* Status: Completed
	******************************************************************************/
	@Then("^I can see the User group customer details$")
	public void ThenICanSeeTheCustomerDetails()
	{
		String CustomerName = UserGroupCSVReader.getCustomerNameTOSelectAndVerify();
		usergroupPage.verifyGroupTab(CustomerName );
	}
	

	/*****************************************************************************
	* Description: Add new user group and verify
	* Status: Completed
	******************************************************************************/
	@And("^I click on Add New button in Groups tab$")
	    public void i_click_on_add_new_button_in_groups_tab(){
	    usergroupPage.clickOnNewButtonToAddGroup();
    }
	

	/*****************************************************************************
	* Description:
	* Status: Completed
	******************************************************************************/
	@And("^I add User group Name$")
	public void i_add_user_group_name(){
		String UserGroupName = UserGroupCSVReader.getUserGroupName();
		usergroupPage.addUserGroup(UserGroupName );
	}
	
	/*****************************************************************************
	* Description:
	* Status: Completed
	******************************************************************************/
	@Then("^I can see newly added user group$")
    public void i_can_see_newly_added_user_group(){
		String UserGroupName = UserGroupCSVReader.getUserGroupName();
	    usergroupPage.verifyNewUserGroupAdded(UserGroupName);
    }

	/*****************************************************************************
	* Description:
	* Status: Completed
	******************************************************************************/
    @And("^I Search for the user group with valid name$")
    public void i_search_for_the_user_group_with_valid_name(){
		String DataToSearch = UserGroupCSVReader.getValidUserGroupName();
		usergroupPage.verifySearchFieldOfUserGroup(DataToSearch);
    }

	/*****************************************************************************
	* Description:
	* Status: Completed
	******************************************************************************/
	@Then("^I see user group name$")
	    public void i_see_user_group_name(){
		assertTrue("User Group search not working for valid input",usergroupPage.verifyUserGroupSearchForValidInput());
    }

	/*****************************************************************************
	* Description:
	* Status: Completed
	******************************************************************************/
	@And("^I Search for the user group with Invalid name$")
    public void i_search_for_the_user_group_with_invalid_name(){
		String DataToSearch = UserGroupCSVReader.getInValidUserGroupName();
		usergroupPage.verifySearchFieldOfUserGroup(DataToSearch);
    }

	/*****************************************************************************
	* Description:
	* Status: Completed
	******************************************************************************/
    @Then("^I will not see user group name$")
    public void i_will_not_see_user_group_name(){
    	assertTrue("User Group search not working for Invalid input",usergroupPage.verifyUserGroupSearchForInValidInput()); 
    }

	/*****************************************************************************
	* Description:
	* Status: Completed
	******************************************************************************/
	@And("^I Search for the user with valid name$")
    public void i_search_for_the_user_with_valid_name(){
	    String DataToSearch = UserGroupCSVReader.getValidUserName();
		usergroupPage.verifySearchFieldOfUserName(DataToSearch);
	}
	
	/*****************************************************************************
	* Description:
	* Status: Completed
	******************************************************************************/
    @Then("^I see user name$")
	    public void i_see_user_name(){
		 assertTrue("User Name search not working for valid input",usergroupPage.verifyUserNameSearchForValidInput());   
    }

	/*****************************************************************************
	* Description:
	* Status: Completed
	******************************************************************************/
    @And("^I Search for the user with Invalid name$")
    public void i_search_for_the_user_with_invalid_name(){
		String DataToSearch = UserGroupCSVReader.getInValidUserName();
	    usergroupPage.verifySearchFieldOfUserName(DataToSearch);   
    }

	/*****************************************************************************
	* Description:
	* Status: Completed
	******************************************************************************/
    @Then("^I will not see user name$")
	    public void i_will_not_see_user_name(){
	    assertTrue("User Name search not working for Invalid input",usergroupPage.verifyUserNameSearchForInValidInput());    
	}
    
    /*****************************************************************************
	* Description:
	* Status: Completed
	******************************************************************************/
    @And("^I select the UserGroup$")
    public void i_select_the_usergroup(){	
	    String UserGroup = UserGroupCSVReader.getUserGroupName();
		usergroupPage.selectUserGroup(UserGroup );
    }
	/*****************************************************************************
	* Description:
	* Status: Completed
	******************************************************************************/
    @And("^I click on Add User button in Group tab$")
	    public void i_click_on_add_user_button_in_group_tab(){
	    usergroupPage.clickOnAddUserButton();
    }
	  
	/*****************************************************************************
	* Description:
	* Status: Completed
	******************************************************************************/
    @And("^I select and add the user to user group$")
    public void i_select_and_add_the_user_to_user_group(){
	    String UserName =UserGroupCSVReader.getUserNameToAddUserGroup();
	    usergroupPage.selectAndAddTheUserToUserGroup(UserName);
    }

	/*****************************************************************************
	* Description:
	* Status: Completed
	******************************************************************************/
    @Then("^I can see user added to group$")
    public void i_can_see_user_added_to_group(){
		 String UserName = UserGroupCSVReader.getUserNameToAddUserGroup();
		 assertTrue("User not added to User Group",usergroupPage.verifyUserAddedToUserGroup(UserName));
    }
	
	/*****************************************************************************
	* Description:
	* Status: Completed
	******************************************************************************/
    @And("^I click on DashboardLink$")
	    public void i_click_on_dashboardlink() {
	    usergroupPage.clickOnDashboardLink();
    }
    
    /*****************************************************************************
	* Description:
	* Status: Completed
	******************************************************************************/
    @Then("^I see newly added UserGroup in AccessControl AccessLevel$")
    public void i_see_newly_added_usergroup_in_accesscontrol_accesslevel() {
	    String UserGroupName =UserGroupCSVReader.getUserGroupName();
		assertTrue("Newly added usergroup not showing in access control,access level tab",usergroupPage.verifyUserGroupInAccessLevel(UserGroupName ));
    }

	/*****************************************************************************
	* Description:
	* Status: Completed
	******************************************************************************/
    @And("^I select User to verify group assigned$")
    public void i_select_user_to_verify_group_assigned() {
	    String UserName = UserGroupCSVReader.getUserNameToVerifyGroupAssigned();
		usergroupPage.selectUserToVerifyGroupAssigned(UserName );
    }
    
    /*****************************************************************************
	* Description:
	* Status: Completed
	******************************************************************************/
    @Then("^I see userGroup assined to User in user details page$")
    public void i_see_usergroup_assined_to_user_in_user_details_page() {
    	String UserName = UserGroupCSVReader.getUserNameToVerifyGroupAssigned();
    	assertTrue("Assigned group not showing as assigned in User details page",usergroupPage.verifyUserGroupShowingAsAssignedInUserDetailsPage(UserName));
    }
	/*****************************************************************************
	* Description:
	* Status: Completed
	******************************************************************************/
    @And("^I Disable the Usergroup$")
    public void i_disable_the_usergroup(){
	    String GroupNameToDisable = UserGroupCSVReader.getUserGroupName();
		usergroupPage.disableUserGroup(GroupNameToDisable );
    }
	

	/*****************************************************************************
	* Description:
	* Status: Completed
	******************************************************************************/
    @Then("^I can see Usergroup disabled$")
    public void i_can_see_usergroup_disabled(){
		String GroupName = UserGroupCSVReader.getUserGroupName();
		assertTrue("UserGroup not disabled",usergroupPage.VerifyUserGroupDisabled(GroupName));
    }

	/*****************************************************************************
	* Description:
	* Status: Completed
	******************************************************************************/
    @And("^I Enable the Usergroup$")
    public void i_enable_the_usergroup(){
		String GroupNameToEnable = UserGroupCSVReader.getUserGroupName();
		usergroupPage.enableUserGroup(GroupNameToEnable);
    }
	    
    /*****************************************************************************
	* Description:
	* Status: Completed
	******************************************************************************/
    @Then("^I can see Usergroup enabled$")
    public void i_can_see_usergroup_enabled(){
		String GroupName = UserGroupCSVReader.getUserGroupName();
		assertTrue("UserGroup not Enabled",usergroupPage.VerifyUserGroupEnabled(GroupName));
    }
    
    /*****************************************************************************
	* Description:
	* Status: Completed
	******************************************************************************/
    @And("^I Delete the Usergroup$")
    public void i_delete_the_usergroup(){
	    String DeleteUserGroup = UserGroupCSVReader.getUserGroupNameToDelete();
		usergroupPage.DeleteUserGroup(DeleteUserGroup );  
    }    
    /*****************************************************************************
	* Description:
	* Status: Completed
	******************************************************************************/   
    @Then("^I can see Usergroup deleted$")
    public void i_can_see_usergroup_deleted(){
        String UserGroupToDelete = UserGroupCSVReader.getUserGroupNameToDelete();
		assertTrue("UserGroup Not Deleted",usergroupPage.verifyDeleteUserGroup(UserGroupToDelete ));
    }
	    
    /*****************************************************************************
	* Description:
	* Status: Completed
	******************************************************************************/
    @And("^I Select the User in Group tab$")
    public void i_select_the_user_in_group_tab() {
    	String UserName = UserGroupCSVReader.getSelectUserName();
		usergroupPage.selectUserToRemoveFromGroup(UserName );
    }    
	        
    /*****************************************************************************
	* Description:
	* Status: Completed
	******************************************************************************/
    @And("^I remove the User from the group$")
    public void i_remove_the_user_from_the_group() {
    	String UserName = UserGroupCSVReader.getSelectUserName();
        usergroupPage.removeUserGroup(UserName);
    }
    
    /*****************************************************************************
	* Description:
	* Status: Completed
	******************************************************************************/
    @Then("^I can see user is removed from Usergroup$")
    public void i_can_see_user_is_removed_from_usergroup() {
    	String UserName = UserGroupCSVReader.getSelectUserName();
        assertTrue("User not removed from group",usergroupPage.verifyUserNameRemovedFromGroup(UserName));
    }  
    
    /*****************************************************************************
	* Description:
	* Status: Completed
	******************************************************************************/
    @And("^I add duplicate UserGroup Name$")
    public void i_add_duplicate_usergroup_name() {
    	String DuplicateUserGroupName = UserGroupCSVReader.getUserGroupName();
        usergroupPage.addDuplicateUserGroup(DuplicateUserGroupName);
    }
    
    /*****************************************************************************
	* Description:
	* Status: Completed
	******************************************************************************/

    @Then("^I can see duplicate User group not added$")
    public void i_can_see_duplicate_user_group_not_added() {
       assertTrue("Duplicate UserGroup added",usergroupPage.verifyDuplicateUserGroupname());
    }
    
    /*****************************************************************************
   	* Description:
   	* Status: Completed
   	******************************************************************************/
    @And("^I add data to User group Name text field and click on Cancel button$")
    public void i_add_data_to_user_group_name_text_field_and_click_on_cancel_button() {
       String UserGroupNameToVerifyCancel = UserGroupCSVReader.getUserGroupNameToVerifyCancel();
       usergroupPage.AddUserNameAndClickOnCancel(UserGroupNameToVerifyCancel );
    }
    
    /*****************************************************************************
   	* Description:
   	* Status: Completed
   	******************************************************************************/
    @Then("^I can see no user group added$")
    public void i_can_see_no_user_group_added() {
       String UserGroupNameToVerifyCancel = UserGroupCSVReader.getUserGroupNameToVerifyCancel();
       assertTrue("UserGroup cancel button not working as expected",usergroupPage.VerifyUserGroupCancelButton(UserGroupNameToVerifyCancel));
    }
    
    /*****************************************************************************
   	* Description:
   	* Status: Completed
   	******************************************************************************/
    @And("^I add Invalid data User group Name text field$")
    public void i_add_invalid_data_user_group_name_text_field() {
        String InvalidData = UserGroupCSVReader.getInvalidDataToUserGroupTextField();
		usergroupPage.addInvalidDataInAddUserGroupTextField(InvalidData);
    }
    /*****************************************************************************
   	* Description:
   	* Status: Completed
   	******************************************************************************/
    @Then("^I can see error message for User group Name text field$")
    public void i_can_see_error_message_for_user_group_name_text_field() {
       assertTrue("Error message is not showing for invalid data",usergroupPage.verifyErrorMessageForUserGroupTextField());
    }
    /*****************************************************************************
   	* Description:
   	* Status: Completed
   	******************************************************************************/
    @Then("^I can see UserGroup not showing as assigned in user details page on remove user or delete of user group$")
    public void i_can_see_usergroup_not_showing_as_assigned_in_user_details_page_on_remove_user_or_delete_of_user_group() {
    	String UserGroupName = UserGroupCSVReader.getUserGroupName();
		assertTrue("User group showing as assigned after on remove of user or delete of user group",usergroupPage.verifyUserGroupNotShowingAssignOnRemoveUserAndDeleteUserGroup(UserGroupName));
    }

    /*****************************************************************************
   	* Description:
   	* Status: Completed
   	******************************************************************************/
    @Then("^I can see UserGroup not showing in Accesslevel on disable of group or delete of user group$")
    public void i_can_see_usergroup_not_showing_in_accesslevel_on_disable_of_group_or_delete_of_user_group() {
    	String UserGroupName = UserGroupCSVReader.getUserGroupName();
		assertTrue("User group is showing in access level tab on disable of group or delete of user group",usergroupPage.verifyUserGroupNotShowInAccessLevelOnDisableAndDeleteOfUserGroup(UserGroupName));
    }
    
    /*****************************************************************************
   	* Description:
   	* Status: Completed
   	******************************************************************************/
    @And("^I select the UserGroup to delete$")
    public void i_select_the_usergroup_to_delete(){
    	String UserGroup = UserGroupCSVReader.getUserGroupNameToDelete();
		usergroupPage.selectUserGroup(UserGroup);
    }
    
}
