package com.zysk.cerebra.steps;

import static org.assertj.core.api.Assertions.assertThat;

import com.zysk.cerebra.csv_reader.CSVHelper;
import com.zysk.cerebra.pages.ConfigurationPage;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import net.thucydides.core.steps.ScenarioSteps;

@SuppressWarnings("serial")
public class ConfigurationSteps extends ScenarioSteps {

	/******************************Page Objects**************************/
	
	ConfigurationPage configuration;
	
	/********************************************************************
	* Description: Visit Configuration of Cerebra Application
	* Status: Completed
	********************************************************************/
	@And("^I select configuration in end app$")
	public void andISelectConfigurationInEndApp()
	{
		configuration.selectConfiguration();
	}
	
	/********************************************************************
	* Description: Verify Configuration Dashboard
	* Status: Completed
	********************************************************************/
	@Then("^I can see Configuration Dashboard$")
	public void thenICanSeeConfigurationDashboard()
	{
		assertThat(configuration.verifyConfigurationPage()).isTrue();
	}
	
	/********************************************************************
	* Description: Go to Configuration Dashboard by passing the Configuration Dashboard URL in the browser
	* Status: Completed
	********************************************************************/
	@And("^I go to Configuration Dashboard$")
	 public void goToConfigurationDashboard() {
		String dashboardURL = CSVHelper.getBaseUrl()+ CSVHelper.getCDUrl();
		configuration.configurationDashboard(dashboardURL );
		 
	 }
	
}
