package com.zysk.cerebra.steps;

import net.thucydides.core.steps.ScenarioSteps;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.awt.AWTException;
import java.lang.reflect.InvocationTargetException;

import com.zysk.cerebra.csv_reader.CSVHelper;
import com.zysk.cerebra.csv_reader.EquipmentStructureCSVReader;
import com.zysk.cerebra.pages.EquipmentStructurePage;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EquipmentStructureSteps extends ScenarioSteps {
	EquipmentStructurePage equipmentStructurePage;
	
	/********************************************************************
	* Description: Click on Equipment Structure link
	* Status: Completed
	********************************************************************/
	@When("^I select Equipment structure$")
	public void whenISelectEquipmentStructure()
	{
		equipmentStructurePage.clickEquipmentStructure();
	}
	
	/********************************************************************
	* Description: verify Equipment Structure page
	* Status: Completed
	********************************************************************/
	@Then("^I verify Equipment structure page is displaying$")
    public void i_verify_equipment_structure_page_is_displaying()  {
		String url = CSVHelper.getBaseUrl()+EquipmentStructureCSVReader.getEquipmentStructureUrl();
		assertTrue("Equipment structure page is not displayed with all details",equipmentStructurePage.verifyEquipmentStructure(url));
    }
	
	/********************************************************************
	* Description: Click on ADD NEW Button
	* Status: Completed
	********************************************************************/
	 @And("^I Click on Add New Button$")
	    public void i_click_on_add_new_button()  {
	       equipmentStructurePage.clickOnAddNewButton();
	    }
	/********************************************************************
	* Description: I click on Add categories and add the category
	* Status: Completed
	********************************************************************/
	 @And("^I click on Add categories and add the category$")
	    public void i_click_on_add_categories_and_add_the_category() {
		 String categoryName = EquipmentStructureCSVReader.getCategoryName();
		 equipmentStructurePage.addCategory(categoryName);
	    }
	 
	 /********************************************************************
		* Description: 
		* Status: Completed
		********************************************************************/
	 @Then("^I verify the category in the categories list and in the category dropdown$")
	    public void i_verify_the_category_in_the_categories_list_and_in_the_category_dropdown() {
		 String categoryName = EquipmentStructureCSVReader.getCategoryName();
			assertTrue("Categories not added in the list",equipmentStructurePage.verifyCategoriesAdded(categoryName));
			assertTrue("Categories not shown in the dropdown",equipmentStructurePage.verifyCategoryInTheDropdown(categoryName));
	    }

	 /********************************************************************
		* Description: 
		* Status: Completed
		********************************************************************/

	    @And("^I edit the Existing category with New category$")
	    public void i_edit_the_existing_category_with_new_category() {
	    	String existingCategoryName = EquipmentStructureCSVReader.getCategoryName();
			String updateCategoryName = EquipmentStructureCSVReader.getCategoryNameToEditAndUpdate();
			equipmentStructurePage.editCategory(existingCategoryName, updateCategoryName);
	    }

	    /********************************************************************
		* Description: 
		* Status: Completed
		********************************************************************/
	    @Then("^I verify the edited category in the categories list and in the category dropdown$")
	    public void i_verify_the_edited_category_in_the_categories_list_and_in_the_category_dropdown() {
	    	String updateCategoryName = EquipmentStructureCSVReader.getCategoryNameToEditAndUpdate();
			assertTrue("Category Not added Successfully",equipmentStructurePage.verifyCategoriesAdded(updateCategoryName));
			assertTrue("Category not displaying in category dropdown",equipmentStructurePage.verifyCategoryInTheDropdown(updateCategoryName));
	    }
	    
	    /********************************************************************
		* Description: 
		* Status: Completed
		********************************************************************/
	    @And("^I disable the category$")
	    public void i_disable_the_category() {
	    	String categoryName = EquipmentStructureCSVReader.getCategoryNameToEditAndUpdate();
			equipmentStructurePage.disableCategories(categoryName);
	    }

	    /********************************************************************
		* Description: 
		* Status: Completed
		********************************************************************/
	    @Then("^I verify the Category in the list gets disabled and it should not display in the dropdown$")
	    public void i_verify_the_category_in_the_list_gets_disabled_and_it_should_not_display_in_the_dropdown() {
	    	String categoryName = EquipmentStructureCSVReader.getCategoryNameToEditAndUpdate();
			assertTrue("Category is displayed in the dropdown",equipmentStructurePage.verifyDisabledCategoryInList(categoryName));
	    }
	    
	    /********************************************************************
		* Description: 
		* Status: Completed
		********************************************************************/
	    @And("^I enable the category$")
	    public void i_enable_the_category() {
	    	equipmentStructurePage.enableCategory();
	    }

	    /********************************************************************
		* Description: 
		* Status: Completed
		********************************************************************/
	    @Then("^I verify Category in the list gets enabled and it should display in the dropdown$")
	    public void i_verify_the_category_in_the_list_gets_enabled_and_it_should_display_in_the_dropdown() {
	    	String categoryName = EquipmentStructureCSVReader.getCategoryNameToEditAndUpdate();
	    	assertTrue("Category not Enabled",equipmentStructurePage.verifyCategoryEnabled(categoryName));      
	    }
	    
	    /********************************************************************
		* Description: 
		* Status: Completed
		********************************************************************/
	    @And("^I delete category$")
	    public void i_delete_category() {
	    	String categoryUpdatedName = EquipmentStructureCSVReader.getCategoryNameToEditAndUpdate();
	    	String categoryName = EquipmentStructureCSVReader.getCategoryName();
			equipmentStructurePage.deleteCategory(categoryUpdatedName,categoryName);
	    }

	    /********************************************************************
		* Description: Category will get removed from the list and from the category dropdown
	    	* Status: Completed
		********************************************************************/
	    @Then("^I verify the category getting deleted$")
	    public void i_verify_the_category_getting_deleted() {
	    		String categoryName = EquipmentStructureCSVReader.getCategoryNameToEditAndUpdate();
	    		assertFalse("Deleted category is displayed in the dropdown",equipmentStructurePage.verifyDeletedCategory(categoryName));
	    		assertFalse("Deleted category is shown in the list",equipmentStructurePage.verifyDeletedCategoryInList());	
	    }
	    
	    /********************************************************************
		* Description: Enter all the details and create machine unit
		* Status: Completed
		********************************************************************/
		@When("^I add new machine unit with all details like name, description, category, assettype$")
		public void whenIAddNewMachineUnitWithAllDetailsLikeNameDescriptionCategoryAssettype()
		{
			
			String machineName = EquipmentStructureCSVReader.getMachineUnitName();
			String machineDescription = EquipmentStructureCSVReader.getMachineUnitDescription();
			String machineCategory = EquipmentStructureCSVReader.getCategoryNameToEditAndUpdate();
			String assetType = EquipmentStructureCSVReader.getMachineUnitAssetType();
			String pathOfImage = EquipmentStructureCSVReader.gePathOfImageForMachineUnit();
			equipmentStructurePage.addMachineUnit(machineName, machineCategory, machineDescription, assetType, pathOfImage);
		}
		
		/********************************************************************
		* Description: 
		* Status: Completed
		********************************************************************/
		 @Then("^I can see machine/equipment added successful message$")
		    public void i_can_see_machineequipment_added_successful_message(){
				String MachineUnitName = EquipmentStructureCSVReader.getMachineUnitName();
			 equipmentStructurePage.verifyEquipmentORMachineUnitadded(MachineUnitName);
		    }
		/********************************************************************
		* Description: 
		* Status: Completed
		********************************************************************/
		@When("^I select Configuration Dashboard$")
		public void whenISelectConfigurationDashboard()
		{
			equipmentStructurePage.selectConfigurationDashboard();
		}

	    /********************************************************************
		* Description: Select machine unit tab
		* Status: Completed
		********************************************************************/
	    @And("^I select the Machine Unit$")
	    public void andISelectTheMachineUnit()
	    {
	    	String MachineUnit = EquipmentStructureCSVReader.getMachineUnitName();
			equipmentStructurePage.SelectAndClickOnMachineUnit(MachineUnit );
	    }

		/********************************************************************
		* Description: Edit the machine unit in the list
		* Status: Completed
		********************************************************************/
		@When("^I edit the machine unit name$")
		public void whenIEditTheMachineUnitName()
		{
//			String EquipmentORMachineUnit = EquipmentStructureCSVReader.getMachineUnitName();
			String existingMachineUnit = EquipmentStructureCSVReader.getMachineUnitName();
			String updateMachineUnit = EquipmentStructureCSVReader.getEditAndUpdatedMachineUnitName();
//			equipmentStructurePage.searchOREquipmentORMachineUnit(EquipmentORMachineUnit);
			equipmentStructurePage.editMachineUnit(existingMachineUnit, updateMachineUnit);
			
		}
		
		/********************************************************************
		* Description: Machine unit name will get updated
		* Status: Completed
		********************************************************************/
		@Then("^I can see machine unit gets updated$")
		public void thenICanSeeMachineUnitGetsUpdated()
		{
			String editmachineunit = EquipmentStructureCSVReader.getEditAndUpdatedMachineUnitName();
			assertTrue("Machine unit is not edited",equipmentStructurePage.verifyEditedMachineUnit(editmachineunit));
		}
	
		/********************************************************************
		* Description: Disable the machine unit
		* Status: Completed
		********************************************************************/
	    @And("^I disable the machine unit$")
	    public void whenIDisableTheMachineUnitInTheList()
	    {
	    	String EquipmentORMachineUnit = EquipmentStructureCSVReader.getEditAndUpdatedMachineUnitName();
	    	String machineUnit = EquipmentStructureCSVReader.getEditAndUpdatedMachineUnitName();
	    	equipmentStructurePage.searchOREquipmentORMachineUnit(EquipmentORMachineUnit);
	    	equipmentStructurePage.disableMachineUnitInList(machineUnit);
	    }
	    
	    /********************************************************************
		* Description: Machine unit disabled
		* Status: Completed
		********************************************************************/
	    @Then("^I verify Machine unit disabled$")
	    public void iVerifyMachineUnitDisabled()
	    {
	    	String machineUnit = EquipmentStructureCSVReader.getEditAndUpdatedMachineUnitName();
	    	assertTrue("Machine Unit is not Disabled",equipmentStructurePage.verifyMachineUnitDisabled(machineUnit));
	    }
	    
	    /********************************************************************
		* Description: Enable the machine unit
		* Status: Completed
		********************************************************************/
	    @And("^I enable the machine unit$")
	    public void iEnableTheMachineUnit()
	    {
	    	String machineUnit = EquipmentStructureCSVReader.getEditAndUpdatedMachineUnitName();
	    	equipmentStructurePage.enableMachineUnit(machineUnit);
	    }
	    
	    /********************************************************************
		* Description: Machine unit enabled
		* Status: Completed
		********************************************************************/
	    @Then("^I Verify Machine unit enabled$")
	    public void thenIVerifyMachineUnitEnabled()
	    {
	    	String machineUnit = EquipmentStructureCSVReader.getEditAndUpdatedMachineUnitName();
	    	assertTrue("Machine Unit is not enabled",equipmentStructurePage.verifyMachineUnitEnabled(machineUnit));
	    }
	    
	    /********************************************************************
		* Description: Machine unit enabled
		* Status: Completed
		********************************************************************/
	    @And("^I Delete the Machine Unit$")
	    public void i_delete_the_machine_unit() {
	       String UpdatedMachineUNitName = EquipmentStructureCSVReader.getEditAndUpdatedMachineUnitName();
		String MachineUNitName = EquipmentStructureCSVReader.getMachineUnitName();
		equipmentStructurePage.deleteMachineUnit(UpdatedMachineUNitName,MachineUNitName  );
	    }
	    
	    /********************************************************************
		* Description: Machine unit enabled
		* Status: Completed
		********************************************************************/
	    @Then("^I verify Machine Unit Deleted$")
	    public void i_verify_machine_unit_deleted() {
	        String MachineUNitName = EquipmentStructureCSVReader.getEditAndUpdatedMachineUnitName();
			equipmentStructurePage.verifyMachineUnitDeleted(MachineUNitName );	    
	        }
	    /********************************************************************
		* Description: Machine unit enabled
		* Status: Completed
		********************************************************************/
	    @And("^I select the Updated Machine Unit$")
	    public void i_select_the_updated_machine_unit() {
	    	String MachineUnit = EquipmentStructureCSVReader.getEditAndUpdatedMachineUnitName();
			equipmentStructurePage.SelectAndClickOnMachineUnit(MachineUnit );
	    }
	    

	    /********************************************************************
		* Description: Disable the machine unit
		* Status: Completed
		********************************************************************/
	    @And("^I disable the machine unit in subsystem page$")
	    public void iDisableTheMachineUnitInSubsystemPage()
	    {
	    	String MachineUnitName = EquipmentStructureCSVReader.getEditAndUpdatedMachineUnitName();
			equipmentStructurePage.disableMachineUnitInSubsystem(MachineUnitName);
	    }
	    
	    /********************************************************************
		* Description: Machine unit disabled
		* Status: Completed
		********************************************************************/
	    @Then("^I verify the machine unit gets disabled in subsystem page$")
	    public void thenIVerifyMachineUnitDisabledInSubsystemPage()
	    {
	    	String MachineUnitName = EquipmentStructureCSVReader.getEditAndUpdatedMachineUnitName();
	    	assertTrue("Machine Unit not disabled in Subsytem",equipmentStructurePage.verifyMachineUnitDisabledInSubsystem(MachineUnitName));

	    }
	    
	    /********************************************************************
		* Description: Enable the machine unit
		* Status: Completed
		********************************************************************/
	    @And("^I enable the machine unit in subsystem page$")
	    public void iEnableTheMachineUnitInSubsystemPage()
	    {
	    	String MachineUnitName = EquipmentStructureCSVReader.getEditAndUpdatedMachineUnitName();
	    	equipmentStructurePage.EnableMachineUnitInSubsystem(MachineUnitName);
	    }
	    
	    /********************************************************************
		* Description: Machine unit disabled
		* Status: Completed
		********************************************************************/
	    @Then("^I verify machine unit gets enabled in subsystem page$")
	    public void thenIVerifyMachineUnitEnabledInSubsytemPage()
	    {
	    	String MachineUnitName = EquipmentStructureCSVReader.getEditAndUpdatedMachineUnitName();
	    	assertTrue("Machine unit is not enabled",equipmentStructurePage.verifyEnabledMachineUnitInSubunit(MachineUnitName));
	    }
		
	    /********************************************************************
		* Description: 
		* Status: Completed
		********************************************************************/
	    @And ("^I delete the machine unit in Subsytem level$")
	    public void iDeleteTheMachineUnitInSubsystemlevel() {
	    	String MachineUnitInsubsystemToDelete = EquipmentStructureCSVReader.getEditAndUpdatedMachineUnitName();
	    	equipmentStructurePage.deleteMachineUnitInSubsystem(MachineUnitInsubsystemToDelete);
	    }
	    
	    /********************************************************************
		* Description: Machine unit disabled
		* Status: Completed
		********************************************************************/
	     @Then("^I verify machine unit deleted in subsystem level$")
	    	 public void iVerifyMacineUintDeleted() {
	    	 String DeletedMachineUnitName = EquipmentStructureCSVReader.getEditAndUpdatedMachineUnitName();
	    	 equipmentStructurePage.verifyMachineUnitDeletedInSubsystemLevel(DeletedMachineUnitName);
	     }
	     
	     /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
	     @And("^I Add the Machine unit by click on plus icon in Subsystem level$")
	     public void i_add_the_machine_unit_by_click_on_plus_icon_in_subsystem_level(){
	    	 equipmentStructurePage.addMachineUnitInSubsystemLevel();
	     }
	     
	     /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
	     @Then("^I verify machine unit addeded in Subsystem level$")
	     public void i_verify_machine_unit_addeded_in_subsystem_level()  {
	       assertTrue("SubsystemNotAdded",equipmentStructurePage.verifyMachineUnitInSubstemAdded());
	     }
	     
	     /********************************************************************
			* Description:
			* Status: Completed
	     * @throws InterruptedException 
			********************************************************************/
	     @And("^I Drag and Drop the machine unit Subsystem level$")
	     public void drag_and_drop_the_machine_unit_subsystem_level() throws InterruptedException  {
	    	 String MachineUnitName = EquipmentStructureCSVReader.getEditAndUpdatedMachineUnitName();
	    	    	equipmentStructurePage.dragAndDropSubsystem(MachineUnitName);
	     }
	     
      /********************************************************************
   			* Description:
   			* Status: Completed
   			********************************************************************/
	      @And("^I go to Configuration Page$")
	      public void i_go_to_configuration_page() {
    	  equipmentStructurePage.clickEquipmentStructure();
      	 String MachineUnit = EquipmentStructureCSVReader.getEditAndUpdatedMachineUnitName();
      	 equipmentStructurePage.SelectAndClickOnMachineUnit(MachineUnit );
      }

	     /********************************************************************
			* Description:
			* Status: Completed
			********************************************************************/
      		@Then("^I verify Machine Unit added Subsystem level by drag and drop$")
      		public void i_verify_machine_unit_added_subsystem_level_by_drap_and_drop()  {
	        
      		}

      		 /********************************************************************
			* Description:
			* Status: Completed
			********************************************************************/
      		 @And("^I Select Machine unit in Subsystem$")
      	    public void i_select_machine_unit_in_subsystem()  {
      			String EquipmaentName = EquipmentStructureCSVReader.getEditAndUpdatedMachineUnitName();
      			equipmentStructurePage.addMachineUnitInSubsystem(EquipmaentName);
      	    }

      	      /********************************************************************
     		* Description: 
     		* Status: Completed
     		********************************************************************/

           @And("^I add parameter unit$")
           public void i_add_parameter_unit()  {
         	  String tabname = CSVHelper.getDesignParameterTab();
         	  String ParameterName = EquipmentStructureCSVReader.getDesignParameterUnit();
         	  equipmentStructurePage.addParametrUnit(tabname,ParameterName);
           }
           
           /********************************************************************
     		* Description: 
     		* Status: Completed
     		********************************************************************/
           
           @Then("^I verify parameter unit added$")
           public void i_verify_parameter_unit_added()  {
             String ParameterUnit = EquipmentStructureCSVReader.getDesignParameterUnit();
              assertTrue("Parameter Not added successfully",equipmentStructurePage.verifyParameterUnitAdded(ParameterUnit));
           }
           
           /********************************************************************
     		* Description: 
     		* Status: Completed
     		********************************************************************/
           @And("^I edit parameter unit$")
           public void i_edit_parameter_unit()  {
         	  String ParameterName = EquipmentStructureCSVReader.getDesignParameterUnit();
         	   String editParameter =EquipmentStructureCSVReader.getUpdatedDesignParameterUnit() ;
     		equipmentStructurePage.editParametrUnit(ParameterName,editParameter );
           }
           
           /********************************************************************
     		* Description: 
     		* Status: Completed
     		********************************************************************/
           @Then("^I verify parameter unit edited$")
           public void i_verify_parameter_unit_edited()  {
               String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
               assertTrue("Parameter Not Edited successfully", equipmentStructurePage.verifyParameterUnitEdited(editParameter));
           }
           
           /********************************************************************
     		* Description: 
     		* Status: Completed
     		********************************************************************/
           @And("^I disable parameter unit$")
           public void i_disable_parameter_unit()  {
             String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
     		equipmentStructurePage.disableParameterUnit(editParameter);
           }

           /********************************************************************
         		* Description: 
         		* Status: Completed
         		********************************************************************/
           @Then("^I verify parameter unit disabled$")
           public void i_verify_parameter_unit_disabled()  {
             String editParameter =EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
     		assertTrue("Parameter Unit not disabled",equipmentStructurePage.verifyParameterUnitDisabled(editParameter));
           }
           /********************************************************************
     		* Description: 
     		* Status: Completed
     		********************************************************************/
           @And("^I enable paramer unit$")
           public void i_enable_paramer_unit()  {
             String editParameter =EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
     		equipmentStructurePage.enableParameterUnit(editParameter);
           }

           /********************************************************************
         		* Description: 
         		* Status: Completed
         		********************************************************************/
           @Then("^I verify parameter unit enabled$")
           public void i_verify_parameter_unit_enabled()  {
         	  String editParameter =EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
       		assertTrue("Parameter Unit not Enabled",equipmentStructurePage.verifyParameterUnitEnabled(editParameter));
           }
           
           /********************************************************************
    		* Description: 
    		* Status: Completed
    		********************************************************************/
           @And("^I click on Add new button then menu icon to delete Parameters on Configuration$")
           public void i_click_on_add_new_button_then_menu_icon_to_delete_parameters_on_configuration() {
        	   String tabname = CSVHelper.getDesignParameterTab();
        	   equipmentStructurePage.ClickOnAddNewAndMenuButton(tabname);
              
           }

           /********************************************************************
     		* Description: 
     		* Status: Completed
     		********************************************************************/
           @And("^I delete Parameter unit$")
           public void i_delete_parameter_unit() {
         	  String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
         	  String ParameterUnit = EquipmentStructureCSVReader.getDesignParameterUnit();
     		equipmentStructurePage.deleteParameterUnit(editParameter,ParameterUnit);
           }
           
           /********************************************************************
     		* Description: 
     		* Status: Completed
     		********************************************************************/
           @And("^verify parameter unit deleted$")
           public void verify_parameter_unit_deleted() {
         	  String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
         	  String ParameterUnit = EquipmentStructureCSVReader.getDesignParameterUnit();
         	  equipmentStructurePage.verifyParameterUnitDeleted(editParameter,ParameterUnit);
         	  
           }
      		 
      		 
	    /********************************************************************
		* Description: 
		* Status: Completed
		********************************************************************/
	     @And("^I Add design parameter$")
	     public void i_add_design_parameter()  {
	    	 
	    	String tabName = CSVHelper.getDesignParameterTab();
	     	String name = EquipmentStructureCSVReader.getDesignParameterName();
	     	String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
	     	equipmentStructurePage.addDesignParameter(tabName,name,editParameter);
	     }
	     /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @Then("^I Verify design parameter type added$")
         public void i_verify_design_parameter_type_added()  {
        	 String Parametername = EquipmentStructureCSVReader.getDesignParameterName();
            equipmentStructurePage.verifyDesignParameterAdded(Parametername);
         }
         
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
	      @And("^I Edit design parameter$")
	      public void i_edit_design_parameter()  {
	      	String addedParameter = EquipmentStructureCSVReader.getDesignParameterName();
	      	String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
	      	equipmentStructurePage.editDesignParameter(addedParameter,editParameter);
	      }
	      
      /********************************************************************
		* Description: 
		* Status: Completed
		********************************************************************/
	       @Then("^I Verify design parameter Edited$")
	       public void i_verify_design_parameter_edited()  {
	      	 String EditedParametername = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
	           equipmentStructurePage.verifyDesignParameterEdited(EditedParametername);
          
       }
	      /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
	       @And("^I Disable or Enable design parameter type$")
	       public void i_disable_design_parameter_type()  {
	    	 String editparameter  = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
	    	   equipmentStructurePage.disableOREnableParameter(editparameter);
	       }
	       
	       /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
        @Then("^I Verify design parameter Enabled$")
        public void i_verify_design_parameter_enabled()  {
        	String parameter  = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
        	assertTrue("Parameter not Enabled",equipmentStructurePage.verifyEnabledParameter(parameter));
        }
        /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
        @Then("^I Verify deign parameter Disabled$")
        public void i_verify_deign_parameter_disabled()  {
        	String parameter  = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
        	assertTrue("parameter not disabled",equipmentStructurePage.verifyDisabledParameter(parameter));
        }
       
	       /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
	        @And("^I Delete design parameter type$")
	        public void i_delete_design_parameter_type()  {
	         String Parametername = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
			equipmentStructurePage.deleteParameter(Parametername);
	        }
         
        /********************************************************************
		* Description: 
		* Status: Completed
		********************************************************************/
        @Then("^I Verify design parameter Deleted$")
        public void i_verify_design_parameter_deleted()  {
           String Parametername = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
		equipmentStructurePage.verifyDesignParameterDeleted(Parametername );
        }
       
      /********************************************************************
		* Description: 
		* Status: Completed
		********************************************************************/

      @And("^I add measurement parameter unit$")
      public void i_add_measurement_parameter_unit()  {
    	  String tabname = CSVHelper.getMeasurementTab();
    	  String ParameterName = EquipmentStructureCSVReader.getDesignParameterUnit();
    	  equipmentStructurePage.addParametrUnit(tabname,ParameterName);
      }
      
      /********************************************************************
		* Description: 
		* Status: Completed
		********************************************************************/
      
      @Then("^I verify measurement parameter unit added$")
      public void i_verify_measurement_parameter_unit_added()  {
        String ParameterUnit = EquipmentStructureCSVReader.getDesignParameterUnit();
         assertTrue("Parameter Not added successfully",equipmentStructurePage.verifyParameterUnitAdded(ParameterUnit));
      }
      
      /********************************************************************
		* Description: 
		* Status: Completed
		********************************************************************/
      @And("^I edit measurement parameter unit$")
      public void i_edit_measurement_parameter_unit()  {
    	  String ParameterName = EquipmentStructureCSVReader.getDesignParameterUnit();
    	   String editParameter =EquipmentStructureCSVReader.getUpdatedDesignParameterUnit() ;
		equipmentStructurePage.editParametrUnit(ParameterName,editParameter );
      }
      
      /********************************************************************
		* Description: 
		* Status: Completed
		********************************************************************/
      @Then("^I verify measurement parameter unit edited$")
      public void i_verify_measurement_parameter_unit_edited()  {
          String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
          assertTrue("Parameter Not Edited successfully", equipmentStructurePage.verifyParameterUnitEdited(editParameter));
      }
      
      /********************************************************************
		* Description: 
		* Status: Completed
		********************************************************************/
      @And("^I disable measurement parameter unit$")
      public void i_disable_measurement_parameter_unit()  {
        String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
		equipmentStructurePage.disableParameterUnit(editParameter);
      }

      /********************************************************************
    		* Description: 
    		* Status: Completed
    		********************************************************************/
      @Then("^I verify measurement parameter unit disabled$")
      public void i_verify_measurement_parameter_unit_disabled()  {
        String editParameter =EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
		assertTrue("Parameter Unit not disabled",equipmentStructurePage.verifyParameterUnitDisabled(editParameter));
      }
      /********************************************************************
		* Description: 
		* Status: Completed
		********************************************************************/
      @And("^I enable measurement paramer unit$")
      public void i_enable_measurement_paramer_unit()  {
        String editParameter =EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
		equipmentStructurePage.enableParameterUnit(editParameter);
      }

      /********************************************************************
    		* Description: 
    		* Status: Completed
    		********************************************************************/
      @Then("^I verify measurement parameter unit enabled$")
      public void i_verify_measurement_parameter_unit_enabled()  {
    	  String editParameter =EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
  		assertTrue("Parameter Unit not Enabled",equipmentStructurePage.verifyParameterUnitEnabled(editParameter));
      }
      
      /********************************************************************
		* Description: 
		* Status: Completed
		********************************************************************/
     @And("^I click on Add new button then menu icon to delete measurement Parameters on Configuration$")
     public void i_click_on_add_new_button_then_menu_icon_to_delete_measurement_parameters_on_configuration()  {
  	   String tabname = CSVHelper.getMeasurementTab();
  	   equipmentStructurePage.ClickOnAddNewAndMenuButton(tabname);
     }
     
      /********************************************************************
		* Description: 
		* Status: Completed
		********************************************************************/
      @And("^I delete measurement Parameter unit$")
      public void i_delete_measurement_parameter_unit() {
    	  String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
    	  String ParameterUnit = EquipmentStructureCSVReader.getDesignParameterUnit();
		equipmentStructurePage.deleteParameterUnit(editParameter,ParameterUnit);
      }
      
      /********************************************************************
		* Description: 
		* Status: Completed
		********************************************************************/
      @And("^verify measurement parameter unit deleted$")
      public void verify_measurement_parameter_unit_deleted() {
    	  String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
    	  String ParameterUnit = EquipmentStructureCSVReader.getDesignParameterUnit();
    	  equipmentStructurePage.verifyParameterUnitDeleted(editParameter,ParameterUnit);
    	  
      }
       
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @And("^I Add Measurement Parameter$")
         public void i_add_measurement_parameter()  {
        	 
	    	String tabName = CSVHelper.getMeasurementTab();
	     	String name = EquipmentStructureCSVReader.getDesignParameterName();
	     	String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
	     	equipmentStructurePage.addDesignParameter(tabName,name,editParameter);
	     	
        	 
         }
         
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
		      @Then("^I Verify Measurement Parameter added$")
		      public void i_verify_measurement_parameter_added()  {
		    	  String Parametername = EquipmentStructureCSVReader.getDesignParameterName();
		            equipmentStructurePage.verifyDesignParameterAdded(Parametername);    
		      }
      
	      /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
		   @And("^I Edit Measurement Parameter$")
		   public void i_edit_measurement_parameter()  {
		      	String addedParameter = EquipmentStructureCSVReader.getDesignParameterName();
		      	String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
		      	equipmentStructurePage.editDesignParameter(addedParameter,editParameter);

		   }

         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @Then("^I Verify Measurement Parameter Edited$")
         public void i_verify_measurement_parameter_edited()  {
        	 String EditedParametername = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
	           equipmentStructurePage.verifyDesignParameterEdited(EditedParametername); 
         }

         
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/

         @And("^I Disable or Enable Measurement Parameter$")
         public void i_disable_or_enable_measurement_parameter()  {
        	 String editparameter  = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
	    	   equipmentStructurePage.disableOREnableParameter(editparameter);
         }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         
         @Then("^I Verify Measurement Parameter Enabled$")
         public void i_verify_measurement_parameter_enabled()  {
        	 String parameter  = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
         	assertTrue("Parameter not Enabled",equipmentStructurePage.verifyEnabledParameter(parameter));
        	 }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @Then("^I Verify Measurement Parameter disabled$")
         public void i_verify_measurement_parameter_disabled() {
        	 String parameter  = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
         	assertTrue("parameter not disabled",equipmentStructurePage.verifyDisabledParameter(parameter));
         }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @And("^I Delete Measurement Parameter$")
         public void i_delete_measurement_parameter()  {
        	 String Parametername = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
 			equipmentStructurePage.deleteParameter(Parametername);
         }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @Then("^Verify Measurement Parameter deleted$")
         public void verify_measurement_parameter_deleted()  {
        	 String Parametername = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
     		equipmentStructurePage.verifyDesignParameterDeleted(Parametername );
         }

         /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/

       @And("^I add alarms parameter unit$")
       public void i_add_alarms_parameter_unit()  {
     	  String tabname = CSVHelper.getAlarmTab();
     	  String ParameterName = EquipmentStructureCSVReader.getDesignParameterUnit();
     	  equipmentStructurePage.addParametrUnit(tabname,ParameterName);
       }
       
       /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/
       
       @Then("^I verify alarms parameter unit added$")
       public void i_verify_alarms_parameter_unit_added()  {
         String ParameterUnit = EquipmentStructureCSVReader.getDesignParameterUnit();
          assertTrue("Parameter Not added successfully",equipmentStructurePage.verifyParameterUnitAdded(ParameterUnit));
       }
       
       /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/
       @And("^I edit alarms parameter unit$")
       public void i_edit_alarms_parameter_unit()  {
     	  String ParameterName = EquipmentStructureCSVReader.getDesignParameterUnit();
     	   String editParameter =EquipmentStructureCSVReader.getUpdatedDesignParameterUnit() ;
 		equipmentStructurePage.editParametrUnit(ParameterName,editParameter );
       }
       
       /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/
       @Then("^I verify alarms parameter unit edited$")
       public void i_verify_alarms_parameter_unit_edited()  {
           String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
           assertTrue("Parameter Not Edited successfully", equipmentStructurePage.verifyParameterUnitEdited(editParameter));
       }
       
       /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/
       @And("^I disable alarms parameter unit$")
       public void i_disable_alarms_parameter_unit()  {
         String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
 		equipmentStructurePage.disableParameterUnit(editParameter);
       }

       /********************************************************************
     		* Description: 
     		* Status: Completed
     		********************************************************************/
       @Then("^I verify alarms parameter unit disabled$")
       public void i_verify_alarms_parameter_unit_disabled()  {
         String editParameter =EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
 		assertTrue("Parameter Unit not disabled",equipmentStructurePage.verifyParameterUnitDisabled(editParameter));
       }
       /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/
       @And("^I enable alarms paramer unit$")
       public void i_enable_alarms_paramer_unit()  {
         String editParameter =EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
 		equipmentStructurePage.enableParameterUnit(editParameter);
       }

       /********************************************************************
     		* Description: 
     		* Status: Completed
     		********************************************************************/
       @Then("^I verify alarms parameter unit enabled$")
       public void i_verify_alarms_parameter_unit_enabled()  {
     	  String editParameter =EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
   		assertTrue("Parameter Unit not Enabled",equipmentStructurePage.verifyParameterUnitEnabled(editParameter));
       }
       /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/
       @And("^I delete alarms Parameter unit$")
       public void i_delete_alarms_parameter_unit() {
     	  String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
     	  String ParameterUnit = EquipmentStructureCSVReader.getDesignParameterUnit();
 		equipmentStructurePage.deleteParameterUnit(editParameter,ParameterUnit);
       }
       
       /********************************************************************
		* Description: 
		* Status: Completed
		********************************************************************/
      @And("^I click on Add new button then menu icon to delete alarms Parameters on Configuration$")
      public void i_click_on_add_new_button_then_menu_icon_to_delete_alarms_parameters_on_configuration()  {
   	   String tabname = CSVHelper.getAlarmTab();
   	   equipmentStructurePage.ClickOnAddNewAndMenuButton(tabname);
      }
       
       /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/
       @And("^verify alarms parameter unit deleted$")
       public void verify_alarms_parameter_unit_deleted() {
     	  String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
     	  String ParameterUnit = EquipmentStructureCSVReader.getDesignParameterUnit();
     	  equipmentStructurePage.verifyParameterUnitDeleted(editParameter,ParameterUnit);
     	  
       }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @And("^I Add Alarms Parameter$")
         public void i_add_alarms_parameter()  {
        	 String tabName = CSVHelper.getAlarmTab();
 	     	String name = EquipmentStructureCSVReader.getDesignParameterName();
 	     	String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
 	     	equipmentStructurePage.addDesignParameter(tabName,name,editParameter);
         }

         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @Then("^I Verify Alarms Parameter added$")
         public void i_verify_alarms_parameter_added()  {
        	 String Parametername = EquipmentStructureCSVReader.getDesignParameterName();
             equipmentStructurePage.verifyDesignParameterAdded(Parametername);
         }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @And("^I Edit Alarms Parameter$")
         public void i_edit_alarms_parameter()  {
 	      	String addedParameter = EquipmentStructureCSVReader.getDesignParameterName();
 	      	String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
 	      	equipmentStructurePage.editDesignParameter(addedParameter,editParameter);

         }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @Then("^I Verify Alarms Parameter Edited$")
         public void i_verify_alarms_parameter_edited()  {
        	 String EditedParametername = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
	           equipmentStructurePage.verifyDesignParameterEdited(EditedParametername);
         }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @And("^I Disable or Enable Alarms Parameter$")
         public void i_disable_or_enable_alarms_parameter()  {
        	 String editparameter  = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
	    	   equipmentStructurePage.disableOREnableParameter(editparameter);
         }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @Then("^I Verify Alarms Parameter Enabled$")
         public void i_verify_alarms_parameter_enabled()  {
        	 String parameter  = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
         	assertTrue("Parameter not Enabled",equipmentStructurePage.verifyEnabledParameter(parameter));
         }
         
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @Then("^I Verify Alarms Parameter disabled$")
         public void i_verify_alarms_parameter_disabled()  {
        	 String parameter  = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
         	assertTrue("parameter not disabled",equipmentStructurePage.verifyDisabledParameter(parameter));
         }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @And("^I Delete Alarms Parameter$")
         public void i_delete_alarms_parameter()  {
        	 String Parametername = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
 			equipmentStructurePage.deleteParameter(Parametername);
         }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @Then("^I Verify Alarms Parameter deleted$")
         public void i_verify_alarms_parameter_deleted()  {
        	 String Parametername = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
     		equipmentStructurePage.verifyDesignParameterDeleted(Parametername ); 
         }
         
         /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/

       @And("^I add trips parameter unit$")
       public void i_add_trips_parameter_unit()  {
     	  String tabname = CSVHelper.getTripTab();
     	  String ParameterName = EquipmentStructureCSVReader.getDesignParameterUnit();
     	  equipmentStructurePage.addParametrUnit(tabname,ParameterName);
       }
       
       /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/
       
       @Then("^I verify trips parameter unit added$")
       public void i_verify_trips_parameter_unit_added()  {
         String ParameterUnit = EquipmentStructureCSVReader.getDesignParameterUnit();
          assertTrue("Parameter Not added successfully",equipmentStructurePage.verifyParameterUnitAdded(ParameterUnit));
       }
       
       /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/
       @And("^I edit trips parameter unit$")
       public void i_edit_trips_parameter_unit()  {
     	  String ParameterName = EquipmentStructureCSVReader.getDesignParameterUnit();
     	   String editParameter =EquipmentStructureCSVReader.getUpdatedDesignParameterUnit() ;
 		equipmentStructurePage.editParametrUnit(ParameterName,editParameter );
       }
       
       /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/
       @Then("^I verify trips parameter unit edited$")
       public void i_verify_trips_parameter_unit_edited()  {
           String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
           assertTrue("Parameter Not Edited successfully", equipmentStructurePage.verifyParameterUnitEdited(editParameter));
       }
       
       /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/
       @And("^I disable trips parameter unit$")
       public void i_disable_trips_parameter_unit()  {
         String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
 		equipmentStructurePage.disableParameterUnit(editParameter);
       }

       /********************************************************************
     		* Description: 
     		* Status: Completed
     		********************************************************************/
       @Then("^I verify trips parameter unit disabled$")
       public void i_verify_trips_parameter_unit_disabled()  {
         String editParameter =EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
 		assertTrue("Parameter Unit not disabled",equipmentStructurePage.verifyParameterUnitDisabled(editParameter));
       }
       /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/
       @And("^I enable trips paramer unit$")
       public void i_enable_trips_paramer_unit()  {
         String editParameter =EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
 		equipmentStructurePage.enableParameterUnit(editParameter);
       }

       /********************************************************************
     		* Description: 
     		* Status: Completed
     		********************************************************************/
       @Then("^I verify trips parameter unit enabled$")
       public void i_verify_trips_parameter_unit_enabled()  {
     	  String editParameter =EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
   		assertTrue("Parameter Unit not Enabled",equipmentStructurePage.verifyParameterUnitEnabled(editParameter));
       }
       
       /********************************************************************
		* Description: 
		* Status: Completed
		********************************************************************/
      @And("^I click on Add new button then menu icon to delete Trips Parameters on Configuration$")
      public void i_click_on_add_new_button_then_menu_icon_to_delete_Trips_parameters_on_configuration()  {
   	   String tabname = CSVHelper.getTripTab();
   	   equipmentStructurePage.ClickOnAddNewAndMenuButton(tabname);
      } 
      
       /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/
       @And("^I delete trips Parameter unit$")
       public void i_delete_trips_parameter_unit() {
     	  String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
     	  String ParameterUnit = EquipmentStructureCSVReader.getDesignParameterUnit();
 		equipmentStructurePage.deleteParameterUnit(editParameter,ParameterUnit);
       }
       
       /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/
       @And("^verify trips parameter unit deleted$")
       public void verify_trips_parameter_unit_deleted() {
     	  String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
     	  String ParameterUnit = EquipmentStructureCSVReader.getDesignParameterUnit();
     	  equipmentStructurePage.verifyParameterUnitDeleted(editParameter,ParameterUnit);
     	  
       }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @And("^I Add Trips Parameter$")
         public void i_add_trips_parameter()  {
        	 String tabName = CSVHelper.getTripTab();
 	     	String name = EquipmentStructureCSVReader.getDesignParameterName();
 	     	String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
 	     	equipmentStructurePage.addDesignParameter(tabName,name,editParameter);
           
         }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @Then("^I Verify Trips Parameter added$")
         public void i_verify_trips_parameter_added()  {
        	 String Parametername = EquipmentStructureCSVReader.getDesignParameterName();
             equipmentStructurePage.verifyDesignParameterAdded(Parametername);

         }

         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @And("^I Edit Trips Parameter$")
         public void i_edit_trips_parameter()  {
 	      	String addedParameter = EquipmentStructureCSVReader.getDesignParameterName();
 	      	String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
 	      	equipmentStructurePage.editDesignParameter(addedParameter,editParameter); 
         }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @Then("^I Verify Trips Parameter Edited$")
         public void i_verify_trips_parameter_edited()  {
        	 String EditedParametername = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
	           equipmentStructurePage.verifyDesignParameterEdited(EditedParametername);

         }

         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @And("^I Disable or Enable Trips Parameter$")
         public void i_disable_or_enable_trips_parameter()  {
        	 String editparameter  = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
	    	   equipmentStructurePage.disableOREnableParameter(editparameter);
         }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @Then("^I Verify Trips Parameter Enabled$")
         public void i_verify_trips_parameter_enabled()  {
        	 String parameter  = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
         	assertTrue("Parameter not Enabled",equipmentStructurePage.verifyEnabledParameter(parameter));
         }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/

         @Then("^I Verify Trips Parameter disabled$")
         public void i_verify_trips_parameter_disabled()  {
        	 String parameter  = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
         	assertTrue("parameter not disabled",equipmentStructurePage.verifyDisabledParameter(parameter));
         }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @And("^I Delete Trips Parameter$")
         public void i_delete_trips_parameter()  {
        	 String Parametername = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
 			equipmentStructurePage.deleteParameter(Parametername);
         }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @Then("^I Verify Trips Parameter deleted$")
         public void i_verify_trips_parameter_deleted()  {
        	 String Parametername = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
     		equipmentStructurePage.verifyDesignParameterDeleted(Parametername );
         }
         
         
         /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/

       @And("^I add faults parameter unit$")
       public void i_add_faults_parameter_unit()  {
     	  String tabname = CSVHelper.getFaultsTab();
     	  String ParameterName = EquipmentStructureCSVReader.getDesignParameterUnit();
     	  equipmentStructurePage.addParametrUnit(tabname,ParameterName);
       }
       
       /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/
       
       @Then("^I verify faults parameter unit added$")
       public void i_verify_faults_parameter_unit_added()  {
         String ParameterUnit = EquipmentStructureCSVReader.getDesignParameterUnit();
          assertTrue("Parameter Not added successfully",equipmentStructurePage.verifyParameterUnitAdded(ParameterUnit));
       }
       
       /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/
       @And("^I edit faults parameter unit$")
       public void i_edit_faults_parameter_unit()  {
     	  String ParameterName = EquipmentStructureCSVReader.getDesignParameterUnit();
     	   String editParameter =EquipmentStructureCSVReader.getUpdatedDesignParameterUnit() ;
 		equipmentStructurePage.editParametrUnit(ParameterName,editParameter );
       }
       
       /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/
       @Then("^I verify faults parameter unit edited$")
       public void i_verify_faults_parameter_unit_edited()  {
           String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
           assertTrue("Parameter Not Edited successfully", equipmentStructurePage.verifyParameterUnitEdited(editParameter));
       }
       
       /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/
       @And("^I disable faults parameter unit$")
       public void i_disable_faults_parameter_unit()  {
         String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
 		equipmentStructurePage.disableParameterUnit(editParameter);
       }

       /********************************************************************
     		* Description: 
     		* Status: Completed
     		********************************************************************/
       @Then("^I verify faults parameter unit disabled$")
       public void i_verify_faults_parameter_unit_disabled()  {
         String editParameter =EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
 		assertTrue("Parameter Unit not disabled",equipmentStructurePage.verifyParameterUnitDisabled(editParameter));
       }
       /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/
       @And("^I enable faults paramer unit$")
       public void i_enable_faults_paramer_unit()  {
         String editParameter =EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
 		equipmentStructurePage.enableParameterUnit(editParameter);
       }

       /********************************************************************
     		* Description: 
     		* Status: Completed
     		********************************************************************/
       @Then("^I verify faults parameter unit enabled$")
       public void i_verify_faults_parameter_unit_enabled()  {
     	  String editParameter =EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
   		assertTrue("Parameter Unit not Enabled",equipmentStructurePage.verifyParameterUnitEnabled(editParameter));
       }
       
       /********************************************************************
		* Description: 
		* Status: Completed
		********************************************************************/
      @And("^I click on Add new button then menu icon to delete faults Parameters on Configuration$")
      public void i_click_on_add_new_button_then_menu_icon_to_delete_faults_parameters_on_configuration()  {
   	   String tabname = CSVHelper.getFaultsTab();
   	   equipmentStructurePage.ClickOnAddNewAndMenuButton(tabname);
      }
      
       /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/
       @And("^I delete faults Parameter unit$")
       public void i_delete_faults_parameter_unit() {
     	  String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
     	  String ParameterUnit = EquipmentStructureCSVReader.getDesignParameterUnit();
 		equipmentStructurePage.deleteParameterUnit(editParameter,ParameterUnit);
       }
       
       /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/
       @And("^verify faults parameter unit deleted$")
       public void verify_faults_parameter_unit_deleted() {
     	  String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
     	  String ParameterUnit = EquipmentStructureCSVReader.getDesignParameterUnit();
     	  equipmentStructurePage.verifyParameterUnitDeleted(editParameter,ParameterUnit);
     	  
       }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @And("^I Add Faults Parameter$")
         public void i_add_faults_parameter()  {
        	 String tabName = CSVHelper.getFaultsTab();
 	     	String name = EquipmentStructureCSVReader.getDesignParameterName();
 	     	String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
 	     	equipmentStructurePage.addDesignParameter(tabName,name,editParameter);
         }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @Then("^I Verify Faults Parameter added$")
         public void i_verify_faults_parameter_added()  {
        	 String Parametername = EquipmentStructureCSVReader.getDesignParameterName();
             equipmentStructurePage.verifyDesignParameterAdded(Parametername);

         }

         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @And("^I Edit Faults Parameter$")
         public void i_edit_faults_parameter()  {
        	
 	      	String addedParameter = EquipmentStructureCSVReader.getDesignParameterName();
 	      	String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
 	      	equipmentStructurePage.editDesignParameter(addedParameter,editParameter);

         }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @Then("^I Verify Faults Parameter Edited$")
         public void i_verify_faults_parameter_edited()  {
        	 String EditedParametername = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
	           equipmentStructurePage.verifyDesignParameterEdited(EditedParametername);

         }

         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @And("^I Disable or Enable Faults Parameter$")
         public void i_disable_or_enable_faults_parameter()  {
        	 String editparameter  = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
	    	   equipmentStructurePage.disableOREnableParameter(editparameter);
         }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @Then("^I Verify Faults Parameter Enabled$")
         public void i_verify_faults_parameter_enabled()  {
        	 String parameter  = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
         	assertTrue("Parameter not Enabled",equipmentStructurePage.verifyEnabledParameter(parameter));
         }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @Then("^I Verify Faults Parameter disabled$")
         public void i_verify_faults_parameter_disabled()  {
        	 String parameter  = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
         	assertTrue("parameter not disabled",equipmentStructurePage.verifyDisabledParameter(parameter));
         }

         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @And("^I Delete Faults Parameter$")
         public void i_delete_faults_parameter()  {
        	 String Parametername = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
 			equipmentStructurePage.deleteParameter(Parametername);

         }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @Then("^I Verify Faults Parameter deleted$")
         public void i_verify_faults_parameter_deleted()  {
        	 String Parametername = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
     		equipmentStructurePage.verifyDesignParameterDeleted(Parametername );
         }
         
         /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/

       @And("^I add function states parameter unit$")
       public void i_add_function_states_parameter_unit()  {
     	  String tabname = CSVHelper.getFunctionStatesTab();
     	  String ParameterName = EquipmentStructureCSVReader.getDesignParameterUnit();
     	  equipmentStructurePage.addParametrUnit(tabname,ParameterName);
       }
       
       /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/
       
       @Then("^I verify function states parameter unit added$")
       public void i_verify_function_states_parameter_unit_added()  {
         String ParameterUnit = EquipmentStructureCSVReader.getDesignParameterUnit();
          assertTrue("Parameter Not added successfully",equipmentStructurePage.verifyParameterUnitAdded(ParameterUnit));
       }
       
       /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/
       @And("^I edit function states parameter unit$")
       public void i_edit_function_states_parameter_unit()  {
     	  String ParameterName = EquipmentStructureCSVReader.getDesignParameterUnit();
     	   String editParameter =EquipmentStructureCSVReader.getUpdatedDesignParameterUnit() ;
 		equipmentStructurePage.editParametrUnit(ParameterName,editParameter );
       }
       
       /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/
       @Then("^I verify function states parameter unit edited$")
       public void i_verify_function_states_parameter_unit_edited()  {
           String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
           assertTrue("Parameter Not Edited successfully", equipmentStructurePage.verifyParameterUnitEdited(editParameter));
       }
       
       /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/
       @And("^I disable function states parameter unit$")
       public void i_disable_function_states_parameter_unit()  {
         String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
 		equipmentStructurePage.disableParameterUnit(editParameter);
       }

       /********************************************************************
     		* Description: 
     		* Status: Completed
     		********************************************************************/
       @Then("^I verify function states parameter unit disabled$")
       public void i_verify_function_states_parameter_unit_disabled()  {
         String editParameter =EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
 		assertTrue("Parameter Unit not disabled",equipmentStructurePage.verifyParameterUnitDisabled(editParameter));
       }
       /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/
       @And("^I enable function states paramer unit$")
       public void i_enable_function_states_paramer_unit()  {
         String editParameter =EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
 		equipmentStructurePage.enableParameterUnit(editParameter);
       }

       /********************************************************************
     		* Description: 
     		* Status: Completed
     		********************************************************************/
       @Then("^I verify function states parameter unit enabled$")
       public void i_verify_function_states_parameter_unit_enabled()  {
     	  String editParameter =EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
   		assertTrue("Parameter Unit not Enabled",equipmentStructurePage.verifyParameterUnitEnabled(editParameter));
       }
       
       /********************************************************************
		* Description: 
		* Status: Completed
		********************************************************************/
      @And("^I click on Add new button then menu icon to delete function states Parameters on Configuration$")
      public void i_click_on_add_new_button_then_menu_icon_to_delete_function_states_parameters_on_configuration()  {
   	   String tabname = CSVHelper.getFunctionStatesTab();
   	   equipmentStructurePage.ClickOnAddNewAndMenuButton(tabname);
      }
       /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/
       @And("^I delete function states Parameter unit$")
       public void i_delete_function_states_parameter_unit() {
     	  String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
     	  String ParameterUnit = EquipmentStructureCSVReader.getDesignParameterUnit();
 		equipmentStructurePage.deleteParameterUnit(editParameter,ParameterUnit);
       }
       
       /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/
       @And("^verify function states parameter unit deleted$")
       public void verify_function_states_parameter_unit_deleted() {
     	  String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
     	  String ParameterUnit = EquipmentStructureCSVReader.getDesignParameterUnit();
     	  equipmentStructurePage.verifyParameterUnitDeleted(editParameter,ParameterUnit);
     	  
       }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @And("^I Add Function States Parameter$")
         public void i_add_function_states_parameter()  {
        	 String tabName = CSVHelper.getFunctionStatesTab();
 	     	String name = EquipmentStructureCSVReader.getDesignParameterName();
 	     	String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
 	     	equipmentStructurePage.addDesignParameter(tabName,name,editParameter);
         }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @Then("^I Verify Function States Parameter added$")
         public void i_verify_function_states_parameter_added()  {
        	 String Parametername = EquipmentStructureCSVReader.getDesignParameterName();
             equipmentStructurePage.verifyDesignParameterAdded(Parametername);

         }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @And("^I Edit Function States Parameter$")
         public void i_edit_function_states_parameter()  {
 	      	String addedParameter = EquipmentStructureCSVReader.getDesignParameterName();
 	      	String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
 	      	equipmentStructurePage.editDesignParameter(addedParameter,editParameter);

         }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @Then("^I Verify Function States Parameter Edited$")
         public void i_verify_function_states_parameter_edited()  {
        	 String EditedParametername = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
	           equipmentStructurePage.verifyDesignParameterEdited(EditedParametername);
         }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @And("^I Disable or Enable Function States Parameter$")
         public void i_disable_or_enable_function_states_parameter()  {
        	 String editparameter  = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
	    	   equipmentStructurePage.disableOREnableParameter(editparameter);
         }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @Then("^I Verify Function States Parameter Enabled$")
         public void i_verify_function_states_parameter_enabled()  {
        	 String parameter  = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
         	assertTrue("Parameter not Enabled",equipmentStructurePage.verifyEnabledParameter(parameter));
         }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @And("^I Delete Function States Parameter$")
         public void i_delete_function_states_parameter()  {
        	 String Parametername = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
 			equipmentStructurePage.deleteParameter(Parametername);
         }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @Then("^I Verify Function States Parameter disabled$")
         public void i_verify_function_states_parameter_disabled()  {
        	 String parameter  = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
         	assertTrue("parameter not disabled",equipmentStructurePage.verifyDisabledParameter(parameter));
         }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @Then("^I Verify Function States Parameter deleted$")
         public void i_verify_function_states_parameter_deleted()  {
        	 String Parametername = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
      		equipmentStructurePage.verifyDesignParameterDeleted(Parametername );
         }

         /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/

       @And("^I add calibration parameter unit$")
       public void i_add_calibration_parameter_unit()  {
     	  String tabname = CSVHelper.getCalibrationTab();
     	  String ParameterName = EquipmentStructureCSVReader.getDesignParameterUnit();
     	  equipmentStructurePage.addParametrUnit(tabname,ParameterName);
       }
       
       /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/
       
       @Then("^I verify calibration parameter unit added$")
       public void i_verify_calibration_parameter_unit_added()  {
         String ParameterUnit = EquipmentStructureCSVReader.getDesignParameterUnit();
          assertTrue("Parameter Not added successfully",equipmentStructurePage.verifyParameterUnitAdded(ParameterUnit));
       }
       
       /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/
       @And("^I edit calibration parameter unit$")
       public void i_edit_calibration_parameter_unit()  {
     	  String ParameterName = EquipmentStructureCSVReader.getDesignParameterUnit();
     	   String editParameter =EquipmentStructureCSVReader.getUpdatedDesignParameterUnit() ;
 		equipmentStructurePage.editParametrUnit(ParameterName,editParameter );
       }
       
       /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/
       @Then("^I verify calibration parameter unit edited$")
       public void i_verify_calibration_parameter_unit_edited()  {
           String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
           assertTrue("Parameter Not Edited successfully", equipmentStructurePage.verifyParameterUnitEdited(editParameter));
       }
       
       /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/
       @And("^I disable calibration parameter unit$")
       public void i_disable_calibration_parameter_unit()  {
         String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
 		equipmentStructurePage.disableParameterUnit(editParameter);
       }

       /********************************************************************
     		* Description: 
     		* Status: Completed
     		********************************************************************/
       @Then("^I verify calibration parameter unit disabled$")
       public void i_verify_calibration_parameter_unit_disabled()  {
         String editParameter =EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
 		assertTrue("Parameter Unit not disabled",equipmentStructurePage.verifyParameterUnitDisabled(editParameter));
       }
       /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/
       @And("^I enable calibration paramer unit$")
       public void i_enable_calibration_paramer_unit()  {
         String editParameter =EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
 		equipmentStructurePage.enableParameterUnit(editParameter);
       }

       /********************************************************************
     		* Description: 
     		* Status: Completed
     		********************************************************************/
       @Then("^I verify calibration parameter unit enabled$")
       public void i_verify_calibration_parameter_unit_enabled()  {
     	  String editParameter =EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
   		assertTrue("Parameter Unit not Enabled",equipmentStructurePage.verifyParameterUnitEnabled(editParameter));
       }
       
       /********************************************************************
		* Description: 
		* Status: Completed
		********************************************************************/
      @And("^I click on Add new button then menu icon to delete Calibration Parameters on Configuration$")
      public void i_click_on_add_new_button_then_menu_icon_to_delete_calibration_parameters_on_configuration()  {
   	   String tabname = CSVHelper.getCalibrationTab();
   	   equipmentStructurePage.ClickOnAddNewAndMenuButton(tabname);
      }
      
       /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/
       @And("^I delete calibration Parameter unit$")
       public void i_delete_calibration_parameter_unit() {
     	  String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
     	  String ParameterUnit = EquipmentStructureCSVReader.getDesignParameterUnit();
 		equipmentStructurePage.deleteParameterUnit(editParameter,ParameterUnit);
       }
       
       /********************************************************************
 		* Description: 
 		* Status: Completed
 		********************************************************************/
       @And("^verify calibration parameter unit deleted$")
       public void verify_calibration_parameter_unit_deleted() {
     	  String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterUnit();
     	  String ParameterUnit = EquipmentStructureCSVReader.getDesignParameterUnit();
     	  equipmentStructurePage.verifyParameterUnitDeleted(editParameter,ParameterUnit);
     	  
       }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @And("^I Add Calibration Parameter$")
         public void i_add_calibration_parameter()  {
        	 String tabName = CSVHelper.getCalibrationTab();
 	     	String name = EquipmentStructureCSVReader.getDesignParameterName();
 	     	String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
 	     	equipmentStructurePage.addDesignParameter(tabName,name,editParameter);
             
         }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @Then("^I Verify Calibration Parameter added$")
         public void i_verify_calibration_parameter_added()  {
        	 String Parametername = EquipmentStructureCSVReader.getDesignParameterName();
             equipmentStructurePage.verifyDesignParameterAdded(Parametername);  
         }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @And("^I Edit Calibration Parameter$")
         public void i_edit_calibration_parameter()  {
 	      	String addedParameter = EquipmentStructureCSVReader.getDesignParameterName();
 	      	String editParameter = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
 	      	equipmentStructurePage.editDesignParameter(addedParameter,editParameter);
         }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @Then("^I Verify Calibration Parameter Edited$")
         public void i_verify_calibration_parameter_edited()  {
        	 String EditedParametername = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
	           equipmentStructurePage.verifyDesignParameterEdited(EditedParametername);


         }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @And("^I Disable or Enable Calibration Parameter$")
         public void i_disable_or_enable_calibration_parameter()  {
        	 String editparameter  = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
	    	   equipmentStructurePage.disableOREnableParameter(editparameter);
         }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @Then("^I Verify Calibration Parameter Enabled$")
         public void i_verify_calibration_parameter_enabled()  {
        	 String parameter  = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
         	assertTrue("Parameter not Enabled",equipmentStructurePage.verifyEnabledParameter(parameter));
         }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @Then("^I Verify Calibration Parameter disabled$")
         public void i_verify_calibration_parameter_disabled()  {
        	 String parameter  = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
         	assertTrue("parameter not disabled",equipmentStructurePage.verifyDisabledParameter(parameter));
         }
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @And("^I Delete Calibration Parameter$")
         public void i_delete_calibration_parameter()  {
        	 String Parametername = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
 			equipmentStructurePage.deleteParameter(Parametername);

         }

         
         /********************************************************************
			* Description: 
			* Status: Completed
			********************************************************************/
         @Then("^I Verify Calibration Parameter deleted$")
         public void i_verify_calibration_parameter_deleted()  {
        	 String Parametername = EquipmentStructureCSVReader.getUpdatedDesignParameterName();
     		equipmentStructurePage.verifyDesignParameterDeleted(Parametername ); 
         }
 }